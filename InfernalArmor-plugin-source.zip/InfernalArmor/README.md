# InfernalArmor (Paper 26.3 / Java 25)

## Compilar
    mvn package        # -> target/InfernalArmor.jar  (copiar a /plugins)

## Resource pack (armadura infernal roja y armadura celestial rosa)
Sube `InfernalArmor-ResourcePack.zip` a un hosting con enlace directo y en `server.properties`:

    resource-pack=<URL>
    resource-pack-sha1=50f443a44c8fc18a6ca59c4591e53480200f59b4
    resource-pack-prompt=Armadura Infernal

La armadura infernal tiene texturas propias (rojo oscuro con vetas de lava, mismo modelo y tamaño que la netherite): `equipment/infernal.json`,
`textures/entity/equipment/humanoid/infernal.png`, `humanoid_leggings/infernal.png` y los iconos `textures/item/infernal_helmet|chestplate|leggings|boots.png`
(más sus modelos con los 11 diseños de trim en `items/helmet.json`, `chestplate.json`, `leggings.json` y `boots.json`). Se generan con `tools/make_infernal_armor.py`
(ver "Aspecto de la armadura infernal" más abajo).
Sin pack: `use-resource-pack: false` en config.yml (se ve como netherite normal).

La armadura celestial es también netherite vanilla teñido, pero en rosa (`16738740` = #FF69B4 en `equipment/celestial.json` y `items/celestial_*.json`).
No lleva texturas propias: para cambiar el tono edita ese número en esos 5 archivos (casco, peto, pantalones, botas y la armadura puesta).
Cada pieza tiene un caso por cada diseño (trim) de armadura vanilla.

## Aspecto de la armadura infernal
Rediseño en el mismo estilo que la del Vacío y la del Fin: la netherite vanilla recoloreada (mismo modelo, mismo tamaño y mismo sombreado), ahora en
rojo oscuro/granate casi negro con vetas de lava rojas y naranjas y alguna chispa de brasa amarilla, con los colores de la Espada Infernal.
El contorno oscuro no lleva detalle. Las texturas salen de `tools/make_infernal_armor.py`, que recolorea la netherite de `tools/vanilla_netherite/`:

    python3 tools/make_infernal_armor.py resourcepack/assets/infernal/textures

Ya no es netherite teñida: el tinte `16728112` se quitó de `equipment/infernal.json` y de `items/*.json`. Si cambias el resource pack, vuelve a comprimir
`resourcepack/` en el zip y actualiza `resource-pack-sha1`.

## Armaduras solo por comando (`armor-lock`, activo por defecto)
Las armaduras **Celestial, del Vacío y del Fin solo se obtienen con `/infernal give`** (permiso `infernalarmor.admin`).
- **Excepción: la Armadura Infernal sí se fabrica** (`armor-lock.allow-infernal: true`, por defecto): se craftean la Estrella del Nether Reforzada
  y el Lingote Infernal, y la mesa de herrería mejora netherite a Infernal. La mejora Infernal -> Vacío sigue bloqueada.
- **La Plantilla Infernal no se craftea** (`infernal-template-crafting: false`, por defecto): **solo sale en los cofres de los bastiones**, siempre en el
  cofre del tesoro y con un 10% en los demás cofres del bastión (`bastion-loot`), como la plantilla de netherite vanilla. Vale para bastiones ya generados
  si sus cofres no se han abierto. Código: `BastionLootListener.java`.
- **El Polvo de Blaze Infernal no se craftea** (`infernal-blaze-powder-crafting: false`, por defecto): solo lo sueltan los Wildfire (1-2 cada uno).
  Hacen falta 2 por Lingote Infernal (8 para la armadura completa).
- **Mesa de herrería:** no se puede mejorar netherite (sin teñir o teñida) a Celestial, ni Infernal a Vacío, ni Celestial a Fin (`block-upgrades`).
- **Mesa de crafteo:** no se craftean los objetos únicos de esas armaduras (`block-ingredient-crafting`): Polvo, Cristal, Lingote y Plantilla Celestial; Aliento Mutado, Cabezas Mutadas, Fruto Fermentado, Huevos Encubados,
  Lingotes y Plantillas del Vacío y del Fin, Obsidiana Teñida y Obsidiana Llorosa Teñida. La Caja de Shulker Reforzada tiene su propia opción (`block-reinforced-shulker`).
  Esas recetas no se registran, así que tampoco aparecen en el libro de recetas.
- **Los objetos siguen existiendo:** se pueden dar con `/infernal give` y los que ya tienen los jugadores no cambian.
- **No se tocan** las espadas y herramientas forjadas ni las recetas del Alma, Codicia y Purificada. Las mejoras de espadas/herramientas que usan el
  Lingote/Plantilla Celestial siguen funcionando, pero esos objetos solo se consiguen por comando (el Lingote Infernal ya se craftea y la Plantilla Infernal sale en los bastiones).
- La consola muestra al arrancar: `Armaduras solo por comando -> mejoras bloqueadas: true, recetas del plugin sin registrar: 29`
  (21 recetas de mesa + 8 mejoras de armadura con los valores por defecto).

## Bloqueo de crafteos
**Desactivado por defecto** (`armor`, `swords` y `tools` en `false`): las armaduras, espadas y herramientas vanilla se craftean con normalidad.
Impide craftear armaduras (cascos, petos, pantalones y botas), espadas y lanzas, y herramientas (picos, hachas, palas y azadas) de **cualquier material**
en la mesa de crafteo, el inventario y el crafter. Se configura en `config.yml`, bloque `block-crafting` (`armor`, `swords`, `tools`; `true` = bloqueado).
- No afecta a la mesa de herrería (mejora a netherite y mejoras infernales, celestiales, del Vacío y del Fin).
- No afecta a reparar combinando dos piezas ni a teñir armadura de cuero (recetas especiales), ni a las recetas propias de este plugin.
- **Además, las recetas se borran del juego al arrancar** (`block-crafting.remove-recipes: true`, por defecto): desaparecen del libro de recetas
  y nadie puede craftearlas de ninguna forma. Solo se borran recetas de crafteo (con forma o sin forma); la mesa de herrería, los hornos, el cortapiedras
  y las recetas especiales (reparar, teñir cuero) no se tocan. Se restauran al apagar el servidor. La consola muestra cuántas se han borrado.
- Permiso para saltarse el bloqueo: `infernalarmor.craft.bypass` (por defecto nadie, ni siquiera los operadores). Con `remove-recipes: true` ya no sirve
  para las piezas vanilla, porque sus recetas no existen.
- Código: `CraftBlockListener.java`, registrado en `InfernalArmorPlugin`.

## Teñir armadura de netherite
En la **mesa de crafteo** (o en el inventario): **una pieza de netherite + un tinte vanilla** -> la misma pieza con el color exacto de ese tinte
(armadura de netherite + tinte azul = azul, + tinte azul claro = azul claro, y así con los 16 tintes). **Los tintes no se mezclan**: solo se admite
un tinte, y volver a teñir una pieza ya teñida le pone el color del tinte nuevo (con el mismo color que ya tiene no hay resultado, para no gastar el tinte).
Conserva encantamientos, diseño (trim), desgaste y nombre. Se elige este método y no el caldero porque el caldero
exigiría interceptar clics y no conserva bien los datos de la pieza; con una receta real el juego consume los ingredientes con normalidad.
- Solo vale la **netherite normal**: no las piezas infernal, celestial, del Vacío ni del Fin (aunque sean de material netherite).
- La pieza teñida **sigue siendo de netherite** (mismo material, atributos y durabilidad): se le pueden poner los diseños de armadura vanilla
  en la mesa de herrería y se puede mejorar como siempre. **Al mejorarla a una armadura forjada se descarta el tinte** (cada una tiene su propio aspecto).
- **El tono decide a qué armadura se puede mejorar** (`smithing-dye-tones` en config.yml):
  - **Armadura Infernal:** netherite sin teñir o teñida en **amarillo, naranja o rojo**.
  - **Armadura Celestial:** netherite sin teñir o teñida en **rosa, magenta o morado**.
  - Cualquier otro tono (azul, verde, negro, blanco, marrón...) no sirve para ninguna de las dos: la mesa de herrería no da resultado.
  - Cuenta el tinte con el que se tiñó la pieza (`DyeTone.java`; si una pieza tuviera un color que no es de tinte, p. ej. dada con /give,
    cuenta el tinte más parecido).
  - `allow-undyed: false` obliga a teñir la pieza del tono correcto; las listas de tonos se pueden cambiar (nombres en inglés: red, orange, pink...).
  - Del Vacío y del Fin no cambian: se siguen haciendo desde la infernal y la celestial.
- No se puede lavar en el caldero. El crafter (bloque) no la fabrica.
- Aunque `block-crafting.armor` bloquee craftear armaduras, esta receta sigue funcionando (es del propio plugin).
- Necesita el resource pack (`use-resource-pack: true`); sin él el plugin lo desactiva y avisa en la consola. Se puede apagar con `dye-netherite-armor: false`.
- Cómo se ve: textura de netherite aclarada en gris (la netherite vanilla es casi negra y el tinte, que multiplica, daría siempre colores muy oscuros) que el juego multiplica
  por el color. Se genera con `tools/make_dyeable_netherite.py` (iconos `textures/item/dyed_netherite_*.png`, armadura puesta `entity/equipment/*/netherite_dyed.png`,
  capa teñible `equipment/netherite_dyed.json`, y modelos/items con los 11 diseños de trim `dyed_netherite_*`):

      python3 tools/make_dyeable_netherite.py resourcepack/assets/infernal

- Código: `DyeNetheriteListener.java` (receta y resultado), `DyeTone.java` (qué tinte tiene la pieza),
  `InfernalItems#dyeNetherite` y la comprobación del tono en `SmithingListener` (`InfernalItems#fitsInfernalTone` / `fitsCelestialTone`).

## Efecto del set infernal
Con las 4 piezas de la Armadura Infernal puestas: **-15% de daño de fuego y lava** (estar en el fuego o en una fogata, estar prendido, la lava y los bloques de magma; `infernal-armor-fire-reduction`). No da Resistencia ni Resistencia al fuego. Además, -20% de daño de los mobs del Nether.
Las piezas que ya existen cambian su descripción con `/infernal update`; el efecto cambia solo, sin hacer nada.

## Recetas
- (Polvo de Blaze Infernal y Estrella del Nether Reforzada tienen textura propia infernal en el resource pack: contorno granate oscuro y lava por dentro.)
- Polvo de Blaze Infernal: no se craftea (lo sueltan los Wildfire). Con `infernal-blaze-powder-crafting: true` vuelve su receta: varas de blaze (esquinas), verruga del Nether (bordes), polvo de blaze (centro)
- Estrella del Nether Reforzada: lágrimas de ghast (esquinas), polvo de blaze (arriba/abajo), cráneos de Wither (lados), estrella del Nether (centro)
- Lingote Infernal: estrellas reforzadas (esquinas), lágrimas de ghast (arriba/abajo), polvos infernales (lados), lingote de netherite (centro)
- Plantilla de mejora (Plantilla Infernal): no se craftea, sale en los cofres de los bastiones. Con `infernal-template-crafting: true` vuelve su receta: restos antiguos (esquinas), plantilla de netherite (arriba), ladrillos del Nether (2 lados + abajo), fragmento de netherite (centro)
- Mesa de herrería: plantilla infernal + pieza de netherite + Lingote Infernal (la netherite sin teñir o teñida en amarillo, naranja o rojo; ver "Teñir armadura de netherite")

## Armadura Celestial (mismas estadísticas que la Armadura Infernal; su set da Resistencia)
Se ve como la armadura de netherite teñida de rosa. Nombres: Casco Celestial,
Peto Celestial, Pantalones Celestiales y Botas Celestiales.
- Mesa de herrería: **plantilla celestial + pieza de netherite + Lingote Celestial** -> pieza celestial
  (los mismos Lingote y Plantilla Celestial que usa la Espada Celestial; sus recetas de crafteo no cambian).
  Conserva encantamientos, diseño (trim), desgaste y nombre. Debe ser una pieza de netherite normal: no sirve una pieza infernal ni una celestial.
  La netherite tiene que estar sin teñir o teñida en rosa, magenta o morado (ver "Teñir armadura de netherite").
- Estadísticas iguales a la infernal: armadura +`armor-bonus` sobre la netherite (casco 7, peto 12, pantalones 10, botas 7 con el valor por defecto),
  dureza 3 por pieza, resistencia al empuje 0.1 por pieza y durabilidad = netherite x `durability-multiplier` + `durability-bonus`.
- Set completo (las 4 piezas celestiales): Resistencia (`resistance-level`, I por defecto). (El set infernal reduce un 15% el daño de fuego y lava en su lugar.)
  No vale mezclar piezas infernales y celestiales: el efecto solo se activa con un set completo del mismo tipo.

## Armadura del Vacío y Armadura del Fin
Dos armaduras nuevas de netherite (casco, peto, pantalones y botas). **Se obtienen mejorando en la mesa de herrería la Armadura Infernal (Vacío) o la Celestial (Fin)**, con su plantilla y su lingote (ver "Mejora en la mesa de herrería" más abajo); los ingredientes, el lingote y la plantilla se craftean (secciones siguientes). También se pueden obtener con
`/infernal give <jugador> void_helmet|void_chestplate|void_leggings|void_boots|end_helmet|end_chestplate|end_leggings|end_boots`.
- **Armadura del Vacío** (viene de la Infernal): nombres "Casco del Vacío", "Peto del Vacío", "Pantalones del Vacío" y "Botas del Vacío". Aspecto: negro obsidiana con vetas y destellos morados del End.
- **Armadura del Fin** (viene de la Celestial): nombres "Casco del Fin", "Peto del Fin", "Pantalones del Fin" y "Botas del Fin". Aspecto: tonos y detalles de los bloques de purpur del End.
- Estadísticas: dureza y empuje como la infernal y la celestial. **+5 puntos de armadura por pieza** sobre ellas (`void-end-armor-extra-armor`):
  casco 12, peto 17, pantalones 15, botas 12 con los valores por defecto. **El doble de durabilidad** que la infernal y la celestial
  (`void-end-armor-durability-multiplier`, 2.0): casco 3481 -> 6962, peto 3851 -> 7702, pantalones 3777 -> 7554, botas 3629 -> 7258.
- **Set completo** (las cuatro piezas del mismo set; no vale mezclar): **Resistencia II** y **Regeneración II** (`void-end-resistance-level`, `void-end-regeneration-level`).
- **Protección (set completo, se suma a la armadura y a los efectos; las reducciones se multiplican):**
  - Vacío: -20% de daño de los mobs del Nether (conserva el de la Infernal, `void-armor-nether-reduction`).
  - Fin: -10% de daño de los mobs hostiles que no son del Nether (conserva el de la Celestial, `end-armor-hostile-reduction`).
  - Vacío y Fin: **-25% de daño de los mobs del End** (enderman, endermite, shulker, ender dragon y phantom; `void-end-armor-end-mobs-reduction`).
    Cuenta el golpe directo, el proyectil del shulker, la bola de fuego y el aliento del dragón.
  - Vacío y Fin: **-20% de daño de explosiones** (creeper, TNT, cristal del End, cama, ancla de reaparición, bolas de fuego...; `void-end-armor-explosion-reduction`).
- La descripción de cada pieza muestra los efectos y porcentajes; `/infernal update` los actualiza en las piezas que ya existen.
- Resource pack: `equipment/void.json` y `equipment/end.json` (texturas propias de armadura puesta), `items/void_*.json` y `items/end_*.json` con modelos para los 11 diseños (trim) de armadura.
  Las texturas se generan con `tools/make_void_end_armor.py` (recolorea la netherite vanilla de `tools/vanilla_netherite/`).
  Si cambias el resource pack, vuelve a comprimir `resourcepack/` en el zip y actualiza `resource-pack-sha1`.
- Los valores nuevos del `config.yml` se añaden solos con su valor por defecto aunque ya tengas un config guardado (puedes copiarlos del config.yml del jar para editarlos).

### Mejora en la mesa de herrería
- **Armadura del Vacío**: Plantilla de mejora: Armadura del Vacío + pieza de **Armadura Infernal** + **Lingote del Vacío** -> la misma pieza del Vacío.
- **Armadura del Fin**: Plantilla de mejora: Armadura del Fin + pieza de **Armadura Celestial** + **Lingote del Fin** -> la misma pieza del Fin.
- Se conservan encantamientos, diseño (trim), daño y nombre personalizado. Las líneas "Set completo:" se sustituyen por las del nuevo set.
- No se puede saltar de fase: la del Vacío exige la infernal y la del Fin exige la celestial (ni netherite ni la otra rama).

## Ingredientes de las armaduras del Vacío y del Fin (recetas de crafteo)
Cadena: Aliento Mutado -> Cabeza Mutada -> Fruto Fermentado -> Huevo Encubado -> Lingote. Todos llevan brillo de encantamiento.
La Cabeza y el Huevo se llaman igual en las dos versiones; la **descripción** dice para qué armadura sirven ("Para la Armadura del Vacío." / "Para la Armadura del Fin.").
Las versiones no se mezclan: la del Vacío usa el Lingote Infernal y sus derivados, la del Fin usa el Lingote Celestial y los suyos.
- Aliento del Dragón Mutado (sirve para las dos): frutos de chorus (esquinas), flores de chorus (arriba/abajo/lados), aliento de dragón vanilla (centro)
- Cabeza del Dragón Mutada, versión Vacío: Alientos Mutados (esquinas), Polvos de Blaze Infernales (arriba/abajo/lados), cabeza de dragón vanilla (centro)
- Cabeza del Dragón Mutada, versión Fin: Alientos Mutados (esquinas), Polvos Celestiales (arriba/abajo/lados), cabeza de dragón vanilla (centro)
- Fruto del Coral Fermentado (sirve para las dos; es el objeto de las esquinas de los dos lingotes): flores de chorus (fila de arriba y de abajo), frutos de chorus (lados), fruto de chorus reventado vanilla (centro).
  Es un fruto de chorus reventado de base, así que no se puede comer. En el centro no vale un Fruto Fermentado, tiene que ser un fruto reventado normal.
- Huevo del Dragón Encubado, versión Vacío: cristales del End vanilla (esquinas), Estrellas del Nether Reforzadas (arriba/abajo/lados), huevo de dragón vanilla (centro)
- Huevo del Dragón Encubado, versión Fin: cristales del End vanilla (esquinas), Cristales Celestiales (arriba/abajo/lados), huevo de dragón vanilla (centro)
- **Lingote del Vacío**: Frutos del Coral Fermentados (esquinas), Cabezas Mutadas del Vacío (arriba/abajo), Huevos Encubados del Vacío (lados), **Lingote Infernal** (centro)
- **Lingote del Fin**: Frutos del Coral Fermentados (esquinas), Cabezas Mutadas del Fin (arriba/abajo), Huevos Encubados del Fin (lados), **Lingote Celestial** (centro)
- Los objetos vanilla que tienen versión propia (aliento, cabeza, huevo, cristal del End y fruto de chorus reventado) deben ser los normales: no sirve el Aliento Mutado, la Cabeza Mutada, el Huevo Encubado, el Cristal Celestial ni el Fruto Fermentado en su lugar.
- La Cabeza y el Huevo mutados no se pueden colocar como bloque (se perdería el objeto). Ningún ingrediente se puede usar en recetas vanilla ni en el soporte de pociones.
- Resource pack: Lingote del Vacío (obsidiana negra con vetas moradas) y Lingote del Fin (tonos purpur), con los mismos colores que su armadura. Se generan con `tools/make_void_end_ingots.py`
  a partir de la silueta `tools/ingot_shape.png`. Los demás ingredientes usan el aspecto del objeto vanilla en el que se basan.

## Plantillas del Vacío y del Fin (y sus ingredientes)
Cada plantilla se hace con la plantilla de su armadura de origen (Vacío <- Infernal, Fin <- Celestial), tres Cajas de Shulker Reforzadas y obsidiana teñida.
Los objetos nuevos no se pueden colocar como bloque ni usar en recetas vanilla (la Caja de Shulker Reforzada es la excepción: se coloca y se tiñe como una caja normal).
- **Caja de Shulker Reforzada** (morada; **doble de espacio**: 54 ranuras): cáscaras de shulker (todo el borde), caja de shulker normal sin teñir (centro).
  - **Es funcional**: click derecho con ella en la mano **apuntando al aire** la abre. Se guarda dentro del propio objeto, así que el contenido viaja con ella.
  - **Se coloca y se rompe como una caja de shulker normal** (del color que tenga). El bloque es una caja de shulker de verdad, con su tapa que se abre y se cierra,
    pero su contenido (54 ranuras) se guarda en los datos del bloque. Click derecho en el bloque abre el inventario (lo comparten todos los que la tengan abierta);
    al romperla suelta la caja reforzada con todo dentro (en creativo, solo si tiene objetos, como en vanilla). Mantiene el nombre si se le puso uno.
    - Al pasar el cursor por la caja (en el inventario o al recogerla) la descripción enseña los **5 primeros objetos** que tiene dentro (`Nombre x3`) y "y N más..." si hay más, como el tooltip de la caja de shulker vanilla. Se actualiza al cerrar la caja, al romperla colocada y al craftearla con una caja de shulker con objetos; vacía, vuelve a ser idéntica a una nueva.
    - Tolvas, cuentagotas y dispensadores no pueden meter ni sacar objetos de ella (irían a un inventario que nadie ve) y un dispensador no la coloca.
    - Los pistones no la mueven (los vanilla destruyen las cajas de shulker y se perdería el contenido). Endermen, wither, etc. no pueden romperla.
    - Las explosiones la sueltan con su contenido.
  - Mientras hay una abierta no se pueden mover ni tirar cajas reforzadas, y no se pueden meter cajas de shulker dentro (como en vanilla).
  - Si la receta se hace con una caja de shulker normal que tiene objetos, estos pasan a la caja reforzada. Si cierras la caja y queda vacía, vuelve a ser idéntica a una nueva.
  - **Se puede teñir como una caja de shulker normal**: caja reforzada + un tinte en la cuadrícula de crafteo (conserva contenido y nombre). Los colores son solo estéticos: todas son la misma caja y cualquier color vale (vacía) en las recetas de las plantillas del Vacío y del Fin.
  - Para las recetas de las plantillas solo valen cajas **vacías**: una con objetos no coincide con la receta, así que no se gasta por error.
- **Obsidiana Teñida** (Vacío): ladrillos de piedra del End (esquinas), losas de ladrillo de piedra del End (arriba/abajo), escaleras de ladrillo de piedra del End (lados), obsidiana (centro)
- **Obsidiana Llorosa Teñida** (Fin): bloques de purpur (esquinas), losas de purpur (arriba/abajo), pilares de purpur (lados), obsidiana llorosa (centro)
- **Plantilla de mejora: Armadura del Vacío**: Obsidiana Teñida (arriba-lados y fila del medio), **Plantilla Infernal** (arriba-centro), Cajas de Shulker Reforzadas (fila de abajo)
- **Plantilla de mejora: Armadura del Fin**: Obsidiana Llorosa Teñida (arriba-lados y fila del medio), **Plantilla Celestial** (arriba-centro), Cajas de Shulker Reforzadas (fila de abajo)
- En las recetas de obsidiana teñida, la obsidiana / obsidiana llorosa del centro debe ser la normal. La plantilla infernal / celestial es la de siempre (la forjada con este plugin).
- Resource pack: texturas propias de las dos plantillas (colores de su armadura) y de las dos obsidianas teñidas (modelo de bloque). La caja reforzada usa el aspecto de la caja de shulker morada.
  Se generan con `tools/make_void_end_templates.py` (silueta `tools/template_shape.png`).

## Protección de las armaduras (set completo)
- **Armadura Infernal:** -20% de daño recibido de los mobs del Nether (blaze, piglin, piglin brute, zombified piglin, ghast,
  wither skeleton, wither, magma cube, hoglin y zoglin), los mismos a los que la Espada Infernal hace más daño.
  Config: `infernal-armor-nether-reduction` (0.20).
- **Armadura Celestial:** -10% de daño recibido de los mobs hostiles de la Espada Celestial (hostiles excepto los del Nether).
  Config: `celestial-armor-hostile-reduction` (0.10).
- Cuenta el golpe directo y también flechas y bolas de fuego lanzadas por el mob. Hace falta el set completo del mismo tipo
  (como el efecto de Resistencia). Se suma a la armadura y a la Resistencia. La descripción de cada pieza muestra el porcentaje;
  `/infernal update` lo añade a las piezas que ya existen.

## Aspecto de la armadura celestial
Netherite vanilla + tinte rosa (ver "Resource pack" arriba); no hay texturas dibujadas a mano.
`tools/draw_celestial.py` es de la versión anterior (texturas propias) y ya no se usa.
Si cambias el resource pack, vuelve a comprimir `resourcepack/` en el zip y actualiza `resource-pack-sha1`.

## Espada del Alma (+1 de daño sobre la espada de netherite)
Se ve como la de netherite pero en blanco con tonos azules (texturas propias de espada, lingote y plantilla en el resource pack).
- Lingote del Alma: dried ghast (esquinas), lágrimas de ghast (arriba/abajo/lados), lingote de netherite (centro)
- Plantilla del Alma: lágrimas de ghast (todas menos arriba-centro y centro), plantilla de mejora de netherite (arriba-centro), dried ghast (centro)
- Mesa de herrería: plantilla del alma + espada de netherite + Lingote del Alma -> Espada del Alma
  (conserva encantamientos, daño y nombre). El daño extra se cambia con `soul-sword-damage-bonus` en config.yml.

## Herramientas del Alma (hacha, pico, pala, azada y lanza)
Mismo aspecto que la Espada del Alma (blanco con tonos azules) sobre los modelos de netherite vanilla; textura propia de cada herramienta
en el resource pack (la lanza tiene además su textura de 32x32 para cuando la llevas en la mano).
Nombres: Hacha del Alma, Pico del Alma, Pala del Alma, Azada del Alma y Lanza del Alma. Descripción: "Forjada con el alma de ghast muertos".
- Mesa de herrería: **plantilla del alma + herramienta de netherite + Lingote del Alma** -> herramienta del Alma
  (mismos Lingote y Plantilla del Alma que la espada; sus recetas de crafteo no cambian). Conserva encantamientos, desgaste y nombre.
  Debe ser una herramienta de netherite normal.
- Hacha, pico, pala y azada: +1 de daño (`soul-tool-damage-bonus`) y +1 de velocidad de minería (`soul-tool-mining-speed-bonus`) sobre netherite.
  La velocidad de minería es el atributo de eficiencia de minería: se suma a la del bloque (9 -> 10) y al encantamiento Eficiencia, y solo cuenta
  en los bloques que esa herramienta mina bien (igual que Eficiencia).
- Lanza: +1 de daño (`soul-spear-damage-bonus`), sin bono de minería.
- El resto de estadísticas (velocidad de ataque, durabilidad, reparación...) son las de netherite.
- `/infernal update` pone a las que ya existen el daño y la velocidad de minería actuales del config.

## Herramientas corrompidas y purificadas (hacha, pico, pala, azada y lanza)
Mismas estadísticas que las herramientas del Alma (+1 de daño; +1 de velocidad de minería salvo la lanza), con el mismo aspecto que la
Espada del Alma Corrompida (granates oscuros con cabeza cian) y que la Espada Purificada (blanco con tonos azules más claros).
Usan los mismos `soul-tool-damage-bonus`, `soul-tool-mining-speed-bonus` y `soul-spear-damage-bonus` de config.yml.
Nombres: "Hacha del Alma Corrompida", "Pico del Alma Corrompido", "Pala del Alma Corrompida", "Azada del Alma Corrompida", "Lanza del Alma Corrompida"
y "Hacha Purificada", "Pico Purificado", "Pala Purificada", "Azada Purificada", "Lanza Purificada".
- Mesa de herrería (corrompida): **plantilla de codicia + herramienta del Alma + Lingote de Codicia** -> la misma herramienta corrompida
  (mismos Lingote y Plantilla de Codicia que la espada). Debe ser la herramienta del Alma del mismo tipo, no sirve una de netherite normal.
- Mesa de herrería (purificada): **plantilla purificada + herramienta del Alma + Lingote Purificado** -> la misma herramienta purificada
  (mismos Lingote y Plantilla Purificada que la espada). Debe ser la herramienta del Alma del mismo tipo.
- Conservan encantamientos, desgaste y nombre. `/infernal update` les pone el daño y la velocidad de minería actuales del config.

## Espada del Alma Corrompida (mismo daño que la Espada del Alma)
Se ve como la Espada del Alma pero con los colores del molde de armadura Rib (granates oscuros con vetas cian).
Descripción: "Espada corrompida por la codicia". Texturas propias de espada, lingote y plantilla en el resource pack.
- Lingote de Codicia ("Lingote fabricado por la codicia"): pepitas de oro (esquinas), moldes Rib (arriba/abajo/lados), lingote de oro (centro)
- Plantilla de Codicia: lingotes de oro (todos menos arriba-centro y centro), plantilla de mejora de netherite (arriba-centro), molde Rib (centro)
- Mesa de herrería: plantilla de codicia + Espada del Alma + Lingote de Codicia -> Espada del Alma Corrompida
  (conserva encantamientos, daño y nombre). Usa el mismo `soul-sword-damage-bonus` de config.yml.

## Espada Infernal (+4 de daño sobre la Espada del Alma Corrompida)
Mejora de la Espada del Alma Corrompida con el **Lingote Infernal** y la **Plantilla de mejora: Armadura Infernal** que ya existen
(sin recetas nuevas de crafteo). Tiene la forma de la espada de netherite vanilla y el mismo estilo que la Armadura Infernal: contorno y mango granate casi negro y hoja con
vetas de lava y alguna chispa de brasa. Textura propia en el resource pack (se genera con `tools/make_infernal_tools.py`).
- Mesa de herrería: plantilla infernal + Espada del Alma Corrompida + Lingote Infernal -> Espada Infernal
  (conserva encantamientos, daño y nombre). Debe ser la Espada del Alma Corrompida, no sirve una de netherite normal.
- Daño: +4 sobre la Espada del Alma Corrompida (netherite 8 -> Alma/Corrompida 9 -> Infernal 13). Se cambia con
  `infernal-sword-damage-bonus` en config.yml.
- Velocidad de ataque: 2.0 (la netherite tiene 1.6). Se cambia con `infernal-sword-attack-speed` en config.yml.
- +45% de daño contra los mobs del Nether: blaze, piglin, piglin brute, zombified piglin, ghast, wither skeleton, wither,
  magma cube, hoglin y zoglin. Aplica al golpe directo con la espada en la mano principal (incluido el barrido).
  Se cambia con `infernal-sword-nether-multiplier` en config.yml (1.45 = +45%).

## Espada Purificada (mismo daño que la Espada del Alma)
Se ve casi igual que la Espada del Alma pero con toques más blancos (texturas propias de espada, lingote y plantilla en el resource pack).
Descripción: "Purificada de toda corrupción". Daño: 9 (netherite 8 + `soul-sword-damage-bonus`), velocidad de ataque 1.6.
- Lingote Purificado: cuarzo del Nether (esquinas), moldes de armadura Flow (arriba/abajo/lados), diamante (centro)
- Plantilla Purificada: cuarzo del Nether (todos menos arriba-centro y centro), plantilla de mejora de netherite (arriba-centro), molde Flow (centro)
- Mesa de herrería: plantilla purificada + **Espada del Alma** + Lingote Purificado -> Espada Purificada
  (conserva encantamientos, desgaste y nombre). Debe ser la Espada del Alma, no sirve una de netherite normal ni la Corrompida o Infernal.

## Espada Celestial (mismo daño que la Espada Infernal)
Se ve como la Espada del Alma pero en tonos rosas. Se mejora desde la **Espada Purificada**. Textura propia de espada, polvo, cristal, lingote y plantilla en el resource pack.
- Daño: 13 (igual que la Infernal: netherite + `soul-sword-damage-bonus` + `infernal-sword-damage-bonus`).
- Velocidad de ataque: 2.0 (`celestial-sword-attack-speed` en config.yml).
- +20% de daño contra los mobs hostiles, **excepto los del Nether** (`celestial-sword-hostile-multiplier`, 1.2 = +20%): creeper, zombie,
  husk, drowned, zombie villager, skeleton, stray, bogged, spider, cave spider, silverfish, slime, vex, witch, pillager, evoker, ravager,
  guardian, breeze, creaking, iron golem, vindicator y elder guardian.
  Los mobs del Nether (blaze, piglin, piglin brute, zombified piglin, ghast, wither skeleton, wither, magma cube, hoglin y zoglin) quedan para la Espada Infernal.
  Aplica al golpe directo con la espada en la mano principal (incluido el barrido).
- Polvo Celestial (sin resource pack, p. ej. Bedrock sin mapeo, se ve como una vara de breeze): cargas de viento (esquinas), cuarzo del Nether (arriba/abajo/lados), vara de breeze (centro)
- Cristal Celestial (sin resource pack, p. ej. Bedrock sin mapeo, se ve como un cristal del End; no se puede colocar): lágrimas de ghast (esquinas), Polvo Celestial (arriba/abajo), balizas (lados), cristal del End vanilla (centro)
- Lingote Celestial: Cristales Celestiales (esquinas), fragmentos de amatista (arriba/abajo), Polvo Celestial (lados), lingote de netherite (centro)
- Plantilla Celestial: bloques de diamante (esquinas), plantilla de mejora de netherite (arriba-centro), fragmentos de amatista (lados y abajo-centro), Cristal Celestial (centro)
- Mesa de herrería: plantilla celestial + **Espada Purificada** + Lingote Celestial -> Espada Celestial
  (conserva encantamientos, desgaste y nombre). Debe ser la Espada Purificada.

## Herramientas infernales y celestiales (hacha, pico, pala, azada y lanza)
Última fase de las herramientas, igual que la Espada Infernal y la Celestial lo son de las espadas. Mismas estadísticas las dos; solo cambian el nombre, la descripción y el aspecto
(infernal: cabeza granate con vetas de lava, mismo estilo que la Armadura Infernal y la Espada Infernal, generada con `tools/make_infernal_tools.py`; celestial: rosa, como la Espada Celestial).
Nombres: "Hacha Infernal", "Pico Infernal", "Pala Infernal", "Azada Infernal", "Lanza Infernal" y "Hacha Celestial", "Pico Celestial", "Pala Celestial", "Azada Celestial", "Lanza Celestial".
- Mesa de herrería (infernal): **plantilla infernal + herramienta corrompida + Lingote Infernal** -> la misma herramienta infernal
  (mismos Lingote y Plantilla Infernal que la espada y la armadura). Debe ser la herramienta corrompida del mismo tipo.
- Mesa de herrería (celestial): **plantilla celestial + herramienta purificada + Lingote Celestial** -> la misma herramienta celestial
  (mismos Lingote y Plantilla Celestial que la espada y la armadura). Debe ser la herramienta purificada del mismo tipo.
- Conservan encantamientos, desgaste y nombre.
- Hacha, pico, pala y azada: **+4 de daño** (`infernal-tool-damage-bonus`) y **+3 de velocidad de minería** (`infernal-tool-mining-speed-bonus`)
  sobre la herramienta del Alma, es decir, sobre netherite: +5 de daño y +4 de minería en total (igual que la Espada Infernal suma sus +4 al +1 del Alma).
  Velocidad de ataque 2.0 (`infernal-tool-attack-speed`; el hacha 1.5, `infernal-axe-attack-speed`). Nunca baja de la de netherite (la azada vanilla ya tiene 4.0, se queda en 4.0).
- Lanza: **+4 de daño** (`infernal-spear-damage-bonus`), **+3 de alcance** (`infernal-spear-reach-bonus`) y velocidad de ataque 1.5 (`infernal-spear-attack-speed`).
  El alcance es el atributo de alcance de entidades de la mano principal. Sin bono de minería.
- **Durabilidad: el doble que netherite** (`infernal-tool-durability-multiplier`, 2.0).
- **Bono contra mobs:** las herramientas infernales hacen **+45% de daño a los mobs del Nether** (`infernal-sword-nether-multiplier`, la misma lista que la Espada Infernal)
  y las celestiales **+20% a los hostiles que no son del Nether** (`celestial-sword-hostile-multiplier`, la misma lista que la Espada Celestial).
  Aplica al golpe directo con la herramienta en la mano principal (también el barrido y la lanza). La descripción lo muestra y `/infernal update` actualiza el porcentaje.

## Durabilidad de las espadas Infernal y Celestial
Ahora tienen el doble de durabilidad que la espada de netherite (2031 -> 4062; `infernal-tool-durability-multiplier`).
Las espadas Infernal y Celestial que ya existían se actualizan con `/infernal update`.

## Tridente de Netherite (mejora vanilla del tridente)
Se hace igual que el resto del equipo de netherite vanilla: **mesa de herrería: plantilla de mejora de netherite + tridente + lingote de netherite**
(los tres normales: no valen las plantillas ni los lingotes del plugin aunque sean del mismo material). Conserva encantamientos, desgaste y nombre.
También se da con `/infernal give <jugador> netherite_trident`. Se llama "Tridente de Netherite" y, como un objeto vanilla, no lleva descripción ni brillo extra.
- **Durabilidad: el doble** que el tridente normal (250 -> 500; `netherite-trident.durability-multiplier`).
- **+1 de daño** (`netherite-trident.damage-bonus`): cuerpo a cuerpo 9 -> 10 (atributo del arma), lanzado 8 -> 9 y al chocar con un mob durante la Propulsión 8 -> 9.
- **Propulsión (Riptide): te impulsa el doble** (`netherite-trident.riptide-multiplier`, 2.0 = el doble). La propulsión la calcula el cliente,
  así que el servidor le manda la velocidad final en el tick siguiente (impulso vanilla x 2).
- **Propiedades de la netherite** (se copian de la espada de netherite del propio juego): no arde en el fuego ni en la lava (tirado, flota en la lava),
  se repara en el yunque con lingotes de netherite y tiene la encantabilidad de la netherite en la mesa de encantamientos.
- No se puede reparar juntando dos tridentes en la cuadrícula de crafteo (daría un tridente normal); en el yunque sí, como el resto del equipo forjado.
- `/infernal update` pone a los que ya existen la durabilidad y el daño actuales del config. `netherite-trident.enabled: false` quita la receta (los que ya existen siguen igual).
- **Resource pack** (`items/netherite_trident.json`, `models/item/netherite_trident*.json`, `textures/item/netherite_trident*.png`): icono plano en el inventario,
  el suelo, marcos y estanterías; modelo 3D en la mano y otro al apuntar para lanzarlo, igual que el vanilla.
  - El juego dibuja el tridente en la mano con un renderizador especial que usa SIEMPRE `textures/entity/trident.png`, así que no se puede cambiar solo para
    un objeto. Por eso el modelo 3D se ha reconstruido como modelo JSON normal (las 5 piezas del modelo vanilla: asta, base y tres puntas, en las mismas posiciones
    de la mano) con su propia textura de netherite (`netherite_trident_in_hand.png`, misma distribución 32x32 que la textura vanilla).
  - **Tridente lanzado:** tampoco se puede cambiar con el pack, así que el plugin oculta el tridente real a los jugadores y lo dibuja con un item display que lo
    sigue tick a tick con la misma posición y el mismo giro (en el aire, clavado y volviendo con Lealtad). El tridente sigue funcionando igual en el servidor.
    `netherite-trident.thrown-model: false` lo desactiva (lanzado se verá como el vanilla). Sin resource pack (`use-resource-pack: false`) se ve como un tridente normal.
  - Las texturas y modelos se generan con `tools/make_netherite_trident.py` a partir de las texturas vanilla del tridente (`tools/vanilla_trident/`),
    recoloreadas con los colores de la espada y la lanza de netherite:

        python3 tools/make_netherite_trident.py tools/vanilla_trident resourcepack/assets/infernal

- Código: `NetheriteTridentListener.java` (daño lanzado y de la propulsión, impulso doble y aspecto del tridente lanzado), `InfernalItems#toNetheriteTrident`,
  la mesa de herrería en `SmithingListener` y la receta (para que la mesa acepte el tridente) en `InfernalRecipes`.

## Tridente Infernal
Se forja desde el Tridente de Netherite: **mesa de herrería: Plantilla Infernal + Tridente de Netherite + Lingote Infernal**. Conserva encantamientos, desgaste,
nombre y todo lo del de netherite (durabilidad 500, +1 de daño, no arde, se repara con netherite). Puntas de lava y asta granate, en la mano, lanzado y en el inventario.
- **Propulsión solo en la lava** ("Propulsión Ígnea"): en la lava, cárgalo y suéltalo como siempre y te impulsa (con el impulso doble del de netherite y el giro
  de la Propulsión: dura 1 segundo o hasta tocar el suelo y, si chocas con un mob, le hace 9 de daño y rebotas, como la vanilla). **Fuera de la lava no funciona**, como un tridente vanilla con Propulsión fuera del agua: en el agua,
  con lluvia o en tierra ni impulsa ni se lanza (en el agua o con lluvia chisporrotea). Sin Propulsión Ígnea se lanza normal en cualquier sitio.
  - Por qué: la Propulsión vanilla la decide el cliente y solo funciona en el agua o la lluvia. Por eso el Tridente Infernal no lleva el encantamiento de verdad:
    al forjarlo, en el yunque, en la mesa de encantamientos o con /enchant, la Propulsión se quita y su nivel se guarda aparte (se ve en la descripción:
    "Propulsión Ígnea III (solo en la lava)", con brillo de encantado). En la lava el plugin cancela el lanzamiento y te impulsa él.
  - Como la Propulsión vanilla, no se puede juntar con Lealtad ni Canalización.
- **Empalamiento solo en la lava:** su daño extra (2.5 por nivel) solo cuenta contra mobs o jugadores que estén en la lava, y ya no contra los mobs acuáticos.
- `/infernal give <jugador> infernal_trident`. `infernal-trident.enabled: false` quita la receta.
- Resource pack: `items/infernal_trident.json`, `models/item/infernal_trident*.json`, `textures/item/infernal_trident*.png`, generados con
  `tools/make_infernal_trident.py` a partir de los del Tridente de Netherite:

      python3 tools/make_infernal_trident.py resourcepack/assets/infernal

- Código: `InfernalTridentListener.java`, `InfernalItems#toInfernalTrident` / `normalizeInfernalTrident`, `SmithingListener` e `InfernalRecipes`.

## Mazo Yin Yang
Un mazo en blanco y negro, con los colores del símbolo yin yang: la cabeza mitad blanca con un punto negro y mitad negra con un punto blanco,
y el mango blanco y negro. **Sigue siendo un mazo** (mismo objeto de base): golpe aplastante, Densidad, Brecha y Aeroimpulso funcionan igual que en vanilla.
- **Mesa de herrería: plantilla de mejora de netherite (normal) + mazo + Núcleo Yin Yang** -> Mazo Yin Yang. Conserva encantamientos, desgaste y nombre.
- **Núcleo Yin Yang:** sale en las **bóvedas ominosas** (las que se abren con la llave de desafío ominosa) con un **6.7%** de probabilidad
  (`yin-yang-mace.core-chance`), además del botín normal (no quita el núcleo pesado ni nada de lo demás). Es un núcleo pesado de base con su mismo diseño
  en gris neutro (marco biselado y ranuras), el símbolo yin yang arriba y abajo y las ranuras de los lados mitad blancas y mitad negras;
  no se puede colocar ni usar para craftear un mazo normal.
- **+1 de daño** sobre el mazo (6 -> 7; `yin-yang-mace.damage-bonus`). El daño extra del golpe aplastante por la caída es el del mazo vanilla.
- **1/4 más de durabilidad** (500 -> 625; `yin-yang-mace.durability-multiplier`, 1.25).
- **Aeroimpulso I incorporado** (`yin-yang-mace.wind-burst`): el golpe aplastante te lanza hacia arriba como el encantamiento Aeroimpulso I
  (es la explosión de una carga de viento a tus pies, que da el mismo impulso, con sus partículas y su sonido, y el daño de caída cuenta desde donde te lanzó).
  Si lo encantas con Aeroimpulso, manda el encantamiento: con II y III subes más alto. La descripción lo indica ("Aeroimpulso I incorporado").
- Se repara en el yunque con varas de breeze, como el mazo; no se puede reparar juntando dos mazos en la cuadrícula de crafteo (daría un mazo normal).
- `/infernal give <jugador> yin_yang_mace` / `yin_yang_core`. `/infernal update` pone el daño, la durabilidad y la descripción actuales a los que ya existen.
- Resource pack: `items/yin_yang_mace.json` (mismo modelo en la mano que el mazo, `item/handheld_mace`), `items/yin_yang_core.json` (modelo de bloque del
  núcleo pesado con su textura `textures/block/yin_yang_core.png`). Se generan con `tools/make_yin_yang.py` a partir de las texturas vanilla del mazo
  y del núcleo pesado (`tools/vanilla_yin_yang/mace.png` y `heavy_core.png`):

      python3 tools/make_yin_yang.py tools/vanilla_yin_yang resourcepack/assets/infernal

- Código: `YinYangMaceListener.java` (Aeroimpulso incorporado y núcleo en las bóvedas ominosas), `InfernalItems#toYinYangMace`,
  la mesa de herrería en `SmithingListener` y la receta en `InfernalRecipes`.

## Wildfire
Un mob nuevo de las **fortalezas del Nether**: un blaze más grande (x1.4), con 60 de vida y armadura 6, rodeado de **4 escudos que giran** a su alrededor.
- **Dónde aparece:** cada blaze que aparece de forma natural (y solo aparecen en las fortalezas del Nether) tiene un **10%** de ser un Wildfire
  (`wildfire.spawn-chance`). Los de los generadores no se convierten (`wildfire.spawner-chance: 0`), para que no se puedan granjear. Se despawnea como un blaze.
- **Ataques:** lanza las bolas de fuego del blaze con +2 de daño y, si tiene jugadores a menos de 5 bloques, hace una **onda expansiva** cada 8 segundos:
  los empuja hacia fuera, les hace 6 de daño y les prende fuego (no afecta a creativo ni espectador).
- **Botín:** al morir a manos de un jugador suelta **de 1 a 2 Polvos de Blaze Infernal** (en vez de varas de blaze) y 20 de experiencia.
- `/infernal wildfire` (admin) hace aparecer uno donde estás. Todo se ajusta en `wildfire:` del config.yml.
- **Aspecto:** el cuerpo es el del blaze (no se puede cambiar el modelo de un solo blaze con un resource pack), más grande y con llamas. Los escudos son
  item displays montados encima del Wildfire con el modelo `infernal:wildfire_shield` (placa de piedra negra con borde y grietas de lava, siempre iluminada),
  generado con `tools/make_wildfire.py`:

      python3 tools/make_wildfire.py resourcepack/assets/infernal

  Sin el resource pack los escudos se ven como bloques de ladrillos del Nether.
- Código: `WildfireListener.java`.

## Jinete Oscuro
Un **esqueleto wither con armadura completa de netherite y una lanza de netherite con Filo V**, montado en un **caballo esqueleto negro**. 40 de vida.
- **Dónde aparece:** en las **fortalezas del Nether**, 1 de cada 10 esqueletos wither (`dark-rider.fortress-chance`, 0.10), y en el **valle de arena de almas**,
  donde cada mob que aparece de forma natural (esqueletos, ghasts, endermans; los strider no) tiene un **1%** de ser un Jinete Oscuro (`soul-sand-valley-chance`).
- **Botín:** al morir a manos de un jugador suelta **de 1 a 5 cráneos de esqueleto wither** (en vez del 2.5% vanilla) y 30 de experiencia.
  No suelta su armadura ni su lanza (`armor-drop-chance` y `spear-drop-chance` a 0 para que no se pueda granjear netherite).
- **El caballo:** el caballo esqueleto vanilla no puede llevar armadura y su textura es la misma para todos, así que el del Jinete es un **caballo zombi invisible**
  con una "armadura" cuya capa (`equipment/dark_rider.json`, `textures/entity/equipment/horse_body/dark_rider.png`) dibuja un caballo esqueleto en los tonos
  del esqueleto wither, y una silla negra con herrajes de netherite (`horse_saddle/dark_rider.png`). Las capas de equipo se dibujan aunque el mob sea invisible.
  **No cambia ninguna textura vanilla:** los caballos esqueleto y zombi normales se ven como siempre.
  Va ensillado, así que lo dirige el jinete (como los jinetes vanilla). Tiene resistencia al fuego, 30 de vida y velocidad 0.3. Suena como un caballo zombi.
  Si el jinete muere, el caballo se desvanece en almas (sin botín). Si el caballo muere, el jinete sigue a pie.
  Hacen falta 4 bloques de alto para ir montado; si no hay sitio (pasillos bajos de la fortaleza), el Jinete va a pie.
- **Embestida con la lanza** (`dark-rider.charge`): en vanilla el esqueleto wither no sabe embestir con la lanza (solo zombis, husks, piglins y piglins
  zombificados), así que la hace el plugin. Montado, si su objetivo está a entre 6 y 20 bloques y lo ve, el caballo relincha y carga en línea recta hacia él
  (0.9 bloques por tick, corrigiendo poco a poco la dirección, con un rastro de llamas de almas). Si lo alcanza: hasta 12 de daño según la velocidad a la que
  llega (la mitad si llega despacio; la armadura y el escudo lo reducen), lo empuja, lo desmonta si iba montado y le pone Wither 10 segundos.
  La carga termina si lo alcanza, se choca, se pasa de largo o tras 2.5 segundos, y espera 6 segundos antes de volver a embestir. Entre embestidas da
  estocadas normales con la lanza. A pie no embiste. No afecta a jugadores en creativo ni espectador.
- **Desaparición:** los jinetes vanilla no desaparecen solos, así que el plugin los quita si no hay ningún jugador a menos de 96 bloques durante 60 segundos.
- `/infernal darkrider` (admin) hace aparecer uno donde estás. Todo se ajusta en `dark-rider:` del config.yml.
- Texturas generadas con `tools/make_dark_rider.py` a partir del caballo esqueleto y la silla vanilla (`tools/vanilla_dark_rider/`):

      python3 tools/make_dark_rider.py tools/vanilla_dark_rider resourcepack/assets/infernal

  Sin el resource pack el caballo es invisible y solo se ve la silla.
- Código: `DarkRiderListener.java`.

## Piglin Guardián
Un **piglin bruto con hacha de netherite y armadura completa de netherite** (50 de vida, la del bruto vanilla).
- **Dónde aparece:** los piglins brutos solo aparecen en los **bastiones** (al generarse; no reaparecen). Cada bruto tiene un **25%** de ser un Piglin Guardián
  (`piglin-guardian.chance`). Se decide una sola vez por bruto, la primera vez que se carga, así que también vale para bastiones ya generados.
  Los brutos puestos con huevo o comando no se convierten.
- **Botín:** **2-4 escombros ancestrales**, **2-4 fragmentos de netherite** y un **50% de un lingote de netherite**, más 40 de experiencia.
  Lo suelta muera como muera (no reaparecen, así que no se pueden granjear). No suelta su armadura ni su hacha (`equipment-drop-chance`).
- `/infernal guardian` (admin) hace aparecer uno donde estás. Todo se ajusta en `piglin-guardian:` del config.yml. No necesita resource pack.
- Código: `PiglinGuardianListener.java`.

## Esqueleto Real
Un **esqueleto con armadura completa de diamante** y un **arco con Llama y Poder I-V**, montado en un **caballo esqueleto** (el normal, ensillado). 30 de vida.
- **Poder del arco** (`royal-skeleton.power-weights`): cuanto más alto el nivel, menos probable: I 40%, II 25%, III 18%, IV 11%, V 6%.
- **Dónde aparece:** en el **valle de arena de almas**: cada esqueleto que aparece ahí de forma natural tiene un **5%** de ser un Esqueleto Real (`royal-skeleton.chance`).
- **Botín:** al morir a manos de un jugador suelta **de 4 a 32 lágrimas de ghast** y 25 de experiencia. No suelta su armadura ni su arco
  (`armor-drop-chance`, `bow-drop-chance`).
- **El caballo:** va ensillado, así que lo dirige el jinete y dispara desde el caballo (como los jinetes vanilla). Tiene resistencia al fuego. Si el jinete muere,
  el caballo se desvanece en almas; si muere el caballo, el jinete sigue a pie. Hacen falta 4 bloques de alto para ir montado; si no hay sitio, va a pie.
  Se quitan si no hay ningún jugador a menos de 96 bloques durante 60 segundos.
- `/infernal royalskeleton` (admin) hace aparecer uno donde estás. Todo se ajusta en `royal-skeleton:` del config.yml. No necesita resource pack.
- Código: `RoyalSkeletonListener.java`.

## Comandos
`/infernal give <jugador> <ingot|star|powder|template|soul_ingot|soul_template|soul_sword|greed_ingot|greed_template|greed_sword|infernal_sword|purified_ingot|purified_template|purified_sword|celestial_dust|celestial_crystal|celestial_ingot|celestial_template|celestial_sword|mutated_breath|void_dragon_head|end_dragon_head|fermented_fruit|void_dragon_egg|end_dragon_egg|void_ingot|end_ingot|reinforced_shulker|dyed_obsidian|dyed_crying_obsidian|void_template|end_template|netherite_trident|infernal_trident|yin_yang_core|yin_yang_mace|soul_axe|soul_pickaxe|soul_shovel|soul_hoe|soul_spear|greed_axe|greed_pickaxe|greed_shovel|greed_hoe|greed_spear|purified_axe|purified_pickaxe|purified_shovel|purified_hoe|purified_spear|infernal_axe|infernal_pickaxe|infernal_shovel|infernal_hoe|infernal_spear|celestial_axe|celestial_pickaxe|celestial_shovel|celestial_hoe|celestial_spear|helmet|chestplate|leggings|boots|celestial_helmet|celestial_chestplate|celestial_leggings|celestial_boots|void_helmet|void_chestplate|void_leggings|void_boots|end_helmet|end_chestplate|end_leggings|end_boots> [cantidad]` (permiso infernalarmor.admin)

`/infernal update [jugador]` actualiza la durabilidad máxima y la descripción de las piezas de armadura (infernales, celestiales, del Vacío y del Fin), de las espadas Infernal y Celestial y de las herramientas infernales y celestiales, el daño y la velocidad de ataque de las espadas forjadas (Alma, Corrompida, Purificada, Infernal y Celestial), el daño, la velocidad de minería y de ataque (y el alcance de las lanzas) de las herramientas forjadas, la durabilidad y el daño del Tridente de Netherite y del Mazo Yin Yang y el % de la descripción de la Espada Infernal y la Celestial que ya existen (inventario,
armadura equipada y mano secundaria) al valor actual del config, conservando encantamientos, diseño, nombre y daño.
Sin jugador actualiza al que lo ejecuta (permiso infernalarmor.update, por defecto todos); con jugador requiere infernalarmor.admin.
Las piezas guardadas en cofres o shulkers hay que llevarlas en el inventario al ejecutarlo.

## Compilar sin instalar nada (GitHub)
1. Crea un repositorio en GitHub y sube el contenido de esta carpeta (incluida `.github`).
2. Pestaña **Actions** -> "Build InfernalArmor" -> espera ~1 min.
3. Entra a la ejecución y descarga el artefacto **InfernalArmor-jar** (contiene `InfernalArmor.jar`).
