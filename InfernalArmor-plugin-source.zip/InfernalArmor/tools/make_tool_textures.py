#!/usr/bin/env python3
"""Genera las texturas de las herramientas celestiales recoloreando las ya existentes.

  - Infernal:  ya NO se genera aquí. Las herramientas infernales (espada, hacha, pico, pala, azada y lanza) salen de
               make_infernal_tools.py (netherite recoloreada, mismo estilo que la Armadura Infernal).
  - Celestial: parte de la herramienta purificada (rampa azul de 6 tonos) y la pasa 1 a 1 a la rampa rosa
               de la Espada Celestial.

Uso: python3 make_tool_textures.py <carpeta textures/item>
"""
import sys
from PIL import Image

DIR = sys.argv[1] if len(sys.argv) > 1 else "../resourcepack/assets/infernal/textures/item"
TOOLS = ["axe", "pickaxe", "shovel", "hoe", "spear", "spear_in_hand"]

# purificada -> celestial (misma luminosidad, tonos rosas de la Espada Celestial)
CELESTIAL = {
    (0x2C, 0x4F, 0x7E): (0x5C, 0x22, 0x50),
    (0x5D, 0x88, 0xB6): (0x8F, 0x3D, 0x7F),
    (0x8C, 0xBF, 0xE3): (0xD2, 0x6B, 0xB0),
    (0xC4, 0xE8, 0xF8): (0xF2, 0xA0, 0xD2),
    (0xE8, 0xF7, 0xFD): (0xFB, 0xD0, 0xEA),
    (0xFF, 0xFF, 0xFF): (0xFF, 0xF0, 0xF8),
}


def recolor(src, dst, table):
    im = Image.open(src).convert("RGBA")
    out = im.copy()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = im.getpixel((x, y))
            if a and (r, g, b) in table:
                out.putpixel((x, y), (*table[(r, g, b)], a))
    out.save(dst)


for t in TOOLS:
    recolor(f"{DIR}/purified_{t}.png", f"{DIR}/celestial_{t}.png", CELESTIAL)
print("ok")
