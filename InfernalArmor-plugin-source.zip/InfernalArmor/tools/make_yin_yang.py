#!/usr/bin/env python3
"""Genera el Mazo Yin Yang y el Núcleo Yin Yang del resource pack (texturas, modelos y definiciones de objeto).

  - Mazo Yin Yang: el mazo vanilla recoloreado en blanco y negro. La cabeza queda mitad blanca (arriba a la izquierda, con
    un punto negro) y mitad negra (abajo a la derecha, con un punto blanco), como el símbolo; el mango es blanco y negro.
    Mismo modelo en la mano que el mazo vanilla (item/handheld_mace).
  - Núcleo Yin Yang: el núcleo pesado vanilla (mismo modelo de bloque 8x8x8 y misma textura de base, en gris neutro: marco
    biselado y ranuras de los lados). El remolino de arriba (y el cuadrado de abajo) pasan a ser el símbolo yin yang y las
    ranuras de los lados quedan mitad blancas y mitad negras.

Entradas (texturas vanilla, 16x16): tools/vanilla_yin_yang/mace.png y tools/vanilla_yin_yang/heavy_core.png.
Uso: python3 make_yin_yang.py <carpeta tools/vanilla_yin_yang> <carpeta resourcepack/assets/infernal>
"""
import json
import os
import sys

from PIL import Image

SRC = sys.argv[1] if len(sys.argv) > 1 else "vanilla_yin_yang"
DST = sys.argv[2] if len(sys.argv) > 2 else "../resourcepack/assets/infernal"
NS = "infernal"

# ------------------------------------------------------------------ mazo
MACE = {
    # cabeza: los tonos claros pasan a blanco y los oscuros a negro (la luz vanilla ya la parte en diagonal)
    (191, 206, 231): (255, 255, 255), (153, 161, 174): (228, 228, 228),
    (124, 132, 145): (198, 198, 198), (102, 108, 122): (162, 162, 162),
    (85, 92, 105): (74, 74, 74), (66, 71, 82): (52, 52, 52),
    (46, 51, 59): (34, 34, 34), (30, 34, 41): (16, 16, 16),
    # mango (vara de breeze): un lado blanco y el otro negro
    (80, 99, 144): (58, 58, 58), (122, 130, 196): (214, 214, 214),
    (35, 66, 105): (20, 20, 20), (181, 165, 202): (246, 246, 246),
}
# Retoques a mano: mitad blanca limpia, punto negro en la mitad blanca y punto blanco en la mitad negra.
MACE_PIXELS = {
    (9, 2): (198, 198, 198), (9, 3): (198, 198, 198), (7, 4): (198, 198, 198), (8, 3): (228, 228, 228),
    (8, 4): (16, 16, 16),
    (12, 6): (240, 240, 240),
}

# ------------------------------------------------------------------ núcleo
# Símbolo 6x6 dentro del marco de la cara (simétrico: cada casilla es la contraria de la opuesta). '.' = se queda el vanilla.
EMBLEM = [
    ".WWWB.",
    "WWBWWB",
    "WWWWBB",
    "WWBBBB",
    "WBBWBB",
    ".WBBB.",
]
SLOT = ["WB", "WB", "WB", "WB"]  # ranura de los lados (2x4)
WHITE, WHITE_SHADE, BLACK, BLACK_LIGHT = (238, 238, 238), (204, 204, 204), (22, 22, 22), (52, 52, 52)


def mace_texture(src, dst):
    im = Image.open(src).convert("RGBA")
    out = im.copy()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = im.getpixel((x, y))
            if not a:
                continue
            if (r, g, b) not in MACE:
                raise SystemExit(f"{src}: color sin traducir {(r, g, b)} en {(x, y)}")
            out.putpixel((x, y), (*MACE[(r, g, b)], a))
    for (x, y), c in MACE_PIXELS.items():
        out.putpixel((x, y), (*c, 255))
    out.save(dst)


def core_texture(src, dst):
    # Distribución de block/heavy_core: arriba uv 0,0-8,8; abajo 8,0-16,8; los 4 lados 0,8-8,16.
    van = Image.open(src).convert("RGBA")
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y in range(16):
        for x in range(16):
            r, g, b, a = van.getpixel((x, y))
            if a:  # el núcleo pesado vanilla en gris neutro (misma luminosidad)
                lum = int(round(0.299 * r + 0.587 * g + 0.114 * b))
                im.putpixel((x, y), (lum, lum, lum, a))

    def paint(ox, oy, rows):
        h, w = len(rows), len(rows[0])

        def at(x, y):
            return rows[y][x] if 0 <= x < w and 0 <= y < h else "."
        for y in range(h):
            for x in range(w):
                ch = rows[y][x]
                if ch == "W":  # borde de abajo/derecha del blanco un poco más oscuro (volumen)
                    c = WHITE_SHADE if at(x + 1, y) != "W" and at(x, y + 1) != "W" else WHITE
                elif ch == "B":  # borde de arriba/izquierda del negro un poco más claro
                    c = BLACK_LIGHT if at(x - 1, y) != "B" and at(x, y - 1) != "B" else BLACK
                else:
                    continue
                im.putpixel((ox + x, oy + y), (*c, 255))

    paint(1, 1, EMBLEM)                                   # arriba: el remolino pasa a ser el símbolo
    paint(9, 1, [r[::-1] for r in EMBLEM[::-1]])          # abajo: el símbolo girado
    paint(3, 10, SLOT)                                    # lados: la ranura, mitad blanca y mitad negra
    im.save(dst)


def write(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def main():
    for d in ("textures/item", "textures/block", "models/item", "models/block", "items"):
        os.makedirs(os.path.join(DST, d), exist_ok=True)

    mace_texture(os.path.join(SRC, "mace.png"), os.path.join(DST, "textures/item/yin_yang_mace.png"))
    write(os.path.join(DST, "models/item/yin_yang_mace.json"), {
        "parent": "minecraft:item/handheld_mace",
        "textures": {"layer0": f"{NS}:item/yin_yang_mace"},
    })
    write(os.path.join(DST, "items/yin_yang_mace.json"), {
        "model": {"type": "minecraft:model", "model": f"{NS}:item/yin_yang_mace"},
    })

    core_texture(os.path.join(SRC, "heavy_core.png"), os.path.join(DST, "textures/block/yin_yang_core.png"))
    write(os.path.join(DST, "models/block/yin_yang_core.json"), {
        "parent": "minecraft:block/heavy_core",
        "textures": {"all": f"{NS}:block/yin_yang_core", "particle": f"{NS}:block/yin_yang_core"},
    })
    write(os.path.join(DST, "items/yin_yang_core.json"), {
        "model": {"type": "minecraft:model", "model": f"{NS}:block/yin_yang_core"},
    })
    print("ok")


if __name__ == "__main__":
    main()
