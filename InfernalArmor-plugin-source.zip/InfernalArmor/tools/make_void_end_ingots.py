"""
Genera las texturas del Lingote del Vacío y del Lingote del Fin (16x16) con los colores de cada armadura.
Usa la silueta y el sombreado de tools/ingot_shape.png y solo cambia la paleta:

  Vacío -> obsidiana oscura con vetas y destellos morados del End (igual que la Armadura del Vacío).
  Fin   -> tonos purpur con destellos claros (igual que la Armadura del Fin).

Uso:  python3 make_void_end_ingots.py <carpeta_resourcepack>/assets/infernal/textures/item
Las paletas y la función de recolorado son las mismas de make_void_end_armor.py.
"""
import os
import sys
import random
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from make_void_end_armor import VOID, VOID_SPARK, END, END_GLINT, ramp, lum  # noqa: E402

SHAPE = os.path.join(HERE, "ingot_shape.png")


def normalized(src):
    """Luminancia de cada píxel opaco normalizada a 0..1 según el rango propio de la imagen."""
    px = src.load()
    vals = [lum(px[x, y]) for y in range(src.height) for x in range(src.width) if px[x, y][3] > 0]
    lo, hi = min(vals), max(vals)
    return lambda p: (lum(p) - lo) / (hi - lo)


def recolor_void(src, seed=7):
    rnd = random.Random(seed)
    t_of = normalized(src)
    out = Image.new("RGBA", src.size, (0, 0, 0, 0))
    sp, dp = src.load(), out.load()
    for y in range(src.height):
        for x in range(src.width):
            p = sp[x, y]
            if p[3] == 0:
                continue
            t = t_of(p)
            c = ramp(VOID, t * 0.55)          # el cuerpo es obsidiana casi negra
            if 0.25 < t < 0.7 and rnd.random() < 0.16:
                c = VOID_SPARK[0] if t < 0.45 else rnd.choice(VOID_SPARK[:2])   # vetas moradas
            elif t >= 0.7 and rnd.random() < 0.45:
                c = rnd.choice(VOID_SPARK[1:])  # destellos violeta en la cara superior
            dp[x, y] = (*c, p[3])
    return out


def recolor_end(src, seed=11):
    rnd = random.Random(seed)
    t_of = normalized(src)
    out = Image.new("RGBA", src.size, (0, 0, 0, 0))
    sp, dp = src.load(), out.load()
    for y in range(src.height):
        for x in range(src.width):
            p = sp[x, y]
            if p[3] == 0:
                continue
            t = t_of(p)
            c = ramp(END, t)
            if t >= 0.85 and rnd.random() < 0.5:
                c = rnd.choice(END_GLINT)       # destellos del purpur
            dp[x, y] = (*c, p[3])
    return out


def main(out_dir):
    os.makedirs(out_dir, exist_ok=True)
    src = Image.open(SHAPE).convert("RGBA")
    recolor_void(src).save(os.path.join(out_dir, "void_ingot.png"))
    recolor_end(src).save(os.path.join(out_dir, "end_ingot.png"))
    print("void_ingot.png y end_ingot.png generados en", out_dir)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
