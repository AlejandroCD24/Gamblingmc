"""
Genera los assets del resource pack para la netherite teñible (crafteo: pieza de netherite + tintes).

La armadura de cuero se tiñe multiplicando una textura GRIS CLARA por el color del tinte. La netherite vanilla es casi negra,
así que multiplicarla daría siempre colores casi negros. Por eso se usa una versión aclarada en escala de grises (misma forma,
mismo sombreado, solo más brillo); el tinte la multiplica en el juego igual que en el cuero.

Salida (en <carpeta_resourcepack>/assets/infernal):
  textures/item/dyed_netherite_<pieza>.png                        iconos 16x16 aclarados
  textures/entity/equipment/humanoid/netherite_dyed.png           casco, peto y botas puestos
  textures/entity/equipment/humanoid_leggings/netherite_dyed.png  pantalones puestos
  equipment/netherite_dyed.json                                   capa teñible ("dyeable")
  models/item/dyed_netherite_<pieza>[_<material>_trim].json       modelo base y uno por cada diseño (trim) de armadura
  items/dyed_netherite_<pieza>.json                               elige el modelo según el trim y aplica el tinte (minecraft:dye)

Uso:  python3 make_dyeable_netherite.py <carpeta_resourcepack>/assets/infernal
Las fuentes vanilla están en tools/vanilla_netherite/.
"""
import json
import os
import sys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "vanilla_netherite")

PIECES = ["helmet", "chestplate", "leggings", "boots"]
TRIMS = ["quartz", "iron", "netherite", "redstone", "copper", "gold", "emerald", "diamond", "lapis", "amethyst", "resin"]
LUM_LO, LUM_HI = 10.0, 128.0      # rango de luminancia de la netherite vanilla
OUT_LO, OUT_HI = 70.0, 255.0      # rango de gris resultante (claro: el tinte lo oscurece al multiplicar)


def lum(p):
    return 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]


def lighten(src):
    """Netherite -> gris claro conservando el sombreado y la transparencia."""
    out = Image.new("RGBA", src.size, (0, 0, 0, 0))
    sp, dp = src.load(), out.load()
    for y in range(src.height):
        for x in range(src.width):
            p = sp[x, y]
            if p[3] == 0:
                continue
            t = max(0.0, min(1.0, (lum(p) - LUM_LO) / (LUM_HI - LUM_LO)))
            v = round(OUT_LO + t * (OUT_HI - OUT_LO))
            dp[x, y] = (v, v, v, p[3])
    return out


def dump(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)
        f.write("\n")


def main(root):
    tex = os.path.join(root, "textures")

    # ---- texturas
    for piece in PIECES:
        src = Image.open(os.path.join(SRC, f"netherite_{piece}.png")).convert("RGBA")
        os.makedirs(os.path.join(tex, "item"), exist_ok=True)
        lighten(src).save(os.path.join(tex, "item", f"dyed_netherite_{piece}.png"))
    layers = {"humanoid": "netherite_humanoid.png", "humanoid_leggings": "netherite_leggings_layer.png"}
    for sub, fname in layers.items():
        d = os.path.join(tex, "entity", "equipment", sub)
        os.makedirs(d, exist_ok=True)
        lighten(Image.open(os.path.join(SRC, fname)).convert("RGBA")).save(os.path.join(d, "netherite_dyed.png"))

    # ---- armadura puesta: capa teñible (si una pieza no llevara tinte se vería blanca, no negra)
    dyeable = [{"texture": "infernal:netherite_dyed", "dyeable": {"color_when_undyed": 16777215}}]
    dump(os.path.join(root, "equipment", "netherite_dyed.json"),
         {"layers": {"humanoid": dyeable, "humanoid_leggings": dyeable}})

    # ---- modelos e items
    tint = [{"type": "minecraft:dye", "default": -1}]   # el color sale del componente dyed_color de la pieza
    for piece in PIECES:
        name = f"dyed_netherite_{piece}"
        dump(os.path.join(root, "models", "item", f"{name}.json"),
             {"parent": "minecraft:item/generated", "textures": {"layer0": f"infernal:item/{name}"}})
        cases = []
        for trim in TRIMS:
            dump(os.path.join(root, "models", "item", f"{name}_{trim}_trim.json"),
                 {"parent": "minecraft:item/generated",
                  "textures": {"layer0": f"infernal:item/{name}",
                               "layer1": f"minecraft:trims/items/{piece}_trim_{trim}"}})
            cases.append({"when": f"minecraft:{trim}",
                          "model": {"type": "minecraft:model", "model": f"infernal:item/{name}_{trim}_trim", "tints": tint}})
        dump(os.path.join(root, "items", f"{name}.json"),
             {"model": {"type": "minecraft:select", "property": "minecraft:trim_material", "cases": cases,
                        "fallback": {"type": "minecraft:model", "model": f"infernal:item/{name}", "tints": tint}}})


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Uso: python3 make_dyeable_netherite.py <ruta>/assets/infernal")
    main(sys.argv[1])
