"""
Genera las texturas de la Armadura del Vacío y la Armadura del Fin a partir de la netherite vanilla
(mismo modelo y mismo sombreado, solo cambia la paleta y se añaden detalles).

  Vacío -> obsidiana oscura con vetas y destellos morados del End (tipo obsidiana llorosa).
  Fin   -> bloques púrpura del End: tono purpur, junta de ladrillo y líneas de pilar purpur.

Uso:  python3 make_void_end_armor.py <carpeta_resourcepack>/assets/infernal/textures
Las fuentes vanilla están en tools/vanilla_netherite/ (iconos 16x16 y capas de armadura 64x32).
"""
import os
import sys
import random
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "vanilla_netherite")

ICONS = ["helmet", "chestplate", "leggings", "boots"]
LUM_LO, LUM_HI = 10.0, 118.0   # rango de luminancia de la netherite vanilla


def hexc(s):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def lerp(a, b, f):
    return tuple(round(a[i] + (b[i] - a[i]) * f) for i in range(3))


def ramp(stops, t):
    t = max(0.0, min(1.0, t))
    for i in range(len(stops) - 1):
        t0, c0 = stops[i]
        t1, c1 = stops[i + 1]
        if t <= t1:
            return lerp(c0, c1, (t - t0) / (t1 - t0) if t1 > t0 else 0)
    return stops[-1][1]


def lum(p):
    return 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]


def norm(p):
    return (lum(p) - LUM_LO) / (LUM_HI - LUM_LO)


# ------------------------------------------------------------------ paletas
VOID = [
    (0.00, hexc("#06030F")),
    (0.18, hexc("#10062A")),
    (0.38, hexc("#240D54")),
    (0.60, hexc("#40178F")),
    (0.80, hexc("#6A2BD0")),
    (1.00, hexc("#9B52F5")),
]
# tonos de la obsidiana llorosa: del morado profundo al violeta brillante de las "lágrimas"
VOID_SPARK = [hexc("#5A1CB5"), hexc("#7B2FE0"), hexc("#A25BFF"), hexc("#C58BFF")]

END = [
    (0.00, hexc("#34184A")),
    (0.18, hexc("#582F7C")),
    (0.38, hexc("#7B4DA0")),
    (0.60, hexc("#A678C4")),
    (0.80, hexc("#CFAEE6")),
    (1.00, hexc("#FBF0FF")),
]
END_MORTAR = hexc("#3A1B55")
END_GLINT = [hexc("#F6E8FA"), hexc("#FFFFFF"), hexc("#FFFFFF")]


def shade_down(c):
    """Junta de ladrillo: mezcla con un púrpura oscuro (conserva la saturación, no se vuelve gris)."""
    return lerp(c, END_MORTAR, 0.30)


def shade_up(c):
    return lerp(c, hexc("#F5E1FA"), 0.28)


# ---------------------------------------------------------------- recolorado
def recolor_void(src, seed):
    rnd = random.Random(seed)
    out = Image.new("RGBA", src.size, (0, 0, 0, 0))
    sp, dp = src.load(), out.load()
    for y in range(src.height):
        for x in range(src.width):
            p = sp[x, y]
            if p[3] == 0:
                continue
            t = norm(p)
            c = ramp(VOID, t)
            # vetas / destellos morados (obsidiana llorosa): solo en medios tonos, nunca en el contorno
            if 0.12 < t < 0.75 and rnd.random() < 0.22:
                c = VOID_SPARK[0] if t < 0.4 else rnd.choice(VOID_SPARK[:3])
            elif t >= 0.75 and rnd.random() < 0.55:
                c = rnd.choice(VOID_SPARK[1:])
            dp[x, y] = (*c, p[3])
    return out


def recolor_end(src, seed, pillar_columns=()):
    rnd = random.Random(seed)
    out = Image.new("RGBA", src.size, (0, 0, 0, 0))
    sp, dp = src.load(), out.load()
    for y in range(src.height):
        for x in range(src.width):
            p = sp[x, y]
            if p[3] == 0:
                continue
            t = norm(p)
            c = ramp(END, t)
            if t > 0.12:  # el contorno oscuro no lleva detalle
                # junta de ladrillo purpur: hiladas de 4 px, juntas verticales alternadas cada 4 px
                row = y // 4
                if y % 4 == 3:
                    c = shade_down(c)
                elif (x + (2 if row % 2 else 0)) % 4 == 3:
                    c = shade_down(c)
                elif y % 4 == 0 and t > 0.4:
                    c = shade_up(c)
                if x in pillar_columns and y % 4 != 3:
                    c = shade_up(c)
                if t >= 0.7 and rnd.random() < 0.45:
                    c = rnd.choice(END_GLINT)
                elif 0.45 <= t < 0.7 and rnd.random() < 0.12:
                    c = END_GLINT[0]
            dp[x, y] = (*c, p[3])
    return out


def main(out_root):
    os.makedirs(os.path.join(out_root, "item"), exist_ok=True)
    for sub in ("humanoid", "humanoid_leggings"):
        os.makedirs(os.path.join(out_root, "entity", "equipment", sub), exist_ok=True)

    for i, piece in enumerate(ICONS):
        src = Image.open(os.path.join(SRC, f"netherite_{piece}.png")).convert("RGBA")
        recolor_void(src, 100 + i).save(os.path.join(out_root, "item", f"void_{piece}.png"))
        recolor_end(src, 200 + i, pillar_columns=(7, 8) if piece == "chestplate" else ()).save(
            os.path.join(out_root, "item", f"end_{piece}.png"))

    layers = {
        "humanoid": "netherite_humanoid.png",
        "humanoid_leggings": "netherite_leggings_layer.png",
    }
    for sub, fname in layers.items():
        src = Image.open(os.path.join(SRC, fname)).convert("RGBA")
        recolor_void(src, 300 + len(sub)).save(
            os.path.join(out_root, "entity", "equipment", sub, "void.png"))
        recolor_end(src, 400 + len(sub)).save(
            os.path.join(out_root, "entity", "equipment", sub, "end.png"))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Uso: python3 make_void_end_armor.py <ruta>/assets/infernal/textures")
    main(sys.argv[1])
