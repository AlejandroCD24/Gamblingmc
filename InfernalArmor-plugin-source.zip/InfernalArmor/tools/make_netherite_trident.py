#!/usr/bin/env python3
"""Genera el Tridente de Netherite del resource pack (texturas, modelos y definición del objeto).

El tridente vanilla se dibuja en la mano con un renderizador especial ("minecraft:trident") que usa SIEMPRE la textura
textures/entity/trident.png, así que no se puede cambiar solo para un objeto. Este script reconstruye el mismo modelo 3D
(las 5 piezas de TridentModel: asta, base y tres puntas) como un modelo JSON normal que usa una textura propia de netherite,
con las mismas posiciones en la mano que el vanilla (trident_in_hand / trident_throwing).

Entradas (texturas vanilla, en tools/vanilla_trident/):
  trident.png         icono del inventario (16x16, textures/item/trident.png)
  trident_entity.png  textura del modelo 3D (32x32, textures/entity/trident.png)

Uso: python3 make_netherite_trident.py <carpeta tools/vanilla_trident> <carpeta resourcepack/assets/infernal>
"""
import json
import math
import os
import sys

from PIL import Image

SRC = sys.argv[1] if len(sys.argv) > 1 else "vanilla_trident"
DST = sys.argv[2] if len(sys.argv) > 2 else "../resourcepack/assets/infernal"
NS = "infernal"
NAME = "netherite_trident"

# ---------------------------------------------------------------- texturas
# Tridente vanilla (prismarina) -> netherite: misma luminosidad relativa, colores de la espada y la lanza de netherite vanilla.
ICON = {
    # puntas (gris/blanco) -> metal de netherite claro, con la sombra morada de la netherite en la base
    (255, 255, 255): (134, 123, 134), (216, 216, 216): (112, 103, 112),
    (150, 150, 150): (93, 86, 93), (107, 107, 107): (74, 41, 64),
    # asta (verde azulado) -> metal de netherite oscuro
    (88, 157, 142): (88, 78, 86), (64, 121, 105): (67, 64, 67),
    (46, 94, 80): (49, 41, 42), (22, 71, 57): (35, 16, 18),
}
ENTITY = {
    # puntas y base
    (222, 232, 218): (134, 123, 134), (214, 228, 222): (128, 117, 128), (178, 213, 203): (112, 103, 112),
    (170, 201, 192): (104, 95, 104), (148, 187, 176): (93, 86, 93), (117, 172, 157): (81, 68, 78),
    # asta (bandas)
    (101, 167, 153): (88, 78, 86), (88, 157, 142): (75, 63, 70), (77, 143, 124): (67, 64, 67),
    (66, 133, 116): (60, 50, 50), (64, 121, 105): (49, 41, 42),
}


def recolor(src, dst, table):
    im = Image.open(src).convert("RGBA")
    out = im.copy()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = im.getpixel((x, y))
            if not a:
                continue
            if (r, g, b) not in table:
                raise SystemExit(f"{src}: color sin traducir {(r, g, b)} en {(x, y)}")
            out.putpixel((x, y), (*table[(r, g, b)], a))
    out.save(dst)


# ---------------------------------------------------------------- modelo 3D
TEX_W = TEX_H = 32
# TridentModel.createLayer(): (nombre, texOffs u, v, caja x, y, z, ancho, alto, fondo, mirror)
PARTS = [
    ("pole", 0, 6, -0.5, 2.0, -0.5, 1, 25, 1, False),
    ("base", 4, 0, -1.5, 0.0, -0.5, 3, 2, 1, False),
    ("left_spike", 4, 3, -2.5, -3.0, -0.5, 1, 4, 1, False),
    ("middle_spike", 0, 0, -0.5, -4.0, -0.5, 1, 4, 1, False),
    ("right_spike", 4, 3, 1.5, -3.0, -0.5, 1, 4, 1, True),
]
# El renderizador especial dibuja el modelo de entidad con scale(1, -1, -1) (giro de 180 grados en X) después de centrar el
# objeto (-0.5). En el JSON: c = (x, -y, -z) + DESPLAZAMIENTO. Las coordenadas JSON deben quedar entre -16 y 32, por eso el
# modelo se sube DY píxeles y se compensa en la traslación de cada "display". Sin desplazamiento en X para que la mano
# izquierda (que el juego refleja en X) siga cuadrando con la misma corrección.
DY = 16.0


def cube_polygons(u, v, x, y, z, w, h, d, mirror):
    """Polígonos de ModelPart.Cube: lista de (dirección, [(posición, (u, v)) x4])."""
    x1, y1, z1 = x, y, z
    x2, y2, z2 = x + w, y + h, z + d
    if mirror:
        x1, x2 = x2, x1
    p0 = (x1, y1, z1); p1 = (x2, y1, z1); p2 = (x2, y2, z1); p3 = (x1, y2, z1)
    p4 = (x1, y1, z2); p5 = (x2, y1, z2); p6 = (x2, y2, z2); p7 = (x1, y2, z2)
    f4 = u; f5 = u + d; f6 = u + d + w; f7 = u + d + w + w; f8 = u + d + w + d; f9 = u + d + w + d + w
    f10 = v; f11 = v + d; f12 = v + d + h
    polys = [
        ("down", [p5, p4, p0, p1], f5, f10, f6, f11),
        ("up", [p2, p3, p7, p6], f6, f11, f7, f10),
        ("west", [p0, p4, p7, p3], f4, f11, f5, f12),
        ("north", [p1, p0, p3, p2], f5, f11, f6, f12),
        ("east", [p5, p1, p2, p6], f6, f11, f8, f12),
        ("south", [p4, p5, p6, p7], f8, f11, f9, f12),
    ]
    out = []
    for name, verts, ua, va, ub, vb in polys:
        # ModelPart.Polygon: v0=(u2,v1) v1=(u1,v1) v2=(u1,v2) v3=(u2,v2)
        uvs = [(ub, va), (ua, va), (ua, vb), (ub, vb)]
        out.append((name, list(zip(verts, uvs))))
    return out


def to_json_space(p):
    return (p[0], -p[1] + DY, -p[2])


FACE_INFO = {  # FaceInfo: posición de los 4 vértices de cada cara de un elemento JSON
    "down": [("x1", "y1", "z2"), ("x1", "y1", "z1"), ("x2", "y1", "z1"), ("x2", "y1", "z2")],
    "up": [("x1", "y2", "z1"), ("x1", "y2", "z2"), ("x2", "y2", "z2"), ("x2", "y2", "z1")],
    "north": [("x2", "y2", "z1"), ("x2", "y1", "z1"), ("x1", "y1", "z1"), ("x1", "y2", "z1")],
    "south": [("x1", "y2", "z2"), ("x1", "y1", "z2"), ("x2", "y1", "z2"), ("x2", "y2", "z2")],
    "west": [("x1", "y2", "z1"), ("x1", "y1", "z1"), ("x1", "y1", "z2"), ("x1", "y2", "z2")],
    "east": [("x2", "y2", "z2"), ("x2", "y1", "z2"), ("x2", "y1", "z1"), ("x2", "y2", "z1")],
}


def face_direction(points, lo, hi):
    for axis, (neg, pos) in enumerate((("west", "east"), ("down", "up"), ("north", "south"))):
        vals = {round(p[axis], 6) for p in points}
        if len(vals) == 1:
            val = vals.pop()
            if abs(val - lo[axis]) < 1e-6:
                return neg
            if abs(val - hi[axis]) < 1e-6:
                return pos
    raise ValueError("cara no alineada")


def solve_face(direction, lo, hi, verts):
    """Busca uv [u1, v1, u2, v2] y rotación para que la cara JSON lleve la misma textura en cada esquina."""
    coord = {"x1": lo[0], "y1": lo[1], "z1": lo[2], "x2": hi[0], "y2": hi[1], "z2": hi[2]}
    corners = [(coord[a], coord[b], coord[c]) for a, b, c in FACE_INFO[direction]]
    lookup = {tuple(round(c, 6) for c in pos): uv for pos, uv in verts}
    wanted = [lookup[tuple(round(c, 6) for c in corner)] for corner in corners]
    for rot in (0, 90, 180, 270):
        need = {}
        ok = True
        for i, (u, v) in enumerate(wanted):
            s = (i + rot // 90) % 4
            ku = "u1" if s in (0, 1) else "u2"
            kv = "v1" if s in (0, 3) else "v2"
            for k, val in ((ku, u), (kv, v)):
                if k in need and abs(need[k] - val) > 1e-6:
                    ok = False
                need.setdefault(k, val)
        if ok and len(need) == 4:
            sx, sy = 16.0 / TEX_W, 16.0 / TEX_H
            uv = [need["u1"] * sx, need["v1"] * sy, need["u2"] * sx, need["v2"] * sy]
            return uv, rot
    raise ValueError(f"sin solución para la cara {direction}")


def num(v):
    v = round(v, 4)
    return int(v) if v == int(v) else v


def build_elements():
    elements = []
    for name, u, v, x, y, z, w, h, d, mirror in PARTS:
        polys = cube_polygons(u, v, x, y, z, w, h, d, mirror)
        pts = [to_json_space(p) for _, vs in polys for p, _ in vs]
        lo = tuple(min(p[i] for p in pts) for i in range(3))
        hi = tuple(max(p[i] for p in pts) for i in range(3))
        for i in range(3):
            if lo[i] < -16 or hi[i] > 32:
                raise SystemExit(f"{name}: fuera de los límites del modelo JSON")
        faces = {}
        for _, vs in polys:
            mapped = [(to_json_space(p), uv) for p, uv in vs]
            direction = face_direction([p for p, _ in mapped], lo, hi)
            uv, rot = solve_face(direction, lo, hi, mapped)
            face = {"uv": [num(c) for c in uv], "texture": "#trident"}
            if rot:
                face["rotation"] = rot
            faces[direction] = face
        elements.append({
            "from": [num(c) for c in lo],
            "to": [num(c) for c in hi],
            "faces": {k: faces[k] for k in ("north", "east", "south", "west", "up", "down")},
        })
    return elements


# ---------------------------------------------------------------- posiciones en la mano (vanilla)
IN_HAND = {
    "thirdperson_righthand": ([0, 60, 0], [11, 17, -2], [1, 1, 1]),
    "thirdperson_lefthand": ([0, 60, 0], [3, 17, 12], [1, 1, 1]),
    "firstperson_righthand": ([0, -90, 25], [-3, 17, 1], [1, 1, 1]),
    "firstperson_lefthand": ([0, 90, -25], [13, 17, 1], [1, 1, 1]),
    "gui": ([15, -25, -5], [2, 3, 0], [0.65, 0.65, 0.65]),
    "fixed": ([0, 180, 0], [-2, 4, -5], [0.5, 0.5, 0.5]),
    "ground": ([0, 0, 0], [4, 4, 2], [0.25, 0.25, 0.25]),
}
THROWING = dict(IN_HAND)
THROWING["thirdperson_righthand"] = ([0, 90, 180], [8, -17, 9], [1, 1, 1])
THROWING["thirdperson_lefthand"] = ([0, 90, 180], [8, -17, -7], [1, 1, 1])


def rot_xyz(rx, ry, rz):
    """Matriz de Quaternionf.rotationXYZ (Rx * Ry * Rz), en grados."""
    a, b, c = (math.radians(t) for t in (rx, ry, rz))
    ca, sa, cb, sb, cc, sc = math.cos(a), math.sin(a), math.cos(b), math.sin(b), math.cos(c), math.sin(c)
    Rx = [[1, 0, 0], [0, ca, -sa], [0, sa, ca]]
    Ry = [[cb, 0, sb], [0, 1, 0], [-sb, 0, cb]]
    Rz = [[cc, -sc, 0], [sc, cc, 0], [0, 0, 1]]

    def mul(A, B):
        return [[sum(A[i][k] * B[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    return mul(mul(Rx, Ry), Rz)


def displays(table):
    out = {}
    delta = (0.0, DY, 0.0)
    for ctx, (rot, trans, scale) in table.items():
        R = rot_xyz(*rot)
        sd = [scale[i] * delta[i] for i in range(3)]
        rsd = [sum(R[i][k] * sd[k] for k in range(3)) for i in range(3)]
        t = [trans[i] - rsd[i] for i in range(3)]
        if any(abs(c) > 80 for c in t):
            raise SystemExit(f"{ctx}: traslación fuera de rango")
        out[ctx] = {"rotation": rot, "translation": [num(c) for c in t], "scale": scale}
    return out


def main():
    tex = os.path.join(DST, "textures", "item")
    models = os.path.join(DST, "models", "item")
    items = os.path.join(DST, "items")
    for d in (tex, models, items):
        os.makedirs(d, exist_ok=True)

    recolor(os.path.join(SRC, "trident.png"), os.path.join(tex, f"{NAME}.png"), ICON)
    recolor(os.path.join(SRC, "trident_entity.png"), os.path.join(tex, f"{NAME}_in_hand.png"), ENTITY)

    def write(path, data):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.write("\n")

    write(os.path.join(models, f"{NAME}.json"), {
        "parent": "minecraft:item/generated",
        "textures": {"layer0": f"{NS}:item/{NAME}"},
    })
    write(os.path.join(models, f"{NAME}_in_hand.json"), {
        "gui_light": "front",
        "textures": {"trident": f"{NS}:item/{NAME}_in_hand", "particle": f"{NS}:item/{NAME}"},
        "elements": build_elements(),
        "display": displays(IN_HAND),
    })
    write(os.path.join(models, f"{NAME}_throwing.json"), {
        "parent": f"{NS}:item/{NAME}_in_hand",
        "display": displays(THROWING),
    })
    # Igual que items/trident.json vanilla: icono plano en el inventario, el suelo, marcos y estanterías; modelo 3D en la mano
    # y otro al apuntar para lanzarlo. El tridente lanzado lo dibuja el plugin con un item display (contexto "none" -> 3D).
    write(os.path.join(items, f"{NAME}.json"), {
        "model": {
            "type": "minecraft:select",
            "property": "minecraft:display_context",
            "cases": [{
                "when": ["gui", "ground", "fixed", "on_shelf"],
                "model": {"type": "minecraft:model", "model": f"{NS}:item/{NAME}"},
            }],
            "fallback": {
                "type": "minecraft:condition",
                "property": "minecraft:using_item",
                "on_false": {"type": "minecraft:model", "model": f"{NS}:item/{NAME}_in_hand"},
                "on_true": {"type": "minecraft:model", "model": f"{NS}:item/{NAME}_throwing"},
            },
        },
    })
    print("ok")


if __name__ == "__main__":
    main()
