"""
Genera las texturas de la Plantilla del Vacío y la Plantilla del Fin (iconos 16x16) y de la Obsidiana Teñida y la
Obsidiana Llorosa Teñida (texturas de bloque 16x16, para el modelo del objeto) con los colores de cada armadura.

  Vacío -> obsidiana oscura con vetas y destellos morados del End (igual que la Armadura y el Lingote del Vacío).
  Fin   -> tonos purpur con destellos claros (igual que la Armadura y el Lingote del Fin).

Las plantillas usan la silueta y el sombreado de tools/template_shape.png (la Plantilla Celestial) y solo cambian la paleta,
con las mismas funciones de recolorado que los lingotes (make_void_end_ingots.py).

Uso:  python3 make_void_end_templates.py <carpeta_resourcepack>/assets/infernal/textures
Escribe item/void_template.png, item/end_template.png, block/dyed_obsidian.png y block/dyed_crying_obsidian.png.
"""
import os
import sys
import random
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from make_void_end_armor import VOID, VOID_SPARK, END, END_GLINT, END_MORTAR, ramp, hexc  # noqa: E402
from make_void_end_ingots import recolor_void, recolor_end  # noqa: E402

SHAPE = os.path.join(HERE, "template_shape.png")


def noise_field(rnd, size=16, cell=4):
    """Ruido de valor suave que se repite en los bordes (para que el bloque encaje consigo mismo)."""
    n = size // cell
    grid = [[rnd.random() for _ in range(n)] for _ in range(n)]

    def at(x, y):
        fx, fy = x / cell, y / cell
        x0, y0 = int(fx) % n, int(fy) % n
        x1, y1 = (x0 + 1) % n, (y0 + 1) % n
        tx, ty = fx - int(fx), fy - int(fy)
        tx, ty = tx * tx * (3 - 2 * tx), ty * ty * (3 - 2 * ty)
        top = grid[y0][x0] * (1 - tx) + grid[y0][x1] * tx
        bot = grid[y1][x0] * (1 - tx) + grid[y1][x1] * tx
        return top * (1 - ty) + bot * ty

    return at


def dyed_obsidian(seed=21):
    """Obsidiana teñida (Vacío): casi negra, con vetas violeta y destellos como en la armadura del Vacío."""
    rnd = random.Random(seed)
    low, fine = noise_field(rnd, cell=8), noise_field(rnd, cell=4)
    img = Image.new("RGBA", (16, 16))
    px = img.load()
    for y in range(16):
        for x in range(16):
            v = 0.6 * low(x, y) + 0.4 * fine(x, y)
            c = ramp(VOID, v * 0.55)                       # cuerpo oscuro
            if v > 0.62 and rnd.random() < 0.55:
                c = VOID_SPARK[0] if v < 0.72 else rnd.choice(VOID_SPARK[:3])   # vetas violeta
            elif rnd.random() < 0.04:
                c = VOID_SPARK[3]                          # chispa clara suelta
            px[x, y] = (*c, 255)
    return img


def dyed_crying_obsidian(seed=33):
    """Obsidiana llorosa teñida (Fin): base morada muy oscura con \"lágrimas\" en tonos purpur (como la llorosa vanilla)."""
    rnd = random.Random(seed)
    low, fine = noise_field(rnd, cell=8), noise_field(rnd, cell=4)
    img = Image.new("RGBA", (16, 16))
    px = img.load()
    for y in range(16):
        for x in range(16):
            v = 0.5 * low(x, y) + 0.5 * fine(x, y)
            c = tuple(round(k * 0.45) for k in ramp(END, v * 0.2))   # base: purpur casi negro
            if v > 0.68:
                t = min(1.0, (v - 0.68) / 0.2)
                c = ramp(END, 0.38 + 0.4 * t)              # lágrimas purpur
                if t > 0.7 and rnd.random() < 0.45:
                    c = ramp(END, 0.85)
            elif rnd.random() < 0.05:
                c = ramp(END, 0.6)                         # gotas sueltas
            px[x, y] = (*c, 255)
    return img


def main(out_dir):
    item_dir = os.path.join(out_dir, "item")
    block_dir = os.path.join(out_dir, "block")
    os.makedirs(item_dir, exist_ok=True)
    os.makedirs(block_dir, exist_ok=True)
    src = Image.open(SHAPE).convert("RGBA")
    recolor_void(src, seed=13).save(os.path.join(item_dir, "void_template.png"))
    recolor_end(src, seed=17).save(os.path.join(item_dir, "end_template.png"))
    dyed_obsidian().save(os.path.join(block_dir, "dyed_obsidian.png"))
    dyed_crying_obsidian().save(os.path.join(block_dir, "dyed_crying_obsidian.png"))
    print("Texturas generadas en", out_dir)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
