"""
Genera las texturas de las herramientas infernales (espada, hacha, pico, pala, azada y lanza) a partir de la netherite vanilla,
con la misma paleta que la Armadura Infernal (make_infernal_armor.py): granate/rojo oscuro casi negro con vetas de lava
y alguna chispa de brasa. Mismo modelo, tamaño y forma que la netherite; solo cambian los colores.

  - Contorno y mango: rojos muy oscuros (sin vetas).
  - Hoja / cabeza: rampa granate -> rojo -> naranja, con vetas de lava y destellos de brasa repartidos al azar (semilla fija).

Uso:  python3 make_infernal_tools.py <carpeta_resourcepack>/assets/infernal/textures/item
Las fuentes vanilla están en tools/vanilla_netherite/netherite_<herramienta>.png.
"""
import os
import sys
import random
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "vanilla_netherite")
TOOLS = ["sword", "axe", "pickaxe", "shovel", "hoe", "spear", "spear_in_hand"]


def hexc(s):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


# color de netherite vanilla -> color infernal (contorno y mango: sin vetas)
BASE = {
    "#160814": "#0D0203", "#231012": "#160204", "#1B1415": "#1C0305",              # contorno
    "#2F2122": "#2A0607", "#322727": "#300808", "#31292A": "#300808", "#3C3232": "#3F0A0A",  # mango oscuro
    "#4A293E": "#4A0A0C", "#4A2940": "#4A0A0C",                                    # remate morado -> granate
    "#4F3C3E": "#4E0F0C", "#603432": "#6A1810", "#734543": "#8A2417",              # mango claro
    "#4B3F46": "#5A0E0C", "#51444E": "#5A0E0C",
}
# hoja / cabeza: color vanilla -> rampa infernal (mismos tonos que la armadura y la Espada Infernal)
HEAD = {
    "#3B393B": "#3A0709", "#434043": "#4A0A0C", "#584E56": "#7A1410",
    "#5D565D": "#8C1A14", "#706770": "#C42A12", "#867B86": "#E8590C",
}
# un paso más caliente para las vetas (solo en la hoja / cabeza)
HOTTER = {
    "#3A0709": "#5A0E0C", "#4A0A0C": "#7A1410", "#7A1410": "#A81E14",
    "#8C1A14": "#C42A12", "#C42A12": "#E8590C", "#E8590C": "#FF8A1A",
}
EMBER = ["#FFC425", "#FFE066"]


def recolor(src, seed):
    rnd = random.Random(seed)
    out = Image.new("RGBA", src.size, (0, 0, 0, 0))
    sp, dp = src.load(), out.load()
    for y in range(src.height):
        for x in range(src.width):
            r, g, b, a = sp[x, y]
            if a == 0:
                continue
            key = "#%02X%02X%02X" % (r, g, b)
            if key in BASE:
                c = BASE[key]
            elif key in HEAD:
                c = HEAD[key]
                if rnd.random() < 0.28 and c in HOTTER:
                    c = HOTTER[c]
                if c in ("#E8590C", "#FF8A1A") and rnd.random() < 0.18:
                    c = rnd.choice(EMBER)
            else:
                raise SystemExit(f"Color sin mapear {key} en la textura de netherite")
            dp[x, y] = (*hexc(c), a)
    return out


def main(out_dir):
    os.makedirs(out_dir, exist_ok=True)
    for i, t in enumerate(TOOLS):
        src = Image.open(os.path.join(SRC, f"netherite_{t}.png")).convert("RGBA")
        recolor(src, 700 + i).save(os.path.join(out_dir, f"infernal_{t}.png"))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Uso: python3 make_infernal_tools.py <ruta>/assets/infernal/textures/item")
    main(sys.argv[1])
