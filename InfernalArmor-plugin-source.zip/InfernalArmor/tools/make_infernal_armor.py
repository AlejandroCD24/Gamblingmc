"""
Genera las texturas de la Armadura Infernal a partir de la netherite vanilla
(mismo modelo, mismo tamaño y mismo sombreado; solo cambia la paleta y se añaden detalles),
igual que make_void_end_armor.py hace con el Vacío y el Fin.

  Infernal -> netherite ennegrecida con tonos granate/rojo sangre y vetas de lava (naranja) con
              destellos de brasa amarillos, como el magma del Nether. El contorno oscuro no lleva detalle.

Uso:  python3 make_infernal_armor.py <carpeta_resourcepack>/assets/infernal/textures
Las fuentes vanilla están en tools/vanilla_netherite/ (iconos 16x16 y capas de armadura 64x32).

Salida:
  item/infernal_helmet|chestplate|leggings|boots.png            (iconos 16x16)
  entity/equipment/humanoid/infernal.png                        (casco, peto y botas puestos)
  entity/equipment/humanoid_leggings/infernal.png               (pantalones puestos)
"""
import os
import sys
import random
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "vanilla_netherite")

ICONS = ["helmet", "chestplate", "leggings", "boots"]
LUM_LO, LUM_HI = 10.0, 118.0   # rango de luminancia de la netherite vanilla


def hexc(s):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def lerp(a, b, f):
    return tuple(round(a[i] + (b[i] - a[i]) * f) for i in range(3))


def ramp(stops, t):
    t = max(0.0, min(1.0, t))
    for i in range(len(stops) - 1):
        t0, c0 = stops[i]
        t1, c1 = stops[i + 1]
        if t <= t1:
            return lerp(c0, c1, (t - t0) / (t1 - t0) if t1 > t0 else 0)
    return stops[-1][1]


def lum(p):
    return 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]


def norm(p):
    return (lum(p) - LUM_LO) / (LUM_HI - LUM_LO)


# ------------------------------------------------------------------ paleta
# Mismos colores que la Espada Infernal (contorno #160204, granates, naranjas de lava).
INFERNAL = [
    (0.00, hexc("#0D0203")),
    (0.18, hexc("#230403")),
    (0.38, hexc("#4A0A0C")),
    (0.60, hexc("#7A1410")),
    (0.80, hexc("#A81E14")),
    (1.00, hexc("#C8301A")),
]
# vetas de lava: del rojo ardiente al naranja; destellos de brasa amarillos en las zonas más claras
LAVA = [hexc("#C42A12"), hexc("#E8590C"), hexc("#FF8A1A")]
EMBER = [hexc("#FF8A1A"), hexc("#FFC425"), hexc("#FFE066")]


def recolor_infernal(src, seed):
    rnd = random.Random(seed)
    out = Image.new("RGBA", src.size, (0, 0, 0, 0))
    sp, dp = src.load(), out.load()
    for y in range(src.height):
        for x in range(src.width):
            p = sp[x, y]
            if p[3] == 0:
                continue
            t = norm(p)
            c = ramp(INFERNAL, t)
            # vetas de lava: solo en medios tonos y claros, nunca en el contorno oscuro.
            # Predomina el rojo; el naranja es menos frecuente y el amarillo solo aparece como chispa suelta.
            if 0.12 < t < 0.75 and rnd.random() < 0.16:
                c = LAVA[0] if t < 0.4 else rnd.choice(LAVA[:2])
            elif t >= 0.75 and rnd.random() < 0.40:
                c = rnd.choice([LAVA[0], LAVA[0], LAVA[1], LAVA[1], LAVA[2]])
                if rnd.random() < 0.10:
                    c = rnd.choice(EMBER[1:])
            dp[x, y] = (*c, p[3])
    return out


def main(out_root):
    os.makedirs(os.path.join(out_root, "item"), exist_ok=True)
    for sub in ("humanoid", "humanoid_leggings"):
        os.makedirs(os.path.join(out_root, "entity", "equipment", sub), exist_ok=True)

    for i, piece in enumerate(ICONS):
        src = Image.open(os.path.join(SRC, f"netherite_{piece}.png")).convert("RGBA")
        recolor_infernal(src, 500 + i).save(os.path.join(out_root, "item", f"infernal_{piece}.png"))

    layers = {
        "humanoid": "netherite_humanoid.png",
        "humanoid_leggings": "netherite_leggings_layer.png",
    }
    for sub, fname in layers.items():
        src = Image.open(os.path.join(SRC, fname)).convert("RGBA")
        recolor_infernal(src, 600 + len(sub)).save(
            os.path.join(out_root, "entity", "equipment", sub, "infernal.png"))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Uso: python3 make_infernal_armor.py <ruta>/assets/infernal/textures")
    main(sys.argv[1])
