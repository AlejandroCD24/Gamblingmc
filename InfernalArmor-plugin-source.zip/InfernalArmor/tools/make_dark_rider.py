#!/usr/bin/env python3
"""Genera el caballo y la silla del Jinete Oscuro para el resource pack.

El caballo esqueleto no puede llevar armadura de caballo, y su textura es la misma para todos (no se puede cambiar para uno
solo). Por eso el caballo del Jinete Oscuro es un caballo zombi INVISIBLE que lleva una "armadura" con la textura de un
caballo esqueleto negro: las capas de equipo se siguen dibujando aunque el mob sea invisible, así que se ve un caballo
esqueleto negro. No se cambia ninguna textura vanilla: los caballos esqueleto y zombi normales se ven como siempre.
La silla también es propia (cuero negro con herrajes de netherite).

  textures/entity/equipment/horse_body/dark_rider.png    caballo esqueleto en los tonos del esqueleto wither (64x64)
  textures/entity/equipment/horse_saddle/dark_rider.png  silla negra con herrajes de netherite (64x64)
  equipment/dark_rider.json                              capas horse_body y horse_saddle

Entradas (texturas vanilla): tools/vanilla_dark_rider/horse_skeleton.png y saddle.png.
Uso: python3 make_dark_rider.py <carpeta tools/vanilla_dark_rider> <carpeta resourcepack/assets/infernal>
"""
import json
import os
import sys

from PIL import Image

SRC = sys.argv[1] if len(sys.argv) > 1 else "vanilla_dark_rider"
DST = sys.argv[2] if len(sys.argv) > 2 else "../resourcepack/assets/infernal"
NS = "infernal"

# Huesos del caballo esqueleto -> tonos del esqueleto wither (misma escala de claro a oscuro).
HORSE = {
    (227, 227, 227): (75, 77, 77), (211, 211, 211): (60, 65, 65), (203, 201, 201): (52, 52, 52),
    (188, 188, 188): (46, 46, 46), (173, 171, 173): (41, 41, 41), (165, 165, 165): (36, 36, 36),
    (151, 151, 151): (31, 31, 31), (142, 141, 142): (27, 27, 27), (121, 118, 118): (24, 24, 24),
    (99, 99, 99): (20, 20, 20), (73, 73, 73): (16, 16, 16), (30, 30, 30): (10, 10, 10), (13, 13, 13): (5, 5, 5),
}
# Silla: cuero marrón -> cuero negro con un toque rojizo; hierro -> netherite.
SADDLE = {
    (78, 44, 19): (26, 20, 22), (89, 51, 23): (33, 26, 28), (97, 58, 29): (40, 31, 33),
    (111, 66, 31): (48, 37, 39), (118, 73, 40): (56, 43, 45), (138, 85, 46): (68, 52, 54),
    (81, 81, 81): (74, 41, 64), (99, 99, 99): (93, 86, 93), (113, 113, 113): (112, 103, 112),
}


def recolor(src, dst, table):
    im = Image.open(src).convert("RGBA")
    out = im.copy()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = im.getpixel((x, y))
            if not a:
                continue
            if (r, g, b) not in table:
                raise SystemExit(f"{src}: color sin traducir {(r, g, b)} en {(x, y)}")
            out.putpixel((x, y), (*table[(r, g, b)], a))
    out.save(dst)


def main():
    body = os.path.join(DST, "textures/entity/equipment/horse_body")
    saddle = os.path.join(DST, "textures/entity/equipment/horse_saddle")
    for d in (body, saddle, os.path.join(DST, "equipment")):
        os.makedirs(d, exist_ok=True)
    recolor(os.path.join(SRC, "horse_skeleton.png"), os.path.join(body, "dark_rider.png"), HORSE)
    recolor(os.path.join(SRC, "saddle.png"), os.path.join(saddle, "dark_rider.png"), SADDLE)
    with open(os.path.join(DST, "equipment/dark_rider.json"), "w", encoding="utf-8") as f:
        json.dump({"layers": {
            "horse_body": [{"texture": f"{NS}:dark_rider"}],
            "horse_saddle": [{"texture": f"{NS}:dark_rider"}],
        }}, f, indent=2)
        f.write("\n")
    print("ok")


if __name__ == "__main__":
    main()
