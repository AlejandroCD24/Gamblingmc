#!/usr/bin/env python3
"""Genera el Tridente Infernal del resource pack a partir del Tridente de Netherite (hay que generar antes ese con
make_netherite_trident.py).

Mismos modelos (icono plano, modelo 3D en la mano, al apuntar y lanzado) con los colores infernales de la espada y la lanza
infernal: puntas de lava (amarillo/naranja) y asta granate oscuro.

Uso: python3 make_infernal_trident.py <carpeta resourcepack/assets/infernal>
"""
import json
import os
import sys

from PIL import Image

DST = sys.argv[1] if len(sys.argv) > 1 else "../resourcepack/assets/infernal"
NS = "infernal"
SRC_NAME, NAME = "netherite_trident", "infernal_trident"

ICON = {
    # puntas -> lava
    (134, 123, 134): (255, 196, 37), (112, 103, 112): (255, 138, 26), (93, 86, 93): (232, 89, 12),
    (74, 41, 64): (140, 26, 20),
    # asta -> granate
    (88, 78, 86): (106, 24, 16), (67, 64, 67): (74, 10, 12), (49, 41, 42): (48, 8, 8), (35, 16, 18): (22, 2, 4),
}
IN_HAND = {
    (134, 123, 134): (255, 196, 37), (128, 117, 128): (255, 170, 32), (112, 103, 112): (255, 138, 26),
    (104, 95, 104): (232, 89, 12), (93, 86, 93): (196, 42, 18), (81, 68, 78): (140, 26, 20),
    (88, 78, 86): (106, 24, 16), (75, 63, 70): (90, 14, 12), (67, 64, 67): (74, 10, 12),
    (60, 50, 50): (58, 7, 9), (49, 41, 42): (42, 6, 7),
}


def recolor(src, dst, table):
    im = Image.open(src).convert("RGBA")
    out = im.copy()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = im.getpixel((x, y))
            if not a:
                continue
            if (r, g, b) not in table:
                raise SystemExit(f"{src}: color sin traducir {(r, g, b)} en {(x, y)}")
            out.putpixel((x, y), (*table[(r, g, b)], a))
    out.save(dst)


def convert_json(src, dst):
    with open(src, encoding="utf-8") as f:
        text = f.read()
    text = text.replace(f"{NS}:item/{SRC_NAME}", f"{NS}:item/{NAME}")
    json.loads(text)
    with open(dst, "w", encoding="utf-8") as f:
        f.write(text)


def main():
    tex = os.path.join(DST, "textures/item")
    models = os.path.join(DST, "models/item")
    items = os.path.join(DST, "items")
    recolor(os.path.join(tex, f"{SRC_NAME}.png"), os.path.join(tex, f"{NAME}.png"), ICON)
    recolor(os.path.join(tex, f"{SRC_NAME}_in_hand.png"), os.path.join(tex, f"{NAME}_in_hand.png"), IN_HAND)
    for suffix in ("", "_in_hand", "_throwing"):
        convert_json(os.path.join(models, f"{SRC_NAME}{suffix}.json"), os.path.join(models, f"{NAME}{suffix}.json"))
    convert_json(os.path.join(items, f"{SRC_NAME}.json"), os.path.join(items, f"{NAME}.json"))
    print("ok")


if __name__ == "__main__":
    main()
