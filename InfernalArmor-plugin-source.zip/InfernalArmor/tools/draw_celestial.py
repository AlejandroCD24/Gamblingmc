import random
from PIL import Image

O=(92,34,80,255); D=(143,61,127,255); M=(210,107,176,255); L=(242,160,210,255); W=(251,208,234,255); Wh=(255,240,248,255)
T=(0,0,0,0)

# ---------------- iconos 16x16 (silueta -> sombreado automático estilo netherite) ----------------
SIL={
'helmet':["................","................","................","....########....","...##########...","..############..","..############..","..############..","..####....####..","..###......###..","..###......###..","..###......###..","................","................","................","................"],
'chestplate':["................","..####....####..",".######..######.",".##############.",".##############.",".##############.",".##############.",".##############.",".###.######.###.",".###.######.###.",".###.######.###.","..##.######.##..","..############..","..############..","..############..","................"],
'leggings':["................","................","..############..","..############..","..############..","..############..","..####....####..","..####....####..","..####....####..","..####....####..","..####....####..","..####....####..","..####....####..","..###......###..","................","................"],
'boots':["................","................","................","................","................","..#####..#####..","..#####..#####..","..#####..#####..","..#####..#####..",".######..######.",".######..######.",".######..######.","................","................","................","................"],
}
# líneas de detalle (color D) por pieza: lista de (x,y)
DETAIL={
'helmet':[(x,7) for x in range(3,13)]+[(5,8),(10,8)],
'chestplate':[(7,3),(8,3),(7,4),(8,4),(7,5),(8,5),(7,6),(8,6)]+[(x,12) for x in range(3,13)]+[(4,8),(11,8)],
'leggings':[(x,2) for x in range(2,14)]+[(7,2),(8,2)]+[(3,8),(4,8),(5,8),(10,8),(11,8),(12,8)],
'boots':[(x,9) for x in (2,3,4,5,6,9,10,11,12,13)]+[(3,5),(4,5),(11,5),(12,5)],
}
def icon(name):
    s=SIL[name]; H=len(s); filled=lambda x,y: 0<=x<16 and 0<=y<16 and s[y][x]=='#'
    rnd=random.Random(hash(name)%1000+7)
    im=Image.new('RGBA',(16,16),T); px=im.load()
    for y in range(16):
        for x in range(16):
            if not filled(x,y): continue
            n=[filled(x,y-1),filled(x,y+1),filled(x-1,y),filled(x+1,y)]
            if not all(n): px[x,y]=O; continue
            up,dn,lf,rt=[not filled(x,y-1) or not filled_edge(filled,x,y-1),0,0,0] if False else (0,0,0,0)
            def edge(a,b): # vecino es contorno?
                return (not filled(a,b)) or not all([filled(a,b-1),filled(a,b+1),filled(a-1,b),filled(a+1,b)])
            c=M
            if edge(x,y-1) or edge(x-1,y): c=L
            if edge(x,y+1) or edge(x+1,y): c=D
            if c==M and rnd.random()<0.13: c=rnd.choice([L,D])
            px[x,y]=c
    for (x,y) in DETAIL[name]:
        if filled(x,y) and px[x,y]!=O: px[x,y]=D
    # brillos
    hl={'helmet':[(4,5),(5,4),(5,5)],'chestplate':[(3,4),(4,3),(3,5),(2,2)],'leggings':[(3,4),(4,3),(3,5)],'boots':[(3,6),(3,7),(12,6)]}[name]
    for (x,y) in hl:
        if filled(x,y) and px[x,y] not in (O,): px[x,y]=W
    return im

# ---------------- armadura puesta (64x32) ----------------
def plate(img,x,y,w,h,rnd,bands=(),dark_rows=(),dark_cols=(),clear=()):
    px=img.load()
    for j in range(h):
        for i in range(w):
            if (i,j) in clear: continue
            c=M
            if j==0: c=L
            if i==0 and c!=L: c=L
            if j==h-1: c=D
            if i==w-1 and j>0: c=D
            if c==M and rnd.random()<0.16: c=rnd.choice([L,D,M])
            if j in dark_rows or i in dark_cols: c=D
            px[x+i,y+j]=c
    # remaches en las esquinas
    for (i,j) in ((1,1),(w-2,1)):
        if w>=6 and h>=6: px[x+i,y+j]=W

def worn(layer):
    img=Image.new('RGBA',(64,32),T); r=random.Random(layer*13+3)
    if layer==1:
        # casco: cabeza
        plate(img,8,0,8,8,r)                          # arriba
        for ox in (0,16): plate(img,ox,8,8,5,r,dark_rows=(4,))   # lados
        plate(img,24,8,8,8,r,dark_rows=(7,))          # atrás
        plate(img,8,8,8,4,r,dark_rows=(3,))           # frente (frente + ceja)
        for ox in (8,14): plate(img,ox,12,2,3,r)      # carrilleras
        # peto
        plate(img,20,16,8,4,r); plate(img,28,16,8,4,r)
        plate(img,20,20,8,12,r,dark_cols=(3,),dark_rows=(11,))
        plate(img,32,20,8,12,r,dark_rows=(11,))
        plate(img,16,20,4,12,r,dark_rows=(11,)); plate(img,28,20,4,12,r,dark_rows=(11,))
        # brazos (hombreras)
        plate(img,44,16,4,4,r); plate(img,48,16,4,4,r)
        for ox in (40,44,48,52): plate(img,ox,20,4,12,r,dark_rows=(4,10))
        # botas (pierna, filas 7-11)
        plate(img,4,16,4,4,r); plate(img,8,16,4,4,r,dark_rows=(0,))
        for ox in (0,4,8,12): plate(img,ox,27,4,5,r,dark_rows=(0,))
    else:
        # cinturón (cuerpo, filas 8-11)
        plate(img,20,28,8,4,r,dark_rows=(0,),dark_cols=(3,4)); plate(img,32,28,8,4,r,dark_rows=(0,))
        plate(img,16,28,4,4,r,dark_rows=(0,)); plate(img,28,28,4,4,r,dark_rows=(0,))
        # piernas completas
        plate(img,4,16,4,4,r); plate(img,8,16,4,4,r)
        for ox in (0,4,8,12): plate(img,ox,20,4,12,r,dark_rows=(3,6))
    return img

if __name__=='__main__':
    import sys
    out=sys.argv[1]
    import os
    os.makedirs(out+'/item',exist_ok=True); os.makedirs(out+'/entity/equipment/humanoid',exist_ok=True); os.makedirs(out+'/entity/equipment/humanoid_leggings',exist_ok=True)
    for n in SIL: icon(n).save(f'{out}/item/celestial_{n}.png')
    worn(1).save(f'{out}/entity/equipment/humanoid/celestial.png'); worn(2).save(f'{out}/entity/equipment/humanoid_leggings/celestial.png')
