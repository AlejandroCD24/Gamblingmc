#!/usr/bin/env python3
"""Genera el escudo del Wildfire para el resource pack (textura, modelo y definición del objeto).

El Wildfire es un blaze más grande rodeado de 4 escudos que giran. Los escudos son item displays montados encima del
blaze con el modelo infernal:wildfire_shield: una placa de piedra negra del Nether con borde y grietas de lava.

Uso: python3 make_wildfire.py <carpeta resourcepack/assets/infernal>
"""
import json
import os
import random
import sys

from PIL import Image

DST = sys.argv[1] if len(sys.argv) > 1 else "../resourcepack/assets/infernal"
NS = "infernal"

STONE = [(34, 24, 28), (42, 30, 34), (50, 36, 38), (58, 42, 42)]
EDGE_DARK = (24, 16, 20)
LAVA = [(255, 214, 92), (255, 160, 40), (230, 96, 20), (160, 52, 18)]

# Placa de 12x16 (x 2..13 de la textura). L = lava, l = lava oscura, E = borde oscuro, '.' = piedra.
PLATE = [
    "EEEEEEEEEEEE",
    "ELLLLLLLLLLE",
    "EL........LE",
    "EL..l.....LE",
    "EL..L..l..LE",
    "EL...L.L..LE",
    "EL...LL...LE",
    "EL....L...LE",
    "EL...LL...LE",
    "EL..L..L..LE",
    "EL.l....L.LE",
    "EL......l.LE",
    "EL........LE",
    "ELLLLLLLLLLE",
    "EllllllllllE",
    "EEEEEEEEEEEE",
]


def texture(dst):
    rnd = random.Random(7)
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y, row in enumerate(PLATE):
        for x, ch in enumerate(row):
            if ch == "E":
                c = EDGE_DARK
            elif ch == "L":
                c = LAVA[1] if (x + y) % 3 else LAVA[0]
            elif ch == "l":
                c = LAVA[2]
            else:
                c = STONE[rnd.randrange(len(STONE))]
            im.putpixel((2 + x, y), (*c, 255))
    # canto de la placa (x 0..1): lava oscura con piedra
    for y in range(16):
        im.putpixel((0, y), (*(LAVA[3] if y % 4 else EDGE_DARK), 255))
        im.putpixel((1, y), (*(LAVA[2] if y % 4 else LAVA[3]), 255))
    im.save(dst)


def main():
    for d in ("textures/item", "models/item", "items"):
        os.makedirs(os.path.join(DST, d), exist_ok=True)
    texture(os.path.join(DST, "textures/item/wildfire_shield.png"))
    face = {"uv": [2, 0, 14, 16], "texture": "#shield"}
    edge = {"uv": [0, 0, 2, 16], "texture": "#shield"}
    top = {"uv": [0, 0, 2, 12], "texture": "#shield", "rotation": 90}
    model = {
        "textures": {"shield": f"{NS}:item/wildfire_shield", "particle": f"{NS}:item/wildfire_shield"},
        "elements": [{
            "from": [2, 0, 7],
            "to": [14, 16, 9],
            "faces": {"north": face, "south": face, "east": edge, "west": edge, "up": top, "down": top},
        }],
    }
    with open(os.path.join(DST, "models/item/wildfire_shield.json"), "w", encoding="utf-8") as f:
        json.dump(model, f, indent=2)
        f.write("\n")
    with open(os.path.join(DST, "items/wildfire_shield.json"), "w", encoding="utf-8") as f:
        json.dump({"model": {"type": "minecraft:model", "model": f"{NS}:item/wildfire_shield"}}, f, indent=2)
        f.write("\n")
    print("ok")


if __name__ == "__main__":
    main()
