package dev.infernal.armor;

import org.bukkit.entity.ComplexEntityPart;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.inventory.ItemStack;

import java.util.EnumSet;
import java.util.Set;

/**
 * Bonos de daño por tipo de mob (solo el golpe directo del jugador con el arma en la mano principal, incluido el barrido;
 * la Espada y las herramientas -hacha, pico, pala, azada y lanza- infernales o celestiales comparten el mismo bono):
 *  - Espada Infernal: +45% (config infernal-sword-nether-multiplier) contra los mobs del Nether:
 *    blaze, piglin, piglin brute, zombified piglin, ghast, wither skeleton, wither, magma cube, hoglin y zoglin.
 *  - Espada Celestial: +20% (config celestial-sword-hostile-multiplier) contra los mobs hostiles de la lista HOSTILE_MOBS
 *    EXCEPTO los del Nether (NETHER_MOBS), que son los que ya reciben el bono de la Espada Infernal.
 */
public final class NetherDamageListener implements Listener {

    static final Set<EntityType> NETHER_MOBS = EnumSet.of(
            EntityType.BLAZE,
            EntityType.PIGLIN,
            EntityType.PIGLIN_BRUTE,
            EntityType.ZOMBIFIED_PIGLIN,
            EntityType.GHAST,
            EntityType.WITHER_SKELETON,
            EntityType.WITHER,
            EntityType.MAGMA_CUBE,
            EntityType.HOGLIN,
            EntityType.ZOGLIN);

    /** Mobs del End: la armadura del Vacío y la del Fin protegen contra ellos (el phantom cuenta como mob del End). */
    static final Set<EntityType> END_MOBS = EnumSet.of(
            EntityType.ENDERMAN,
            EntityType.ENDERMITE,
            EntityType.SHULKER,
            EntityType.ENDER_DRAGON,
            EntityType.PHANTOM);

    private static final Set<EntityType> HOSTILE_MOBS = EnumSet.of(
            EntityType.WITHER_SKELETON,
            EntityType.ZOMBIFIED_PIGLIN,
            EntityType.MAGMA_CUBE,
            EntityType.GHAST,
            EntityType.CREEPER,
            EntityType.ZOMBIE,
            EntityType.HUSK,
            EntityType.DROWNED,
            EntityType.ZOMBIE_VILLAGER,
            EntityType.SKELETON,
            EntityType.STRAY,
            EntityType.BOGGED,
            EntityType.SPIDER,
            EntityType.CAVE_SPIDER,
            EntityType.SILVERFISH,
            EntityType.SLIME,
            EntityType.BLAZE,
            EntityType.VEX,
            EntityType.WITCH,
            EntityType.PILLAGER,
            EntityType.EVOKER,
            EntityType.RAVAGER,
            EntityType.HOGLIN,
            EntityType.ZOGLIN,
            EntityType.GUARDIAN,
            EntityType.BREEZE,
            EntityType.CREAKING,
            EntityType.IRON_GOLEM,
            EntityType.PIGLIN,
            EntityType.PIGLIN_BRUTE,
            EntityType.VINDICATOR,
            EntityType.WITHER,
            EntityType.ELDER_GUARDIAN);

    /** Mobs que reciben el bono de la Espada Celestial: los hostiles menos los del Nether (esos son de la Infernal). */
    static final Set<EntityType> CELESTIAL_MOBS = EnumSet.copyOf(HOSTILE_MOBS);

    static {
        CELESTIAL_MOBS.removeAll(NETHER_MOBS);
    }

    private final InfernalItems items;

    public NetherDamageListener(InfernalItems items) {
        this.items = items;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;

        DamageCause cause = event.getCause();
        if (cause != DamageCause.ENTITY_ATTACK && cause != DamageCause.ENTITY_SWEEP_ATTACK) return;

        ItemStack weapon = player.getInventory().getItemInMainHand();

        // El Ender Dragon recibe el golpe en una de sus partes: se usa la entidad principal.
        Entity target = event.getEntity();
        if (target instanceof ComplexEntityPart part) target = part.getParent();
        EntityType type = target.getType();

        // Espada y herramientas infernales: bono contra los mobs del Nether.
        // Espada y herramientas celestiales: bono contra los demás hostiles.
        if ((items.isInfernalSword(weapon) || items.isInfernalTool(weapon)) && NETHER_MOBS.contains(type)) {
            event.setDamage(event.getDamage() * items.infernalNetherMultiplier());
        } else if ((items.isCelestialSword(weapon) || items.isCelestialTool(weapon)) && CELESTIAL_MOBS.contains(type)) {
            event.setDamage(event.getDamage() * items.celestialHostileMultiplier());
        }
    }
}
