package dev.infernal.armor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.bukkit.Bukkit;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.CrafterCraftEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ComplexRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;

/**
 * Bloquea el crafteo (mesa de crafteo, inventario y crafter) de armaduras, espadas y herramientas.
 * Además, con block-crafting.remove-recipes, borra esas recetas del juego al arrancar ({@link #removeRecipes()}):
 * así desaparecen del libro de recetas y no se pueden craftear de ninguna forma (ni con permisos). Se restauran al apagar.
 * No toca la mesa de herrería, así que las mejoras de netherite e infernales siguen funcionando.
 * Tampoco toca las recetas especiales (reparar combinando dos piezas, teñir armadura de cuero)
 * ni las recetas propias de este plugin.
 */
public class CraftBlockListener implements Listener {

    static final String BYPASS_PERMISSION = "infernalarmor.craft.bypass";

    private static final String[] ARMOR = {"_HELMET", "_CHESTPLATE", "_LEGGINGS", "_BOOTS"};
    private static final String[] SWORDS = {"_SWORD", "_SPEAR"};
    private static final String[] TOOLS = {"_PICKAXE", "_AXE", "_SHOVEL", "_HOE"};

    private final boolean blockArmor;
    private final boolean blockSwords;
    private final boolean blockTools;
    private final String ownNamespace;
    private final List<Recipe> removed = new ArrayList<>();

    public CraftBlockListener(boolean blockArmor, boolean blockSwords, boolean blockTools, String ownNamespace) {
        this.blockArmor = blockArmor;
        this.blockSwords = blockSwords;
        this.blockTools = blockTools;
        this.ownNamespace = ownNamespace;
    }

    private static boolean endsWithAny(String name, String[] suffixes) {
        for (String s : suffixes) {
            if (name.endsWith(s)) {
                return true;
            }
        }
        return false;
    }

    boolean isBlockedMaterial(Material material) {
        String name = material.name().toUpperCase(Locale.ROOT);
        return (blockArmor && endsWithAny(name, ARMOR))
                || (blockSwords && endsWithAny(name, SWORDS))
                || (blockTools && endsWithAny(name, TOOLS));
    }

    boolean isBlocked(Recipe recipe, ItemStack result) {
        if (result == null) {
            return false;
        }
        if (recipe instanceof ComplexRecipe) {
            return false; // reparar, teñir armadura de cuero, etc.
        }
        if (recipe instanceof Keyed keyed && ownNamespace.equals(keyed.getKey().getNamespace())) {
            return false; // recetas propias del plugin
        }
        return isBlockedMaterial(result.getType());
    }

    /**
     * Borra del juego las recetas de crafteo (con forma o sin forma) cuyo resultado esté bloqueado, salvo las de este plugin.
     * No toca la mesa de herrería (mejora a netherite y diseños), ni las recetas especiales (reparar, teñir cuero...),
     * ni hornos, cortapiedras, etc. Devuelve cuántas recetas ha borrado.
     */
    int removeRecipes() {
        List<Recipe> toRemove = new ArrayList<>();
        Iterator<Recipe> it = Bukkit.recipeIterator();
        while (it.hasNext()) {
            Recipe recipe = it.next();
            if (!(recipe instanceof ShapedRecipe) && !(recipe instanceof ShapelessRecipe)) continue;
            if (isBlocked(recipe, recipe.getResult())) toRemove.add(recipe);
        }
        for (Recipe recipe : toRemove) {
            if (Bukkit.removeRecipe(((Keyed) recipe).getKey())) removed.add(recipe);
        }
        return removed.size();
    }

    /** Vuelve a añadir las recetas borradas (al apagar o recargar el plugin). */
    void restoreRecipes() {
        for (Recipe recipe : removed) {
            try {
                Bukkit.addRecipe(recipe);
            } catch (IllegalStateException ignored) {
                // ya existía (otro plugin la volvió a añadir)
            }
        }
        removed.clear();
    }

    private static boolean hasBypass(HumanEntity human) {
        return human != null && human.hasPermission(BYPASS_PERMISSION);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepare(PrepareItemCraftEvent event) {
        if (event.isRepair()) {
            return;
        }
        Recipe recipe = event.getRecipe();
        ItemStack result = event.getInventory().getResult();
        if (recipe == null || !isBlocked(recipe, result)) {
            return;
        }
        for (HumanEntity viewer : event.getViewers()) {
            if (hasBypass(viewer)) {
                return;
            }
        }
        event.getInventory().setResult(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCraft(CraftItemEvent event) {
        if (isBlocked(event.getRecipe(), event.getCurrentItem()) && !hasBypass(event.getWhoClicked())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCrafter(CrafterCraftEvent event) {
        if (isBlocked(event.getRecipe(), event.getResult())) {
            event.setCancelled(true);
        }
    }
}
