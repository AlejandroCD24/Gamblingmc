package dev.infernal.armor;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;

public final class InfernalArmorPlugin extends JavaPlugin {

    private InfernalRecipes recipes;
    private ReinforcedShulkerListener reinforcedShulkers;
    private DyeNetheriteListener dyeNetherite;
    private CraftBlockListener craftBlock;
    private NetheriteTridentListener netheriteTrident;
    private InfernalTridentListener infernalTrident;
    private WildfireListener wildfire;
    private DarkRiderListener darkRider;
    private PiglinGuardianListener piglinGuardian;
    private RoyalSkeletonListener royalSkeleton;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        InfernalItems items = new InfernalItems(this);
        String namespace = getName().toLowerCase(Locale.ROOT);

        recipes = new InfernalRecipes(this, items);
        recipes.register();
        getLogger().info("Armaduras solo por comando -> mejoras bloqueadas: " + items.armorUpgradesBlocked()
                + " (Armadura Infernal permitida: " + items.infernalArmorAllowed() + ")"
                + ", recetas del plugin sin registrar: " + recipes.blockedCount());

        getServer().getPluginManager().registerEvents(new ProtectionListener(items, namespace), this);
        reinforcedShulkers = new ReinforcedShulkerListener(this, items);
        getServer().getPluginManager().registerEvents(reinforcedShulkers, this);
        getServer().getPluginManager().registerEvents(new SmithingListener(items), this);
        getServer().getPluginManager().registerEvents(new NetherDamageListener(items), this);
        getServer().getPluginManager().registerEvents(new ArmorDefenseListener(items), this);
        netheriteTrident = new NetheriteTridentListener(this, items);
        getServer().getPluginManager().registerEvents(netheriteTrident, this);
        netheriteTrident.start();
        infernalTrident = new InfernalTridentListener(this, items);
        getServer().getPluginManager().registerEvents(infernalTrident, this);
        infernalTrident.start();
        getServer().getPluginManager().registerEvents(new YinYangMaceListener(this, items), this);
        getServer().getPluginManager().registerEvents(new BastionLootListener(this, items), this);
        wildfire = new WildfireListener(this, items);
        getServer().getPluginManager().registerEvents(wildfire, this);
        wildfire.start();
        darkRider = new DarkRiderListener(this);
        getServer().getPluginManager().registerEvents(darkRider, this);
        darkRider.start();
        piglinGuardian = new PiglinGuardianListener(this);
        getServer().getPluginManager().registerEvents(piglinGuardian, this);
        royalSkeleton = new RoyalSkeletonListener(this, items);
        getServer().getPluginManager().registerEvents(royalSkeleton, this);
        royalSkeleton.start();
        registerCraftBlock(namespace);
        registerDyeNetherite(items, namespace);
        new SetBonusTask(items).runTaskTimer(this, 20L, 20L);

        PluginCommand command = getCommand("infernal");
        if (command != null) {
            InfernalCommand handler = new InfernalCommand(items, wildfire, darkRider, piglinGuardian, royalSkeleton);
            command.setExecutor(handler);
            command.setTabCompleter(handler);
        }
    }

    /** Teñir armadura de netherite en la mesa de crafteo (ver bloque dye-netherite-armor de config.yml). Necesita el resource pack. */
    private void registerDyeNetherite(InfernalItems items, String namespace) {
        if (!getConfig().getBoolean("dye-netherite-armor", true)) return;
        if (!items.usesResourcePack()) {
            getLogger().warning("dye-netherite-armor está activo pero use-resource-pack es false: el tinte no se vería, se desactiva el teñido.");
            return;
        }
        dyeNetherite = new DyeNetheriteListener(this, items, namespace);
        dyeNetherite.register();
        getServer().getPluginManager().registerEvents(dyeNetherite, this);
    }

    /** Bloquea el crafteo de armaduras, espadas y herramientas (ver bloque block-crafting de config.yml). */
    private void registerCraftBlock(String namespace) {
        boolean armor = getConfig().getBoolean("block-crafting.armor", false);
        boolean swords = getConfig().getBoolean("block-crafting.swords", false);
        boolean tools = getConfig().getBoolean("block-crafting.tools", false);
        craftBlock = new CraftBlockListener(armor, swords, tools, namespace);
        getServer().getPluginManager().registerEvents(craftBlock, this);
        getLogger().info("Bloqueo de crafteos -> armaduras: " + armor + ", espadas/lanzas: " + swords + ", herramientas: " + tools);
        if (getConfig().getBoolean("block-crafting.remove-recipes", true)) {
            int count = craftBlock.removeRecipes();
            getLogger().info("Recetas de crafteo borradas del juego (y del libro de recetas): " + count);
        }
    }

    @Override
    public void onDisable() {
        if (reinforcedShulkers != null) reinforcedShulkers.closeAll(); // guarda las cajas reforzadas abiertas
        if (infernalTrident != null) infernalTrident.stop();
        if (netheriteTrident != null) netheriteTrident.stop(); // quita los modelos de los tridentes lanzados
        if (royalSkeleton != null) royalSkeleton.stop();
        if (darkRider != null) darkRider.stop();
        if (wildfire != null) wildfire.stop(); // quita los escudos de los Wildfire (se vuelven a poner al cargar)
        if (recipes != null) recipes.unregister();
        if (dyeNetherite != null) dyeNetherite.unregister();
        if (craftBlock != null) craftBlock.restoreRecipes();
    }
}
