package dev.infernal.armor;

import dev.infernal.armor.InfernalItems.Kind;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * /infernal give <jugador> <ingot|star|powder|template|soul_ingot|soul_template|soul_sword|greed_ingot|greed_template|greed_sword|infernal_sword|purified_ingot|purified_template|purified_sword|celestial_dust|celestial_crystal|celestial_ingot|celestial_template|celestial_sword|mutated_breath|void_dragon_head|end_dragon_head|fermented_fruit|void_dragon_egg|end_dragon_egg|void_ingot|end_ingot|reinforced_shulker|dyed_obsidian|dyed_crying_obsidian|void_template|end_template|netherite_trident|infernal_trident|yin_yang_core|yin_yang_mace|soul_axe|soul_pickaxe|soul_shovel|soul_hoe|soul_spear|greed_axe|greed_pickaxe|greed_shovel|greed_hoe|greed_spear|purified_axe|purified_pickaxe|purified_shovel|purified_hoe|purified_spear|infernal_axe|infernal_pickaxe|infernal_shovel|infernal_hoe|infernal_spear|celestial_axe|celestial_pickaxe|celestial_shovel|celestial_hoe|celestial_spear|helmet|chestplate|leggings|boots|celestial_helmet|celestial_chestplate|celestial_leggings|celestial_boots|void_helmet|void_chestplate|void_leggings|void_boots|end_helmet|end_chestplate|end_leggings|end_boots> [cantidad]
 * /infernal wildfire  -> hace aparecer un Wildfire donde estás (admin)
 * /infernal darkrider -> hace aparecer un Jinete Oscuro donde estás (admin)
 * /infernal guardian  -> hace aparecer un Piglin Guardián donde estás (admin)
 * /infernal royalskeleton -> hace aparecer un Esqueleto Real donde estás (admin)
 * /infernal update [jugador]  -> actualiza durabilidad, daño, velocidades y descripciones de las piezas forjadas ya existentes (armaduras, espadas, herramientas, Tridente de Netherite y Mazo Yin Yang)
 */
public final class InfernalCommand implements CommandExecutor, TabCompleter {

    private final InfernalItems items;
    private final WildfireListener wildfire;
    private final DarkRiderListener darkRider;
    private final PiglinGuardianListener piglinGuardian;
    private final RoyalSkeletonListener royalSkeleton;

    public InfernalCommand(InfernalItems items, WildfireListener wildfire, DarkRiderListener darkRider,
                           PiglinGuardianListener piglinGuardian, RoyalSkeletonListener royalSkeleton) {
        this.items = items;
        this.wildfire = wildfire;
        this.darkRider = darkRider;
        this.piglinGuardian = piglinGuardian;
        this.royalSkeleton = royalSkeleton;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("update")) {
            return onUpdate(sender, args);
        }
        if (!sender.hasPermission("infernalarmor.admin")) {
            sender.sendMessage("No tienes permiso.");
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("royalskeleton")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Solo un jugador puede usarlo (aparece donde estás).");
                return true;
            }
            royalSkeleton.spawn(player.getLocation());
            sender.sendMessage("Ha aparecido un Esqueleto Real.");
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("guardian")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Solo un jugador puede usarlo (aparece donde estás).");
                return true;
            }
            piglinGuardian.spawn(player.getLocation());
            sender.sendMessage("Ha aparecido un Piglin Guardián.");
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("darkrider")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Solo un jugador puede usarlo (aparece donde estás).");
                return true;
            }
            darkRider.spawn(player.getLocation());
            sender.sendMessage("Ha aparecido un Jinete Oscuro.");
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("wildfire")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Solo un jugador puede usarlo (aparece donde estás).");
                return true;
            }
            wildfire.spawn(player.getLocation());
            sender.sendMessage("Ha aparecido un Wildfire.");
            return true;
        }
        if (args.length < 3 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage("Uso: /infernal give <jugador> <objeto> [cantidad] | /infernal wildfire | /infernal darkrider | /infernal guardian | /infernal royalskeleton");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage("Jugador no encontrado.");
            return true;
        }
        Kind kind = Kind.byId(args[2].toLowerCase(Locale.ROOT));
        if (kind == null) {
            sender.sendMessage("Objeto desconocido. Opciones: " + String.join(", ", kindIds()));
            return true;
        }
        int amount = 1;
        if (args.length > 3) {
            try {
                amount = Math.max(1, Math.min(2304, Integer.parseInt(args[3])));
            } catch (NumberFormatException e) {
                sender.sendMessage("Cantidad inválida.");
                return true;
            }
        }

        ItemStack template = items.create(kind);
        int max = template.getMaxStackSize();
        while (amount > 0) {
            int n = Math.min(amount, max);
            ItemStack give = template.clone();
            give.setAmount(n);
            target.getInventory().addItem(give).values()
                    .forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
            amount -= n;
        }
        sender.sendMessage("Entregado a " + target.getName() + ".");
        return true;
    }

    /** /infernal update [jugador]: sin jugador actualiza al que lo ejecuta; con jugador requiere admin. */
    private boolean onUpdate(CommandSender sender, String[] args) {
        Player target;
        if (args.length > 1) {
            if (!sender.hasPermission("infernalarmor.admin")) {
                sender.sendMessage("No tienes permiso.");
                return true;
            }
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage("Jugador no encontrado.");
                return true;
            }
        } else if (sender instanceof Player self) {
            if (!sender.hasPermission("infernalarmor.update")) {
                sender.sendMessage("No tienes permiso.");
                return true;
            }
            target = self;
        } else {
            sender.sendMessage("Uso: /infernal update <jugador>");
            return true;
        }

        int changed = items.refreshAll(target.getInventory());
        if (changed == 0) {
            sender.sendMessage("No hay piezas forjadas por actualizar.");
        } else {
            sender.sendMessage("Piezas actualizadas: " + changed + ".");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = sender.hasPermission("infernalarmor.admin");
        if (args.length == 1) {
            out.add("update");
            if (admin) {
                out.add("give");
                out.add("wildfire");
                out.add("darkrider");
                out.add("guardian");
                out.add("royalskeleton");
            }
        } else if (admin && args.length == 2 && !args[0].equalsIgnoreCase("wildfire")
                && !args[0].equalsIgnoreCase("darkrider") && !args[0].equalsIgnoreCase("guardian")
                && !args[0].equalsIgnoreCase("royalskeleton")) {
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        } else if (admin && args.length == 3 && args[0].equalsIgnoreCase("give")) {
            out.addAll(kindIds());
        }
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }

    private static List<String> kindIds() {
        return Arrays.stream(Kind.values()).map(Kind::id).toList();
    }
}
