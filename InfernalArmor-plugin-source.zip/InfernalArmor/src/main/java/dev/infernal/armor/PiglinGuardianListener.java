package dev.infernal.armor;

import com.destroystokyo.paper.event.entity.EntityAddToWorldEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.PiglinBrute;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.EnumSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Piglin Guardián: un piglin bruto con hacha de netherite y armadura completa de netherite, de los bastiones.
 *  - Los piglins brutos solo aparecen en los bastiones (al generarse, no reaparecen). Cada piglin bruto tiene
 *    piglin-guardian.chance de ser un Piglin Guardián; se decide UNA vez por bruto, la primera vez que se carga.
 *  - Al morir suelta 2-4 escombros ancestrales, 2-4 fragmentos de netherite y un 50% de un lingote de netherite.
 *    No suelta su armadura ni su hacha.
 */
public final class PiglinGuardianListener implements Listener {

    private static final TextColor NAME_COLOR = TextColor.color(0x4D3A3D);
    /** Brutos puestos a mano (huevos, comandos, otros plugins): no se convierten. */
    private static final Set<SpawnReason> MANUAL = EnumSet.of(
            SpawnReason.SPAWNER_EGG, SpawnReason.DISPENSE_EGG, SpawnReason.COMMAND, SpawnReason.CUSTOM);

    private final JavaPlugin plugin;
    private final NamespacedKey guardianKey;
    private final NamespacedKey checkedKey;

    private final boolean enabled;
    private final double chance;
    private final double health;
    private final int debrisMin;
    private final int debrisMax;
    private final int scrapMin;
    private final int scrapMax;
    private final double ingotChance;
    private final int xp;
    private final float equipmentDropChance;

    public PiglinGuardianListener(JavaPlugin plugin) {
        this.plugin = plugin;
        this.guardianKey = new NamespacedKey(plugin, "piglin_guardian");
        this.checkedKey = new NamespacedKey(plugin, "piglin_guardian_checked");
        FileConfiguration cfg = plugin.getConfig();
        this.enabled = cfg.getBoolean("piglin-guardian.enabled", true);
        this.chance = clamp01(cfg.getDouble("piglin-guardian.chance", 0.25));
        this.health = Math.max(1.0, cfg.getDouble("piglin-guardian.health", 50.0));
        int dMin = Math.max(0, cfg.getInt("piglin-guardian.debris-min", 2));
        this.debrisMin = dMin;
        this.debrisMax = Math.max(dMin, cfg.getInt("piglin-guardian.debris-max", 4));
        int sMin = Math.max(0, cfg.getInt("piglin-guardian.scrap-min", 2));
        this.scrapMin = sMin;
        this.scrapMax = Math.max(sMin, cfg.getInt("piglin-guardian.scrap-max", 4));
        this.ingotChance = clamp01(cfg.getDouble("piglin-guardian.ingot-chance", 0.5));
        this.xp = Math.max(0, cfg.getInt("piglin-guardian.xp", 40));
        this.equipmentDropChance = (float) clamp01(cfg.getDouble("piglin-guardian.equipment-drop-chance", 0.0));
    }

    public boolean isGuardian(Entity e) {
        return e instanceof PiglinBrute && e.getPersistentDataContainer().has(guardianKey, PersistentDataType.BYTE);
    }

    /** Hace aparecer un Piglin Guardián (comando /infernal guardian). */
    public void spawn(Location location) {
        location.getWorld().spawn(location, PiglinBrute.class, brute -> {
            brute.getPersistentDataContainer().set(checkedKey, PersistentDataType.BYTE, (byte) 1);
            makeGuardian(brute);
        });
    }

    /** Cada piglin bruto de los bastiones tira una sola vez (la primera vez que se carga). */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onAddToWorld(EntityAddToWorldEvent event) {
        if (!enabled || !(event.getEntity() instanceof PiglinBrute brute)) return;
        if (brute.getPersistentDataContainer().has(checkedKey, PersistentDataType.BYTE)) return;
        brute.getPersistentDataContainer().set(checkedKey, PersistentDataType.BYTE, (byte) 1);
        if (MANUAL.contains(brute.getEntitySpawnReason())) return;
        if (chance <= 0 || ThreadLocalRandom.current().nextDouble() >= chance) return;
        // En el tick siguiente: cambiar el equipo mientras se está añadiendo al mundo no es seguro.
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (brute.isValid() && !brute.isDead()) makeGuardian(brute);
        });
    }

    /** Piglin bruto -> Piglin Guardián: hacha y armadura completa de netherite (sin soltarlas), nombre y vida. */
    private void makeGuardian(PiglinBrute brute) {
        brute.getPersistentDataContainer().set(guardianKey, PersistentDataType.BYTE, (byte) 1);
        brute.customName(Component.text("Piglin Guardián", NAME_COLOR));
        brute.setCustomNameVisible(false);
        AttributeInstance max = brute.getAttribute(Attribute.MAX_HEALTH);
        if (max != null) max.setBaseValue(health);
        brute.setHealth(health);

        EntityEquipment eq = brute.getEquipment();
        if (eq == null) return;
        eq.setHelmet(new ItemStack(Material.NETHERITE_HELMET));
        eq.setChestplate(new ItemStack(Material.NETHERITE_CHESTPLATE));
        eq.setLeggings(new ItemStack(Material.NETHERITE_LEGGINGS));
        eq.setBoots(new ItemStack(Material.NETHERITE_BOOTS));
        eq.setItemInMainHand(new ItemStack(Material.NETHERITE_AXE));
        eq.setHelmetDropChance(equipmentDropChance);
        eq.setChestplateDropChance(equipmentDropChance);
        eq.setLeggingsDropChance(equipmentDropChance);
        eq.setBootsDropChance(equipmentDropChance);
        eq.setItemInMainHandDropChance(equipmentDropChance);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(EntityDeathEvent event) {
        if (!isGuardian(event.getEntity())) return;
        ThreadLocalRandom random = ThreadLocalRandom.current();
        // Como no reaparecen (solo los de los bastiones), suelta su botín muera como muera.
        int debris = debrisMin + random.nextInt(debrisMax - debrisMin + 1);
        int scrap = scrapMin + random.nextInt(scrapMax - scrapMin + 1);
        if (debris > 0) event.getDrops().add(new ItemStack(Material.ANCIENT_DEBRIS, debris));
        if (scrap > 0) event.getDrops().add(new ItemStack(Material.NETHERITE_SCRAP, scrap));
        if (ingotChance > 0 && random.nextDouble() < ingotChance) event.getDrops().add(new ItemStack(Material.NETHERITE_INGOT));
        event.setDroppedExp(xp);
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }
}
