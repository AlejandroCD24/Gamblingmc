package dev.infernal.armor;

import com.destroystokyo.paper.event.entity.EntityAddToWorldEvent;
import dev.infernal.armor.InfernalItems.Kind;
import io.papermc.paper.datacomponent.DataComponentTypes;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Blaze;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.SmallFireball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Wildfire: el "hermano mayor" del blaze, de las fortalezas del Nether.
 *  - Aparece en las fortalezas: cada blaze que aparece de forma natural (solo aparecen en las fortalezas) tiene
 *    wildfire.spawn-chance de ser un Wildfire. Los de los generadores, wildfire.spawner-chance (0 por defecto).
 *  - Es un blaze más grande (wildfire.scale), con más vida y armadura, rodeado de 4 escudos que giran a su alrededor
 *    (item displays montados encima, con su modelo en el resource pack).
 *  - Ataques: las bolas de fuego del blaze (+daño) y una onda expansiva cuando tiene jugadores cerca (los empuja,
 *    les hace daño y les prende fuego).
 *  - Al morir a manos de un jugador suelta de 1 a 2 Polvos de Blaze Infernal (en vez de varas de blaze).
 */
public final class WildfireListener implements Listener {

    private static final TextColor NAME_COLOR = TextColor.color(0xFF7A1A);
    private static final int SHIELDS = 4;
    /** Cada cuántos ticks avanzan los escudos y cuánto giran (24 grados cada 4 ticks = una vuelta cada 3 segundos). */
    private static final int SPIN_PERIOD = 4;
    private static final float SPIN_STEP = (float) Math.toRadians(24.0);

    private final JavaPlugin plugin;
    private final InfernalItems items;
    private final NamespacedKey wildfireKey;
    private final Map<UUID, Wildfire> tracked = new HashMap<>();
    private BukkitTask task;
    private long tick;

    // config
    private final boolean enabled;
    private final double spawnChance;
    private final double spawnerChance;
    private final double health;
    private final double scale;
    private final double armor;
    private final double fireballBonus;
    private final double shockwaveDamage;
    private final double shockwaveRadius;
    private final int shockwaveCooldown;
    private final int dropsMin;
    private final int dropsMax;
    private final int xp;
    private final boolean usePack;

    private static final class Wildfire {
        final Blaze blaze;
        final List<ItemDisplay> shields = new ArrayList<>();
        float angle;
        long nextShockwave;

        Wildfire(Blaze blaze) {
            this.blaze = blaze;
        }
    }

    public WildfireListener(JavaPlugin plugin, InfernalItems items) {
        this.plugin = plugin;
        this.items = items;
        this.wildfireKey = new NamespacedKey(plugin, "wildfire");
        FileConfiguration cfg = plugin.getConfig();
        this.enabled = cfg.getBoolean("wildfire.enabled", true);
        this.spawnChance = clamp01(cfg.getDouble("wildfire.spawn-chance", 0.10));
        this.spawnerChance = clamp01(cfg.getDouble("wildfire.spawner-chance", 0.0));
        this.health = Math.max(1.0, cfg.getDouble("wildfire.health", 60.0));
        this.scale = Math.max(0.5, Math.min(3.0, cfg.getDouble("wildfire.scale", 1.4)));
        this.armor = Math.max(0.0, cfg.getDouble("wildfire.armor", 6.0));
        this.fireballBonus = Math.max(0.0, cfg.getDouble("wildfire.fireball-damage-bonus", 2.0));
        this.shockwaveDamage = Math.max(0.0, cfg.getDouble("wildfire.shockwave-damage", 6.0));
        this.shockwaveRadius = Math.max(1.0, cfg.getDouble("wildfire.shockwave-radius", 5.0));
        this.shockwaveCooldown = Math.max(1, cfg.getInt("wildfire.shockwave-cooldown", 8)) * 20;
        int min = Math.max(0, cfg.getInt("wildfire.drops-min", 1));
        this.dropsMin = min;
        this.dropsMax = Math.max(min, cfg.getInt("wildfire.drops-max", 2));
        this.xp = Math.max(0, cfg.getInt("wildfire.xp", 20));
        this.usePack = cfg.getBoolean("use-resource-pack", true);
    }

    public void start() {
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
        // Wildfires que ya estaban cargados (chunks del spawn, /reload...).
        for (World world : plugin.getServer().getWorlds()) {
            for (Blaze blaze : world.getEntitiesByClass(Blaze.class)) {
                if (isWildfire(blaze)) track(blaze);
            }
        }
    }

    public void stop() {
        if (task != null) task.cancel();
        task = null;
        for (Wildfire w : tracked.values()) removeShields(w);
        tracked.clear();
    }

    public boolean isWildfire(Entity entity) {
        return entity instanceof Blaze
                && entity.getPersistentDataContainer().has(wildfireKey, PersistentDataType.BYTE);
    }

    /** Hace aparecer un Wildfire (comando /infernal wildfire). */
    public Blaze spawn(Location location) {
        Blaze blaze = location.getWorld().spawn(location, Blaze.class, this::makeWildfire);
        plugin.getServer().getScheduler().runTask(plugin, () -> track(blaze));
        return blaze;
    }

    // ------------------------------------------------------------------ aparición

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        if (!enabled || !(event.getEntity() instanceof Blaze blaze)) return;
        double chance;
        if (event.getSpawnReason() == SpawnReason.NATURAL) {
            chance = spawnChance;            // los blazes naturales solo aparecen en las fortalezas del Nether
        } else if (event.getSpawnReason() == SpawnReason.SPAWNER) {
            chance = spawnerChance;
        } else {
            return;
        }
        if (chance <= 0.0 || ThreadLocalRandom.current().nextDouble() >= chance) return;
        makeWildfire(blaze);
        // Los escudos (montados encima) se ponen en el tick siguiente, cuando ya está en el mundo (lo hace onAddToWorld).
    }

    /** Convierte un blaze en Wildfire: nombre, tamaño, vida, armadura y marca. */
    private void makeWildfire(Blaze blaze) {
        blaze.getPersistentDataContainer().set(wildfireKey, PersistentDataType.BYTE, (byte) 1);
        blaze.customName(Component.text("Wildfire", NAME_COLOR));
        blaze.setCustomNameVisible(false);
        setBase(blaze, Attribute.MAX_HEALTH, health);
        setBase(blaze, Attribute.SCALE, scale);
        setBase(blaze, Attribute.ARMOR, armor);
        setBase(blaze, Attribute.KNOCKBACK_RESISTANCE, 0.6);
        setBase(blaze, Attribute.FOLLOW_RANGE, 48.0);
        blaze.setHealth(health);
    }

    private static void setBase(Blaze blaze, Attribute attribute, double value) {
        AttributeInstance instance = blaze.getAttribute(attribute);
        if (instance != null) instance.setBaseValue(value);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onAddToWorld(EntityAddToWorldEvent event) {
        if (!(event.getEntity() instanceof Blaze blaze) || !isWildfire(blaze)) return;
        plugin.getServer().getScheduler().runTask(plugin, () -> track(blaze));
    }

    private void track(Blaze blaze) {
        if (!blaze.isValid() || blaze.isDead()) return;
        Wildfire old = tracked.get(blaze.getUniqueId());
        if (old != null) {
            if (old.blaze == blaze) return;
            removeShields(old);
        }
        Wildfire w = new Wildfire(blaze);
        w.angle = ThreadLocalRandom.current().nextFloat() * (float) (Math.PI * 2);
        w.nextShockwave = tick + 60;
        tracked.put(blaze.getUniqueId(), w);
        spawnShields(w);
    }

    // ------------------------------------------------------------------ escudos

    private void spawnShields(Wildfire w) {
        removeShields(w);
        Blaze blaze = w.blaze;
        ItemStack look = new ItemStack(Material.NETHER_BRICKS);
        if (usePack) look.setData(DataComponentTypes.ITEM_MODEL, Key.key(InfernalItems.PACK_NAMESPACE, "wildfire_shield"));
        for (int i = 0; i < SHIELDS; i++) {
            final int index = i;
            ItemDisplay shield = blaze.getWorld().spawn(blaze.getLocation(), ItemDisplay.class, d -> {
                d.setPersistent(false);
                d.setItemStack(look);
                d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
                d.setBrightness(new Display.Brightness(15, 15)); // escudos ardientes: siempre iluminados
                d.setInterpolationDuration(SPIN_PERIOD);
                d.setTransformation(shieldTransform(w, index));
            });
            blaze.addPassenger(shield);
            w.shields.add(shield);
        }
    }

    private static void removeShields(Wildfire w) {
        for (ItemDisplay shield : w.shields) {
            if (shield.isValid()) shield.remove();
        }
        w.shields.clear();
    }

    /**
     * Posición de un escudo: van montados encima del Wildfire (punto de montura = la parte de arriba), así que se bajan
     * hasta la mitad del cuerpo y se reparten en círculo a su alrededor, mirando hacia fuera.
     */
    private Transformation shieldTransform(Wildfire w, int index) {
        float s = (float) scale;
        float height = (float) w.blaze.getHeight();
        float angle = w.angle + index * (float) (Math.PI / 2);
        float radius = 0.85f * s;
        Vector3f translation = new Vector3f(
                (float) Math.sin(angle) * radius,
                -height * 0.5f,
                (float) Math.cos(angle) * radius);
        Quaternionf rotation = new Quaternionf().rotationY(angle);
        return new Transformation(translation, rotation, new Vector3f(0.9f * s, 1.15f * s, 0.9f * s), new Quaternionf());
    }

    // ------------------------------------------------------------------ cada tick

    private void tick() {
        tick++;
        if (tracked.isEmpty()) return;
        Iterator<Wildfire> it = tracked.values().iterator();
        while (it.hasNext()) {
            Wildfire w = it.next();
            Blaze blaze = w.blaze;
            if (!blaze.isValid() || blaze.isDead()) {
                // Muerto, descargado con su chunk o pasado a otra dimensión (allí se vuelve a registrar).
                removeShields(w);
                it.remove();
                continue;
            }
            boolean broken = w.shields.size() != SHIELDS;
            for (ItemDisplay shield : w.shields) {
                if (!shield.isValid() || !blaze.getPassengers().contains(shield)) broken = true;
            }
            if (broken) {
                spawnShields(w);
                continue;
            }
            if (tick % SPIN_PERIOD == 0) {
                w.angle += SPIN_STEP;
                if (w.angle > Math.PI * 2) w.angle -= (float) (Math.PI * 2);
                for (int i = 0; i < w.shields.size(); i++) {
                    ItemDisplay shield = w.shields.get(i);
                    shield.setInterpolationDelay(0);
                    shield.setInterpolationDuration(SPIN_PERIOD);
                    shield.setTransformation(shieldTransform(w, i));
                }
            }
            if (tick % 5 == 0) {
                Location center = blaze.getLocation().add(0, blaze.getHeight() * 0.5, 0);
                blaze.getWorld().spawnParticle(Particle.FLAME, center, 3, 0.6, 0.6, 0.6, 0.01);
                if (tick % 20 == 0) blaze.getWorld().spawnParticle(Particle.LAVA, center, 1, 0.4, 0.4, 0.4, 0.0);
            }
            if (tick >= w.nextShockwave && tick % 10 == 0) tryShockwave(w);
        }
    }

    /** Onda expansiva: si tiene jugadores cerca, los empuja hacia fuera, les hace daño y les prende fuego. */
    private void tryShockwave(Wildfire w) {
        Blaze blaze = w.blaze;
        double r = shockwaveRadius;
        List<Player> hit = new ArrayList<>();
        for (Entity e : blaze.getNearbyEntities(r, r, r)) {
            if (e instanceof Player p && p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR
                    && p.getLocation().distanceSquared(blaze.getLocation()) <= r * r && blaze.hasLineOfSight(p)) {
                hit.add(p);
            }
        }
        if (hit.isEmpty()) return;
        w.nextShockwave = tick + shockwaveCooldown;

        Location center = blaze.getLocation().add(0, blaze.getHeight() * 0.4, 0);
        World world = blaze.getWorld();
        world.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.6f);
        world.playSound(center, Sound.ENTITY_BLAZE_SHOOT, 1.5f, 0.5f);
        world.spawnParticle(Particle.EXPLOSION, center, 3, 0.5, 0.3, 0.5, 0.0);
        for (int i = 0; i < 32; i++) {
            double a = Math.PI * 2 * i / 32;
            world.spawnParticle(Particle.FLAME, center.clone().add(Math.cos(a) * r * 0.6, 0, Math.sin(a) * r * 0.6),
                    2, 0.1, 0.1, 0.1, 0.05);
        }
        for (Player p : hit) {
            Vector push = p.getLocation().toVector().subtract(blaze.getLocation().toVector()).setY(0);
            if (push.lengthSquared() < 1.0E-4) push = new Vector(1, 0, 0);
            push.normalize().multiply(1.3).setY(0.55);
            if (shockwaveDamage > 0) p.damage(shockwaveDamage, blaze);
            p.setVelocity(push);
            p.setFireTicks(Math.max(p.getFireTicks(), 60));
        }
    }

    // ------------------------------------------------------------------ daño y botín

    /** Las bolas de fuego del Wildfire hacen más daño que las del blaze. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFireball(EntityDamageByEntityEvent event) {
        if (fireballBonus <= 0) return;
        if (event.getDamager() instanceof SmallFireball fireball && fireball.getShooter() instanceof Blaze blaze
                && isWildfire(blaze)) {
            event.setDamage(event.getDamage() + fireballBonus);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(EntityDeathEvent event) {
        if (!isWildfire(event.getEntity())) return;
        Wildfire w = tracked.remove(event.getEntity().getUniqueId());
        if (w != null) removeShields(w);

        event.getDrops().clear(); // sin varas de blaze: suelta Polvo de Blaze Infernal
        event.setDroppedExp(xp);
        if (event.getEntity().getKiller() == null) return; // como las varas del blaze: solo si lo mata un jugador
        int amount = dropsMin + ThreadLocalRandom.current().nextInt(dropsMax - dropsMin + 1);
        if (amount <= 0) return;
        ItemStack powder = items.create(Kind.POWDER);
        powder.setAmount(amount);
        event.getDrops().add(powder);
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }
}
