package dev.infernal.armor;

import com.destroystokyo.paper.event.entity.EntityAddToWorldEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Biome;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.SkeletonHorse;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Esqueleto Real: un esqueleto con armadura completa de diamante y un arco con Llama y Poder I-V (cuanto más alto el nivel,
 * menos probable), montado en un caballo esqueleto (el vanilla, sin cambios de textura).
 *  - Aparece en el valle de arena de almas: cada esqueleto que aparece ahí de forma natural tiene royal-skeleton.chance de
 *    ser un Esqueleto Real.
 *  - Al morir a manos de un jugador suelta de 4 a 32 lágrimas de ghast.
 *  - Ensillado, el caballo lo dirige el jinete (como los jinetes vanilla) y dispara montado. Si el jinete muere, el caballo
 *    se desvanece. Como los jinetes vanilla no desaparecen solos, se quitan si no hay ningún jugador cerca durante un rato.
 */
public final class RoyalSkeletonListener implements Listener {

    private static final TextColor NAME_COLOR = TextColor.color(0x5FD4E8);
    private static final int MOUNTED_HEIGHT = 4;

    private final JavaPlugin plugin;
    private final NamespacedKey riderKey;
    private final NamespacedKey horseKey;
    private final Map<UUID, LivingEntity> riders = new HashMap<>();
    private final Map<UUID, Long> lonelySince = new HashMap<>();
    private BukkitTask task;

    private final boolean enabled;
    private final double chance;
    private final double health;
    private final double horseHealth;
    private final int[] powerWeights;
    private final int tearsMin;
    private final int tearsMax;
    private final int xp;
    private final float armorDropChance;
    private final float bowDropChance;
    private final int despawnDistance;
    private final int despawnSeconds;

    public RoyalSkeletonListener(JavaPlugin plugin, InfernalItems items) {
        this.plugin = plugin;
        this.riderKey = new NamespacedKey(plugin, "royal_skeleton");
        this.horseKey = new NamespacedKey(plugin, "royal_skeleton_horse");
        FileConfiguration cfg = plugin.getConfig();
        this.enabled = cfg.getBoolean("royal-skeleton.enabled", true);
        this.chance = clamp01(cfg.getDouble("royal-skeleton.chance", 0.05));
        this.health = Math.max(1.0, cfg.getDouble("royal-skeleton.health", 30.0));
        this.horseHealth = Math.max(1.0, cfg.getDouble("royal-skeleton.horse-health", 25.0));
        this.powerWeights = readWeights(cfg.getIntegerList("royal-skeleton.power-weights"));
        int min = Math.max(0, cfg.getInt("royal-skeleton.tears-min", 4));
        this.tearsMin = min;
        this.tearsMax = Math.max(min, cfg.getInt("royal-skeleton.tears-max", 32));
        this.xp = Math.max(0, cfg.getInt("royal-skeleton.xp", 25));
        this.armorDropChance = (float) clamp01(cfg.getDouble("royal-skeleton.armor-drop-chance", 0.0));
        this.bowDropChance = (float) clamp01(cfg.getDouble("royal-skeleton.bow-drop-chance", 0.0));
        this.despawnDistance = Math.max(32, cfg.getInt("royal-skeleton.despawn-distance", 96));
        this.despawnSeconds = Math.max(5, cfg.getInt("royal-skeleton.despawn-seconds", 60));
    }

    /** Pesos de Poder I..V. Por defecto 40/25/18/11/6 (Poder V: 6%). */
    private static int[] readWeights(List<Integer> list) {
        int[] def = {40, 25, 18, 11, 6};
        if (list == null || list.size() != 5) return def;
        int[] w = new int[5];
        int total = 0;
        for (int i = 0; i < 5; i++) {
            w[i] = Math.max(0, list.get(i) == null ? 0 : list.get(i));
            total += w[i];
        }
        return total > 0 ? w : def;
    }

    public void start() {
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
        for (World world : plugin.getServer().getWorlds()) {
            for (LivingEntity e : world.getLivingEntities()) {
                if (isRider(e)) riders.put(e.getUniqueId(), e);
            }
        }
    }

    public void stop() {
        if (task != null) task.cancel();
        task = null;
        riders.clear();
        lonelySince.clear();
    }

    public boolean isRider(Entity e) {
        return e instanceof Skeleton && e.getType() == EntityType.SKELETON
                && e.getPersistentDataContainer().has(riderKey, PersistentDataType.BYTE);
    }

    public boolean isHorse(Entity e) {
        return e instanceof SkeletonHorse && e.getPersistentDataContainer().has(horseKey, PersistentDataType.BYTE);
    }

    /** Hace aparecer un Esqueleto Real (comando /infernal royalskeleton). */
    public void spawn(Location location) {
        Skeleton rider = location.getWorld().spawn(location, Skeleton.class, this::equip);
        plugin.getServer().getScheduler().runTask(plugin, () -> mount(rider));
    }

    // ------------------------------------------------------------------ aparición

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        if (!enabled || chance <= 0 || event.getSpawnReason() != SpawnReason.NATURAL) return;
        if (event.getEntityType() != EntityType.SKELETON || !(event.getEntity() instanceof Skeleton skeleton)) return;
        if (!Biome.SOUL_SAND_VALLEY.equals(skeleton.getLocation().getBlock().getBiome())) return;
        if (ThreadLocalRandom.current().nextDouble() >= chance) return;
        equip(skeleton);
        plugin.getServer().getScheduler().runTask(plugin, () -> mount(skeleton));
    }

    /** Esqueleto -> Esqueleto Real: armadura completa de diamante, arco con Llama y Poder I-V, nombre y vida. */
    private void equip(Skeleton skeleton) {
        skeleton.getPersistentDataContainer().set(riderKey, PersistentDataType.BYTE, (byte) 1);
        skeleton.customName(Component.text("Esqueleto Real", NAME_COLOR));
        skeleton.setCustomNameVisible(false);
        AttributeInstance max = skeleton.getAttribute(Attribute.MAX_HEALTH);
        if (max != null) max.setBaseValue(health);
        skeleton.setHealth(health);
        skeleton.setCanPickupItems(false);

        EntityEquipment eq = skeleton.getEquipment();
        if (eq != null) {
            eq.setHelmet(new ItemStack(Material.DIAMOND_HELMET));
            eq.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
            eq.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
            eq.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
            ItemStack bow = new ItemStack(Material.BOW);
            bow.addUnsafeEnchantment(Enchantment.FLAME, 1);
            bow.addUnsafeEnchantment(Enchantment.POWER, rollPower());
            eq.setItemInMainHand(bow);
            eq.setHelmetDropChance(armorDropChance);
            eq.setChestplateDropChance(armorDropChance);
            eq.setLeggingsDropChance(armorDropChance);
            eq.setBootsDropChance(armorDropChance);
            eq.setItemInMainHandDropChance(bowDropChance);
        }
        riders.put(skeleton.getUniqueId(), skeleton);
    }

    /** Poder I-V: cuanto más alto, menos probable (royal-skeleton.power-weights). */
    private int rollPower() {
        int total = 0;
        for (int w : powerWeights) total += w;
        int r = ThreadLocalRandom.current().nextInt(total);
        for (int i = 0; i < powerWeights.length; i++) {
            r -= powerWeights[i];
            if (r < 0) return i + 1;
        }
        return 1;
    }

    /** Lo monta en un caballo esqueleto ensillado, si hay sitio (si no, va a pie). */
    private void mount(Skeleton rider) {
        if (!rider.isValid() || rider.isDead() || rider.isInsideVehicle()) return;
        Location loc = rider.getLocation();
        if (!hasRoom(loc, MOUNTED_HEIGHT)) return;
        SkeletonHorse horse = loc.getWorld().spawn(loc, SkeletonHorse.class, h -> {
            h.getPersistentDataContainer().set(horseKey, PersistentDataType.BYTE, (byte) 1);
            h.setAdult();
            h.setTamed(true);
            h.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, PotionEffect.INFINITE_DURATION, 0, false, false));
            AttributeInstance max = h.getAttribute(Attribute.MAX_HEALTH);
            if (max != null) max.setBaseValue(horseHealth);
            h.setHealth(horseHealth);
            h.getInventory().setSaddle(new ItemStack(Material.SADDLE));
        });
        horse.addPassenger(rider);
    }

    private static boolean hasRoom(Location loc, int height) {
        Block feet = loc.getBlock();
        if (feet.getRelative(0, -1, 0).isPassable()) return false;
        for (int dy = 0; dy < height; dy++) {
            if (!feet.getRelative(0, dy, 0).isPassable()) return false;
        }
        return true;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onAddToWorld(EntityAddToWorldEvent event) {
        if (isRider(event.getEntity())) riders.put(event.getEntity().getUniqueId(), (LivingEntity) event.getEntity());
    }

    // ------------------------------------------------------------------ muerte y botín

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(EntityDeathEvent event) {
        LivingEntity dead = event.getEntity();
        if (isHorse(dead)) {
            event.getDrops().removeIf(i -> i != null && i.getType() == Material.SADDLE);
            return;
        }
        if (!isRider(dead)) return;
        riders.remove(dead.getUniqueId());
        lonelySince.remove(dead.getUniqueId());
        if (dead.getVehicle() instanceof SkeletonHorse horse && isHorse(horse)) vanish(horse);

        event.setDroppedExp(xp);
        if (dead.getKiller() == null) return; // solo si lo mata un jugador
        int tears = tearsMin + ThreadLocalRandom.current().nextInt(tearsMax - tearsMin + 1);
        if (tears > 0) event.getDrops().add(new ItemStack(Material.GHAST_TEAR, tears));
    }

    private static void vanish(SkeletonHorse horse) {
        Location at = horse.getLocation().add(0, 1, 0);
        horse.getWorld().spawnParticle(Particle.SOUL, at, 20, 0.5, 0.6, 0.5, 0.02);
        horse.getWorld().spawnParticle(Particle.LARGE_SMOKE, at, 10, 0.5, 0.6, 0.5, 0.01);
        horse.eject();
        horse.remove();
    }

    // ------------------------------------------------------------------ cada segundo: despawn

    private void tick() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, LivingEntity>> it = riders.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, LivingEntity> entry = it.next();
            LivingEntity rider = entry.getValue();
            if (!rider.isValid() || rider.isDead()) {
                it.remove();
                lonelySince.remove(entry.getKey());
                continue;
            }
            if (playerNear(rider)) {
                lonelySince.remove(entry.getKey());
                continue;
            }
            long since = lonelySince.computeIfAbsent(entry.getKey(), k -> now);
            if (now - since >= despawnSeconds * 1000L) {
                Entity vehicle = rider.getVehicle();
                if (vehicle != null && isHorse(vehicle)) vehicle.remove();
                rider.remove();
                it.remove();
                lonelySince.remove(entry.getKey());
            }
        }
        for (World world : plugin.getServer().getWorlds()) {
            for (SkeletonHorse horse : world.getEntitiesByClass(SkeletonHorse.class)) {
                if (isHorse(horse) && horse.getPassengers().isEmpty()) vanish(horse);
            }
        }
    }

    private boolean playerNear(LivingEntity rider) {
        double max = (double) despawnDistance * despawnDistance;
        Location loc = rider.getLocation();
        for (Player p : rider.getWorld().getPlayers()) {
            if (p.getLocation().distanceSquared(loc) <= max) return true;
        }
        return false;
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }
}
