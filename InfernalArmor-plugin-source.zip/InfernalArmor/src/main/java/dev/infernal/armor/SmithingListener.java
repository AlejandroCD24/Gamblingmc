package dev.infernal.armor;

import dev.infernal.armor.InfernalItems.Kind;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.SmithingInventory;

/**
 * Mesa de herrería:
 *  - plantilla infernal + armadura de netherite + lingote infernal -> pieza infernal
 *    conservando encantamientos, diseño (trim), daño y nombre. La netherite tiene que estar sin teñir o teñida en un tono
 *    de la lista infernal (por defecto amarillo, naranja o rojo; config smithing-dye-tones).
 *  - plantilla del alma + espada de netherite + lingote del alma -> Espada del Alma
 *    conservando encantamientos, daño y nombre.
 *  - plantilla del alma + hacha/pico/pala/azada/lanza de netherite + lingote del alma -> herramienta del Alma
 *    conservando encantamientos, daño y nombre.
 *  - plantilla de codicia + herramienta del Alma + lingote de codicia -> la misma herramienta corrompida
 *    conservando encantamientos, daño y nombre.
 *  - plantilla purificada + herramienta del Alma + lingote purificado -> la misma herramienta purificada
 *    conservando encantamientos, daño y nombre.
 *  - plantilla de codicia + Espada del Alma + lingote de codicia -> Espada del Alma Corrompida
 *    conservando encantamientos, daño y nombre.
 *  - plantilla infernal + Espada del Alma Corrompida + lingote infernal -> Espada Infernal
 *    conservando encantamientos, daño y nombre.
 *  - plantilla infernal + herramienta corrompida + lingote infernal -> la misma herramienta infernal
 *    conservando encantamientos, daño y nombre.
 *  - plantilla celestial + herramienta purificada + lingote celestial -> la misma herramienta celestial
 *    conservando encantamientos, daño y nombre.
 *  - plantilla purificada + Espada del Alma + lingote purificado -> Espada Purificada
 *    conservando encantamientos, daño y nombre.
 *  - plantilla celestial + Espada Purificada + lingote celestial -> Espada Celestial
 *    conservando encantamientos, daño y nombre.
 *  - plantilla celestial + armadura de netherite + lingote celestial -> pieza celestial
 *    conservando encantamientos, diseño (trim), daño y nombre. La netherite tiene que estar sin teñir o teñida en un tono
 *    de la lista celestial (por defecto rosa, magenta o morado; config smithing-dye-tones).
 *  - plantilla del Vacío + armadura infernal + lingote del Vacío -> la misma pieza del Vacío
 *    conservando encantamientos, diseño (trim), daño y nombre.
 *  - plantilla del Fin + armadura celestial + lingote del Fin -> la misma pieza del Fin
 *    conservando encantamientos, diseño (trim), daño y nombre.
 *  - plantilla de mejora de netherite + tridente + lingote de netherite (todo vanilla) -> Tridente de Netherite
 *    conservando encantamientos, daño y nombre (netherite-trident.enabled).
 *  - Plantilla Infernal + Tridente de Netherite + Lingote Infernal -> Tridente Infernal (infernal-trident.enabled).
 *  - plantilla de mejora de netherite (vanilla) + mazo + Núcleo Yin Yang -> Mazo Yin Yang
 *    conservando encantamientos, daño y nombre (yin-yang-mace.enabled).
 *  - con armor-lock.block-upgrades (por defecto) NINGUNA mejora de armadura da resultado: netherite -> Infernal/Celestial,
 *    Infernal -> Vacío y Celestial -> Fin. Esas armaduras solo se obtienen con /infernal give.
 *  - los objetos infernales, del alma y de codicia NO sirven en ninguna receta vanilla de la mesa.
 */
public final class SmithingListener implements Listener {

    private final InfernalItems items;

    public SmithingListener(InfernalItems items) {
        this.items = items;
    }

    @EventHandler
    public void onPrepareSmithing(PrepareSmithingEvent event) {
        SmithingInventory inv = event.getInventory();
        ItemStack template = inv.getInputTemplate();
        ItemStack base = inv.getInputEquipment();
        ItemStack addition = inv.getInputMineral();

        // Tridente de Netherite: como la mejora vanilla a netherite, plantilla de mejora de netherite + tridente + lingote de
        // netherite (los tres normales: no valen las plantillas ni los lingotes del plugin, que son del mismo material).
        // Ninguna receta vanilla usa el tridente, así que cualquier otra combinación con un tridente no da resultado.
        if (base != null && base.getType() == Material.TRIDENT) {
            // Tridente Infernal: Plantilla Infernal + Tridente de Netherite + Lingote Infernal.
            if (items.kindOf(template) == Kind.TEMPLATE || items.kindOf(addition) == Kind.INGOT) {
                boolean infernalTrident = items.infernalTridentEnabled()
                        && items.kindOf(template) == Kind.TEMPLATE
                        && items.kindOf(addition) == Kind.INGOT
                        && items.isNetheriteTrident(base);
                event.setResult(infernalTrident ? items.toInfernalTrident(base) : null);
                return;
            }
            boolean netheriteTrident = items.netheriteTridentEnabled()
                    && template != null && template.getType() == Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE
                    && items.kindOf(template) == null
                    && addition != null && addition.getType() == Material.NETHERITE_INGOT
                    && items.kindOf(addition) == null
                    && !items.isNetheriteTrident(base);
            event.setResult(netheriteTrident ? items.toNetheriteTrident(base) : null);
            return;
        }

        // Mazo Yin Yang: plantilla de mejora de netherite (normal) + mazo + Núcleo Yin Yang.
        // Ninguna receta vanilla usa el mazo, así que cualquier otra combinación con un mazo no da resultado.
        if (base != null && base.getType() == Material.MACE) {
            boolean yinYang = items.yinYangMaceEnabled()
                    && template != null && template.getType() == Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE
                    && items.kindOf(template) == null
                    && items.kindOf(addition) == Kind.YIN_YANG_CORE
                    && !items.isYinYangMace(base);
            event.setResult(yinYang ? items.toYinYangMace(base) : null);
            return;
        }

        boolean anyCustom = items.isIngredient(template) || items.isIngredient(base) || items.isIngredient(addition);
        if (!anyCustom) return; // mejoras a netherite y diseños vanilla no se tocan

        // Infernal: netherite sin teñir o en tonos amarillo/naranja/rojo. Celestial: sin teñir o rosa/magenta/morado (config smithing-dye-tones).
        boolean armorUpgrade = items.kindOf(template) == Kind.TEMPLATE
                && items.kindOf(addition) == Kind.INGOT
                && base != null
                && InfernalItems.armorKindOf(base.getType()) != null
                && !items.isCustomArmor(base)
                && items.fitsInfernalTone(base)
                && !items.infernalUpgradeBlocked();

        boolean celestialArmorUpgrade = items.kindOf(template) == Kind.CELESTIAL_TEMPLATE
                && items.kindOf(addition) == Kind.CELESTIAL_INGOT
                && base != null
                && InfernalItems.armorKindOf(base.getType()) != null
                && !items.isCustomArmor(base)
                && items.fitsCelestialTone(base)
                && !items.armorUpgradesBlocked();

        boolean voidArmorUpgrade = items.kindOf(template) == Kind.VOID_TEMPLATE
                && items.kindOf(addition) == Kind.VOID_INGOT
                && items.isInfernalArmor(base)
                && !items.armorUpgradesBlocked();

        boolean endArmorUpgrade = items.kindOf(template) == Kind.END_TEMPLATE
                && items.kindOf(addition) == Kind.END_INGOT
                && items.isCelestialArmor(base)
                && !items.armorUpgradesBlocked();

        boolean swordUpgrade = items.kindOf(template) == Kind.SOUL_TEMPLATE
                && items.kindOf(addition) == Kind.SOUL_INGOT
                && base != null
                && base.getType() == Material.NETHERITE_SWORD
                && !items.isSoulSword(base)
                && !items.isGreedSword(base)
                && !items.isInfernalSword(base)
                && !items.isPurifiedSword(base)
                && !items.isCelestialSword(base);

        boolean toolUpgrade = items.kindOf(template) == Kind.SOUL_TEMPLATE
                && items.kindOf(addition) == Kind.SOUL_INGOT
                && base != null
                && InfernalItems.soulToolKindOf(base.getType()) != null
                && !items.isForgedTool(base);

        boolean greedToolUpgrade = items.kindOf(template) == Kind.GREED_TEMPLATE
                && items.kindOf(addition) == Kind.GREED_INGOT
                && items.isSoulTool(base);

        boolean purifiedToolUpgrade = items.kindOf(template) == Kind.PURIFIED_TEMPLATE
                && items.kindOf(addition) == Kind.PURIFIED_INGOT
                && items.isSoulTool(base);

        boolean infernalToolUpgrade = items.kindOf(template) == Kind.TEMPLATE
                && items.kindOf(addition) == Kind.INGOT
                && items.isGreedTool(base);

        boolean celestialToolUpgrade = items.kindOf(template) == Kind.CELESTIAL_TEMPLATE
                && items.kindOf(addition) == Kind.CELESTIAL_INGOT
                && items.isPurifiedTool(base);

        boolean purifiedUpgrade = items.kindOf(template) == Kind.PURIFIED_TEMPLATE
                && items.kindOf(addition) == Kind.PURIFIED_INGOT
                && items.isSoulSword(base);

        boolean celestialUpgrade = items.kindOf(template) == Kind.CELESTIAL_TEMPLATE
                && items.kindOf(addition) == Kind.CELESTIAL_INGOT
                && items.isPurifiedSword(base);

        boolean greedUpgrade = items.kindOf(template) == Kind.GREED_TEMPLATE
                && items.kindOf(addition) == Kind.GREED_INGOT
                && items.isSoulSword(base);

        boolean infernalSwordUpgrade = items.kindOf(template) == Kind.TEMPLATE
                && items.kindOf(addition) == Kind.INGOT
                && items.isGreedSword(base);

        if (armorUpgrade) {
            event.setResult(items.toInfernal(base));
        } else if (swordUpgrade) {
            event.setResult(items.toSoulSword(base));
        } else if (toolUpgrade) {
            event.setResult(items.toSoulTool(base));
        } else if (greedToolUpgrade) {
            event.setResult(items.toGreedTool(base));
        } else if (purifiedToolUpgrade) {
            event.setResult(items.toPurifiedTool(base));
        } else if (infernalToolUpgrade) {
            event.setResult(items.toInfernalTool(base));
        } else if (celestialToolUpgrade) {
            event.setResult(items.toCelestialTool(base));
        } else if (purifiedUpgrade) {
            event.setResult(items.toPurifiedSword(base));
        } else if (celestialUpgrade) {
            event.setResult(items.toCelestialSword(base));
        } else if (celestialArmorUpgrade) {
            event.setResult(items.toCelestialArmor(base));
        } else if (voidArmorUpgrade) {
            event.setResult(items.toVoidArmor(base));
        } else if (endArmorUpgrade) {
            event.setResult(items.toEndArmor(base));
        } else if (greedUpgrade) {
            event.setResult(items.toGreedSword(base));
        } else if (infernalSwordUpgrade) {
            event.setResult(items.toInfernalSword(base));
        } else {
            event.setResult(null);
        }
    }
}
