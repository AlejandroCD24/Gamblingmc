package dev.infernal.armor;

import org.bukkit.GameMode;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Tridente Infernal:
 *  - Propulsión SOLO en la lava (Propulsión Ígnea). La Propulsión vanilla la decide el cliente y solo funciona en el agua o la
 *    lluvia, así que el tridente no lleva el encantamiento de verdad (InfernalItems#normalizeInfernalTrident guarda su nivel
 *    aparte). En la lava, al cargarlo y soltarlo, el plugin cancela el lanzamiento y te impulsa él (con el impulso doble del
 *    Tridente de Netherite), con el giro de la Propulsión. Fuera de la lava (agua, lluvia o tierra) un tridente con Propulsión
 *    Ígnea no hace nada, como uno vanilla con Propulsión fuera del agua: ni impulsa ni se lanza (en el agua o con lluvia,
 *    además, chisporrotea). Sin Propulsión Ígnea se lanza normal en cualquier sitio.
 *  - Empalamiento: su daño extra (2.5 por nivel) solo cuenta contra quien esté en la lava (cualquier mob o jugador), y no
 *    contra los mobs acuáticos como en vanilla.
 *  - Mantiene el encantamiento de verdad fuera del tridente: yunque, mesa de encantamientos y, cada 2 segundos, los
 *    inventarios de los jugadores (por /enchant o creativo). La Propulsión Ígnea es incompatible con Lealtad y Canalización.
 */
public final class InfernalTridentListener implements Listener {

    private static final double IMPALING_PER_LEVEL = 2.5;
    /** Duración del giro de la Propulsión (ticks), como la vanilla. */
    private static final int SPIN_TICKS = 20;
    /** Daño del choque de la Propulsión vanilla (se le suma el +daño del Tridente de Netherite). */
    private static final double SPIN_DAMAGE = 8.0;

    private final JavaPlugin plugin;
    private final InfernalItems items;
    private BukkitTask task;
    private BukkitTask spinTask;
    /**
     * Propulsiones Ígneas en curso: jugador -> ticks que lleva girando. setRiptiding(true) solo pone la animación (no
     * arranca el temporizador vanilla que la quita ni hace daño al chocar), así que el plugin la quita a los 20 ticks
     * (o al tocar el suelo) y hace el golpe del choque.
     */
    private final Map<UUID, Integer> spinning = new HashMap<>();

    public InfernalTridentListener(JavaPlugin plugin, InfernalItems items) {
        this.plugin = plugin;
        this.items = items;
    }

    public void start() {
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::scanPlayers, 40L, 40L);
        spinTask = plugin.getServer().getScheduler().runTaskTimer(plugin, this::spinTick, 1L, 1L);
    }

    public void stop() {
        if (task != null) task.cancel();
        if (spinTask != null) spinTask.cancel();
        task = null;
        spinTask = null;
        for (UUID id : spinning.keySet()) {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null) p.setRiptiding(false);
        }
        spinning.clear();
    }

    /** Cada tick: termina el giro a los 20 ticks o al tocar el suelo, y golpea al primer mob con el que choque. */
    private void spinTick() {
        if (spinning.isEmpty()) return;
        Iterator<Map.Entry<UUID, Integer>> it = spinning.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> entry = it.next();
            Player player = plugin.getServer().getPlayer(entry.getKey());
            if (player == null || !player.isOnline() || player.isDead()) {
                it.remove();
                continue;
            }
            int ticks = entry.getValue() + 1;
            entry.setValue(ticks);
            boolean end = ticks >= SPIN_TICKS || (ticks > 3 && player.isOnGround());
            if (!end) {
                LivingEntity hit = firstTouching(player);
                if (hit != null) {
                    hit.damage(SPIN_DAMAGE + items.netheriteTridentDamageBonus(), player);
                    // Como la vanilla: al chocar rebota un poco hacia atrás y deja de girar.
                    player.setVelocity(player.getVelocity().multiply(-0.2));
                    end = true;
                }
            }
            if (end) {
                player.setRiptiding(false);
                it.remove();
            }
        }
    }

    /** Primer ser vivo (que no sea el jugador, ni un espectador o creativo) que toca al jugador mientras gira. */
    private static LivingEntity firstTouching(Player player) {
        for (Entity e : player.getNearbyEntities(0.6, 0.6, 0.6)) {
            if (!(e instanceof LivingEntity living) || living.isDead() || e instanceof ArmorStand) continue;
            if (e instanceof Player other && (other.getGameMode() == GameMode.CREATIVE || other.getGameMode() == GameMode.SPECTATOR)) continue;
            return living;
        }
        return null;
    }

    // ------------------------------------------------------------------ propulsión en la lava

    /** Lanzar el Tridente Infernal (cargado y soltado) estando en la lava = Propulsión Ígnea en vez de lanzarlo. */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onLaunch(ProjectileLaunchEvent event) {
        if (!(event.getEntity() instanceof Trident trident) || !(trident.getShooter() instanceof Player player)) return;
        ItemStack item = trident.getItemStack();
        int level = items.lavaRiptideLevel(item);
        if (level <= 0) return; // sin Propulsión Ígnea: se lanza normal

        event.setCancelled(true); // el tridente se queda en la mano
        if (!player.isInLava()) {
            // Fuera de la lava no funciona (como la Propulsión vanilla fuera del agua). En el agua o con lluvia se "apaga".
            if (player.isInWaterOrRain()) {
                player.getWorld().playSound(player.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 0.8f, 1.2f);
            }
            plugin.getServer().getScheduler().runTask(plugin, player::updateInventory);
            return;
        }
        double strength = (1.5 + 0.75 * (level - 1)) * items.netheriteTridentRiptideMultiplier();
        Vector push = player.getLocation().getDirection().normalize().multiply(strength);
        player.setVelocity(push);
        player.setRiptiding(true);
        spinning.put(player.getUniqueId(), 0);
        Sound sound = level >= 3 ? Sound.ITEM_TRIDENT_RIPTIDE_3 : level == 2 ? Sound.ITEM_TRIDENT_RIPTIDE_2 : Sound.ITEM_TRIDENT_RIPTIDE_1;
        player.getWorld().playSound(player.getLocation(), sound, 1.0f, 1.0f);
        plugin.getServer().getScheduler().runTask(plugin, player::updateInventory);
    }

    // ------------------------------------------------------------------ empalamiento solo en la lava

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        ItemStack weapon = null;
        Entity damager = event.getDamager();
        if (damager instanceof Trident trident) {
            weapon = trident.getItemStack();
        } else if (damager instanceof Player player && event.getCause() == DamageCause.ENTITY_ATTACK) {
            weapon = player.getInventory().getItemInMainHand();
        }
        if (weapon == null || !items.isInfernalTrident(weapon)) return;
        int impaling = weapon.getEnchantmentLevel(Enchantment.IMPALING);
        if (impaling <= 0) return;

        Entity target = event.getEntity();
        double bonus = IMPALING_PER_LEVEL * impaling;
        boolean vanillaApplied = Tag.ENTITY_TYPES_SENSITIVE_TO_IMPALING.isTagged(target.getType());
        double adjust = (target.isInLava() ? bonus : 0.0) - (vanillaApplied ? bonus : 0.0);
        if (adjust != 0.0) event.setDamage(Math.max(0.0, event.getDamage() + adjust));
    }

    // ------------------------------------------------------------------ mantener la Propulsión fuera del encantamiento

    @EventHandler(priority = EventPriority.HIGH)
    public void onAnvil(PrepareAnvilEvent event) {
        ItemStack result = event.getResult();
        if (result == null || !items.isInfernalTrident(result)) return;
        result = result.clone();
        items.normalizeInfernalTrident(result);
        // La Propulsión (también la Ígnea) no se puede juntar con Lealtad ni Canalización.
        if (items.lavaRiptideLevel(result) > 0 && (result.getEnchantmentLevel(Enchantment.LOYALTY) > 0
                || result.getEnchantmentLevel(Enchantment.CHANNELING) > 0)) {
            event.setResult(null);
            return;
        }
        event.setResult(result);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEnchant(EnchantItemEvent event) {
        ItemStack item = event.getItem();
        if (!items.isInfernalTrident(item)) return;
        Map<Enchantment, Integer> add = event.getEnchantsToAdd();
        boolean hasLavaRiptide = items.lavaRiptideLevel(item) > 0 || add.containsKey(Enchantment.RIPTIDE);
        if (hasLavaRiptide) {
            add.remove(Enchantment.LOYALTY);
            add.remove(Enchantment.CHANNELING);
        }
        // La Propulsión que se añada se convierte en Ígnea en el tick siguiente (cuando ya está en el tridente).
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            ItemStack inTable = event.getInventory().getItem(0);
            if (inTable != null && items.isInfernalTrident(inTable) && items.normalizeInfernalTrident(inTable)) {
                event.getInventory().setItem(0, inTable);
            }
        });
    }

    /** Cada 2 segundos: tridentes infernales con la Propulsión de verdad (por /enchant, creativo...) -> Propulsión Ígnea. */
    private void scanPlayers() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            PlayerInventory inv = player.getInventory();
            ItemStack[] contents = inv.getContents();
            for (int i = 0; i < contents.length; i++) {
                ItemStack item = contents[i];
                if (item == null || item.getEnchantmentLevel(Enchantment.RIPTIDE) <= 0 || !items.isInfernalTrident(item)) continue;
                items.normalizeInfernalTrident(item);
                inv.setItem(i, item);
            }
        }
    }
}
