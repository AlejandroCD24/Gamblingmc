package dev.infernal.armor;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Dice con qué tinte de Minecraft está teñida una pieza (los 16 colores de tinte vanilla, mismos valores que
 * {@code org.bukkit.DyeColor#getColor()}). Las piezas teñidas con este plugin tienen exactamente el color de un tinte, así que
 * el resultado es ese tinte. Si una pieza tuviera otro color (p. ej. dada con /give), se compara en el espacio CIELAB, que se
 * parece a cómo ve el color una persona, y se devuelve el tinte más cercano.
 * Es lógica pura (colores 0xRRGGBB, nombres como los de {@code DyeColor}) para poder probarla sin servidor.
 */
final class DyeTone {

    private DyeTone() {}

    /** Nombre (como {@code DyeColor#name()}) -> color 0xRRGGBB del tinte. */
    static final Map<String, Integer> DYES = new LinkedHashMap<>();

    static {
        DYES.put("WHITE", 0xF9FFFE);
        DYES.put("ORANGE", 0xF9801D);
        DYES.put("MAGENTA", 0xC74EBD);
        DYES.put("LIGHT_BLUE", 0x3AB3DA);
        DYES.put("YELLOW", 0xFED83D);
        DYES.put("LIME", 0x80C71F);
        DYES.put("PINK", 0xF38BAA);
        DYES.put("GRAY", 0x474F52);
        DYES.put("LIGHT_GRAY", 0x9D9D97);
        DYES.put("CYAN", 0x169C9C);
        DYES.put("PURPLE", 0x8932B8);
        DYES.put("BLUE", 0x3C44AA);
        DYES.put("BROWN", 0x835432);
        DYES.put("GREEN", 0x5E7C16);
        DYES.put("RED", 0xB02E26);
        DYES.put("BLACK", 0x1D1D21);
    }

    /** Tinte más cercano al color (nombre como en DyeColor, p. ej. "RED"). */
    static String nearest(int rgb) {
        double[] lab = lab(rgb);
        String best = null;
        double bestDist = Double.MAX_VALUE;
        for (Map.Entry<String, Integer> e : DYES.entrySet()) {
            double[] o = lab(e.getValue());
            double d = sq(lab[0] - o[0]) + sq(lab[1] - o[1]) + sq(lab[2] - o[2]);
            if (d < bestDist) {
                bestDist = d;
                best = e.getKey();
            }
        }
        return best;
    }

    /** Normaliza un nombre del config ("red", "Light Blue", "light-blue"...) al formato de DyeColor, o null si no es un tinte. */
    static String normalize(String name) {
        if (name == null) return null;
        String n = name.trim().toUpperCase(Locale.ROOT).replace(' ', '_').replace('-', '_');
        return DYES.containsKey(n) ? n : null;
    }

    private static double sq(double v) {
        return v * v;
    }

    private static double[] lab(int rgb) {
        double r = lin(((rgb >> 16) & 0xFF) / 255.0);
        double g = lin(((rgb >> 8) & 0xFF) / 255.0);
        double b = lin((rgb & 0xFF) / 255.0);
        // sRGB (D65) -> XYZ, normalizado por el blanco de referencia
        double x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047;
        double y = (0.2126 * r + 0.7152 * g + 0.0722 * b);
        double z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883;
        double fx = f(x), fy = f(y), fz = f(z);
        return new double[] {116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)};
    }

    private static double lin(double c) {
        return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    }

    private static double f(double t) {
        return t > 216.0 / 24389.0 ? Math.cbrt(t) : (24389.0 / 27.0 * t + 16) / 116.0;
    }
}
