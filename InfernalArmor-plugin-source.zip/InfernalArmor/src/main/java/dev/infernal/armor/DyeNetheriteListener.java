package dev.infernal.armor;

import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.CrafterCraftEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.recipe.CraftingBookCategory;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

/**
 * Teñir armadura de netherite en la mesa de crafteo (y en el inventario 2x2):
 * <b>una pieza de netherite + un tinte vanilla</b> -> la misma pieza con el color exacto de ese tinte.
 * Los tintes NO se mezclan: la receta admite un solo tinte, y volver a teñir una pieza ya teñida sustituye su color por el del tinte nuevo
 * (con el mismo color que ya tiene no hay resultado, para no gastar el tinte).
 *
 * <p>Se registra una receta sin forma (pieza + 1 tinte) para que el juego consuma los ingredientes con normalidad;
 * el resultado real (la pieza del jugador con su color, encantamientos, diseño, daño y nombre) se calcula en
 * {@link PrepareItemCraftEvent}, porque una receta fija no puede conservar los datos de la pieza.
 *
 * <p>Solo vale la netherite normal: las piezas infernal, celestial, del Vacío y del Fin (también de material netherite) no se tiñen.
 * La pieza teñida sigue siendo de netherite, así que se puede mejorar en la mesa de herrería y ponerle diseños como siempre
 * (la mejora a infernal/celestial descarta el tinte; el tono decide cuál de las dos se puede forjar, ver smithing-dye-tones).
 */
public final class DyeNetheriteListener implements Listener {

    private static final String KEY_PREFIX = "dye_netherite_";

    private final JavaPlugin plugin;
    private final InfernalItems items;
    private final String namespace;
    private final List<NamespacedKey> keys = new ArrayList<>();

    public DyeNetheriteListener(JavaPlugin plugin, InfernalItems items, String namespace) {
        this.plugin = plugin;
        this.items = items;
        this.namespace = namespace;
    }

    public void register() {
        List<Material> armor = List.of(Material.NETHERITE_HELMET, Material.NETHERITE_CHESTPLATE,
                Material.NETHERITE_LEGGINGS, Material.NETHERITE_BOOTS);
        List<Material> dyes = new ArrayList<>();
        for (DyeColor color : DyeColor.values()) dyes.add(dyeMaterial(color));

        NamespacedKey key = new NamespacedKey(plugin, KEY_PREFIX + "armor");
        // El resultado de la receta es solo un marcador: PrepareItemCraftEvent lo sustituye por la pieza teñida.
        ShapelessRecipe recipe = new ShapelessRecipe(key, new ItemStack(Material.NETHERITE_HELMET));
        recipe.addIngredient(new RecipeChoice.MaterialChoice(armor));
        recipe.addIngredient(new RecipeChoice.MaterialChoice(dyes));
        recipe.setGroup("infernal_dye_netherite");
        recipe.setCategory(CraftingBookCategory.EQUIPMENT);
        Bukkit.addRecipe(recipe);
        keys.add(key);
    }

    public void unregister() {
        for (NamespacedKey k : keys) Bukkit.removeRecipe(k);
        keys.clear();
    }

    private static Material dyeMaterial(DyeColor color) {
        return Material.valueOf(color.name() + "_DYE");
    }

    /** Color 0xRRGGBB del tinte si el material es un tinte, o null. */
    private static Integer dyeRgb(Material material) {
        String name = material.name();
        if (!name.endsWith("_DYE")) return null;
        try {
            return DyeColor.valueOf(name.substring(0, name.length() - 4)).getColor().asRGB();
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    private boolean isOurs(Object recipe) {
        if (!(recipe instanceof Keyed keyed)) return false;
        NamespacedKey key = keyed.getKey();
        return key.getNamespace().equals(namespace) && key.getKey().startsWith(KEY_PREFIX);
    }

    @EventHandler
    public void onPrepare(PrepareItemCraftEvent event) {
        if (!isOurs(event.getRecipe())) return;
        CraftingInventory inv = event.getInventory();

        ItemStack piece = null;
        Integer dye = null;
        for (ItemStack stack : inv.getMatrix()) {
            if (stack == null || stack.getType().isAir()) continue;
            Integer rgb = items.isIngredient(stack) ? null : dyeRgb(stack.getType());
            if (rgb != null && dye == null) {
                dye = rgb;
            } else if (rgb == null && piece == null && items.isDyeableNetherite(stack)) {
                piece = stack;
            } else {
                // un segundo tinte, una segunda pieza o algo que no es tinte ni netherite normal (p. ej. una pieza infernal)
                inv.setResult(null);
                return;
            }
        }
        if (piece == null || dye == null || items.dyedColorOf(piece) == dye) {
            inv.setResult(null);
            return;
        }
        inv.setResult(items.dyeNetherite(piece, dye));
    }

    /** El crafter no pasa por PrepareItemCraftEvent: sacaría la pieza marcador sin teñir, así que no se permite. */
    @EventHandler
    public void onCrafter(CrafterCraftEvent event) {
        if (isOurs(event.getRecipe())) event.setCancelled(true);
    }
}
