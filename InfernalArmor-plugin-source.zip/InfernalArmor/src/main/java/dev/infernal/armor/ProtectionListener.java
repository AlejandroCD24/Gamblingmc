package dev.infernal.armor;

import org.bukkit.Keyed;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;

/** Evita que los ingredientes infernales (mismo material que uno vanilla) se usen como el vanilla. */
public final class ProtectionListener implements Listener {

    private final InfernalItems items;
    private final String namespace;

    public ProtectionListener(InfernalItems items, String namespace) {
        this.items = items;
        this.namespace = namespace;
    }

    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        Recipe recipe = event.getRecipe();
        if (recipe == null) return;
        if (recipe instanceof Keyed keyed && keyed.getKey().getNamespace().equals(namespace)) return;

        for (ItemStack stack : event.getInventory().getMatrix()) {
            // También se bloquea reparar piezas infernales / Espada del Alma en la cuadrícula (daría una de netherite).
            if (items.isIngredient(stack) || (event.isRepair() && items.isForgedGear(stack))) {
                event.getInventory().setResult(null);
                return;
            }
        }
    }

    /** El Cristal Celestial es un cristal del End de base, pero no se puede colocar (no genera el cristal real). */
    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (items.kindOf(event.getItem()) == InfernalItems.Kind.CELESTIAL_CRYSTAL) {
            event.setUseItemInHand(Event.Result.DENY);
        }
    }

    /** La cabeza y el huevo del dragón mutados no se pueden colocar como bloque: al hacerlo se perdería el objeto especial. */
    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        // La caja de shulker reforzada sí se puede colocar (ReinforcedShulkerListener guarda su contenido en el bloque).
        if (items.kindOf(event.getItemInHand()) == InfernalItems.Kind.REINFORCED_SHULKER) return;
        if (items.isIngredient(event.getItemInHand())) event.setCancelled(true);
    }

    // Estrella reforzada -> baliza, polvo de blaze -> soporte de pociones: no se permiten.
    private static boolean restricted(Inventory top) {
        InventoryType type = top.getType();
        return type == InventoryType.BEACON || type == InventoryType.BREWING;
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!restricted(top)) return;

        ItemStack moving = null;
        if (event.getClick().isShiftClick()) {
            if (event.getClickedInventory() != top) moving = event.getCurrentItem();
        } else if (event.getClickedInventory() == top) {
            moving = event.getCursor();
            if (event.getClick() == ClickType.NUMBER_KEY) {
                moving = event.getWhoClicked().getInventory().getItem(event.getHotbarButton());
            } else if (event.getClick() == ClickType.SWAP_OFFHAND) {
                moving = event.getWhoClicked().getInventory().getItemInOffHand();
            }
        }
        if (items.isIngredient(moving)) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!restricted(top) || !items.isIngredient(event.getOldCursor())) return;
        for (int slot : event.getRawSlots()) {
            if (slot < top.getSize()) {
                event.setCancelled(true);
                return;
            }
        }
    }
}
