package dev.infernal.armor;

import com.destroystokyo.paper.event.entity.EntityAddToWorldEvent;
import io.papermc.paper.datacomponent.DataComponentTypes;
import net.kyori.adventure.key.Key;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRiptideEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Tridente de Netherite:
 *  - Lanzado: +1 de daño (netherite-trident.damage-bonus; vanilla 8 -> 9). El cuerpo a cuerpo (+1) va en sus atributos.
 *  - Propulsión (Riptide): el doble de impulso (netherite-trident.riptide-multiplier) y +1 de daño al chocar con un mob.
 *  - Aspecto del tridente lanzado: el juego dibuja SIEMPRE el tridente lanzado con la textura vanilla (no se puede cambiar
 *    por objeto con un resource pack), así que el tridente real se oculta a los jugadores y un item display con el modelo 3D
 *    de netherite lo sigue tick a tick con la misma posición y el mismo giro (netherite-trident.thrown-model).
 *    El tridente sigue existiendo y funcionando igual en el servidor (golpea, se clava, vuelve con Lealtad, se recoge...).
 */
public final class NetheriteTridentListener implements Listener {

    /**
     * Centro del objeto en el modelo 3D, ya girado por el item display: el juego centra el modelo restando 0.5 bloques y el
     * modelo JSON está subido 16 píxeles (DY en tools/make_netherite_trident.py), así que el punto del tridente queda en
     * (-0.5, 0.5, -0.5); tras el giro de 180 grados del item display, (0.5, 0.5, 0.5).
     */
    private static final Vector3f MODEL_CENTER_OFFSET = new Vector3f(0.5f, 0.5f, 0.5f);

    private final JavaPlugin plugin;
    private final InfernalItems items;
    /** Tridentes de netherite lanzados que se están dibujando: UUID del tridente -> su item display. */
    private final Map<UUID, Shown> shown = new HashMap<>();
    /** Jugadores cuya última propulsión fue con un Tridente de Netherite (para el +1 de daño del choque). */
    private final Set<UUID> netheriteRiptide = new HashSet<>();
    private BukkitTask task;

    private static final class Shown {
        final Trident trident;
        ItemDisplay display;
        float yaw = Float.NaN;
        float pitch = Float.NaN;

        Shown(Trident trident) {
            this.trident = trident;
        }
    }

    public NetheriteTridentListener(JavaPlugin plugin, InfernalItems items) {
        this.plugin = plugin;
        this.items = items;
    }

    public void start() {
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
        // Tridentes que ya estaban cargados antes de activar el plugin (chunks del spawn, /reload...).
        for (World world : plugin.getServer().getWorlds()) {
            for (Trident trident : world.getEntitiesByClass(Trident.class)) handle(trident);
        }
    }

    /** Al apagar: quita los item displays y vuelve a mostrar los tridentes (así se guardan visibles). */
    public void stop() {
        if (task != null) task.cancel();
        task = null;
        for (Shown s : shown.values()) {
            if (s.display != null && s.display.isValid()) s.display.remove();
            if (s.trident.isValid()) s.trident.setVisibleByDefault(true);
        }
        shown.clear();
        netheriteRiptide.clear();
    }

    // ------------------------------------------------------------------ daño

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        double bonus = items.netheriteTridentDamageBonus();
        if (bonus <= 0.0) return;

        Entity damager = event.getDamager();
        if (damager instanceof Trident trident) {
            // Tridente lanzado.
            if (items.isNetheriteBasedTrident(trident.getItemStack())) event.setDamage(event.getDamage() + bonus);
        } else if (damager instanceof Player player) {
            // Choque con la propulsión: el juego usa un daño fijo (8) en vez de los atributos del arma.
            if (event.getCause() == DamageCause.ENTITY_ATTACK && player.isRiptiding()
                    && netheriteRiptide.contains(player.getUniqueId())) {
                event.setDamage(event.getDamage() + bonus);
            }
        }
    }

    // ------------------------------------------------------------------ propulsión

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onRiptide(PlayerRiptideEvent event) {
        Player player = event.getPlayer();
        if (!items.isNetheriteTrident(event.getItem())) {
            netheriteRiptide.remove(player.getUniqueId());
            return;
        }
        netheriteRiptide.add(player.getUniqueId());

        double multiplier = items.netheriteTridentRiptideMultiplier();
        if (multiplier <= 1.0) return;
        // La propulsión la calcula el cliente: el servidor le manda la velocidad final (impulso x multiplicador) en el tick
        // siguiente, cuando el impulso vanilla ya se ha aplicado.
        Vector boost = event.getVelocity().clone().multiply(multiplier);
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (player.isOnline() && player.isValid()) player.setVelocity(boost);
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        netheriteRiptide.remove(event.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ aspecto del tridente lanzado

    /** Se lanza un tridente, se carga un chunk con uno clavado o cruza un portal: todos pasan por aquí. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onAddToWorld(EntityAddToWorldEvent event) {
        if (event.getEntity() instanceof Trident trident) handle(trident);
    }

    private void handle(Trident trident) {
        if (!items.isNetheriteBasedTrident(trident.getItemStack())) return;

        if (!items.netheriteTridentThrownModel()) {
            // Por si quedó oculto de antes (opción desactivada después): se vuelve a ver el tridente vanilla.
            if (!trident.isVisibleByDefault()) trident.setVisibleByDefault(true);
            return;
        }
        // Se oculta ya (antes de que los jugadores lo reciban) y el item display se crea en el tick siguiente,
        // cuando el tridente ya está del todo en el mundo.
        trident.setVisibleByDefault(false);
        plugin.getServer().getScheduler().runTask(plugin, () -> track(trident));
    }

    private void track(Trident trident) {
        if (!trident.isValid()) return;
        Shown old = shown.get(trident.getUniqueId());
        if (old != null) {
            if (old.trident == trident && old.trident.isValid()) return; // ya se está dibujando
            // Mismo UUID pero otra entidad (p. ej. el tridente cruzó un portal): se cambia por la nueva.
            if (old.display != null && old.display.isValid()) old.display.remove();
        }
        Shown s = new Shown(trident);
        s.display = spawnDisplay(s);
        shown.put(trident.getUniqueId(), s);
    }

    private void tick() {
        if (shown.isEmpty()) return;
        Iterator<Shown> it = shown.values().iterator();
        while (it.hasNext()) {
            Shown s = it.next();
            Trident trident = s.trident;
            if (!trident.isValid()) {
                // Recogido, destruido, descargado con su chunk o pasado a otra dimensión (allí se vuelve a registrar).
                if (s.display != null && s.display.isValid()) s.display.remove();
                it.remove();
                continue;
            }
            if (s.display == null || !s.display.isValid() || s.display.getWorld() != trident.getWorld()) {
                if (s.display != null && s.display.isValid()) s.display.remove();
                s.yaw = Float.NaN;
                s.display = spawnDisplay(s);
                continue;
            }
            Location loc = trident.getLocation();
            float yaw = loc.getYaw();
            float pitch = loc.getPitch();
            loc.setYaw(0f);
            loc.setPitch(0f);
            if (s.display.getLocation().distanceSquared(loc) > 1.0E-6) s.display.teleport(loc);
            if (yaw != s.yaw || pitch != s.pitch) {
                s.yaw = yaw;
                s.pitch = pitch;
                s.display.setInterpolationDelay(0);
                s.display.setInterpolationDuration(1);
                s.display.setTransformation(transformation(yaw, pitch));
            }
        }
    }

    private ItemDisplay spawnDisplay(Shown s) {
        Trident trident = s.trident;
        Location loc = trident.getLocation();
        float yaw = loc.getYaw();
        float pitch = loc.getPitch();
        loc.setYaw(0f);
        loc.setPitch(0f);
        s.yaw = yaw;
        s.pitch = pitch;
        // El mismo objeto (con su brillo si está encantado, como el tridente vanilla lanzado), siempre con el modelo de netherite
        // (por si se forjó cuando el resource pack estaba desactivado). En el contexto "none" el pack usa el modelo 3D.
        ItemStack look = trident.getItemStack().clone();
        InfernalItems.Kind kind = items.isInfernalTrident(look) ? InfernalItems.Kind.INFERNAL_TRIDENT : InfernalItems.Kind.NETHERITE_TRIDENT;
        look.setData(DataComponentTypes.ITEM_MODEL, Key.key(InfernalItems.PACK_NAMESPACE, kind.id()));
        return trident.getWorld().spawn(loc, ItemDisplay.class, display -> {
            display.setPersistent(false);
            display.setItemStack(look);
            display.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
            display.setTeleportDuration(1);
            display.setInterpolationDuration(1);
            display.setTransformation(transformation(yaw, pitch));
        });
    }

    /**
     * Giro del modelo para que quede igual que el tridente vanilla lanzado. El juego lo dibuja con
     * Ry(yaw - 90) * Rz(pitch + 90) sobre el modelo de entidad; el item display añade Ry(180) y el modelo JSON es el de entidad
     * girado 180 grados en X (Ry(180) * Rx(180) = Rz(180)), así que el giro es Ry(yaw - 90) * Rz(pitch - 90) y la traslación
     * devuelve el centro del modelo al punto del tridente.
     */
    static Transformation transformation(float yaw, float pitch) {
        Quaternionf rotation = new Quaternionf()
                .rotationY((float) Math.toRadians(yaw - 90.0))
                .rotateZ((float) Math.toRadians(pitch - 90.0));
        Vector3f translation = rotation.transform(new Vector3f(MODEL_CENTER_OFFSET)).negate();
        return new Transformation(translation, rotation, new Vector3f(1f, 1f, 1f), new Quaternionf());
    }
}
