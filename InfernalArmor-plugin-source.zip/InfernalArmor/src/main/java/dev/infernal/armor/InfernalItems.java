package dev.infernal.armor;

import io.papermc.paper.datacomponent.DataComponentType;
import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.datacomponent.item.DyedItemColor;
import io.papermc.paper.datacomponent.item.Equippable;
import io.papermc.paper.datacomponent.item.ItemAttributeModifiers;
import io.papermc.paper.datacomponent.item.ItemLore;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Crea e identifica todos los objetos infernales. */
public final class InfernalItems {

    /** Namespace del resource pack (assets/infernal/...). */
    public static final String PACK_NAMESPACE = "infernal";
    private static final TextColor COLOR = TextColor.color(0xFF4030);
    private static final TextColor SOUL_COLOR = TextColor.color(0x8FE3FF);
    private static final TextColor GREED_COLOR = TextColor.color(0xFFB830);
    private static final TextColor PURE_COLOR = TextColor.color(0xE8F6FF);
    private static final TextColor CELESTIAL_COLOR = TextColor.color(0xFF9AD5);
    private static final TextColor VOID_COLOR = TextColor.color(0x9D5CFF);
    private static final TextColor END_COLOR = TextColor.color(0xD59BFF);
    /** Color del nombre del Mazo Yin Yang y de su núcleo. */
    private static final TextColor YIN_YANG_COLOR = TextColor.color(0xEDEDED);
    /** Línea de descripción del Mazo Yin Yang (se rehace al cambiar el nivel en el config). */
    private static final String YIN_YANG_LORE_PREFIX = "Aeroimpulso ";
    private static final String YIN_YANG_LORE_SUFFIX = " incorporado";
    /** Color del nombre de los ingredientes compartidos por el Vacío y el Fin (aliento, cabeza, fruto y huevo). */
    private static final TextColor MUTATED_COLOR = TextColor.color(0xC44DFF);
    /** Prefijo de las líneas de descripción que describen el bono del set completo de una armadura. */
    private static final String SET_LORE_PREFIX = "Set completo:";
    /** Línea de descripción que la Espada del Alma añade (se quita al corromperla). */
    private static final String SOUL_SWORD_LORE = "Forjada con el alma de ghast muertos";
    /** Línea de descripción que la Espada del Alma Corrompida añade (se quita al hacerla infernal). */
    private static final String GREED_SWORD_LORE = "Espada corrompida por la codicia";
    /** Línea de descripción que la Espada Purificada añade (se quita al hacerla celestial). */
    private static final String PURIFIED_SWORD_LORE = "Purificada de toda corrupción";
    /** Modificador de daño de la espada de netherite (7) + 1 base del jugador = 8 de daño. */
    private static final double NETHERITE_SWORD_DAMAGE = 7.0;
    private static final double SWORD_ATTACK_SPEED = -2.4;
    /** Modificadores del tridente vanilla (8 + 1 del jugador = 9 de daño; 4 - 2.9 = 1.1 de velocidad de ataque). Solo se usan
     *  si no se pueden leer del propio juego. */
    private static final double TRIDENT_DAMAGE = 8.0;
    private static final double TRIDENT_ATTACK_SPEED = -2.9;
    /** Modificadores del mazo vanilla (5 + 1 = 6 de daño; 4 - 3.4 = 0.6 de velocidad de ataque). Solo si no se pueden leer del juego. */
    private static final double MACE_DAMAGE = 5.0;
    private static final double MACE_ATTACK_SPEED = -3.4;
    /** Velocidad de ataque base del jugador (el modificador del arma se suma a este valor). */
    private static final double PLAYER_BASE_ATTACK_SPEED = 4.0;
    private static final String[] ROMAN = {"I", "II", "III", "IV", "V"};
    /** Las 17 cajas de shulker (sin teñir + 16 colores): la caja reforzada puede tener cualquiera de ellas. */
    public static final List<Material> SHULKER_BOXES = List.of(
            Material.SHULKER_BOX, Material.WHITE_SHULKER_BOX, Material.ORANGE_SHULKER_BOX, Material.MAGENTA_SHULKER_BOX,
            Material.LIGHT_BLUE_SHULKER_BOX, Material.YELLOW_SHULKER_BOX, Material.LIME_SHULKER_BOX,
            Material.PINK_SHULKER_BOX, Material.GRAY_SHULKER_BOX, Material.LIGHT_GRAY_SHULKER_BOX,
            Material.CYAN_SHULKER_BOX, Material.PURPLE_SHULKER_BOX, Material.BLUE_SHULKER_BOX,
            Material.BROWN_SHULKER_BOX, Material.GREEN_SHULKER_BOX, Material.RED_SHULKER_BOX,
            Material.BLACK_SHULKER_BOX);

    public enum Kind {
        INGOT, STAR, POWDER, TEMPLATE, SOUL_INGOT, SOUL_TEMPLATE, SOUL_SWORD,
        GREED_INGOT, GREED_TEMPLATE, GREED_SWORD, INFERNAL_SWORD,
        PURIFIED_INGOT, PURIFIED_TEMPLATE, PURIFIED_SWORD,
        CELESTIAL_DUST, CELESTIAL_CRYSTAL, CELESTIAL_INGOT, CELESTIAL_TEMPLATE, CELESTIAL_SWORD,
        // Ingredientes de las armaduras del Vacío y del Fin (la cabeza y el huevo tienen una versión para cada armadura).
        MUTATED_BREATH, VOID_DRAGON_HEAD, END_DRAGON_HEAD, FERMENTED_FRUIT, VOID_DRAGON_EGG, END_DRAGON_EGG,
        VOID_INGOT, END_INGOT,
        // Plantillas del Vacío y del Fin y sus ingredientes (caja de shulker reforzada y obsidianas teñidas).
        REINFORCED_SHULKER, DYED_OBSIDIAN, DYED_CRYING_OBSIDIAN, VOID_TEMPLATE, END_TEMPLATE,
        // Tridente de Netherite (mejora vanilla del tridente en la mesa de herrería). Va antes de las herramientas y armaduras
        // porque isTool() / isArmor() usan rangos de ordinal.
        NETHERITE_TRIDENT,
        // Tridente Infernal (Tridente de Netherite + Plantilla y Lingote Infernal): Propulsión solo en la lava.
        INFERNAL_TRIDENT,
        // Mazo Yin Yang (mazo + Núcleo Yin Yang en la mesa de herrería). El núcleo sale en las bóvedas ominosas.
        YIN_YANG_CORE, YIN_YANG_MACE,
        SOUL_AXE, SOUL_PICKAXE, SOUL_SHOVEL, SOUL_HOE, SOUL_SPEAR,
        GREED_AXE, GREED_PICKAXE, GREED_SHOVEL, GREED_HOE, GREED_SPEAR,
        PURIFIED_AXE, PURIFIED_PICKAXE, PURIFIED_SHOVEL, PURIFIED_HOE, PURIFIED_SPEAR,
        INFERNAL_AXE, INFERNAL_PICKAXE, INFERNAL_SHOVEL, INFERNAL_HOE, INFERNAL_SPEAR,
        CELESTIAL_AXE, CELESTIAL_PICKAXE, CELESTIAL_SHOVEL, CELESTIAL_HOE, CELESTIAL_SPEAR,
        HELMET, CHESTPLATE, LEGGINGS, BOOTS,
        CELESTIAL_HELMET, CELESTIAL_CHESTPLATE, CELESTIAL_LEGGINGS, CELESTIAL_BOOTS,
        VOID_HELMET, VOID_CHESTPLATE, VOID_LEGGINGS, VOID_BOOTS,
        END_HELMET, END_CHESTPLATE, END_LEGGINGS, END_BOOTS;

        public String id() {
            return name().toLowerCase(Locale.ROOT);
        }

        /** Cualquier pieza de armadura forjada (infernal, celestial, del Vacío o del Fin). */
        public boolean isArmor() {
            return ordinal() >= HELMET.ordinal();
        }

        /** Pieza de la armadura infernal. */
        public boolean isInfernalArmor() {
            return ordinal() >= HELMET.ordinal() && ordinal() <= BOOTS.ordinal();
        }

        /** Pieza de la armadura celestial. */
        public boolean isCelestialArmor() {
            return ordinal() >= CELESTIAL_HELMET.ordinal() && ordinal() <= CELESTIAL_BOOTS.ordinal();
        }

        /** Pieza de la armadura del Vacío (viene de la infernal). */
        public boolean isVoidArmor() {
            return ordinal() >= VOID_HELMET.ordinal() && ordinal() <= VOID_BOOTS.ordinal();
        }

        /** Pieza de la armadura del Fin (viene de la celestial). */
        public boolean isEndArmor() {
            return ordinal() >= END_HELMET.ordinal() && ordinal() <= END_BOOTS.ordinal();
        }

        /** Set al que pertenece esta pieza de armadura (null si no es una armadura). */
        public ArmorSet armorSet() {
            if (isInfernalArmor()) return ArmorSet.INFERNAL;
            if (isCelestialArmor()) return ArmorSet.CELESTIAL;
            if (isVoidArmor()) return ArmorSet.VOID;
            if (isEndArmor()) return ArmorSet.END;
            return null;
        }

        /** La pieza del Vacío que corresponde a esta pieza infernal (casco infernal -> casco del Vacío...). */
        public Kind voidVersion() {
            return switch (this) {
                case HELMET -> VOID_HELMET;
                case CHESTPLATE -> VOID_CHESTPLATE;
                case LEGGINGS -> VOID_LEGGINGS;
                case BOOTS -> VOID_BOOTS;
                default -> this;
            };
        }

        /** La pieza del Fin que corresponde a esta pieza infernal o celestial (casco celestial -> casco del Fin...). */
        public Kind endVersion() {
            return switch (this) {
                case HELMET, CELESTIAL_HELMET -> END_HELMET;
                case CHESTPLATE, CELESTIAL_CHESTPLATE -> END_CHESTPLATE;
                case LEGGINGS, CELESTIAL_LEGGINGS -> END_LEGGINGS;
                case BOOTS, CELESTIAL_BOOTS -> END_BOOTS;
                default -> this;
            };
        }

        /** La pieza celestial que corresponde a esta pieza infernal (casco -> casco celestial...) o a esta herramienta del Alma (hacha del Alma -> hacha celestial...). */
        public Kind celestial() {
            return switch (this) {
                case HELMET -> CELESTIAL_HELMET;
                case CHESTPLATE -> CELESTIAL_CHESTPLATE;
                case LEGGINGS -> CELESTIAL_LEGGINGS;
                case BOOTS -> CELESTIAL_BOOTS;
                case SOUL_AXE -> CELESTIAL_AXE;
                case SOUL_PICKAXE -> CELESTIAL_PICKAXE;
                case SOUL_SHOVEL -> CELESTIAL_SHOVEL;
                case SOUL_HOE -> CELESTIAL_HOE;
                case SOUL_SPEAR -> CELESTIAL_SPEAR;
                default -> this;
            };
        }

        /** Cualquier herramienta forjada (del Alma, corrompida, purificada, infernal o celestial). */
        public boolean isTool() {
            return ordinal() >= SOUL_AXE.ordinal() && ordinal() <= CELESTIAL_SPEAR.ordinal();
        }

        /** Herramienta del Alma (hacha, pico, pala, azada o lanza). */
        public boolean isSoulTool() {
            return ordinal() >= SOUL_AXE.ordinal() && ordinal() <= SOUL_SPEAR.ordinal();
        }

        /** Herramienta corrompida por la codicia. */
        public boolean isGreedTool() {
            return ordinal() >= GREED_AXE.ordinal() && ordinal() <= GREED_SPEAR.ordinal();
        }

        /** Herramienta purificada. */
        public boolean isPurifiedTool() {
            return ordinal() >= PURIFIED_AXE.ordinal() && ordinal() <= PURIFIED_SPEAR.ordinal();
        }

        /** Herramienta infernal (hacha, pico, pala, azada o lanza). */
        public boolean isInfernalTool() {
            return ordinal() >= INFERNAL_AXE.ordinal() && ordinal() <= INFERNAL_SPEAR.ordinal();
        }

        /** Herramienta celestial (hacha, pico, pala, azada o lanza). */
        public boolean isCelestialTool() {
            return ordinal() >= CELESTIAL_AXE.ordinal() && ordinal() <= CELESTIAL_SPEAR.ordinal();
        }

        /** Herramienta de la última fase (infernal o celestial): +daño, +minería, velocidad de ataque propia y el doble de durabilidad. */
        public boolean isTopTool() {
            return isInfernalTool() || isCelestialTool();
        }

        /** Lanza (del Alma, corrompida, purificada, infernal o celestial). */
        public boolean isSpear() {
            return this == SOUL_SPEAR || this == GREED_SPEAR || this == PURIFIED_SPEAR
                    || this == INFERNAL_SPEAR || this == CELESTIAL_SPEAR;
        }

        /** Hacha (de cualquier fase). */
        public boolean isAxe() {
            return soul() == SOUL_AXE;
        }

        /** La herramienta del Alma equivalente (las demás vienen de ella; el resto se devuelve igual). */
        public Kind soul() {
            return switch (this) {
                case GREED_AXE, PURIFIED_AXE, INFERNAL_AXE, CELESTIAL_AXE -> SOUL_AXE;
                case GREED_PICKAXE, PURIFIED_PICKAXE, INFERNAL_PICKAXE, CELESTIAL_PICKAXE -> SOUL_PICKAXE;
                case GREED_SHOVEL, PURIFIED_SHOVEL, INFERNAL_SHOVEL, CELESTIAL_SHOVEL -> SOUL_SHOVEL;
                case GREED_HOE, PURIFIED_HOE, INFERNAL_HOE, CELESTIAL_HOE -> SOUL_HOE;
                case GREED_SPEAR, PURIFIED_SPEAR, INFERNAL_SPEAR, CELESTIAL_SPEAR -> SOUL_SPEAR;
                default -> this;
            };
        }

        /** La herramienta corrompida que corresponde a esta herramienta del Alma. */
        public Kind greed() {
            return switch (this) {
                case SOUL_AXE -> GREED_AXE;
                case SOUL_PICKAXE -> GREED_PICKAXE;
                case SOUL_SHOVEL -> GREED_SHOVEL;
                case SOUL_HOE -> GREED_HOE;
                case SOUL_SPEAR -> GREED_SPEAR;
                default -> this;
            };
        }

        /** La herramienta purificada que corresponde a esta herramienta del Alma. */
        public Kind purified() {
            return switch (this) {
                case SOUL_AXE -> PURIFIED_AXE;
                case SOUL_PICKAXE -> PURIFIED_PICKAXE;
                case SOUL_SHOVEL -> PURIFIED_SHOVEL;
                case SOUL_HOE -> PURIFIED_HOE;
                case SOUL_SPEAR -> PURIFIED_SPEAR;
                default -> this;
            };
        }

        /** La herramienta infernal que corresponde a esta herramienta del Alma. */
        public Kind infernal() {
            return switch (this) {
                case SOUL_AXE -> INFERNAL_AXE;
                case SOUL_PICKAXE -> INFERNAL_PICKAXE;
                case SOUL_SHOVEL -> INFERNAL_SHOVEL;
                case SOUL_HOE -> INFERNAL_HOE;
                case SOUL_SPEAR -> INFERNAL_SPEAR;
                default -> this;
            };
        }

        /** Ingredientes personalizados (lingotes, estrella, polvo, plantillas). */
        public boolean isIngredient() {
            return this != SOUL_SWORD && this != GREED_SWORD && this != INFERNAL_SWORD && this != PURIFIED_SWORD
                    && this != CELESTIAL_SWORD && this != NETHERITE_TRIDENT && this != INFERNAL_TRIDENT && this != YIN_YANG_MACE && !isTool() && !isArmor();
        }

        /** Las cinco herramientas del Alma (se forjan desde sus equivalentes de netherite). */
        public static List<Kind> soulTools() {
            return List.of(SOUL_AXE, SOUL_PICKAXE, SOUL_SHOVEL, SOUL_HOE, SOUL_SPEAR);
        }

        /** Las cinco herramientas corrompidas (se forjan desde las del Alma). */
        public static List<Kind> greedTools() {
            return List.of(GREED_AXE, GREED_PICKAXE, GREED_SHOVEL, GREED_HOE, GREED_SPEAR);
        }

        /** Las cinco herramientas purificadas (se forjan desde las del Alma). */
        public static List<Kind> purifiedTools() {
            return List.of(PURIFIED_AXE, PURIFIED_PICKAXE, PURIFIED_SHOVEL, PURIFIED_HOE, PURIFIED_SPEAR);
        }

        /** Las cinco herramientas infernales (se forjan desde las corrompidas). */
        public static List<Kind> infernalTools() {
            return List.of(INFERNAL_AXE, INFERNAL_PICKAXE, INFERNAL_SHOVEL, INFERNAL_HOE, INFERNAL_SPEAR);
        }

        /** Las cinco herramientas celestiales (se forjan desde las purificadas). */
        public static List<Kind> celestialTools() {
            return List.of(CELESTIAL_AXE, CELESTIAL_PICKAXE, CELESTIAL_SHOVEL, CELESTIAL_HOE, CELESTIAL_SPEAR);
        }

        /** Las cuatro piezas de la armadura infernal. */
        public static List<Kind> armor() {
            return List.of(HELMET, CHESTPLATE, LEGGINGS, BOOTS);
        }

        /** Las cuatro piezas de la armadura celestial. */
        public static List<Kind> celestialArmor() {
            return List.of(CELESTIAL_HELMET, CELESTIAL_CHESTPLATE, CELESTIAL_LEGGINGS, CELESTIAL_BOOTS);
        }

        /** Las cuatro piezas de la armadura del Vacío. */
        public static List<Kind> voidArmor() {
            return List.of(VOID_HELMET, VOID_CHESTPLATE, VOID_LEGGINGS, VOID_BOOTS);
        }

        /** Las cuatro piezas de la armadura del Fin. */
        public static List<Kind> endArmor() {
            return List.of(END_HELMET, END_CHESTPLATE, END_LEGGINGS, END_BOOTS);
        }

        public static Kind byId(String id) {
            if (id == null) return null;
            for (Kind k : values()) if (k.id().equals(id)) return k;
            return null;
        }
    }

    /** Los cuatro sets de armadura forjada. El set completo exige las cuatro piezas del mismo set (no vale mezclar). */
    public enum ArmorSet {
        INFERNAL, CELESTIAL, VOID, END;

        /** Armaduras de la última fase (Vacío y Fin): resistencia y regeneración, protección contra mobs del End y contra explosiones. */
        public boolean isEndgame() {
            return this == VOID || this == END;
        }

        /** Las cuatro piezas del set, en orden casco, peto, pantalones, botas. */
        public List<Kind> pieces() {
            return switch (this) {
                case INFERNAL -> Kind.armor();
                case CELESTIAL -> Kind.celestialArmor();
                case VOID -> Kind.voidArmor();
                case END -> Kind.endArmor();
            };
        }
    }

    /** Efectos del set completo: amplificador de Resistencia y de Regeneración (-1 = sin Regeneración). */
    /** Efectos del set: nivel (amplificador) de Resistencia y de Regeneración (-1 = no da) y si da Resistencia al fuego (ningún set la da ahora). */
    public record SetBonus(int resistance, int regeneration, boolean fireResistance) {}

    private record ArmorSpec(Material netherite, EquipmentSlot slot, EquipmentSlotGroup group,
                             double baseArmor, String name) {}

    private static final Map<Kind, ArmorSpec> ARMOR = new EnumMap<>(Kind.class);

    /** Herramienta del Alma -> herramienta de netherite de la que se forja. */
    private static final Map<Kind, Material> SOUL_TOOLS = new EnumMap<>(Kind.class);

    static {
        SOUL_TOOLS.put(Kind.SOUL_AXE, Material.NETHERITE_AXE);
        SOUL_TOOLS.put(Kind.SOUL_PICKAXE, Material.NETHERITE_PICKAXE);
        SOUL_TOOLS.put(Kind.SOUL_SHOVEL, Material.NETHERITE_SHOVEL);
        SOUL_TOOLS.put(Kind.SOUL_HOE, Material.NETHERITE_HOE);
        SOUL_TOOLS.put(Kind.SOUL_SPEAR, Material.NETHERITE_SPEAR);

        ARMOR.put(Kind.HELMET, new ArmorSpec(Material.NETHERITE_HELMET, EquipmentSlot.HEAD,
                EquipmentSlotGroup.HEAD, 3, "Casco Infernal"));
        ARMOR.put(Kind.CHESTPLATE, new ArmorSpec(Material.NETHERITE_CHESTPLATE, EquipmentSlot.CHEST,
                EquipmentSlotGroup.CHEST, 8, "Peto Infernal"));
        ARMOR.put(Kind.LEGGINGS, new ArmorSpec(Material.NETHERITE_LEGGINGS, EquipmentSlot.LEGS,
                EquipmentSlotGroup.LEGS, 6, "Pantalones Infernales"));
        ARMOR.put(Kind.BOOTS, new ArmorSpec(Material.NETHERITE_BOOTS, EquipmentSlot.FEET,
                EquipmentSlotGroup.FEET, 3, "Botas Infernales"));

        // Armadura celestial: mismas estadísticas que la infernal (solo cambian el nombre y el aspecto).
        ARMOR.put(Kind.CELESTIAL_HELMET, new ArmorSpec(Material.NETHERITE_HELMET, EquipmentSlot.HEAD,
                EquipmentSlotGroup.HEAD, 3, "Casco Celestial"));
        ARMOR.put(Kind.CELESTIAL_CHESTPLATE, new ArmorSpec(Material.NETHERITE_CHESTPLATE, EquipmentSlot.CHEST,
                EquipmentSlotGroup.CHEST, 8, "Peto Celestial"));
        ARMOR.put(Kind.CELESTIAL_LEGGINGS, new ArmorSpec(Material.NETHERITE_LEGGINGS, EquipmentSlot.LEGS,
                EquipmentSlotGroup.LEGS, 6, "Pantalones Celestiales"));
        ARMOR.put(Kind.CELESTIAL_BOOTS, new ArmorSpec(Material.NETHERITE_BOOTS, EquipmentSlot.FEET,
                EquipmentSlotGroup.FEET, 3, "Botas Celestiales"));

        // Armadura del Vacío (viene de la infernal) y del Fin (viene de la celestial): mismas estadísticas que ellas.
        ARMOR.put(Kind.VOID_HELMET, new ArmorSpec(Material.NETHERITE_HELMET, EquipmentSlot.HEAD,
                EquipmentSlotGroup.HEAD, 3, "Casco del Vacío"));
        ARMOR.put(Kind.VOID_CHESTPLATE, new ArmorSpec(Material.NETHERITE_CHESTPLATE, EquipmentSlot.CHEST,
                EquipmentSlotGroup.CHEST, 8, "Peto del Vacío"));
        ARMOR.put(Kind.VOID_LEGGINGS, new ArmorSpec(Material.NETHERITE_LEGGINGS, EquipmentSlot.LEGS,
                EquipmentSlotGroup.LEGS, 6, "Pantalones del Vacío"));
        ARMOR.put(Kind.VOID_BOOTS, new ArmorSpec(Material.NETHERITE_BOOTS, EquipmentSlot.FEET,
                EquipmentSlotGroup.FEET, 3, "Botas del Vacío"));

        ARMOR.put(Kind.END_HELMET, new ArmorSpec(Material.NETHERITE_HELMET, EquipmentSlot.HEAD,
                EquipmentSlotGroup.HEAD, 3, "Casco del Fin"));
        ARMOR.put(Kind.END_CHESTPLATE, new ArmorSpec(Material.NETHERITE_CHESTPLATE, EquipmentSlot.CHEST,
                EquipmentSlotGroup.CHEST, 8, "Peto del Fin"));
        ARMOR.put(Kind.END_LEGGINGS, new ArmorSpec(Material.NETHERITE_LEGGINGS, EquipmentSlot.LEGS,
                EquipmentSlotGroup.LEGS, 6, "Pantalones del Fin"));
        ARMOR.put(Kind.END_BOOTS, new ArmorSpec(Material.NETHERITE_BOOTS, EquipmentSlot.FEET,
                EquipmentSlotGroup.FEET, 3, "Botas del Fin"));
    }

    private final JavaPlugin plugin;
    private final NamespacedKey idKey;
    /** Nivel de "Propulsión Ígnea" del Tridente Infernal (la Propulsión que solo funciona en la lava). */
    private final NamespacedKey lavaRiptideKey;
    private final boolean usePack;
    private final double armorBonus;
    private final double endgameArmorBonus;
    private final double endgameDurabilityMultiplier;
    private final double durabilityMultiplier;
    private final int durabilityBonus;
    private final double soulSwordDamageBonus;
    private final double soulToolDamageBonus;
    private final double soulToolMiningSpeedBonus;
    private final double soulSpearDamageBonus;
    private final double topToolDamageBonus;
    private final double topToolMiningSpeedBonus;
    private final double topToolAttackSpeed;
    private final double topAxeAttackSpeed;
    private final double topSpearDamageBonus;
    private final double topSpearReachBonus;
    private final double topSpearAttackSpeed;
    private final double topDurabilityMultiplier;
    private final double infernalSwordDamageBonus;
    private final double infernalSwordNetherMultiplier;
    private final double infernalSwordAttackSpeed;
    private final double celestialSwordAttackSpeed;
    private final double celestialHostileMultiplier;
    private final int resistanceLevel;
    private final double infernalArmorNetherReduction;
    private final double infernalArmorFireReduction;
    private final double celestialArmorHostileReduction;
    private final int endgameResistanceLevel;
    private final int endgameRegenerationLevel;
    private final double voidArmorNetherReduction;
    private final double endArmorHostileReduction;
    private final double endMobsReduction;
    private final double explosionReduction;
    private final boolean armorUpgradesBlocked;
    private final boolean infernalArmorAllowed;
    private final boolean toneAllowsUndyed;
    private final Set<String> infernalTones;
    private final Set<String> celestialTones;
    private final boolean netheriteTridentEnabled;
    private final double netheriteTridentDurabilityMultiplier;
    private final double netheriteTridentDamageBonus;
    private final double netheriteTridentRiptideMultiplier;
    private final boolean netheriteTridentThrownModel;
    private final boolean infernalTridentEnabled;
    private final boolean yinYangMaceEnabled;
    private final double yinYangDurabilityMultiplier;
    private final double yinYangDamageBonus;
    private final boolean yinYangWindBurst;
    private final double yinYangCoreChance;

    public InfernalItems(JavaPlugin plugin) {
        this.plugin = plugin;
        this.idKey = new NamespacedKey(plugin, "id");
        this.lavaRiptideKey = new NamespacedKey(plugin, "lava_riptide");
        FileConfiguration cfg = plugin.getConfig();
        this.usePack = cfg.getBoolean("use-resource-pack", true);
        this.armorBonus = cfg.getDouble("armor-bonus", 4.0);
        this.endgameArmorBonus = cfg.getDouble("void-end-armor-extra-armor", 5.0);
        this.endgameDurabilityMultiplier = Math.max(1.0, cfg.getDouble("void-end-armor-durability-multiplier", 2.0));
        this.durabilityMultiplier = cfg.getDouble("durability-multiplier", 2.0);
        this.durabilityBonus = Math.max(0, cfg.getInt("durability-bonus", 2667));
        this.soulSwordDamageBonus = cfg.getDouble("soul-sword-damage-bonus", 1.0);
        this.soulToolDamageBonus = cfg.getDouble("soul-tool-damage-bonus", 1.0);
        this.soulToolMiningSpeedBonus = cfg.getDouble("soul-tool-mining-speed-bonus", 1.0);
        this.soulSpearDamageBonus = cfg.getDouble("soul-spear-damage-bonus", 1.0);
        this.topToolDamageBonus = cfg.getDouble("infernal-tool-damage-bonus", 4.0);
        this.topToolMiningSpeedBonus = cfg.getDouble("infernal-tool-mining-speed-bonus", 3.0);
        this.topToolAttackSpeed = cfg.getDouble("infernal-tool-attack-speed", 2.0);
        this.topAxeAttackSpeed = cfg.getDouble("infernal-axe-attack-speed", 1.5);
        this.topSpearDamageBonus = cfg.getDouble("infernal-spear-damage-bonus", 4.0);
        this.topSpearReachBonus = cfg.getDouble("infernal-spear-reach-bonus", 3.0);
        this.topSpearAttackSpeed = cfg.getDouble("infernal-spear-attack-speed", 1.5);
        this.topDurabilityMultiplier = Math.max(1.0, cfg.getDouble("infernal-tool-durability-multiplier", 2.0));
        this.infernalSwordDamageBonus = cfg.getDouble("infernal-sword-damage-bonus", 4.0);
        this.infernalSwordNetherMultiplier = Math.max(1.0, cfg.getDouble("infernal-sword-nether-multiplier", 1.45));
        this.infernalSwordAttackSpeed = cfg.getDouble("infernal-sword-attack-speed", 2.0);
        this.celestialSwordAttackSpeed = cfg.getDouble("celestial-sword-attack-speed", 2.0);
        this.celestialHostileMultiplier = Math.max(1.0, cfg.getDouble("celestial-sword-hostile-multiplier", 1.2));
        this.resistanceLevel = Math.max(1, cfg.getInt("resistance-level", 1));
        this.infernalArmorNetherReduction = clamp01(cfg.getDouble("infernal-armor-nether-reduction", 0.20));
        this.infernalArmorFireReduction = clamp01(cfg.getDouble("infernal-armor-fire-reduction", 0.15));
        this.celestialArmorHostileReduction = clamp01(cfg.getDouble("celestial-armor-hostile-reduction", 0.10));
        this.endgameResistanceLevel = Math.max(1, cfg.getInt("void-end-resistance-level", 2));
        this.endgameRegenerationLevel = Math.max(1, cfg.getInt("void-end-regeneration-level", 2));
        this.voidArmorNetherReduction = clamp01(cfg.getDouble("void-armor-nether-reduction", 0.20));
        this.endArmorHostileReduction = clamp01(cfg.getDouble("end-armor-hostile-reduction", 0.10));
        this.endMobsReduction = clamp01(cfg.getDouble("void-end-armor-end-mobs-reduction", 0.25));
        this.explosionReduction = clamp01(cfg.getDouble("void-end-armor-explosion-reduction", 0.20));
        this.armorUpgradesBlocked = cfg.getBoolean("armor-lock.block-upgrades", true);
        this.infernalArmorAllowed = cfg.getBoolean("armor-lock.allow-infernal", true);
        this.toneAllowsUndyed = cfg.getBoolean("smithing-dye-tones.allow-undyed", true);
        this.infernalTones = readTones(cfg, "smithing-dye-tones.infernal", List.of("YELLOW", "ORANGE", "RED"));
        this.celestialTones = readTones(cfg, "smithing-dye-tones.celestial", List.of("PINK", "MAGENTA", "PURPLE"));
        this.netheriteTridentEnabled = cfg.getBoolean("netherite-trident.enabled", true);
        this.netheriteTridentDurabilityMultiplier = Math.max(1.0, cfg.getDouble("netherite-trident.durability-multiplier", 2.0));
        this.netheriteTridentDamageBonus = Math.max(0.0, cfg.getDouble("netherite-trident.damage-bonus", 1.0));
        this.netheriteTridentRiptideMultiplier = Math.max(1.0, cfg.getDouble("netherite-trident.riptide-multiplier", 2.0));
        this.netheriteTridentThrownModel = cfg.getBoolean("netherite-trident.thrown-model", true);
        this.infernalTridentEnabled = cfg.getBoolean("infernal-trident.enabled", true);
        this.yinYangMaceEnabled = cfg.getBoolean("yin-yang-mace.enabled", true);
        this.yinYangDurabilityMultiplier = Math.max(1.0, cfg.getDouble("yin-yang-mace.durability-multiplier", 1.25));
        this.yinYangDamageBonus = Math.max(0.0, cfg.getDouble("yin-yang-mace.damage-bonus", 1.0));
        this.yinYangWindBurst = cfg.getBoolean("yin-yang-mace.wind-burst", true);
        this.yinYangCoreChance = clamp01(cfg.getDouble("yin-yang-mace.core-chance", 0.067));
    }

    // ------------------------------------------------------------------ creación

    public ItemStack create(Kind kind) {
        return switch (kind) {
            case INGOT -> basic(Material.NETHERITE_INGOT, kind, "Lingote Infernal",
                    "Forjado con el fuego del Nether.");
            case STAR -> basic(Material.NETHER_STAR, kind, "Estrella del Nether Reforzada",
                    "Una estrella templada con cráneos del Wither.");
            case POWDER -> basic(Material.BLAZE_POWDER, kind, "Polvo de Blaze Infernal",
                    "Polvo de blaze concentrado.");
            case TEMPLATE -> basic(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, kind,
                    "Plantilla de mejora: Armadura Infernal",
                    "Mejora armadura de netherite con un Lingote Infernal.");
            case SOUL_INGOT -> basic(Material.NETHERITE_INGOT, kind, "Lingote del Alma",
                    "Forjado con lágrimas de ghast.");
            case SOUL_TEMPLATE -> basic(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, kind,
                    "Plantilla de mejora: Espada del Alma",
                    "Mejora una espada de netherite con un Lingote del Alma.");
            case SOUL_SWORD -> toSoulSword(new ItemStack(Material.NETHERITE_SWORD));
            case GREED_INGOT -> basic(Material.NETHERITE_INGOT, kind, "Lingote de Codicia",
                    "Lingote fabricado por la codicia");
            case GREED_TEMPLATE -> basic(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, kind,
                    "Plantilla de Codicia",
                    "Mejora la Espada del Alma con un Lingote de Codicia.");
            case GREED_SWORD -> toGreedSword(new ItemStack(Material.NETHERITE_SWORD));
            case INFERNAL_SWORD -> toInfernalSword(new ItemStack(Material.NETHERITE_SWORD));
            case PURIFIED_INGOT -> basic(Material.NETHERITE_INGOT, kind, "Lingote Purificado",
                    "Cristalizado con cuarzo y energía del viento.");
            case PURIFIED_TEMPLATE -> basic(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, kind,
                    "Plantilla de mejora: Espada Purificada",
                    "Mejora la Espada del Alma con un Lingote Purificado.");
            case PURIFIED_SWORD -> toPurifiedSword(new ItemStack(Material.NETHERITE_SWORD));
            // Material base = lo que ven los jugadores sin el resource pack (Bedrock): vara de breeze / cristal del End.
            case CELESTIAL_DUST -> basic(Material.BREEZE_ROD, kind, "Polvo Celestial",
                    "Polvo condensado del viento y el cuarzo.");
            case CELESTIAL_CRYSTAL -> basic(Material.END_CRYSTAL, kind, "Cristal Celestial",
                    "Un cristal que late con luz de las estrellas.");
            case CELESTIAL_INGOT -> basic(Material.NETHERITE_INGOT, kind, "Lingote Celestial",
                    "Forjado con cristales celestiales.");
            case CELESTIAL_TEMPLATE -> basic(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, kind,
                    "Plantilla de mejora: Espada Celestial",
                    "Mejora la Espada Purificada con un Lingote Celestial.");
            case CELESTIAL_SWORD -> toCelestialSword(new ItemStack(Material.NETHERITE_SWORD));
            // Armaduras del Vacío y del Fin. La cabeza y el huevo se llaman igual en las dos versiones;
            // la descripción dice para qué armadura sirven. Material base = lo que se ve sin resource pack.
            case MUTATED_BREATH -> basic(Material.DRAGON_BREATH, kind, "Aliento del Dragón Mutado",
                    "Aliento de dragón alterado por el chorus.");
            case VOID_DRAGON_HEAD -> basic(Material.DRAGON_HEAD, kind, "Cabeza del Dragón Mutada",
                    "Para la Armadura del Vacío.");
            case END_DRAGON_HEAD -> basic(Material.DRAGON_HEAD, kind, "Cabeza del Dragón Mutada",
                    "Para la Armadura del Fin.");
            // Chorus procesado: base "fruto de chorus reventado" (no se puede comer ni teletransporta).
            case FERMENTED_FRUIT -> basic(Material.POPPED_CHORUS_FRUIT, kind, "Fruto del Coral Fermentado",
                    "Chorus reventado y fermentado.");
            case VOID_DRAGON_EGG -> basic(Material.DRAGON_EGG, kind, "Huevo del Dragón Encubado",
                    "Para la Armadura del Vacío.");
            case END_DRAGON_EGG -> basic(Material.DRAGON_EGG, kind, "Huevo del Dragón Encubado",
                    "Para la Armadura del Fin.");
            case VOID_INGOT -> basic(Material.NETHERITE_INGOT, kind, "Lingote del Vacío",
                    "Forjado con la esencia del Vacío.");
            case END_INGOT -> basic(Material.NETHERITE_INGOT, kind, "Lingote del Fin",
                    "Forjado con la esencia del Fin.");
            // Caja de shulker reforzada: base = caja de shulker morada (se ve así sin resource pack). No se puede colocar:
            // se abre con click derecho (ver ReinforcedShulkerListener) y guarda el doble que una caja normal.
            case REINFORCED_SHULKER -> reinforcedShulker(Material.PURPLE_SHULKER_BOX);
            case DYED_OBSIDIAN -> basic(Material.OBSIDIAN, kind, "Obsidiana Teñida",
                    "Obsidiana teñida con piedra del End.");
            case DYED_CRYING_OBSIDIAN -> basic(Material.CRYING_OBSIDIAN, kind, "Obsidiana Llorosa Teñida",
                    "Obsidiana llorosa teñida con purpur.");
            case VOID_TEMPLATE -> basic(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, kind,
                    "Plantilla de mejora: Armadura del Vacío",
                    "Mejora armadura infernal con un Lingote del Vacío.");
            case END_TEMPLATE -> basic(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, kind,
                    "Plantilla de mejora: Armadura del Fin",
                    "Mejora armadura celestial con un Lingote del Fin.");
            case NETHERITE_TRIDENT -> toNetheriteTrident(new ItemStack(Material.TRIDENT));
            case INFERNAL_TRIDENT -> toInfernalTrident(toNetheriteTrident(new ItemStack(Material.TRIDENT)));
            // Material base = núcleo pesado (así se ve sin resource pack). No se puede colocar (ProtectionListener).
            case YIN_YANG_CORE -> basic(Material.HEAVY_CORE, kind, "Núcleo Yin Yang",
                    "Mejora un mazo en la mesa de herrería.");
            case YIN_YANG_MACE -> toYinYangMace(new ItemStack(Material.MACE));
            case SOUL_AXE, SOUL_PICKAXE, SOUL_SHOVEL, SOUL_HOE, SOUL_SPEAR ->
                    toSoulTool(new ItemStack(netheriteToolOf(kind)));
            case GREED_AXE, GREED_PICKAXE, GREED_SHOVEL, GREED_HOE, GREED_SPEAR ->
                    toGreedTool(new ItemStack(netheriteToolOf(kind)));
            case PURIFIED_AXE, PURIFIED_PICKAXE, PURIFIED_SHOVEL, PURIFIED_HOE, PURIFIED_SPEAR ->
                    toPurifiedTool(new ItemStack(netheriteToolOf(kind)));
            case INFERNAL_AXE, INFERNAL_PICKAXE, INFERNAL_SHOVEL, INFERNAL_HOE, INFERNAL_SPEAR ->
                    toInfernalTool(new ItemStack(netheriteToolOf(kind)));
            case CELESTIAL_AXE, CELESTIAL_PICKAXE, CELESTIAL_SHOVEL, CELESTIAL_HOE, CELESTIAL_SPEAR ->
                    toCelestialTool(new ItemStack(netheriteToolOf(kind)));
            case CELESTIAL_HELMET, CELESTIAL_CHESTPLATE, CELESTIAL_LEGGINGS, CELESTIAL_BOOTS ->
                    toCelestialArmor(new ItemStack(ARMOR.get(kind).netherite()));
            case VOID_HELMET, VOID_CHESTPLATE, VOID_LEGGINGS, VOID_BOOTS ->
                    toVoidArmor(new ItemStack(ARMOR.get(kind).netherite()));
            case END_HELMET, END_CHESTPLATE, END_LEGGINGS, END_BOOTS ->
                    toEndArmor(new ItemStack(ARMOR.get(kind).netherite()));
            default -> toInfernal(new ItemStack(ARMOR.get(kind).netherite()));
        };
    }

    /**
     * Caja de shulker reforzada del color (material de caja de shulker) indicado. La que se craftea es morada;
     * se puede teñir como una caja normal (ver ReinforcedShulkerListener) y todos los colores son la misma caja.
     */
    public ItemStack reinforcedShulker(Material box) {
        return withExtraLore(basic(box, Kind.REINFORCED_SHULKER,
                "Caja de Shulker Reforzada", "Una caja de shulker con el doble de espacio."),
                "Click derecho para abrirla (" + ReinforcedShulkerListener.SIZE + " ranuras).");
    }

    private ItemStack basic(Material material, Kind kind, String name, String description) {
        ItemStack item = new ItemStack(material);
        item.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, kind.id()));
        item.setData(DataComponentTypes.ITEM_NAME, Component.text(name, colorOf(kind)));
        item.setData(DataComponentTypes.LORE, ItemLore.lore().addLine(line(description)).build());
        item.setData(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        if (usePack && (kind == Kind.INGOT || kind == Kind.POWDER || kind == Kind.STAR || kind == Kind.SOUL_INGOT || kind == Kind.SOUL_TEMPLATE
                || kind == Kind.GREED_INGOT || kind == Kind.GREED_TEMPLATE
                || kind == Kind.PURIFIED_INGOT || kind == Kind.PURIFIED_TEMPLATE
                || kind == Kind.CELESTIAL_DUST || kind == Kind.CELESTIAL_CRYSTAL
                || kind == Kind.CELESTIAL_INGOT || kind == Kind.CELESTIAL_TEMPLATE
                || kind == Kind.VOID_INGOT || kind == Kind.END_INGOT
                || kind == Kind.DYED_OBSIDIAN || kind == Kind.DYED_CRYING_OBSIDIAN
                || kind == Kind.VOID_TEMPLATE || kind == Kind.END_TEMPLATE || kind == Kind.YIN_YANG_CORE)) {
            item.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, kind.id()));
        }
        return item;
    }

    /**
     * Convierte una pieza de netherite en su versión infernal conservando TODO lo demás
     * (encantamientos, diseño/trim, daño, nombre personalizado...).
     */
    public ItemStack toInfernal(ItemStack base) {
        Kind kind = armorKindOf(base.getType());
        if (kind == null) return null;
        return forgeArmor(base, kind, COLOR, "infernal");
    }

    /**
     * Convierte una pieza de netherite en su versión celestial conservando TODO lo demás
     * (encantamientos, diseño/trim, daño, nombre personalizado...). Mismas estadísticas que la infernal.
     */
    public ItemStack toCelestialArmor(ItemStack base) {
        Kind infernal = armorKindOf(base.getType());
        if (infernal == null) return null;
        return forgeArmor(base, infernal.celestial(), CELESTIAL_COLOR, "celestial");
    }

    /**
     * Convierte una pieza de netherite (o infernal) en su versión del Vacío conservando TODO lo demás
     * (encantamientos, diseño/trim, daño, nombre personalizado...). Mismas estadísticas que la infernal.
     */
    public ItemStack toVoidArmor(ItemStack base) {
        Kind infernal = armorKindOf(base.getType());
        if (infernal == null) return null;
        return forgeArmor(base, infernal.voidVersion(), VOID_COLOR, "void");
    }

    /**
     * Convierte una pieza de netherite (o celestial) en su versión del Fin conservando TODO lo demás
     * (encantamientos, diseño/trim, daño, nombre personalizado...). Mismas estadísticas que la celestial.
     */
    public ItemStack toEndArmor(ItemStack base) {
        Kind infernal = armorKindOf(base.getType());
        if (infernal == null) return null;
        return forgeArmor(base, infernal.endVersion(), END_COLOR, "end");
    }

    // ------------------------------------------------------------------ netherite teñida

    /** El teñido de netherite solo se ofrece con resource pack (sin él el tinte no se vería). */
    public boolean usesResourcePack() {
        return usePack;
    }

    /** Pieza de armadura de netherite normal (no forjada: infernal, celestial, del Vacío o del Fin) que se puede teñir. */
    public boolean isDyeableNetherite(ItemStack item) {
        return item != null && armorKindOf(item.getType()) != null && !isCustomArmor(item);
    }

    /** Color 0xRRGGBB con el que está teñida la pieza, o -1 si no lo está. */
    public int dyedColorOf(ItemStack item) {
        DyedItemColor dyed = item.getData(DataComponentTypes.DYED_COLOR);
        return dyed == null ? -1 : dyed.color().asRGB();
    }

    /** Lee una lista de tintes del config (nombres como en DyeColor); los nombres que no son tintes se avisan y se ignoran. */
    private Set<String> readTones(FileConfiguration cfg, String path, List<String> defaults) {
        List<String> raw = cfg.isList(path) ? cfg.getStringList(path) : defaults;
        Set<String> out = new HashSet<>();
        for (String name : raw) {
            String tone = DyeTone.normalize(name);
            if (tone == null) {
                plugin.getLogger().warning(path + ": '" + name + "' no es un tinte de Minecraft (usa nombres en inglés: red, orange, yellow, pink, magenta, purple...)");
            } else {
                out.add(tone);
            }
        }
        return out;
    }

    /**
     * ¿La pieza de netherite sirve para forjar esa armadura según su tono? Sin teñir: depende de smithing-dye-tones.allow-undyed.
     * Teñida: el tinte con que se tiñó ({@link DyeTone#nearest}) tiene que estar en la lista.
     */
    private boolean toneFits(ItemStack base, Set<String> tones) {
        int rgb = dyedColorOf(base);
        if (rgb < 0) return toneAllowsUndyed;
        return tones.contains(DyeTone.nearest(rgb));
    }

    /**
     * armor-lock.block-upgrades: la mesa de herrería no mejora netherite (base o teñida) a Infernal/Celestial,
     * ni Infernal a Vacío ni Celestial a Fin. Esas armaduras solo se obtienen con /infernal give.
     */
    public boolean armorUpgradesBlocked() {
        return armorUpgradesBlocked;
    }

    /**
     * ¿Está bloqueada la mejora netherite -> Armadura Infernal? Solo si armor-lock.block-upgrades está activo y
     * armor-lock.allow-infernal no (la Armadura Infernal es la excepción al bloqueo: se puede fabricar).
     */
    public boolean infernalUpgradeBlocked() {
        return armorUpgradesBlocked && !infernalArmorAllowed;
    }

    /** armor-lock.allow-infernal: la Armadura Infernal se puede fabricar aunque las demás armaduras sean solo por comando. */
    public boolean infernalArmorAllowed() {
        return infernalArmorAllowed;
    }

    /** Netherite sin teñir (si está permitido) o teñida en un tono de la lista infernal (por defecto amarillo, naranja y rojo). */
    public boolean fitsInfernalTone(ItemStack base) {
        return toneFits(base, infernalTones);
    }

    /** Netherite sin teñir (si está permitido) o teñida en un tono de la lista celestial (por defecto rosa, magenta y morado). */
    public boolean fitsCelestialTone(ItemStack base) {
        return toneFits(base, celestialTones);
    }

    /**
     * Tiñe una pieza de netherite normal conservando TODO lo demás (encantamientos, diseño/trim, daño, nombre...).
     * La pieza sigue siendo de netherite (mismo material, atributos y durabilidad), así que sigue valiendo en la mesa de herrería
     * para las mejoras infernal, celestial, del Vacío y del Fin y para los diseños de armadura vanilla.
     *
     * @param rgb color 0xRRGGBB
     */
    public ItemStack dyeNetherite(ItemStack base, int rgb) {
        if (!isDyeableNetherite(base)) return null;
        Kind kind = armorKindOf(base.getType());
        ArmorSpec spec = ARMOR.get(kind);

        ItemStack out = base.clone();
        out.setAmount(1);
        out.setData(DataComponentTypes.DYED_COLOR, DyedItemColor.dyedItemColor(org.bukkit.Color.fromRGB(rgb & 0xFFFFFF)));
        out.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, "dyed_netherite_" + kind.id()));
        out.setData(DataComponentTypes.EQUIPPABLE, Equippable.equippable(spec.slot())
                .assetId(Key.key(PACK_NAMESPACE, "netherite_dyed"))
                .equipSound(Key.key("item.armor.equip_netherite"))
                .build());
        return out;
    }

    /**
     * Forja una pieza de armadura (infernal, celestial, del Vacío o del Fin) a partir de una de netherite: mismos atributos,
     * durabilidad y efecto de set; solo cambian el nombre, el modelo del objeto y la textura de la armadura puesta.
     *
     * @param kind  pieza resultante (HELMET..., CELESTIAL_HELMET..., VOID_HELMET... o END_HELMET...)
     * @param color color del nombre
     * @param asset nombre del asset de equipamiento del resource pack (assets/infernal/equipment/&lt;asset&gt;.json)
     */
    private ItemStack forgeArmor(ItemStack base, Kind kind, TextColor color, String asset) {
        ArmorSpec spec = ARMOR.get(kind);

        ItemStack out = base.clone();
        out.setAmount(1);
        out.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, kind.id()));
        // Si venía de netherite teñida, el tinte se descarta: las piezas forjadas tienen su propio aspecto.
        out.unsetData(DataComponentTypes.DYED_COLOR);

        out.setData(DataComponentTypes.ITEM_NAME, Component.text(spec.name(), color));

        ItemLore previous = base.getData(DataComponentTypes.LORE);
        ItemLore.Builder lore = ItemLore.lore();
        if (previous != null) {
            // Al mejorar una pieza forjada (infernal -> Vacío, celestial -> Fin) se descartan las líneas "Set completo:"
            // de la pieza anterior para que no se mezclen con las del nuevo set; el resto de la descripción se conserva.
            for (Component existing : previous.lines()) {
                String plain = PlainTextComponentSerializer.plainText().serialize(existing);
                if (!plain.startsWith(SET_LORE_PREFIX)) lore.addLine(existing);
            }
        }
        for (String text : armorLoreLines(kind)) lore.addLine(line(text));
        out.setData(DataComponentTypes.LORE, lore.build());

        // Atributos: netherite + bonus (se reescriben todos porque el componente reemplaza al de fábrica).
        EquipmentSlotGroup g = spec.group();
        ItemAttributeModifiers.Builder attrs = ItemAttributeModifiers.itemAttributes();
        attrs.addModifier(Attribute.ARMOR, new AttributeModifier(
                new NamespacedKey(plugin, kind.id() + "_armor"),
                spec.baseArmor() + armorBonus + (kind.armorSet().isEndgame() ? endgameArmorBonus : 0.0),
                AttributeModifier.Operation.ADD_NUMBER, g));
        attrs.addModifier(Attribute.ARMOR_TOUGHNESS, new AttributeModifier(
                new NamespacedKey(plugin, kind.id() + "_toughness"),
                3.0, AttributeModifier.Operation.ADD_NUMBER, g));
        attrs.addModifier(Attribute.KNOCKBACK_RESISTANCE, new AttributeModifier(
                new NamespacedKey(plugin, kind.id() + "_knockback"),
                0.1, AttributeModifier.Operation.ADD_NUMBER, g));
        out.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, attrs.build());

        // Durabilidad: multiplicador sobre netherite + durabilidad extra fija.
        out.setData(DataComponentTypes.MAX_DAMAGE, maxDamageFor(kind));

        if (usePack) {
            out.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, kind.id()));
            out.setData(DataComponentTypes.EQUIPPABLE, Equippable.equippable(spec.slot())
                    .assetId(Key.key(PACK_NAMESPACE, asset))
                    .equipSound(Key.key("item.armor.equip_netherite"))
                    .build());
        }
        return out;
    }

    /**
     * Convierte una espada de netherite en la Espada del Alma (+1 de daño sobre la de netherite)
     * conservando TODO lo demás (encantamientos, daño, nombre personalizado...).
     */
    public ItemStack toSoulSword(ItemStack base) {
        if (base == null || base.getType() != Material.NETHERITE_SWORD) return null;

        ItemStack out = base.clone();
        out.setAmount(1);
        out.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, Kind.SOUL_SWORD.id()));

        out.setData(DataComponentTypes.ITEM_NAME, Component.text("Espada del Alma", SOUL_COLOR));

        ItemLore previous = base.getData(DataComponentTypes.LORE);
        ItemLore.Builder lore = ItemLore.lore();
        if (previous != null) lore.addLines(previous.lines());
        lore.addLine(line("Forjada con el alma de ghast muertos"));
        out.setData(DataComponentTypes.LORE, lore.build());

        // Atributos: se reescriben los de fábrica (el componente los reemplaza) con las mismas
        // claves vanilla para que el tooltip los siga mostrando como base del arma.
        ItemAttributeModifiers.Builder attrs = ItemAttributeModifiers.itemAttributes();
        attrs.addModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_damage"),
                NETHERITE_SWORD_DAMAGE + soulSwordDamageBonus,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        attrs.addModifier(Attribute.ATTACK_SPEED, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_speed"),
                SWORD_ATTACK_SPEED,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        out.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, attrs.build());

        if (usePack) {
            out.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, Kind.SOUL_SWORD.id()));
        }
        return out;
    }

    /**
     * Convierte una herramienta de netherite (hacha, pico, pala, azada o lanza) en su versión del Alma:
     * +1 de daño (config soul-tool-damage-bonus / soul-spear-damage-bonus) y, salvo la lanza, +1 de velocidad
     * de minería (config soul-tool-mining-speed-bonus). Conserva TODO lo demás (encantamientos, desgaste, nombre...).
     */
    public ItemStack toSoulTool(ItemStack base) {
        if (base == null) return null;
        Kind soul = soulToolKindOf(base.getType());
        return soul == null ? null : forgeTool(base, soul);
    }

    /**
     * Convierte una herramienta del Alma (o una de netherite) en su versión corrompida por la codicia:
     * mismas estadísticas que la herramienta del Alma, conservando TODO lo demás.
     */
    public ItemStack toGreedTool(ItemStack base) {
        if (base == null) return null;
        Kind soul = soulToolKindOf(base.getType());
        return soul == null ? null : forgeTool(base, soul.greed());
    }

    /**
     * Convierte una herramienta del Alma (o una de netherite) en su versión purificada:
     * mismas estadísticas que la herramienta del Alma, conservando TODO lo demás.
     */
    public ItemStack toPurifiedTool(ItemStack base) {
        if (base == null) return null;
        Kind soul = soulToolKindOf(base.getType());
        return soul == null ? null : forgeTool(base, soul.purified());
    }

    /**
     * Convierte una herramienta corrompida (o una de netherite) en su versión infernal: sobre la herramienta del Alma
     * añade +daño, +velocidad de minería, velocidad de ataque propia y el doble de durabilidad (la lanza, además, +alcance).
     * Conserva TODO lo demás (encantamientos, desgaste, nombre...).
     */
    public ItemStack toInfernalTool(ItemStack base) {
        if (base == null) return null;
        Kind soul = soulToolKindOf(base.getType());
        return soul == null ? null : forgeTool(base, soul.infernal());
    }

    /**
     * Convierte una herramienta purificada (o una de netherite) en su versión celestial: mismas estadísticas que la infernal.
     * Conserva TODO lo demás (encantamientos, desgaste, nombre...).
     */
    public ItemStack toCelestialTool(ItemStack base) {
        if (base == null) return null;
        Kind soul = soulToolKindOf(base.getType());
        return soul == null ? null : forgeTool(base, soul.celestial());
    }

    /**
     * Forja una herramienta (del Alma, corrompida, purificada, infernal o celestial) a partir de una de netherite o de otra forjada:
     * las tres primeras llevan los atributos de netherite + bono del Alma; las dos últimas, además, el bono de la última fase.
     * Cambian el nombre, la descripción y el modelo.
     */
    private ItemStack forgeTool(ItemStack base, Kind kind) {
        ItemStack out = base.clone();
        out.setAmount(1);
        out.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, kind.id()));

        out.setData(DataComponentTypes.ITEM_NAME, Component.text(toolName(kind), colorOf(kind)));

        // Descripción: se conserva lo que hubiera, salvo la línea de otra herramienta forjada (Alma / corrompida / purificada).
        ItemLore previous = base.getData(DataComponentTypes.LORE);
        ItemLore.Builder lore = ItemLore.lore();
        if (previous != null) {
            for (Component existing : previous.lines()) {
                if (!isToolLoreLine(PlainTextComponentSerializer.plainText().serialize(existing))) lore.addLine(existing);
            }
        }
        lore.addLine(line(toolLore(kind)));
        // Mismo bono contra mobs que la Espada Infernal / Celestial (lo aplica NetherDamageListener).
        if (kind.isInfernalTool()) lore.addLine(line(netherLoreText()));
        if (kind.isCelestialTool()) lore.addLine(line(celestialLoreText()));
        out.setData(DataComponentTypes.LORE, lore.build());

        ItemAttributeModifiers attrs = soulToolAttributes(base.getType(), kind);
        if (attrs != null) out.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, attrs);

        // Infernal / celestial: el doble de durabilidad que la de netherite.
        if (kind.isTopTool()) out.setData(DataComponentTypes.MAX_DAMAGE, topMaxDamage(netheriteToolOf(kind)));

        if (usePack) {
            out.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, kind.id()));
        }
        return out;
    }

    /**
     * Atributos de una herramienta forjada: los de la herramienta de netherite (se leen del propio juego, así valen
     * para cualquier versión) con +daño sobre el daño base y, salvo la lanza, un modificador de eficiencia de minería
     * (se suma a la velocidad del bloque y al encantamiento Eficiencia). La herramienta del Alma y sus versiones corrompida y
     * purificada llevan +1 de daño y +1 de minería; las infernales y celestiales suman encima el bono de la última fase
     * (+4 de daño, +3 de minería, velocidad de ataque propia sin bajar nunca de la de netherite y, en la lanza, +alcance).
     * Devuelve null si no se pueden leer los atributos de la herramienta de netherite.
     */
    private ItemAttributeModifiers soulToolAttributes(Material netherite, Kind kind) {
        ItemAttributeModifiers proto = new ItemStack(netherite).getData(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        if (proto == null) {
            plugin.getLogger().warning("No se pudieron leer los atributos de " + netherite
                    + "; la herramienta forjada no recibe el bono.");
            return null;
        }
        boolean top = kind.isTopTool();
        double damageBonus = (kind.isSpear() ? soulSpearDamageBonus : soulToolDamageBonus)
                + (top ? (kind.isSpear() ? topSpearDamageBonus : topToolDamageBonus) : 0.0);
        double miningBonus = soulToolMiningSpeedBonus + (top ? topToolMiningSpeedBonus : 0.0);
        // Velocidad de ataque deseada (valor total, no modificador): la lanza 1.5, el hacha 1.5 y el resto 2.0.
        double wantedSpeed = kind.isSpear() ? topSpearAttackSpeed : kind.isAxe() ? topAxeAttackSpeed : topToolAttackSpeed;

        ItemAttributeModifiers.Builder attrs = ItemAttributeModifiers.itemAttributes();
        boolean damageSeen = false;
        for (ItemAttributeModifiers.Entry entry : proto.modifiers()) {
            if (entry.attribute().equals(Attribute.ATTACK_DAMAGE)) {
                AttributeModifier m = entry.modifier();
                attrs.addModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                        m.getKey(), m.getAmount() + damageBonus, m.getOperation(), m.getSlotGroup()));
                damageSeen = true;
            } else if (top && entry.attribute().equals(Attribute.ATTACK_SPEED)) {
                // Nunca baja de la velocidad de netherite (la azada de netherite ya tiene 4.0).
                AttributeModifier m = entry.modifier();
                attrs.addModifier(Attribute.ATTACK_SPEED, new AttributeModifier(
                        m.getKey(), Math.max(m.getAmount(), wantedSpeed - PLAYER_BASE_ATTACK_SPEED),
                        m.getOperation(), m.getSlotGroup()));
            } else {
                attrs.addModifier(entry.attribute(), entry.modifier());
            }
        }
        if (!damageSeen) {
            attrs.addModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                    NamespacedKey.minecraft("base_attack_damage"), damageBonus,
                    AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        }
        // La lanza no mina: solo lleva el bono de daño (y, la de última fase, el de alcance).
        if (!kind.isSpear() && miningBonus != 0.0) {
            attrs.addModifier(Attribute.MINING_EFFICIENCY, new AttributeModifier(
                    new NamespacedKey(plugin, "soul_tool_mining_speed"), miningBonus,
                    AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        }
        if (top && kind.isSpear() && topSpearReachBonus != 0.0) {
            attrs.addModifier(Attribute.ENTITY_INTERACTION_RANGE, new AttributeModifier(
                    new NamespacedKey(plugin, "top_spear_reach"), topSpearReachBonus,
                    AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        }
        return attrs.build();
    }

    // ------------------------------------------------------------ tridente de netherite

    /**
     * Convierte un tridente normal en el Tridente de Netherite (mejora vanilla en la mesa de herrería: plantilla de mejora de
     * netherite + tridente + lingote de netherite), conservando TODO lo demás (encantamientos, desgaste, nombre...).
     * Como el resto de la netherite vanilla: el doble de durabilidad (netherite-trident.durability-multiplier), +1 de daño
     * cuerpo a cuerpo (netherite-trident.damage-bonus; el del tridente lanzado y el de la propulsión los suma
     * NetheriteTridentListener), no arde en el fuego ni en la lava, se repara con lingotes de netherite en el yunque y
     * tiene la encantabilidad de la netherite.
     */
    public ItemStack toNetheriteTrident(ItemStack base) {
        if (base == null || base.getType() != Material.TRIDENT) return null;

        ItemStack out = base.clone();
        out.setAmount(1);
        out.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, Kind.NETHERITE_TRIDENT.id()));
        // Sin color propio, como un objeto vanilla: el juego le pone el color de la rareza del tridente.
        out.setData(DataComponentTypes.ITEM_NAME, Component.text("Tridente de Netherite"));

        // Propiedades de la netherite, leídas de la espada de netherite del propio juego (así valen para cualquier versión):
        // no arde en el fuego ni en la lava, se repara con lingotes de netherite y encantabilidad de la netherite.
        ItemStack netherite = new ItemStack(Material.NETHERITE_SWORD);
        copyData(netherite, out, DataComponentTypes.DAMAGE_RESISTANT);
        copyData(netherite, out, DataComponentTypes.REPAIRABLE);
        copyData(netherite, out, DataComponentTypes.ENCHANTABLE);

        out.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, netheriteTridentAttributes());
        refreshDurability(out); // el doble que el tridente normal (250 -> 500), conservando el desgaste que traía

        if (usePack) {
            out.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, Kind.NETHERITE_TRIDENT.id()));
        }
        return out;
    }

    /**
     * Atributos del Tridente de Netherite: los del tridente vanilla (se leen del propio juego) con +daño
     * (netherite-trident.damage-bonus) sobre el daño base: 9 -> 10 con el valor por defecto.
     */
    private ItemAttributeModifiers netheriteTridentAttributes() {
        return vanillaAttributesWithBonus(Material.TRIDENT, netheriteTridentDamageBonus, TRIDENT_DAMAGE, TRIDENT_ATTACK_SPEED);
    }

    /**
     * Atributos de un arma vanilla (se leen del propio juego, así valen para cualquier versión) con +daño sobre su daño base.
     * Si no se pueden leer, usa los valores vanilla conocidos (modificador de daño y de velocidad de ataque).
     */
    private ItemAttributeModifiers vanillaAttributesWithBonus(Material weapon, double bonus,
                                                              double fallbackDamage, double fallbackSpeed) {
        ItemAttributeModifiers proto = new ItemStack(weapon).getData(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        ItemAttributeModifiers.Builder attrs = ItemAttributeModifiers.itemAttributes();
        boolean damageSeen = false;
        if (proto != null) {
            for (ItemAttributeModifiers.Entry entry : proto.modifiers()) {
                if (entry.attribute().equals(Attribute.ATTACK_DAMAGE)) {
                    AttributeModifier m = entry.modifier();
                    attrs.addModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                            m.getKey(), m.getAmount() + bonus, m.getOperation(), m.getSlotGroup()));
                    damageSeen = true;
                } else {
                    attrs.addModifier(entry.attribute(), entry.modifier());
                }
            }
        }
        if (!damageSeen) {
            plugin.getLogger().warning("No se pudieron leer los atributos de " + weapon + "; se usan los valores vanilla conocidos.");
            attrs.addModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                    NamespacedKey.minecraft("base_attack_damage"), fallbackDamage + bonus,
                    AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
            if (proto == null) {
                attrs.addModifier(Attribute.ATTACK_SPEED, new AttributeModifier(
                        NamespacedKey.minecraft("base_attack_speed"), fallbackSpeed,
                        AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
            }
        }
        return attrs.build();
    }

    /** Durabilidad máxima del Tridente de Netherite: la del tridente por el multiplicador (250 x 2 = 500 por defecto). */
    private int netheriteTridentMaxDamage() {
        return (int) Math.round(Material.TRIDENT.getMaxDurability() * netheriteTridentDurabilityMultiplier);
    }

    /**
     * Pone a un Tridente de Netherite YA EXISTENTE el daño que le corresponde según la config actual.
     * No toca encantamientos, desgaste ni nombre. Devuelve true si cambió algo.
     */
    public boolean refreshNetheriteTridentAttributes(ItemStack item) {
        if (!isNetheriteBasedTrident(item)) return false;
        ItemAttributeModifiers expected = netheriteTridentAttributes();
        ItemAttributeModifiers current = item.getData(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        if (current != null && sameAttributes(current, expected)) return false;
        item.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, expected);
        return true;
    }

    /** ¿Se puede forjar el Tridente de Netherite en la mesa de herrería? (netherite-trident.enabled) */
    public boolean netheriteTridentEnabled() {
        return netheriteTridentEnabled;
    }

    /** Daño extra del Tridente de Netherite lanzado y al chocar con la propulsión (netherite-trident.damage-bonus). */
    public double netheriteTridentDamageBonus() {
        return netheriteTridentDamageBonus;
    }

    /** Multiplicador del impulso de Propulsión del Tridente de Netherite (2.0 = el doble). */
    public double netheriteTridentRiptideMultiplier() {
        return netheriteTridentRiptideMultiplier;
    }

    /** ¿Se dibuja el Tridente de Netherite lanzado con su textura? Necesita el resource pack. */
    public boolean netheriteTridentThrownModel() {
        return usePack && netheriteTridentThrownModel;
    }

    public boolean isNetheriteTrident(ItemStack item) {
        return kindOf(item) == Kind.NETHERITE_TRIDENT;
    }

    // ------------------------------------------------------------------ tridente infernal

    /** ¿Se puede forjar el Tridente Infernal en la mesa de herrería? (infernal-trident.enabled) */
    public boolean infernalTridentEnabled() {
        return infernalTridentEnabled;
    }

    public boolean isInfernalTrident(ItemStack item) {
        return kindOf(item) == Kind.INFERNAL_TRIDENT;
    }

    /** Tridente de Netherite o Tridente Infernal (los dos llevan las propiedades del de netherite). */
    public boolean isNetheriteBasedTrident(ItemStack item) {
        Kind kind = kindOf(item);
        return kind == Kind.NETHERITE_TRIDENT || kind == Kind.INFERNAL_TRIDENT;
    }

    /**
     * Tridente de Netherite -> Tridente Infernal (mesa de herrería: Plantilla Infernal + Tridente de Netherite + Lingote Infernal),
     * conservando todo (encantamientos, desgaste, nombre, durabilidad y daño del de netherite).
     * La Propulsión pasa a ser "Propulsión Ígnea": solo funciona en la lava (ver {@link #normalizeInfernalTrident}).
     */
    public ItemStack toInfernalTrident(ItemStack base) {
        if (base == null || !isNetheriteTrident(base)) return null;
        ItemStack out = base.clone();
        out.setAmount(1);
        out.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, Kind.INFERNAL_TRIDENT.id()));
        out.setData(DataComponentTypes.ITEM_NAME, Component.text("Tridente Infernal", COLOR));
        if (usePack) {
            out.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, Kind.INFERNAL_TRIDENT.id()));
        }
        normalizeInfernalTrident(out);
        return out;
    }

    /** Nivel de Propulsión Ígnea (Propulsión solo en la lava) de un Tridente Infernal; 0 si no tiene. */
    public int lavaRiptideLevel(ItemStack item) {
        if (!isInfernalTrident(item)) return 0;
        Integer level = item.getItemMeta().getPersistentDataContainer().get(lavaRiptideKey, PersistentDataType.INTEGER);
        return level == null ? 0 : Math.max(0, level);
    }

    /**
     * Deja un Tridente Infernal como debe estar. La Propulsión vanilla la decide el cliente y solo funciona en el agua o la
     * lluvia (y la haría también en el agua), así que el Tridente Infernal NO lleva el encantamiento de verdad: si lo tiene
     * (al forjarlo, del yunque, de la mesa de encantamientos o por comando) se quita y su nivel se guarda como Propulsión
     * Ígnea, que hace el plugin solo en la lava. Así en el agua se lanza como un tridente normal. Pone la descripción y el
     * brillo de encantado. Devuelve true si cambió algo.
     */
    public boolean normalizeInfernalTrident(ItemStack item) {
        if (!isInfernalTrident(item)) return false;
        boolean changed = false;
        int level = lavaRiptideLevel(item);
        int real = item.getEnchantmentLevel(Enchantment.RIPTIDE);
        if (real > 0) {
            item.removeEnchantment(Enchantment.RIPTIDE);
            level = Math.max(level, real);
            final int lvl = level;
            item.editMeta(meta -> meta.getPersistentDataContainer().set(lavaRiptideKey, PersistentDataType.INTEGER, lvl));
            changed = true;
        }
        ItemLore.Builder lore = ItemLore.lore();
        if (level > 0) lore.addLine(line("Propulsión Ígnea " + roman(level) + " (solo en la lava)"));
        lore.addLine(line("Empalamiento: solo contra quien esté en la lava"));
        ItemLore newLore = lore.build();
        ItemLore oldLore = item.getData(DataComponentTypes.LORE);
        if (oldLore == null || !oldLore.lines().equals(newLore.lines())) {
            item.setData(DataComponentTypes.LORE, newLore);
            changed = true;
        }
        // Brillo de encantado aunque la Propulsión Ígnea sea su único "encantamiento".
        boolean glint = level > 0;
        Boolean current = item.getData(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE);
        if (glint && !Boolean.TRUE.equals(current)) {
            item.setData(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
            changed = true;
        } else if (!glint && current != null) {
            item.unsetData(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE);
            changed = true;
        }
        return changed;
    }

    // ------------------------------------------------------------------ mazo yin yang

    /**
     * Convierte un mazo normal en el Mazo Yin Yang (mesa de herrería: plantilla de mejora de netherite + mazo + Núcleo Yin Yang),
     * conservando TODO lo demás (encantamientos, desgaste, nombre...). Sigue siendo un mazo: golpe aplastante, Densidad,
     * Brecha y Aeroimpulso funcionan igual. Lleva +1 de daño (yin-yang-mace.damage-bonus), 1/4 más de durabilidad
     * (yin-yang-mace.durability-multiplier) y Aeroimpulso I incorporado al golpear desde el aire (lo hace YinYangMaceListener).
     */
    public ItemStack toYinYangMace(ItemStack base) {
        if (base == null || base.getType() != Material.MACE) return null;

        ItemStack out = base.clone();
        out.setAmount(1);
        out.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, Kind.YIN_YANG_MACE.id()));
        out.setData(DataComponentTypes.ITEM_NAME, Component.text("Mazo Yin Yang", YIN_YANG_COLOR));
        out.setData(DataComponentTypes.LORE, yinYangLore(base.getData(DataComponentTypes.LORE)));
        out.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, yinYangAttributes());
        refreshDurability(out); // 500 -> 625, conservando el desgaste que traía

        if (usePack) {
            out.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, Kind.YIN_YANG_MACE.id()));
        }
        return out;
    }

    /** Atributos del Mazo Yin Yang: los del mazo vanilla con +daño (6 -> 7 con el valor por defecto). */
    private ItemAttributeModifiers yinYangAttributes() {
        return vanillaAttributesWithBonus(Material.MACE, yinYangDamageBonus, MACE_DAMAGE, MACE_ATTACK_SPEED);
    }

    /** Descripción: la que tuviera (sin la línea del Aeroimpulso) + "Aeroimpulso I incorporado" si está activo. */
    private ItemLore yinYangLore(ItemLore previous) {
        ItemLore.Builder lore = ItemLore.lore();
        if (previous != null) {
            for (Component existing : previous.lines()) {
                String plain = PlainTextComponentSerializer.plainText().serialize(existing);
                if (!(plain.startsWith(YIN_YANG_LORE_PREFIX) && plain.endsWith(YIN_YANG_LORE_SUFFIX))) lore.addLine(existing);
            }
        }
        if (yinYangWindBurst) lore.addLine(line(YIN_YANG_LORE_PREFIX + "I" + YIN_YANG_LORE_SUFFIX));
        return lore.build();
    }

    /** Durabilidad máxima del Mazo Yin Yang: la del mazo por el multiplicador (500 x 1.25 = 625 por defecto). */
    private int yinYangMaxDamage() {
        return (int) Math.round(Material.MACE.getMaxDurability() * yinYangDurabilityMultiplier);
    }

    /**
     * Pone a un Mazo Yin Yang YA EXISTENTE el daño y la descripción que le corresponden según la config actual.
     * No toca encantamientos, desgaste ni nombre. Devuelve true si cambió algo.
     */
    public boolean refreshYinYangMace(ItemStack item) {
        if (kindOf(item) != Kind.YIN_YANG_MACE) return false;
        boolean changed = false;
        ItemAttributeModifiers expected = yinYangAttributes();
        ItemAttributeModifiers current = item.getData(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        if (current == null || !sameAttributes(current, expected)) {
            item.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, expected);
            changed = true;
        }
        ItemLore oldLore = item.getData(DataComponentTypes.LORE);
        ItemLore newLore = yinYangLore(oldLore);
        if (oldLore == null || !oldLore.lines().equals(newLore.lines())) {
            item.setData(DataComponentTypes.LORE, newLore);
            changed = true;
        }
        return changed;
    }

    /** ¿Se puede forjar el Mazo Yin Yang en la mesa de herrería? (yin-yang-mace.enabled) */
    public boolean yinYangMaceEnabled() {
        return yinYangMaceEnabled;
    }

    /** ¿El Mazo Yin Yang lleva Aeroimpulso I incorporado? (yin-yang-mace.wind-burst) */
    public boolean yinYangWindBurst() {
        return yinYangWindBurst;
    }

    /** Probabilidad de que una bóveda ominosa dé además un Núcleo Yin Yang (0.067 = 6.7%). */
    public double yinYangCoreChance() {
        return yinYangCoreChance;
    }

    public boolean isYinYangMace(ItemStack item) {
        return kindOf(item) == Kind.YIN_YANG_MACE;
    }

    /** Copia un componente (si lo tiene) de un objeto a otro. */
    private static <T> void copyData(ItemStack from, ItemStack to, DataComponentType.Valued<T> type) {
        T value = from.getData(type);
        if (value != null) to.setData(type, value);
    }

    /** Nombre en español de la herramienta (Hacha, Pico, Pala, Azada o Lanza). */
    private static String toolNoun(Kind kind) {
        return switch (kind.soul()) {
            case SOUL_AXE -> "Hacha";
            case SOUL_PICKAXE -> "Pico";
            case SOUL_SHOVEL -> "Pala";
            case SOUL_HOE -> "Azada";
            case SOUL_SPEAR -> "Lanza";
            default -> "Herramienta";
        };
    }

    /** El pico es masculino; el resto de herramientas, femenino. */
    private static boolean masculine(Kind kind) {
        return kind.soul() == Kind.SOUL_PICKAXE;
    }

    /** Nombre del objeto: "Hacha del Alma", "Pico del Alma Corrompido", "Lanza Purificada", "Pala Infernal", "Azada Celestial"... */
    private static String toolName(Kind kind) {
        String noun = toolNoun(kind);
        if (kind.isGreedTool()) return noun + " del Alma " + (masculine(kind) ? "Corrompido" : "Corrompida");
        if (kind.isPurifiedTool()) return noun + (masculine(kind) ? " Purificado" : " Purificada");
        if (kind.isInfernalTool()) return noun + " Infernal";
        if (kind.isCelestialTool()) return noun + " Celestial";
        return noun + " del Alma";
    }

    /** Línea de descripción de la herramienta. */
    private static String toolLore(Kind kind) {
        if (kind.isGreedTool()) {
            return toolNoun(kind) + (masculine(kind) ? " corrompido" : " corrompida") + " por la codicia";
        }
        if (kind.isPurifiedTool()) return (masculine(kind) ? "Purificado" : "Purificada") + " de toda corrupción";
        if (kind.isInfernalTool()) return (masculine(kind) ? "Forjado" : "Forjada") + " en las llamas del Nether";
        if (kind.isCelestialTool()) return (masculine(kind) ? "Bendecido" : "Bendecida") + " por la luz celestial";
        return SOUL_SWORD_LORE;
    }

    /** ¿Es la línea de descripción de alguna herramienta forjada (del Alma, corrompida o purificada)? */
    private static boolean isToolLoreLine(String plain) {
        for (Kind k : Kind.values()) {
            if (k.isTool() && toolLore(k).equals(plain)) return true;
        }
        return false;
    }

    /** La herramienta del Alma que corresponde a una herramienta de netherite (null si no es una de las cinco). */
    public static Kind soulToolKindOf(Material material) {
        for (Map.Entry<Kind, Material> e : SOUL_TOOLS.entrySet()) {
            if (e.getValue() == material) return e.getKey();
        }
        return null;
    }

    /** Herramienta de netherite de la que se forja una herramienta del Alma. */
    public static Material netheriteToolOf(Kind kind) {
        return SOUL_TOOLS.get(kind.soul());
    }

    /** ¿Los atributos tienen las mismas entradas (atributo, clave y cantidad)? */
    private static boolean sameAttributes(ItemAttributeModifiers a, ItemAttributeModifiers b) {
        List<ItemAttributeModifiers.Entry> la = a.modifiers();
        List<ItemAttributeModifiers.Entry> lb = b.modifiers();
        if (la.size() != lb.size()) return false;
        for (ItemAttributeModifiers.Entry ea : la) {
            boolean match = false;
            for (ItemAttributeModifiers.Entry eb : lb) {
                if (ea.attribute().equals(eb.attribute())
                        && ea.modifier().getKey().equals(eb.modifier().getKey())
                        && Math.abs(ea.modifier().getAmount() - eb.modifier().getAmount()) < 1e-6) {
                    match = true;
                    break;
                }
            }
            if (!match) return false;
        }
        return true;
    }

    /**
     * Convierte una Espada del Alma (o una de netherite) en la Espada del Alma Corrompida:
     * mismo daño que la Espada del Alma, conservando TODO lo demás (encantamientos, daño, nombre...).
     */
    public ItemStack toGreedSword(ItemStack base) {
        if (base == null || base.getType() != Material.NETHERITE_SWORD) return null;

        ItemStack out = base.clone();
        out.setAmount(1);
        out.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, Kind.GREED_SWORD.id()));

        out.setData(DataComponentTypes.ITEM_NAME, Component.text("Espada del Alma Corrompida", GREED_COLOR));

        // Descripción: se conserva lo que hubiera, salvo la línea de la Espada del Alma.
        ItemLore previous = base.getData(DataComponentTypes.LORE);
        ItemLore.Builder lore = ItemLore.lore();
        if (previous != null) {
            for (Component existing : previous.lines()) {
                String plain = PlainTextComponentSerializer.plainText().serialize(existing);
                if (!plain.equals(SOUL_SWORD_LORE)) lore.addLine(existing);
            }
        }
        lore.addLine(line("Espada corrompida por la codicia"));
        out.setData(DataComponentTypes.LORE, lore.build());

        // Mismo daño que la Espada del Alma (config soul-sword-damage-bonus).
        ItemAttributeModifiers.Builder attrs = ItemAttributeModifiers.itemAttributes();
        attrs.addModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_damage"),
                NETHERITE_SWORD_DAMAGE + soulSwordDamageBonus,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        attrs.addModifier(Attribute.ATTACK_SPEED, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_speed"),
                SWORD_ATTACK_SPEED,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        out.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, attrs.build());

        if (usePack) {
            out.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, Kind.GREED_SWORD.id()));
        }
        return out;
    }

    /**
     * Convierte una Espada del Alma Corrompida (o una de netherite) en la Espada Infernal:
     * +4 de daño respecto a la Espada del Alma Corrompida (config infernal-sword-damage-bonus) y
     * +45% de daño contra los mobs del Nether (lo aplica NetherDamageListener).
     * Conserva TODO lo demás (encantamientos, durabilidad gastada, nombre personalizado...).
     */
    public ItemStack toInfernalSword(ItemStack base) {
        if (base == null || base.getType() != Material.NETHERITE_SWORD) return null;

        ItemStack out = base.clone();
        out.setAmount(1);
        out.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, Kind.INFERNAL_SWORD.id()));

        out.setData(DataComponentTypes.ITEM_NAME, Component.text("Espada Infernal", COLOR));

        // Descripción: se conserva lo que hubiera, salvo las líneas de la Espada del Alma / Corrompida.
        ItemLore previous = base.getData(DataComponentTypes.LORE);
        ItemLore.Builder lore = ItemLore.lore();
        if (previous != null) {
            for (Component existing : previous.lines()) {
                String plain = PlainTextComponentSerializer.plainText().serialize(existing);
                if (!plain.equals(SOUL_SWORD_LORE) && !plain.equals(GREED_SWORD_LORE)) lore.addLine(existing);
            }
        }
        lore.addLine(line("Forjada en las llamas del Nether"));
        lore.addLine(line(netherLoreText()));
        out.setData(DataComponentTypes.LORE, lore.build());

        // Daño: netherite (7) + bonus de la Espada del Alma (1) + bonus infernal (4) = 12 (13 con la base del jugador).
        ItemAttributeModifiers.Builder attrs = ItemAttributeModifiers.itemAttributes();
        attrs.addModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_damage"),
                NETHERITE_SWORD_DAMAGE + soulSwordDamageBonus + infernalSwordDamageBonus,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        // Velocidad de ataque propia (2.0 por defecto): el modificador es el valor deseado menos la base del jugador (4.0).
        attrs.addModifier(Attribute.ATTACK_SPEED, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_speed"),
                infernalSwordAttackSpeed - PLAYER_BASE_ATTACK_SPEED,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        out.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, attrs.build());

        // Durabilidad: el doble que la espada de netherite.
        out.setData(DataComponentTypes.MAX_DAMAGE, topMaxDamage(Material.NETHERITE_SWORD));

        if (usePack) {
            out.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, Kind.INFERNAL_SWORD.id()));
        }
        return out;
    }

    /**
     * Convierte una Espada del Alma (o una de netherite) en la Espada Purificada: mismo daño que la
     * Espada del Alma (config soul-sword-damage-bonus), conservando TODO lo demás (encantamientos, desgaste, nombre...).
     */
    public ItemStack toPurifiedSword(ItemStack base) {
        if (base == null || base.getType() != Material.NETHERITE_SWORD) return null;

        ItemStack out = base.clone();
        out.setAmount(1);
        out.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, Kind.PURIFIED_SWORD.id()));

        out.setData(DataComponentTypes.ITEM_NAME, Component.text("Espada Purificada", PURE_COLOR));

        // Descripción: se conserva lo que hubiera, salvo la línea de la Espada del Alma.
        ItemLore previous = base.getData(DataComponentTypes.LORE);
        ItemLore.Builder lore = ItemLore.lore();
        if (previous != null) {
            for (Component existing : previous.lines()) {
                String plain = PlainTextComponentSerializer.plainText().serialize(existing);
                if (!plain.equals(SOUL_SWORD_LORE)) lore.addLine(existing);
            }
        }
        lore.addLine(line(PURIFIED_SWORD_LORE));
        out.setData(DataComponentTypes.LORE, lore.build());

        ItemAttributeModifiers.Builder attrs = ItemAttributeModifiers.itemAttributes();
        attrs.addModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_damage"),
                NETHERITE_SWORD_DAMAGE + soulSwordDamageBonus,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        attrs.addModifier(Attribute.ATTACK_SPEED, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_speed"),
                SWORD_ATTACK_SPEED,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        out.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, attrs.build());

        if (usePack) {
            out.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, Kind.PURIFIED_SWORD.id()));
        }
        return out;
    }


    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }

    private static long pct(double fraction) {
        return Math.round(fraction * 100.0);
    }

    /**
     * Líneas "Set completo: ..." de la descripción de una pieza (efectos y protecciones de su set), con los valores
     * actuales de la config. Ej. del Vacío: Resistencia II y Regeneración II, -20% mobs del Nether, -25% mobs del End, -20% explosiones.
     */
    private List<String> armorLoreLines(Kind kind) {
        List<String> lines = new ArrayList<>();
        ArmorSet set = kind.armorSet();
        if (set == null) return lines;
        String netherMobs = "% de daño de los mobs del Nether";
        switch (set) {
            case INFERNAL -> {
                lines.add(SET_LORE_PREFIX + " -" + pct(infernalArmorFireReduction) + "% de daño de fuego y lava");
                lines.add(SET_LORE_PREFIX + " -" + pct(infernalArmorNetherReduction) + netherMobs);
            }
            case CELESTIAL -> {
                lines.add(SET_LORE_PREFIX + " Resistencia " + roman(resistanceLevel));
                lines.add(SET_LORE_PREFIX + " -" + pct(celestialArmorHostileReduction)
                        + "% de daño de los mobs hostiles (excepto del Nether)");
            }
            case VOID -> {
                lines.add(SET_LORE_PREFIX + " Resistencia " + roman(endgameResistanceLevel)
                        + " y Regeneración " + roman(endgameRegenerationLevel));
                lines.add(SET_LORE_PREFIX + " -" + pct(voidArmorNetherReduction) + netherMobs);
            }
            case END -> {
                lines.add(SET_LORE_PREFIX + " Resistencia " + roman(endgameResistanceLevel)
                        + " y Regeneración " + roman(endgameRegenerationLevel));
                lines.add(SET_LORE_PREFIX + " -" + pct(endArmorHostileReduction)
                        + "% de daño de los mobs hostiles (excepto del Nether)");
            }
        }
        if (set.isEndgame()) {
            lines.add(SET_LORE_PREFIX + " -" + pct(endMobsReduction) + "% de daño de los mobs del End");
            lines.add(SET_LORE_PREFIX + " -" + pct(explosionReduction) + "% de daño de explosiones");
        }
        return lines;
    }

    /** Reducción de daño (0.20 = -20%) del set infernal completo contra los mobs del Nether. */
    /** Set Infernal completo: reducción del daño de fuego y lava (0.15 = -15%). */
    public double infernalArmorFireReduction() {
        return infernalArmorFireReduction;
    }

    public double infernalArmorNetherReduction() {
        return infernalArmorNetherReduction;
    }

    /** Reducción de daño (0.10 = -10%) del set celestial completo contra los mobs hostiles (excepto del Nether). */
    public double celestialArmorHostileReduction() {
        return celestialArmorHostileReduction;
    }

    /** Reducción de daño (0.20 = -20%) del set del Vacío completo contra los mobs del Nether. */
    public double voidArmorNetherReduction() {
        return voidArmorNetherReduction;
    }

    /** Reducción de daño (0.10 = -10%) del set del Fin completo contra los mobs hostiles (excepto del Nether). */
    public double endArmorHostileReduction() {
        return endArmorHostileReduction;
    }

    /** Reducción de daño (0.25 = -25%) de los sets del Vacío y del Fin completos contra los mobs del End (incluido el phantom). */
    public double endMobsReduction() {
        return endMobsReduction;
    }

    /** Reducción de daño (0.20 = -20%) de los sets del Vacío y del Fin completos contra explosiones. */
    public double explosionReduction() {
        return explosionReduction;
    }

    /**
     * Pone a una pieza de armadura YA EXISTENTE las líneas "Set completo: ..." actuales (añade las que falten o corrige
     * los porcentajes y niveles si la config cambió). Devuelve true si cambió algo.
     */
    public boolean refreshArmorLore(ItemStack item) {
        Kind kind = kindOf(item);
        if (kind == null || !kind.isArmor()) return false;
        ItemLore previous = item.getData(DataComponentTypes.LORE);
        if (previous == null) return false;

        List<String> expected = armorLoreLines(kind);
        List<String> current = new ArrayList<>();
        for (Component existing : previous.lines()) {
            String plain = PlainTextComponentSerializer.plainText().serialize(existing);
            if (plain.startsWith(SET_LORE_PREFIX)) current.add(plain);
        }
        if (current.equals(expected)) return false;

        // Las líneas del set se reemplazan donde estaban la primera; el resto de la descripción queda igual.
        ItemLore.Builder lore = ItemLore.lore();
        boolean placed = false;
        for (Component existing : previous.lines()) {
            String plain = PlainTextComponentSerializer.plainText().serialize(existing);
            if (plain.startsWith(SET_LORE_PREFIX)) {
                if (!placed) {
                    for (String text : expected) lore.addLine(line(text));
                    placed = true;
                }
            } else {
                lore.addLine(existing);
            }
        }
        if (!placed) {
            for (String text : expected) lore.addLine(line(text));
        }
        item.setData(DataComponentTypes.LORE, lore.build());
        return true;
    }

    /** Línea de descripción del bono de la Espada Infernal contra los mobs del Nether (ej. "+45% de daño a los mobs del Nether"). */
    private String netherLoreText() {
        return "+" + Math.round((infernalSwordNetherMultiplier - 1.0) * 100.0) + "% de daño a los mobs del Nether";
    }

    /** Línea de descripción del bono de la Espada Celestial (ej. "+20% de daño a los mobs hostiles (excepto del Nether)"). */
    private String celestialLoreText() {
        return "+" + Math.round((celestialHostileMultiplier - 1.0) * 100.0) + "% de daño a los mobs hostiles (excepto del Nether)";
    }

    /**
     * Convierte una Espada Purificada (o una de netherite) en la Espada Celestial: mismo daño que la
     * Espada Infernal (netherite + soul-sword-damage-bonus + infernal-sword-damage-bonus), velocidad de ataque propia
     * (config celestial-sword-attack-speed, 2.0 por defecto) y +20% de daño a los mobs hostiles,
     * excepto los del Nether (lo aplica NetherDamageListener). Conserva TODO lo demás (encantamientos, desgaste, nombre...).
     */
    public ItemStack toCelestialSword(ItemStack base) {
        if (base == null || base.getType() != Material.NETHERITE_SWORD) return null;

        ItemStack out = base.clone();
        out.setAmount(1);
        out.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, Kind.CELESTIAL_SWORD.id()));

        out.setData(DataComponentTypes.ITEM_NAME, Component.text("Espada Celestial", CELESTIAL_COLOR));

        // Descripción: se conserva lo que hubiera, salvo las líneas de la Espada del Alma / Purificada.
        ItemLore previous = base.getData(DataComponentTypes.LORE);
        ItemLore.Builder lore = ItemLore.lore();
        if (previous != null) {
            for (Component existing : previous.lines()) {
                String plain = PlainTextComponentSerializer.plainText().serialize(existing);
                if (!plain.equals(SOUL_SWORD_LORE) && !plain.equals(PURIFIED_SWORD_LORE)) lore.addLine(existing);
            }
        }
        lore.addLine(line("Bendecida por la luz celestial"));
        lore.addLine(line(celestialLoreText()));
        out.setData(DataComponentTypes.LORE, lore.build());

        ItemAttributeModifiers.Builder attrs = ItemAttributeModifiers.itemAttributes();
        attrs.addModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_damage"),
                NETHERITE_SWORD_DAMAGE + soulSwordDamageBonus + infernalSwordDamageBonus,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        attrs.addModifier(Attribute.ATTACK_SPEED, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_speed"),
                celestialSwordAttackSpeed - PLAYER_BASE_ATTACK_SPEED,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        out.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, attrs.build());

        // Durabilidad: el doble que la espada de netherite.
        out.setData(DataComponentTypes.MAX_DAMAGE, topMaxDamage(Material.NETHERITE_SWORD));

        if (usePack) {
            out.setData(DataComponentTypes.ITEM_MODEL, Key.key(PACK_NAMESPACE, Kind.CELESTIAL_SWORD.id()));
        }
        return out;
    }

    /**
     * Actualiza la línea del bono contra mobs del Nether de una Espada Infernal YA EXISTENTE al porcentaje
     * actual de la config (las espadas viejas dicen +25% o +40%). Devuelve true si cambió algo.
     */
    public boolean refreshInfernalLore(ItemStack item) {
        if (!isInfernalSword(item) && !isInfernalTool(item)) return false;
        ItemLore previous = item.getData(DataComponentTypes.LORE);
        if (previous == null) return false;

        String expected = netherLoreText();
        boolean changed = false;
        ItemLore.Builder lore = ItemLore.lore();
        for (Component existing : previous.lines()) {
            String plain = PlainTextComponentSerializer.plainText().serialize(existing);
            if (plain.matches("\\+\\d+% de daño a los mobs del Nether") && !plain.equals(expected)) {
                lore.addLine(line(expected));
                changed = true;
            } else {
                lore.addLine(existing);
            }
        }
        if (changed) item.setData(DataComponentTypes.LORE, lore.build());
        return changed;
    }

    /**
     * Actualiza la línea del bono de una Espada Celestial YA EXISTENTE al texto actual
     * (las espadas viejas dicen "+20% de daño a los mobs hostiles" sin la excepción del Nether).
     * Devuelve true si cambió algo.
     */
    public boolean refreshCelestialLore(ItemStack item) {
        if (!isCelestialSword(item) && !isCelestialTool(item)) return false;
        ItemLore previous = item.getData(DataComponentTypes.LORE);
        if (previous == null) return false;

        String expected = celestialLoreText();
        boolean changed = false;
        ItemLore.Builder lore = ItemLore.lore();
        for (Component existing : previous.lines()) {
            String plain = PlainTextComponentSerializer.plainText().serialize(existing);
            if (plain.matches("\\+\\d+% de daño a los mobs hostiles.*") && !plain.equals(expected)) {
                lore.addLine(line(expected));
                changed = true;
            } else {
                lore.addLine(existing);
            }
        }
        if (changed) item.setData(DataComponentTypes.LORE, lore.build());
        return changed;
    }

    /**
     * Pone a una espada forjada YA EXISTENTE el daño y la velocidad de ataque que le corresponden según la config
     * actual (esos valores se guardan en cada espada al forjarla). No toca encantamientos, desgaste ni nombre.
     * Devuelve true si cambió algo.
     */
    public boolean refreshSwordAttributes(ItemStack item) {
        Kind kind = kindOf(item);
        if (kind == null) return false;

        double damage;
        double speed;
        switch (kind) {
            case SOUL_SWORD, GREED_SWORD, PURIFIED_SWORD -> {
                damage = NETHERITE_SWORD_DAMAGE + soulSwordDamageBonus;
                speed = SWORD_ATTACK_SPEED;
            }
            case INFERNAL_SWORD -> {
                damage = NETHERITE_SWORD_DAMAGE + soulSwordDamageBonus + infernalSwordDamageBonus;
                speed = infernalSwordAttackSpeed - PLAYER_BASE_ATTACK_SPEED;
            }
            case CELESTIAL_SWORD -> {
                damage = NETHERITE_SWORD_DAMAGE + soulSwordDamageBonus + infernalSwordDamageBonus;
                speed = celestialSwordAttackSpeed - PLAYER_BASE_ATTACK_SPEED;
            }
            default -> {
                return false;
            }
        }

        double currentDamage = Double.NaN;
        double currentSpeed = Double.NaN;
        ItemAttributeModifiers current = item.getData(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        if (current != null) {
            for (ItemAttributeModifiers.Entry entry : current.modifiers()) {
                if (entry.attribute().equals(Attribute.ATTACK_DAMAGE)) currentDamage = entry.modifier().getAmount();
                else if (entry.attribute().equals(Attribute.ATTACK_SPEED)) currentSpeed = entry.modifier().getAmount();
            }
        }
        if (Math.abs(currentDamage - damage) < 1e-6 && Math.abs(currentSpeed - speed) < 1e-6) return false;

        ItemAttributeModifiers.Builder attrs = ItemAttributeModifiers.itemAttributes();
        attrs.addModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_damage"), damage,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        attrs.addModifier(Attribute.ATTACK_SPEED, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_speed"), speed,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        item.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, attrs.build());
        return true;
    }

    /**
     * Pone a una herramienta del Alma YA EXISTENTE el daño y la velocidad de minería que le corresponden según la
     * config actual. No toca encantamientos, desgaste ni nombre. Devuelve true si cambió algo.
     */
    public boolean refreshToolAttributes(ItemStack item) {
        Kind kind = kindOf(item);
        if (kind == null || !kind.isTool()) return false;

        ItemAttributeModifiers expected = soulToolAttributes(item.getType(), kind);
        if (expected == null) return false;
        ItemAttributeModifiers current = item.getData(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        if (current != null && sameAttributes(current, expected)) return false;

        item.setData(DataComponentTypes.ATTRIBUTE_MODIFIERS, expected);
        return true;
    }

    /** Aplica todas las actualizaciones posibles a una pieza ya existente (durabilidad, descripción, daño y velocidad).
     *  También al Tridente de Netherite (durabilidad y daño). */
    private boolean refreshItem(ItemStack item) {
        boolean a = refreshDurability(item);
        boolean b = refreshInfernalLore(item);
        boolean c = refreshSwordAttributes(item);
        boolean d = refreshCelestialLore(item);
        boolean e = refreshArmorLore(item);
        boolean f = refreshToolAttributes(item);
        boolean g = refreshNetheriteTridentAttributes(item);
        boolean h = refreshYinYangMace(item);
        boolean i = normalizeInfernalTrident(item);
        return a || b || c || d || e || f || g || h || i;
    }

    /**
     * Durabilidad máxima que le corresponde a una pieza de armadura según la config actual: la de la infernal / celestial
     * (netherite x durability-multiplier + durability-bonus); en el Vacío y el Fin, el doble (void-end-armor-durability-multiplier).
     */
    private int maxDamageFor(Kind kind) {
        ArmorSpec spec = ARMOR.get(kind);
        int base = (int) Math.round(spec.netherite().getMaxDurability() * durabilityMultiplier) + durabilityBonus;
        return kind.armorSet().isEndgame() ? (int) Math.round(base * endgameDurabilityMultiplier) : base;
    }

    /** Durabilidad máxima de la espada o herramienta infernal / celestial: la de netherite por el multiplicador (x2 por defecto). */
    private int topMaxDamage(Material netherite) {
        return (int) Math.round(netherite.getMaxDurability() * topDurabilityMultiplier);
    }

    /** Durabilidad máxima que le corresponde a una pieza forjada según la config actual (-1 si su durabilidad es la de siempre). */
    private int expectedMaxDamage(Kind kind) {
        if (kind.isArmor()) return maxDamageFor(kind);
        if (kind == Kind.INFERNAL_SWORD || kind == Kind.CELESTIAL_SWORD) return topMaxDamage(Material.NETHERITE_SWORD);
        if (kind.isTopTool()) return topMaxDamage(netheriteToolOf(kind));
        if (kind == Kind.NETHERITE_TRIDENT || kind == Kind.INFERNAL_TRIDENT) return netheriteTridentMaxDamage();
        if (kind == Kind.YIN_YANG_MACE) return yinYangMaxDamage();
        return -1;
    }

    /**
     * Pone a una pieza ya existente (armadura infernal/celestial, Espada Infernal/Celestial o herramienta
     * infernal/celestial) la durabilidad máxima actual, sin tocar encantamientos, diseño, nombre ni el daño acumulado.
     * Modifica el ItemStack recibido; devuelve true si cambió algo.
     */
    public boolean refreshDurability(ItemStack item) {
        Kind kind = kindOf(item);
        if (kind == null) return false;

        int expected = expectedMaxDamage(kind);
        if (expected < 0) return false;
        Integer current = item.getData(DataComponentTypes.MAX_DAMAGE);
        if (current != null && current == expected) return false;

        item.setData(DataComponentTypes.MAX_DAMAGE, expected);
        // Si algún día se baja la durabilidad en la config, evita que la pieza quede rota.
        Integer damage = item.getData(DataComponentTypes.DAMAGE);
        if (damage != null && damage >= expected) {
            item.setData(DataComponentTypes.DAMAGE, expected - 1);
        }
        return true;
    }

    /** Actualiza todas las piezas forjadas (armaduras y espadas) del inventario, armadura equipada y mano secundaria. */
    public int refreshAll(PlayerInventory inv) {
        int changed = 0;

        for (int i = 0; i < 36; i++) {
            ItemStack stack = inv.getItem(i);
            if (refreshItem(stack)) {
                inv.setItem(i, stack);
                changed++;
            }
        }

        ItemStack[] armor = inv.getArmorContents();
        boolean armorChanged = false;
        for (ItemStack piece : armor) {
            if (refreshItem(piece)) {
                armorChanged = true;
                changed++;
            }
        }
        if (armorChanged) inv.setArmorContents(armor);

        ItemStack offHand = inv.getItemInOffHand();
        if (refreshItem(offHand)) {
            inv.setItemInOffHand(offHand);
            changed++;
        }
        return changed;
    }

    // ------------------------------------------------------------- identificación

    public Kind kindOf(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return null;
        return Kind.byId(item.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING));
    }

    /** Ingrediente personalizado (lingotes, estrella, polvo, plantillas). */
    public boolean isIngredient(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isIngredient();
    }

    public boolean isSoulSword(ItemStack item) {
        return kindOf(item) == Kind.SOUL_SWORD;
    }

    public boolean isGreedSword(ItemStack item) {
        return kindOf(item) == Kind.GREED_SWORD;
    }

    public boolean isInfernalSword(ItemStack item) {
        return kindOf(item) == Kind.INFERNAL_SWORD;
    }

    public boolean isPurifiedSword(ItemStack item) {
        return kindOf(item) == Kind.PURIFIED_SWORD;
    }

    public boolean isCelestialSword(ItemStack item) {
        return kindOf(item) == Kind.CELESTIAL_SWORD;
    }

    /** Herramienta del Alma (hacha, pico, pala, azada o lanza). */
    public boolean isSoulTool(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isSoulTool();
    }

    /** Herramienta corrompida por la codicia. */
    public boolean isGreedTool(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isGreedTool();
    }

    /** Herramienta purificada. */
    public boolean isPurifiedTool(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isPurifiedTool();
    }

    /** Herramienta infernal. */
    public boolean isInfernalTool(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isInfernalTool();
    }

    /** Herramienta celestial. */
    public boolean isCelestialTool(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isCelestialTool();
    }

    /** Cualquier herramienta forjada (del Alma, corrompida, purificada, infernal o celestial). */
    public boolean isForgedTool(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isTool();
    }

    /** Multiplicador de daño de la Espada Celestial contra los mobs hostiles (1.2 = +20%). */
    public double celestialHostileMultiplier() {
        return celestialHostileMultiplier;
    }

    /** Multiplicador de daño de la Espada Infernal contra los mobs del Nether (1.45 = +45%). */
    public double infernalNetherMultiplier() {
        return infernalSwordNetherMultiplier;
    }

    /** Equipo terminado (armaduras forjadas, todas las espadas y herramientas forjadas y el Tridente de Netherite). */
    public boolean isForgedGear(ItemStack item) {
        return isCustomArmor(item) || isSoulSword(item) || isGreedSword(item) || isInfernalSword(item) || isPurifiedSword(item)
                || isCelestialSword(item) || isForgedTool(item) || isNetheriteBasedTrident(item) || isYinYangMace(item);
    }

    /** Pieza de la armadura infernal. */
    public boolean isInfernalArmor(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isInfernalArmor();
    }

    /** Pieza de la armadura celestial. */
    public boolean isCelestialArmor(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isCelestialArmor();
    }

    /** Pieza de la armadura del Vacío. */
    public boolean isVoidArmor(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isVoidArmor();
    }

    /** Pieza de la armadura del Fin. */
    public boolean isEndArmor(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isEndArmor();
    }

    /** Cualquier pieza de armadura forjada (infernal, celestial, del Vacío o del Fin). */
    public boolean isCustomArmor(ItemStack item) {
        Kind k = kindOf(item);
        return k != null && k.isArmor();
    }

    /** Pieza infernal que corresponde a una pieza de netherite (la celestial se obtiene con {@link Kind#celestial()}). */
    public static Kind armorKindOf(Material material) {
        for (Map.Entry<Kind, ArmorSpec> e : ARMOR.entrySet()) {
            if (e.getKey().isInfernalArmor() && e.getValue().netherite() == material) return e.getKey();
        }
        return null;
    }

    public static Material netheriteOf(Kind kind) {
        return ARMOR.get(kind).netherite();
    }

    /**
     * Set completo que lleva puesto el jugador: las cuatro piezas del mismo set (infernal, celestial, del Vacío o del Fin),
     * cada una en su ranura. No vale mezclar sets. Devuelve null si no lleva ningún set completo.
     */
    public ArmorSet fullSet(Player player) {
        PlayerInventory inv = player.getInventory();
        List<Kind> worn = Arrays.asList(
                kindOf(inv.getHelmet()), kindOf(inv.getChestplate()),
                kindOf(inv.getLeggings()), kindOf(inv.getBoots()));
        for (ArmorSet set : ArmorSet.values()) {
            if (worn.equals(set.pieces())) return set;
        }
        return null;
    }

    /** Efectos que da el set completo (Infernal: ninguno, su bono es -15% de fuego y lava; Celestial: Resistencia; Vacío y Fin: Resistencia y Regeneración). */
    public SetBonus setBonus(ArmorSet set) {
        if (set.isEndgame()) return new SetBonus(endgameResistanceLevel - 1, endgameRegenerationLevel - 1, false);
        // Infernal: sin efectos (reduce el daño de fuego y lava en ArmorDefenseListener). Celestial: Resistencia.
        if (set == ArmorSet.INFERNAL) return new SetBonus(-1, -1, false); // su bono es -15% de daño de fuego y lava (ArmorDefenseListener)
        return new SetBonus(resistanceLevel - 1, -1, false);
    }

    // ------------------------------------------------------------------- helpers

    private static TextColor colorOf(Kind kind) {
        if (kind == Kind.YIN_YANG_CORE || kind == Kind.YIN_YANG_MACE) return YIN_YANG_COLOR;
        if (kind == Kind.VOID_INGOT || kind == Kind.VOID_TEMPLATE || kind == Kind.DYED_OBSIDIAN) return VOID_COLOR;
        if (kind == Kind.END_INGOT || kind == Kind.END_TEMPLATE || kind == Kind.DYED_CRYING_OBSIDIAN) return END_COLOR;
        if (kind == Kind.REINFORCED_SHULKER || kind == Kind.MUTATED_BREATH || kind == Kind.VOID_DRAGON_HEAD || kind == Kind.END_DRAGON_HEAD
                || kind == Kind.FERMENTED_FRUIT || kind == Kind.VOID_DRAGON_EGG || kind == Kind.END_DRAGON_EGG) {
            return MUTATED_COLOR;
        }
        // INFERNAL_SWORD (y el resto de piezas infernales) usan el rojo infernal por defecto.
        if (kind == Kind.PURIFIED_INGOT || kind == Kind.PURIFIED_TEMPLATE || kind == Kind.PURIFIED_SWORD
                || kind.isPurifiedTool()) return PURE_COLOR;
        if (kind == Kind.CELESTIAL_DUST || kind == Kind.CELESTIAL_CRYSTAL || kind == Kind.CELESTIAL_INGOT
                || kind == Kind.CELESTIAL_TEMPLATE || kind == Kind.CELESTIAL_SWORD
                || kind.isCelestialTool()) return CELESTIAL_COLOR;
        if (kind == Kind.GREED_INGOT || kind == Kind.GREED_TEMPLATE || kind == Kind.GREED_SWORD
                || kind.isGreedTool()) return GREED_COLOR;
        return kind == Kind.SOUL_INGOT || kind == Kind.SOUL_TEMPLATE || kind == Kind.SOUL_SWORD || kind.isSoulTool()
                ? SOUL_COLOR : COLOR;
    }

    /** Añade una línea más de descripción a un objeto ya creado. */
    private static ItemStack withExtraLore(ItemStack item, String text) {
        ItemLore previous = item.getData(DataComponentTypes.LORE);
        ItemLore.Builder lore = ItemLore.lore();
        if (previous != null) lore.addLines(previous.lines());
        lore.addLine(line(text));
        item.setData(DataComponentTypes.LORE, lore.build());
        return item;
    }

    private static Component line(String text) {
        return Component.text(text, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false);
    }

    private static String roman(int n) {
        return n >= 1 && n <= ROMAN.length ? ROMAN[n - 1] : String.valueOf(n);
    }
}
