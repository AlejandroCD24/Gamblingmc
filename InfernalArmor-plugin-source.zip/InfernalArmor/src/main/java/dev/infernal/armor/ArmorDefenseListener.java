package dev.infernal.armor;

import dev.infernal.armor.InfernalItems.ArmorSet;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.ComplexEntityPart;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.projectiles.ProjectileSource;

/**
 * Protección del set completo (se aplica al daño que recibe el jugador, antes de armadura y resistencia):
 *  - Armadura Infernal: -20% (config infernal-armor-nether-reduction) del daño de los mobs del Nether
 *    (los mismos a los que la Espada Infernal hace más daño) y -15% (config infernal-armor-fire-reduction) del daño de
 *    fuego y lava: estar en el fuego o en una fogata, estar prendido, la lava y los bloques de magma.
 *  - Armadura Celestial: -10% (config celestial-armor-hostile-reduction) del daño de los mobs hostiles
 *    (los mismos a los que la Espada Celestial hace más daño: los hostiles excepto los del Nether).
 *  - Armadura del Vacío (viene de la infernal): conserva el -20% contra los mobs del Nether (void-armor-nether-reduction).
 *  - Armadura del Fin (viene de la celestial): conserva el -10% contra los hostiles (end-armor-hostile-reduction).
 *  - Vacío y Fin además: -25% contra los mobs del End -enderman, endermite, shulker, ender dragon y phantom-
 *    (void-end-armor-end-mobs-reduction) y -20% contra explosiones (void-end-armor-explosion-reduction).
 * Cuenta el golpe directo y también proyectiles y bolas de fuego lanzados por el mob (flechas, bolas de fuego de blaze/ghast,
 * proyectiles de shulker, bola de fuego y aliento del dragón...). Las reducciones se multiplican entre sí.
 */
public final class ArmorDefenseListener implements Listener {

    private final InfernalItems items;

    public ArmorDefenseListener(InfernalItems items) {
        this.items = items;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        ArmorSet set = items.fullSet(player);
        if (set == null) return;

        double multiplier = 1.0;

        // Protección contra el tipo de mob que causa el daño (golpe directo o proyectil / nube lanzados por él).
        if (event instanceof EntityDamageByEntityEvent byEntity) {
            EntityType type = sourceType(byEntity.getDamager());
            if (type != null) multiplier *= mobMultiplier(set, type);
        }

        // Infernal: protección contra fuego y lava.
        if (set == ArmorSet.INFERNAL && isFireOrLava(event)) {
            multiplier *= 1.0 - items.infernalArmorFireReduction();
        }

        // Protección contra explosiones (creeper, TNT, cristal del End, cama, ancla, bolas de fuego...).
        if (set.isEndgame()) {
            DamageCause cause = event.getCause();
            if (cause == DamageCause.ENTITY_EXPLOSION || cause == DamageCause.BLOCK_EXPLOSION) {
                multiplier *= 1.0 - items.explosionReduction();
            }
        }

        if (multiplier < 1.0) {
            event.setDamage(event.getDamage() * multiplier);
        }
    }

    /** Daño de fuego o lava: dentro del fuego, prendido, lava, bloque de magma y fogata. */
    private static boolean isFireOrLava(EntityDamageEvent event) {
        DamageType type = event.getDamageSource().getDamageType();
        return type == DamageType.IN_FIRE || type == DamageType.ON_FIRE || type == DamageType.LAVA
                || type == DamageType.HOT_FLOOR || type == DamageType.CAMPFIRE;
    }

    /** Tipo de mob responsable del daño: el atacante, o quien lanzó el proyectil / la nube de aliento. Null si no hay mob. */
    private static EntityType sourceType(Entity damager) {
        Entity source = damager;
        if (source instanceof ComplexEntityPart part) source = part.getParent();
        ProjectileSource shooter = null;
        if (source instanceof Projectile projectile) {
            shooter = projectile.getShooter();
        } else if (source instanceof AreaEffectCloud cloud) {
            shooter = cloud.getSource(); // aliento del Ender Dragon
        }
        if (shooter != null) {
            if (!(shooter instanceof Entity shooterEntity)) return null;
            source = shooterEntity;
            if (source instanceof ComplexEntityPart part) source = part.getParent();
        }
        return source.getType();
    }

    /** Multiplicador de daño (1.0 = sin protección) que da el set completo contra este tipo de mob. */
    private double mobMultiplier(ArmorSet set, EntityType type) {
        double multiplier = 1.0;
        switch (set) {
            case INFERNAL -> {
                if (NetherDamageListener.NETHER_MOBS.contains(type)) multiplier *= 1.0 - items.infernalArmorNetherReduction();
            }
            case CELESTIAL -> {
                if (NetherDamageListener.CELESTIAL_MOBS.contains(type)) multiplier *= 1.0 - items.celestialArmorHostileReduction();
            }
            case VOID -> {
                if (NetherDamageListener.NETHER_MOBS.contains(type)) multiplier *= 1.0 - items.voidArmorNetherReduction();
                if (NetherDamageListener.END_MOBS.contains(type)) multiplier *= 1.0 - items.endMobsReduction();
            }
            case END -> {
                if (NetherDamageListener.CELESTIAL_MOBS.contains(type)) multiplier *= 1.0 - items.endArmorHostileReduction();
                if (NetherDamageListener.END_MOBS.contains(type)) multiplier *= 1.0 - items.endMobsReduction();
            }
        }
        return multiplier;
    }
}
