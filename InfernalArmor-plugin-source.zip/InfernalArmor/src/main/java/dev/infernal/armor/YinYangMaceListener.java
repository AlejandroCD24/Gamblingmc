package dev.infernal.armor;

import dev.infernal.armor.InfernalItems.Kind;
import org.bukkit.damage.DamageType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.entity.WindCharge;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockDispenseLootEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Mazo Yin Yang:
 *  - Aeroimpulso I incorporado: al hacer un golpe aplastante (golpear cayendo, como el mazo vanilla) te lanza hacia arriba como
 *    el encantamiento Aeroimpulso I. Si el mazo tiene Aeroimpulso encantado, manda el encantamiento (II y III suben más alto).
 *  - El Núcleo Yin Yang sale en las bóvedas ominosas (yin-yang-mace.core-chance, 6.7%), además del botín normal.
 */
public final class YinYangMaceListener implements Listener {

    private final JavaPlugin plugin;
    private final InfernalItems items;

    public YinYangMaceListener(JavaPlugin plugin, InfernalItems items) {
        this.plugin = plugin;
        this.items = items;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSmash(EntityDamageByEntityEvent event) {
        if (!items.yinYangWindBurst()) return;
        if (!(event.getDamager() instanceof Player player)) return;
        // Solo el golpe aplastante (caer más de 1.5 bloques y golpear), que es cuando actúa el Aeroimpulso vanilla.
        if (!DamageType.MACE_SMASH.equals(event.getDamageSource().getDamageType())) return;

        ItemStack weapon = player.getInventory().getItemInMainHand();
        if (!items.isYinYangMace(weapon)) return;
        // Con Aeroimpulso encantado lo hace el propio encantamiento (I igual, II y III más alto).
        if (weapon.getEnchantmentLevel(Enchantment.WIND_BURST) > 0) return;

        // En el tick siguiente: el mazo deja al jugador quieto en el aire al golpear y el impulso tiene que ir después.
        plugin.getServer().getScheduler().runTask(plugin, () -> windBurst(player));
    }

    /**
     * Aeroimpulso I: la explosión de una carga de viento en los pies del jugador. Es la misma que hace el encantamiento
     * (impulso 1.2 hacia arriba; la de la carga de viento es 1.22), con sus partículas y su sonido, empuja a los mobs de
     * alrededor y, como en vanilla, el daño de caída cuenta desde donde te lanzó.
     */
    private void windBurst(Player player) {
        if (!player.isOnline() || !player.isValid() || player.isGliding()) return;
        WindCharge charge = player.getWorld().spawn(player.getLocation(), WindCharge.class, c -> {
            c.setShooter(player);
            c.setVelocity(new Vector());
        });
        charge.explode();
    }

    /** Bóveda ominosa abierta con su llave: con un 6.7% de probabilidad suelta además un Núcleo Yin Yang. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onVaultLoot(BlockDispenseLootEvent event) {
        if (event.getPlayer() == null) return;
        if (!(event.getBlock().getBlockData() instanceof org.bukkit.block.data.type.Vault vault) || !vault.isOminous()) return;
        double chance = items.yinYangCoreChance();
        if (chance <= 0.0 || ThreadLocalRandom.current().nextDouble() >= chance) return;

        List<ItemStack> loot = new ArrayList<>(event.getDispensedLoot());
        loot.add(items.create(Kind.YIN_YANG_CORE));
        event.setDispensedLoot(loot);
    }
}
