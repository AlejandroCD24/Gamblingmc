package dev.infernal.armor;

import dev.infernal.armor.InfernalItems.Kind;
import org.bukkit.Bukkit;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.SmithingTransformRecipe;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Registra los crafteos de ingredientes y las recetas de mejora en mesa de herrería (armaduras infernal y celestial, espadas y herramientas forjadas). */
public final class InfernalRecipes {

    private final JavaPlugin plugin;
    private final InfernalItems items;
    private final List<NamespacedKey> keys = new ArrayList<>();

    /** Recetas de mesa de crafteo de los objetos únicos de la Armadura Infernal (sin el polvo, que tiene su propia opción). */
    private static final Set<String> INFERNAL_INGREDIENTS = Set.of(
            "reinforced_nether_star", "infernal_ingot", "infernal_upgrade_template");

    /** Recetas de mesa de crafteo de los objetos únicos de la Armadura Celestial. */
    private static final Set<String> CELESTIAL_INGREDIENTS = Set.of(
            "celestial_dust", "celestial_crystal", "celestial_ingot", "celestial_upgrade_template");

    /** Recetas de mesa de crafteo de los objetos únicos de las armaduras del Vacío y del Fin (sin la caja reforzada). */
    private static final Set<String> VOID_END_INGREDIENTS = Set.of(
            "mutated_dragon_breath", "void_mutated_dragon_head", "end_mutated_dragon_head", "fermented_coral_fruit",
            "void_incubated_dragon_egg", "end_incubated_dragon_egg", "void_ingot", "end_ingot",
            "dyed_obsidian", "dyed_crying_obsidian", "void_upgrade_template", "end_upgrade_template");

    /** Recetas que no se registran según armor-lock (config.yml). */
    private final Set<String> blocked = new HashSet<>();

    public InfernalRecipes(JavaPlugin plugin, InfernalItems items) {
        this.plugin = plugin;
        this.items = items;
        boolean infernalAllowed = items.infernalArmorAllowed();
        if (plugin.getConfig().getBoolean("armor-lock.block-ingredient-crafting", true)) {
            if (!infernalAllowed) blocked.addAll(INFERNAL_INGREDIENTS);
            blocked.addAll(CELESTIAL_INGREDIENTS);
            blocked.addAll(VOID_END_INGREDIENTS);
        }
        // Plantilla Infernal: por defecto NO se craftea (solo sale en los cofres de los bastiones, BastionLootListener).
        if (!plugin.getConfig().getBoolean("infernal-template-crafting", false)) {
            blocked.add("infernal_upgrade_template");
        }
        // Polvo de Blaze Infernal: por defecto NO se craftea (solo lo sueltan los Wildfire).
        if (!plugin.getConfig().getBoolean("infernal-blaze-powder-crafting", false)) {
            blocked.add("infernal_blaze_powder");
        }
        if (plugin.getConfig().getBoolean("armor-lock.block-reinforced-shulker", true)) {
            blocked.add("reinforced_shulker_box");
        }
        if (plugin.getConfig().getBoolean("armor-lock.block-upgrades", true)) {
            if (!infernalAllowed) {
                for (Kind kind : Kind.armor()) blocked.add("upgrade_" + kind.id());
            }
            for (Kind kind : Kind.celestialArmor()) blocked.add("upgrade_" + kind.id());
        }
    }

    public void register() {
        // Polvo de Blaze Infernal  (imagen 3)
        ShapedRecipe powder = new ShapedRecipe(key("infernal_blaze_powder"), items.create(Kind.POWDER));
        powder.shape("RWR", "WPW", "RWR");
        powder.setIngredient('R', Material.BLAZE_ROD);
        powder.setIngredient('W', Material.NETHER_WART);
        powder.setIngredient('P', plain(Material.BLAZE_POWDER));
        add(powder);

        // Estrella del Nether Reforzada  (imagen 2)
        ShapedRecipe star = new ShapedRecipe(key("reinforced_nether_star"), items.create(Kind.STAR));
        star.shape("GBG", "SNS", "GBG");
        star.setIngredient('G', Material.GHAST_TEAR);
        star.setIngredient('B', plain(Material.BLAZE_POWDER));
        star.setIngredient('S', Material.WITHER_SKELETON_SKULL);
        star.setIngredient('N', plain(Material.NETHER_STAR));
        add(star);

        // Lingote Infernal  (imagen 1)
        ShapedRecipe ingot = new ShapedRecipe(key("infernal_ingot"), items.create(Kind.INGOT));
        ingot.shape("SGS", "PIP", "SGS");
        ingot.setIngredient('S', custom(Kind.STAR));
        ingot.setIngredient('G', Material.GHAST_TEAR);
        ingot.setIngredient('P', custom(Kind.POWDER));
        ingot.setIngredient('I', plain(Material.NETHERITE_INGOT));
        add(ingot);

        // Plantilla de mejora infernal  (imagen 4)
        ShapedRecipe template = new ShapedRecipe(key("infernal_upgrade_template"), items.create(Kind.TEMPLATE));
        template.shape("DTD", "BSB", "DBD");
        template.setIngredient('D', Material.ANCIENT_DEBRIS);
        template.setIngredient('T', plain(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE));
        template.setIngredient('B', Material.NETHER_BRICK);
        template.setIngredient('S', Material.NETHERITE_SCRAP);
        add(template);

        // Lingote del Alma: dried ghast (esquinas), lágrimas de ghast (lados), lingote de netherite (centro)
        ShapedRecipe soulIngot = new ShapedRecipe(key("soul_ingot"), items.create(Kind.SOUL_INGOT));
        soulIngot.shape("DGD", "GIG", "DGD");
        soulIngot.setIngredient('D', Material.DRIED_GHAST);
        soulIngot.setIngredient('G', Material.GHAST_TEAR);
        soulIngot.setIngredient('I', plain(Material.NETHERITE_INGOT));
        add(soulIngot);

        // Plantilla del Alma: lágrimas de ghast, plantilla de netherite (arriba), dried ghast (centro)
        ShapedRecipe soulTemplate = new ShapedRecipe(key("soul_upgrade_template"), items.create(Kind.SOUL_TEMPLATE));
        soulTemplate.shape("GTG", "GDG", "GGG");
        soulTemplate.setIngredient('G', Material.GHAST_TEAR);
        soulTemplate.setIngredient('T', plain(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE));
        soulTemplate.setIngredient('D', Material.DRIED_GHAST);
        add(soulTemplate);

        // Lingote de Codicia: pepitas de oro (esquinas), plantillas rib (lados), lingote de oro (centro)
        ShapedRecipe greedIngot = new ShapedRecipe(key("greed_ingot"), items.create(Kind.GREED_INGOT));
        greedIngot.shape("NRN", "RGR", "NRN");
        greedIngot.setIngredient('N', Material.GOLD_NUGGET);
        greedIngot.setIngredient('R', Material.RIB_ARMOR_TRIM_SMITHING_TEMPLATE);
        greedIngot.setIngredient('G', Material.GOLD_INGOT);
        add(greedIngot);

        // Plantilla de Codicia: lingotes de oro, plantilla de netherite (arriba-centro), plantilla rib (centro)
        ShapedRecipe greedTemplate = new ShapedRecipe(key("greed_upgrade_template"), items.create(Kind.GREED_TEMPLATE));
        greedTemplate.shape("GTG", "GRG", "GGG");
        greedTemplate.setIngredient('G', Material.GOLD_INGOT);
        greedTemplate.setIngredient('T', plain(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE));
        greedTemplate.setIngredient('R', Material.RIB_ARMOR_TRIM_SMITHING_TEMPLATE);
        add(greedTemplate);

        // Lingote Purificado: cuarzo (esquinas), moldes Flow (arriba/abajo/lados), diamante (centro)
        ShapedRecipe purifiedIngot = new ShapedRecipe(key("purified_ingot"), items.create(Kind.PURIFIED_INGOT));
        purifiedIngot.shape("QFQ", "FDF", "QFQ");
        purifiedIngot.setIngredient('Q', Material.QUARTZ);
        purifiedIngot.setIngredient('F', Material.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE);
        purifiedIngot.setIngredient('D', Material.DIAMOND);
        add(purifiedIngot);

        // Plantilla Purificada: cuarzo (todos menos arriba-centro y centro), plantilla de netherite (arriba-centro), molde Flow (centro)
        ShapedRecipe purifiedTemplate = new ShapedRecipe(key("purified_upgrade_template"), items.create(Kind.PURIFIED_TEMPLATE));
        purifiedTemplate.shape("QTQ", "QFQ", "QQQ");
        purifiedTemplate.setIngredient('Q', Material.QUARTZ);
        purifiedTemplate.setIngredient('T', plain(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE));
        purifiedTemplate.setIngredient('F', Material.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE);
        add(purifiedTemplate);

        // Polvo Celestial: cargas de viento (esquinas), cuarzo (lados), vara de breeze (centro).
        // El Polvo Celestial usa una vara de breeze de base, así que aquí la vara debe ser la vanilla "pura".
        ShapedRecipe celestialDust = new ShapedRecipe(key("celestial_dust"), items.create(Kind.CELESTIAL_DUST));
        celestialDust.shape("WQW", "QBQ", "WQW");
        celestialDust.setIngredient('W', Material.WIND_CHARGE);
        celestialDust.setIngredient('Q', Material.QUARTZ);
        celestialDust.setIngredient('B', plain(Material.BREEZE_ROD));
        add(celestialDust);

        // Cristal Celestial: lágrimas de ghast (esquinas), Polvo Celestial (arriba/abajo), balizas (lados), cristal del End (centro).
        // El Cristal Celestial usa un cristal del End de base, así que aquí el cristal debe ser el vanilla "puro".
        ShapedRecipe celestialCrystal = new ShapedRecipe(key("celestial_crystal"), items.create(Kind.CELESTIAL_CRYSTAL));
        celestialCrystal.shape("TDT", "BEB", "TDT");
        celestialCrystal.setIngredient('T', Material.GHAST_TEAR);
        celestialCrystal.setIngredient('D', custom(Kind.CELESTIAL_DUST));
        celestialCrystal.setIngredient('B', Material.BEACON);
        celestialCrystal.setIngredient('E', plain(Material.END_CRYSTAL));
        add(celestialCrystal);

        // Lingote Celestial: cristales celestiales (esquinas), amatista (arriba/abajo), Polvo Celestial (lados), lingote de netherite (centro)
        ShapedRecipe celestialIngot = new ShapedRecipe(key("celestial_ingot"), items.create(Kind.CELESTIAL_INGOT));
        celestialIngot.shape("CAC", "DND", "CAC");
        celestialIngot.setIngredient('C', custom(Kind.CELESTIAL_CRYSTAL));
        celestialIngot.setIngredient('A', Material.AMETHYST_SHARD);
        celestialIngot.setIngredient('D', custom(Kind.CELESTIAL_DUST));
        celestialIngot.setIngredient('N', plain(Material.NETHERITE_INGOT));
        add(celestialIngot);

        // Plantilla Celestial: bloques de diamante (esquinas), plantilla de netherite (arriba-centro), amatista (lados y abajo-centro), Cristal Celestial (centro)
        ShapedRecipe celestialTemplate = new ShapedRecipe(key("celestial_upgrade_template"), items.create(Kind.CELESTIAL_TEMPLATE));
        celestialTemplate.shape("DTD", "AXA", "DAD");
        celestialTemplate.setIngredient('D', Material.DIAMOND_BLOCK);
        celestialTemplate.setIngredient('T', plain(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE));
        celestialTemplate.setIngredient('A', Material.AMETHYST_SHARD);
        celestialTemplate.setIngredient('X', custom(Kind.CELESTIAL_CRYSTAL));
        add(celestialTemplate);

        // ------------------------------------------------------------------------------------------------
        // Armadura del Vacío (viene de la Infernal) y Armadura del Fin (viene de la Celestial): ingredientes.
        // Los objetos vanilla que tienen versión propia (aliento, cabeza, huevo, cristal del End) van con plain()
        // para que no acepten la versión mutada hecha con el mismo material.
        // ------------------------------------------------------------------------------------------------

        // Aliento del Dragón Mutado: frutos de chorus (esquinas), flores de chorus (lados), aliento de dragón (centro)
        ShapedRecipe mutatedBreath = new ShapedRecipe(key("mutated_dragon_breath"), items.create(Kind.MUTATED_BREATH));
        mutatedBreath.shape("FCF", "CBC", "FCF");
        mutatedBreath.setIngredient('F', Material.CHORUS_FRUIT);
        mutatedBreath.setIngredient('C', Material.CHORUS_FLOWER);
        mutatedBreath.setIngredient('B', plain(Material.DRAGON_BREATH));
        add(mutatedBreath);

        // Cabeza del Dragón Mutada (Vacío): Alientos Mutados (esquinas), Polvos de Blaze Infernales (lados), cabeza de dragón (centro)
        ShapedRecipe voidHead = new ShapedRecipe(key("void_mutated_dragon_head"), items.create(Kind.VOID_DRAGON_HEAD));
        voidHead.shape("BPB", "PHP", "BPB");
        voidHead.setIngredient('B', custom(Kind.MUTATED_BREATH));
        voidHead.setIngredient('P', custom(Kind.POWDER));
        voidHead.setIngredient('H', plain(Material.DRAGON_HEAD));
        add(voidHead);

        // Cabeza del Dragón Mutada (Fin): Alientos Mutados (esquinas), Polvos Celestiales (lados), cabeza de dragón (centro)
        ShapedRecipe endHead = new ShapedRecipe(key("end_mutated_dragon_head"), items.create(Kind.END_DRAGON_HEAD));
        endHead.shape("BPB", "PHP", "BPB");
        endHead.setIngredient('B', custom(Kind.MUTATED_BREATH));
        endHead.setIngredient('P', custom(Kind.CELESTIAL_DUST));
        endHead.setIngredient('H', plain(Material.DRAGON_HEAD));
        add(endHead);

        // Fruto del Coral Fermentado (sirve para las dos armaduras): flores de chorus (arriba y abajo),
        // frutos de chorus (lados), fruto de chorus reventado vanilla (centro).
        // El centro va con plain(): el propio Fruto Fermentado es un fruto reventado de base y no debe valer ahí.
        ShapedRecipe fermentedFruit = new ShapedRecipe(key("fermented_coral_fruit"), items.create(Kind.FERMENTED_FRUIT));
        fermentedFruit.shape("FFF", "CPC", "FFF");
        fermentedFruit.setIngredient('F', Material.CHORUS_FLOWER);
        fermentedFruit.setIngredient('C', Material.CHORUS_FRUIT);
        fermentedFruit.setIngredient('P', plain(Material.POPPED_CHORUS_FRUIT));
        add(fermentedFruit);

        // Huevo del Dragón Encubado (Vacío): cristales del End (esquinas), Estrellas del Nether Reforzadas (lados), huevo de dragón (centro)
        ShapedRecipe voidEgg = new ShapedRecipe(key("void_incubated_dragon_egg"), items.create(Kind.VOID_DRAGON_EGG));
        voidEgg.shape("CSC", "SES", "CSC");
        voidEgg.setIngredient('C', plain(Material.END_CRYSTAL));
        voidEgg.setIngredient('S', custom(Kind.STAR));
        voidEgg.setIngredient('E', plain(Material.DRAGON_EGG));
        add(voidEgg);

        // Huevo del Dragón Encubado (Fin): cristales del End (esquinas), Cristales Celestiales (lados), huevo de dragón (centro)
        ShapedRecipe endEgg = new ShapedRecipe(key("end_incubated_dragon_egg"), items.create(Kind.END_DRAGON_EGG));
        endEgg.shape("CSC", "SES", "CSC");
        endEgg.setIngredient('C', plain(Material.END_CRYSTAL));
        endEgg.setIngredient('S', custom(Kind.CELESTIAL_CRYSTAL));
        endEgg.setIngredient('E', plain(Material.DRAGON_EGG));
        add(endEgg);

        // Lingote del Vacío: Frutos del Coral Fermentados (esquinas), Cabezas Mutadas del Vacío (arriba/abajo),
        // Huevos Encubados del Vacío (lados), Lingote Infernal (centro)
        ShapedRecipe voidIngot = new ShapedRecipe(key("void_ingot"), items.create(Kind.VOID_INGOT));
        voidIngot.shape("SHS", "EIE", "SHS");
        voidIngot.setIngredient('S', custom(Kind.FERMENTED_FRUIT));
        voidIngot.setIngredient('H', custom(Kind.VOID_DRAGON_HEAD));
        voidIngot.setIngredient('E', custom(Kind.VOID_DRAGON_EGG));
        voidIngot.setIngredient('I', custom(Kind.INGOT));
        add(voidIngot);

        // Lingote del Fin: Frutos del Coral Fermentados (esquinas), Cabezas Mutadas del Fin (arriba/abajo),
        // Huevos Encubados del Fin (lados), Lingote Celestial (centro)
        ShapedRecipe endIngot = new ShapedRecipe(key("end_ingot"), items.create(Kind.END_INGOT));
        endIngot.shape("SHS", "EIE", "SHS");
        endIngot.setIngredient('S', custom(Kind.FERMENTED_FRUIT));
        endIngot.setIngredient('H', custom(Kind.END_DRAGON_HEAD));
        endIngot.setIngredient('E', custom(Kind.END_DRAGON_EGG));
        endIngot.setIngredient('I', custom(Kind.CELESTIAL_INGOT));
        add(endIngot);

        // ------------------------------------------------------------------------------------------------
        // Plantillas del Vacío y del Fin. Cada una se hace con la plantilla de su armadura de origen
        // (Vacío <- Infernal, Fin <- Celestial), cajas de shulker reforzadas y obsidiana teñida.
        // ------------------------------------------------------------------------------------------------

        // Caja de Shulker Reforzada (doble de espacio, funcional): cáscaras de shulker (todo el borde) + caja de shulker (centro).
        // El centro acepta una caja de shulker normal (sin teñir) aunque tenga objetos: ReinforcedShulkerListener los pasa a la nueva caja.
        ShapedRecipe reinforcedShulker = new ShapedRecipe(key("reinforced_shulker_box"), items.create(Kind.REINFORCED_SHULKER));
        reinforcedShulker.shape("SSS", "SBS", "SSS");
        reinforcedShulker.setIngredient('S', Material.SHULKER_SHELL);
        reinforcedShulker.setIngredient('B', new RecipeChoice.MaterialChoice(Material.SHULKER_BOX));
        add(reinforcedShulker);

        // Obsidiana Teñida (Vacío): ladrillos de piedra del End (esquinas), losas de ladrillo de piedra del End (arriba/abajo),
        // escaleras de ladrillo de piedra del End (lados), obsidiana (centro)
        ShapedRecipe dyedObsidian = new ShapedRecipe(key("dyed_obsidian"), items.create(Kind.DYED_OBSIDIAN));
        dyedObsidian.shape("BSB", "TOT", "BSB");
        dyedObsidian.setIngredient('B', Material.END_STONE_BRICKS);
        dyedObsidian.setIngredient('S', Material.END_STONE_BRICK_SLAB);
        dyedObsidian.setIngredient('T', Material.END_STONE_BRICK_STAIRS);
        dyedObsidian.setIngredient('O', plain(Material.OBSIDIAN));
        add(dyedObsidian);

        // Obsidiana Llorosa Teñida (Fin): bloques de purpur (esquinas), losas de purpur (arriba/abajo),
        // pilares de purpur (lados), obsidiana llorosa (centro)
        ShapedRecipe dyedCryingObsidian = new ShapedRecipe(key("dyed_crying_obsidian"), items.create(Kind.DYED_CRYING_OBSIDIAN));
        dyedCryingObsidian.shape("PSP", "LCL", "PSP");
        dyedCryingObsidian.setIngredient('P', Material.PURPUR_BLOCK);
        dyedCryingObsidian.setIngredient('S', Material.PURPUR_SLAB);
        dyedCryingObsidian.setIngredient('L', Material.PURPUR_PILLAR);
        dyedCryingObsidian.setIngredient('C', plain(Material.CRYING_OBSIDIAN));
        add(dyedCryingObsidian);

        // Plantilla del Vacío: Obsidiana Teñida (arriba-lados y toda la fila del medio), Plantilla Infernal (arriba-centro),
        // Cajas de Shulker Reforzadas (fila de abajo), de cualquier color. Las cajas tienen que estar vacías (si no, no coinciden con la receta).
        ShapedRecipe voidTemplate = new ShapedRecipe(key("void_upgrade_template"), items.create(Kind.VOID_TEMPLATE));
        voidTemplate.shape("OTO", "OOO", "RRR");
        voidTemplate.setIngredient('O', custom(Kind.DYED_OBSIDIAN));
        voidTemplate.setIngredient('T', custom(Kind.TEMPLATE));
        voidTemplate.setIngredient('R', anyReinforcedShulker());
        add(voidTemplate);

        // Plantilla del Fin: Obsidiana Llorosa Teñida (arriba-lados y toda la fila del medio), Plantilla Celestial (arriba-centro),
        // Cajas de Shulker Reforzadas (fila de abajo).
        ShapedRecipe endTemplate = new ShapedRecipe(key("end_upgrade_template"), items.create(Kind.END_TEMPLATE));
        endTemplate.shape("OTO", "OOO", "RRR");
        endTemplate.setIngredient('O', custom(Kind.DYED_CRYING_OBSIDIAN));
        endTemplate.setIngredient('T', custom(Kind.CELESTIAL_TEMPLATE));
        endTemplate.setIngredient('R', anyReinforcedShulker());
        add(endTemplate);

        // Tridente de Netherite en mesa de herrería: plantilla de mejora de netherite + tridente + lingote de netherite (vanilla).
        // Sin esta receta la mesa no deja poner el tridente. El resultado real (con encantamientos, etc.) lo calcula SmithingListener.
        if (items.netheriteTridentEnabled()) {
            add(new SmithingTransformRecipe(
                    key("netherite_trident"),
                    items.create(Kind.NETHERITE_TRIDENT),
                    plain(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE),
                    new RecipeChoice.MaterialChoice(Material.TRIDENT),
                    plain(Material.NETHERITE_INGOT)));
        }

        // Tridente Infernal en mesa de herrería: Plantilla Infernal + Tridente de Netherite + Lingote Infernal.
        // El resultado real (con encantamientos, etc.) lo calcula SmithingListener.
        if (items.infernalTridentEnabled()) {
            add(new SmithingTransformRecipe(
                    key("infernal_trident"),
                    items.create(Kind.INFERNAL_TRIDENT),
                    custom(Kind.TEMPLATE),
                    new RecipeChoice.MaterialChoice(Material.TRIDENT),
                    custom(Kind.INGOT)));
        }

        // Mazo Yin Yang en mesa de herrería: plantilla de mejora de netherite + mazo + Núcleo Yin Yang (sale en las bóvedas ominosas).
        // El resultado real (con encantamientos, etc.) lo calcula SmithingListener.
        if (items.yinYangMaceEnabled()) {
            add(new SmithingTransformRecipe(
                    key("yin_yang_mace"),
                    items.create(Kind.YIN_YANG_MACE),
                    plain(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE),
                    new RecipeChoice.MaterialChoice(Material.MACE),
                    custom(Kind.YIN_YANG_CORE)));
        }

        // Espada del Alma en mesa de herrería: espada de netherite + lingote del alma + plantilla del alma.
        // El resultado real (con encantamientos, etc.) lo calcula SmithingListener.
        add(new SmithingTransformRecipe(
                key("upgrade_soul_sword"),
                items.create(Kind.SOUL_SWORD),
                custom(Kind.SOUL_TEMPLATE),
                new RecipeChoice.MaterialChoice(Material.NETHERITE_SWORD),
                custom(Kind.SOUL_INGOT)));

        // Herramientas del Alma en mesa de herrería: hacha / pico / pala / azada / lanza de netherite
        // + lingote del alma + plantilla del alma. El resultado real (con encantamientos, etc.) lo calcula SmithingListener.
        for (Kind kind : Kind.soulTools()) {
            add(new SmithingTransformRecipe(
                    key("upgrade_" + kind.id()),
                    items.create(kind),
                    custom(Kind.SOUL_TEMPLATE),
                    new RecipeChoice.MaterialChoice(InfernalItems.netheriteToolOf(kind)),
                    custom(Kind.SOUL_INGOT)));
        }

        // Herramientas corrompidas en mesa de herrería: herramienta del Alma + Lingote de Codicia + Plantilla de Codicia.
        // Herramientas purificadas: herramienta del Alma + Lingote Purificado + Plantilla Purificada.
        // El resultado real (con encantamientos, etc.) lo calcula SmithingListener.
        for (Kind soul : Kind.soulTools()) {
            add(new SmithingTransformRecipe(
                    key("upgrade_" + soul.greed().id()),
                    items.create(soul.greed()),
                    custom(Kind.GREED_TEMPLATE),
                    new RecipeChoice.MaterialChoice(InfernalItems.netheriteToolOf(soul)),
                    custom(Kind.GREED_INGOT)));
            add(new SmithingTransformRecipe(
                    key("upgrade_" + soul.purified().id()),
                    items.create(soul.purified()),
                    custom(Kind.PURIFIED_TEMPLATE),
                    new RecipeChoice.MaterialChoice(InfernalItems.netheriteToolOf(soul)),
                    custom(Kind.PURIFIED_INGOT)));
        }

        // Herramientas infernales en mesa de herrería: herramienta corrompida + Lingote Infernal + Plantilla infernal.
        // Herramientas celestiales: herramienta purificada + Lingote Celestial + Plantilla Celestial.
        // El resultado real (con encantamientos, etc.) lo calcula SmithingListener.
        for (Kind soul : Kind.soulTools()) {
            add(new SmithingTransformRecipe(
                    key("upgrade_" + soul.infernal().id()),
                    items.create(soul.infernal()),
                    custom(Kind.TEMPLATE),
                    new RecipeChoice.MaterialChoice(InfernalItems.netheriteToolOf(soul)),
                    custom(Kind.INGOT)));
            add(new SmithingTransformRecipe(
                    key("upgrade_" + soul.celestial().id()),
                    items.create(soul.celestial()),
                    custom(Kind.CELESTIAL_TEMPLATE),
                    new RecipeChoice.MaterialChoice(InfernalItems.netheriteToolOf(soul)),
                    custom(Kind.CELESTIAL_INGOT)));
        }

        // Espada del Alma Corrompida en mesa de herrería: Espada del Alma + Lingote de Codicia + Plantilla de Codicia.
        // El resultado real (con encantamientos, etc.) lo calcula SmithingListener.
        add(new SmithingTransformRecipe(
                key("upgrade_greed_sword"),
                items.create(Kind.GREED_SWORD),
                custom(Kind.GREED_TEMPLATE),
                new RecipeChoice.MaterialChoice(Material.NETHERITE_SWORD),
                custom(Kind.GREED_INGOT)));

        // Espada Infernal en mesa de herrería: Espada del Alma Corrompida + Lingote Infernal + Plantilla infernal.
        // El resultado real (con encantamientos, etc.) lo calcula SmithingListener.
        add(new SmithingTransformRecipe(
                key("upgrade_infernal_sword"),
                items.create(Kind.INFERNAL_SWORD),
                custom(Kind.TEMPLATE),
                new RecipeChoice.MaterialChoice(Material.NETHERITE_SWORD),
                custom(Kind.INGOT)));

        // Espada Purificada en mesa de herrería: Espada del Alma + Lingote Purificado + Plantilla Purificada.
        // El resultado real (con encantamientos, etc.) lo calcula SmithingListener.
        add(new SmithingTransformRecipe(
                key("upgrade_purified_sword"),
                items.create(Kind.PURIFIED_SWORD),
                custom(Kind.PURIFIED_TEMPLATE),
                new RecipeChoice.MaterialChoice(Material.NETHERITE_SWORD),
                custom(Kind.PURIFIED_INGOT)));

        // Espada Celestial en mesa de herrería: Espada Purificada + Lingote Celestial + Plantilla Celestial.
        // El resultado real (con encantamientos, etc.) lo calcula SmithingListener.
        add(new SmithingTransformRecipe(
                key("upgrade_celestial_sword"),
                items.create(Kind.CELESTIAL_SWORD),
                custom(Kind.CELESTIAL_TEMPLATE),
                new RecipeChoice.MaterialChoice(Material.NETHERITE_SWORD),
                custom(Kind.CELESTIAL_INGOT)));

        // Mejora en mesa de herrería: armadura de netherite + lingote infernal + plantilla infernal.
        // El resultado real (con encantamientos, trim, etc.) lo calcula SmithingListener.
        for (Kind kind : Kind.armor()) {
            SmithingTransformRecipe upgrade = new SmithingTransformRecipe(
                    key("upgrade_" + kind.id()),
                    items.create(kind),
                    custom(Kind.TEMPLATE),
                    new RecipeChoice.MaterialChoice(InfernalItems.netheriteOf(kind)),
                    custom(Kind.INGOT));
            add(upgrade);
        }

        // Armadura celestial en mesa de herrería: armadura de netherite + lingote celestial + plantilla celestial
        // (los mismos que usa la Espada Celestial). El resultado real lo calcula SmithingListener.
        for (Kind kind : Kind.celestialArmor()) {
            SmithingTransformRecipe upgrade = new SmithingTransformRecipe(
                    key("upgrade_" + kind.id()),
                    items.create(kind),
                    custom(Kind.CELESTIAL_TEMPLATE),
                    new RecipeChoice.MaterialChoice(InfernalItems.netheriteOf(kind)),
                    custom(Kind.CELESTIAL_INGOT));
            add(upgrade);
        }
    }

    public void unregister() {
        for (NamespacedKey k : keys) Bukkit.removeRecipe(k);
        keys.clear();
    }

    private NamespacedKey key(String id) {
        NamespacedKey k = new NamespacedKey(plugin, id);
        keys.add(k);
        return k;
    }

    /** Registra la receta salvo que armor-lock la bloquee (así tampoco aparece en el libro de recetas). */
    private void add(Recipe recipe) {
        if (recipe instanceof Keyed keyed && blocked.contains(keyed.getKey().getKey())) return;
        Bukkit.addRecipe(recipe);
    }

    /** Cuántas recetas del plugin se han dejado sin registrar por armor-lock. */
    public int blockedCount() {
        return blocked.size();
    }

    /** Objeto vanilla "puro": no acepta las versiones infernales hechas con el mismo material. */
    private static RecipeChoice plain(Material material) {
        return new RecipeChoice.ExactChoice(new ItemStack(material));
    }

    private RecipeChoice custom(Kind kind) {
        return new RecipeChoice.ExactChoice(items.create(kind));
    }

    /** Caja de Shulker Reforzada vacía de cualquier color (se puede teñir como una caja de shulker normal). */
    private RecipeChoice anyReinforcedShulker() {
        List<ItemStack> variants = new ArrayList<>();
        for (Material box : InfernalItems.SHULKER_BOXES) variants.add(items.reinforcedShulker(box));
        return new RecipeChoice.ExactChoice(variants);
    }
}
