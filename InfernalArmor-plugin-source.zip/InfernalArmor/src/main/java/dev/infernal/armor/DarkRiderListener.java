package dev.infernal.armor;

import com.destroystokyo.paper.event.entity.EntityAddToWorldEvent;
import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.datacomponent.item.Equippable;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Biome;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.WitherSkeleton;
import org.bukkit.entity.ZombieHorse;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Jinete Oscuro: un esqueleto wither con armadura completa de netherite y una lanza de netherite con Filo V, montado en un
 * caballo esqueleto negro.
 *  - Aparece en las fortalezas del Nether (1 de cada 10 esqueletos wither, dark-rider.fortress-chance) y en el valle de
 *    arena de almas (cada mob que aparece ahí de forma natural tiene un 1% de ser un Jinete Oscuro, dark-rider.soul-sand-valley-chance).
 *  - Al morir a manos de un jugador suelta de 1 a 5 cráneos de esqueleto wither.
 *  - El caballo: el caballo esqueleto no puede llevar armadura y su textura es la misma para todos, así que es un caballo
 *    zombi INVISIBLE con una "armadura" (capa de equipo infernal:dark_rider) que dibuja un caballo esqueleto negro, y una
 *    silla negra propia. No cambia ninguna textura vanilla: los caballos esqueleto y zombi normales se ven como siempre.
 *    Ensillado, lo dirige el jinete (como los jinetes vanilla). Si el jinete muere, el caballo se desvanece.
 *  - Embestida (la hace el plugin: el esqueleto wither no sabe embestir con la lanza en vanilla): montado, cuando su
 *    objetivo está a cierta distancia, el caballo carga en línea recta hacia él con la lanza; si lo alcanza le hace daño
 *    según la velocidad, lo empuja, le pone Wither y lo desmonta. Luego espera un rato antes de volver a embestir.
 *  - Como los jinetes vanilla no desaparecen solos, el plugin los quita si no hay ningún jugador cerca durante un rato.
 */
public final class DarkRiderListener implements Listener {

    private static final TextColor NAME_COLOR = TextColor.color(0x5A1F2E);
    /** Altura libre (bloques) que necesita el jinete montado: caballo + esqueleto wither encima. */
    private static final int MOUNTED_HEIGHT = 4;

    private final JavaPlugin plugin;
    private final NamespacedKey riderKey;
    private final NamespacedKey horseKey;
    private final Map<UUID, Long> lonelySince = new HashMap<>();
    private final Map<UUID, LivingEntity> riders = new HashMap<>();
    private BukkitTask task;
    private long tick;
    /** Embestidas en curso y esperas: UUID del jinete -> estado. */
    private final Map<UUID, Charge> charges = new HashMap<>();

    private static final class Charge {
        LivingEntity target;
        Vector direction;
        int ticksLeft;
        int elapsed;
        long cooldownUntil;
    }

    private final boolean enabled;
    private final double fortressChance;
    private final double soulSandValleyChance;
    private final double riderHealth;
    private final double horseHealth;
    private final double horseSpeed;
    private final int skullsMin;
    private final int skullsMax;
    private final int xp;
    private final float armorDropChance;
    private final float spearDropChance;
    private final int despawnDistance;
    private final int despawnSeconds;
    private final boolean usePack;
    private final boolean chargeEnabled;
    private final double chargeMinDistance;
    private final double chargeMaxDistance;
    private final double chargeSpeed;
    private final double chargeDamage;
    private final int chargeCooldown;
    private final int chargeWitherSeconds;

    public DarkRiderListener(JavaPlugin plugin) {
        this.plugin = plugin;
        this.riderKey = new NamespacedKey(plugin, "dark_rider");
        this.horseKey = new NamespacedKey(plugin, "dark_rider_horse");
        FileConfiguration cfg = plugin.getConfig();
        this.enabled = cfg.getBoolean("dark-rider.enabled", true);
        this.fortressChance = clamp01(cfg.getDouble("dark-rider.fortress-chance", 0.10));
        this.soulSandValleyChance = clamp01(cfg.getDouble("dark-rider.soul-sand-valley-chance", 0.01));
        this.riderHealth = Math.max(1.0, cfg.getDouble("dark-rider.health", 40.0));
        this.horseHealth = Math.max(1.0, cfg.getDouble("dark-rider.horse-health", 30.0));
        this.horseSpeed = Math.max(0.05, cfg.getDouble("dark-rider.horse-speed", 0.3));
        int min = Math.max(0, cfg.getInt("dark-rider.skulls-min", 1));
        this.skullsMin = min;
        this.skullsMax = Math.max(min, cfg.getInt("dark-rider.skulls-max", 5));
        this.xp = Math.max(0, cfg.getInt("dark-rider.xp", 30));
        this.armorDropChance = (float) clamp01(cfg.getDouble("dark-rider.armor-drop-chance", 0.0));
        this.spearDropChance = (float) clamp01(cfg.getDouble("dark-rider.spear-drop-chance", 0.0));
        this.despawnDistance = Math.max(32, cfg.getInt("dark-rider.despawn-distance", 96));
        this.despawnSeconds = Math.max(5, cfg.getInt("dark-rider.despawn-seconds", 60));
        this.usePack = cfg.getBoolean("use-resource-pack", true);
        this.chargeEnabled = cfg.getBoolean("dark-rider.charge.enabled", true);
        this.chargeMinDistance = Math.max(2.0, cfg.getDouble("dark-rider.charge.min-distance", 6.0));
        this.chargeMaxDistance = Math.max(chargeMinDistance, cfg.getDouble("dark-rider.charge.max-distance", 20.0));
        this.chargeSpeed = Math.max(0.2, Math.min(2.0, cfg.getDouble("dark-rider.charge.speed", 0.9)));
        this.chargeDamage = Math.max(0.0, cfg.getDouble("dark-rider.charge.damage", 12.0));
        this.chargeCooldown = Math.max(1, cfg.getInt("dark-rider.charge.cooldown", 6)) * 20;
        this.chargeWitherSeconds = Math.max(0, cfg.getInt("dark-rider.charge.wither-seconds", 10));
    }

    public void start() {
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
        for (World world : plugin.getServer().getWorlds()) {
            for (LivingEntity e : world.getLivingEntities()) {
                if (isRider(e)) riders.put(e.getUniqueId(), e);
            }
        }
    }

    public void stop() {
        if (task != null) task.cancel();
        task = null;
        riders.clear();
        lonelySince.clear();
        charges.clear();
    }

    public boolean isRider(Entity e) {
        return e instanceof WitherSkeleton && e.getPersistentDataContainer().has(riderKey, PersistentDataType.BYTE);
    }

    public boolean isHorse(Entity e) {
        return e instanceof ZombieHorse && e.getPersistentDataContainer().has(horseKey, PersistentDataType.BYTE);
    }

    /** Hace aparecer un Jinete Oscuro (comando /infernal darkrider). */
    public void spawn(Location location) {
        WitherSkeleton rider = location.getWorld().spawn(location, WitherSkeleton.class, this::equipRider);
        plugin.getServer().getScheduler().runTask(plugin, () -> mount(rider));
    }

    // ------------------------------------------------------------------ aparición

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        if (!enabled || event.getSpawnReason() != SpawnReason.NATURAL) return;
        LivingEntity entity = event.getEntity();
        ThreadLocalRandom random = ThreadLocalRandom.current();

        // Fortalezas del Nether: los esqueletos wither solo aparecen de forma natural en ellas.
        if (entity instanceof WitherSkeleton skeleton) {
            if (fortressChance > 0 && random.nextDouble() < fortressChance) {
                equipRider(skeleton);
                plugin.getServer().getScheduler().runTask(plugin, () -> mount(skeleton));
            }
            return;
        }
        // Valle de arena de almas: cualquier mob que aparece ahí de forma natural (esqueletos, ghasts, endermans...).
        if (soulSandValleyChance <= 0 || entity.getType() == EntityType.STRIDER) return;
        Location loc = entity.getLocation();
        if (!Biome.SOUL_SAND_VALLEY.equals(loc.getBlock().getBiome())) return;
        if (random.nextDouble() >= soulSandValleyChance) return;
        if (!hasRoom(loc, 3)) return; // al menos sitio para el esqueleto wither a pie
        event.setCancelled(true);
        Location at = loc.clone();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (at.getWorld() != null && at.isChunkLoaded()) spawn(at);
        });
    }

    /** Esqueleto wither -> Jinete Oscuro: armadura completa de netherite, lanza de netherite con Filo V, nombre y vida. */
    private void equipRider(WitherSkeleton skeleton) {
        skeleton.getPersistentDataContainer().set(riderKey, PersistentDataType.BYTE, (byte) 1);
        skeleton.customName(Component.text("Jinete Oscuro", NAME_COLOR));
        skeleton.setCustomNameVisible(false);
        AttributeInstance health = skeleton.getAttribute(Attribute.MAX_HEALTH);
        if (health != null) health.setBaseValue(riderHealth);
        skeleton.setHealth(riderHealth);
        skeleton.setCanPickupItems(false);

        EntityEquipment eq = skeleton.getEquipment();
        if (eq != null) {
            eq.setHelmet(new ItemStack(Material.NETHERITE_HELMET));
            eq.setChestplate(new ItemStack(Material.NETHERITE_CHESTPLATE));
            eq.setLeggings(new ItemStack(Material.NETHERITE_LEGGINGS));
            eq.setBoots(new ItemStack(Material.NETHERITE_BOOTS));
            ItemStack spear = new ItemStack(Material.NETHERITE_SPEAR);
            spear.addUnsafeEnchantment(Enchantment.SHARPNESS, 5);
            eq.setItemInMainHand(spear);
            eq.setItemInOffHand(null);
            eq.setHelmetDropChance(armorDropChance);
            eq.setChestplateDropChance(armorDropChance);
            eq.setLeggingsDropChance(armorDropChance);
            eq.setBootsDropChance(armorDropChance);
            eq.setItemInMainHandDropChance(spearDropChance);
        }
        riders.put(skeleton.getUniqueId(), skeleton);
    }

    /** Monta al jinete en su caballo esqueleto negro, si hay sitio (si no, va a pie). */
    private void mount(WitherSkeleton rider) {
        if (!rider.isValid() || rider.isDead() || rider.isInsideVehicle()) return;
        Location loc = rider.getLocation();
        if (!hasRoom(loc, MOUNTED_HEIGHT)) return;
        ZombieHorse horse = loc.getWorld().spawn(loc, ZombieHorse.class, h -> {
            h.getPersistentDataContainer().set(horseKey, PersistentDataType.BYTE, (byte) 1);
            h.setAdult();
            h.setTamed(true);
            h.setInvisible(true); // se ve solo la capa del caballo esqueleto negro y la silla
            h.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, PotionEffect.INFINITE_DURATION, 0, false, false));
            AttributeInstance health = h.getAttribute(Attribute.MAX_HEALTH);
            if (health != null) health.setBaseValue(horseHealth);
            h.setHealth(horseHealth);
            AttributeInstance speed = h.getAttribute(Attribute.MOVEMENT_SPEED);
            if (speed != null) speed.setBaseValue(horseSpeed);
            EntityEquipment eq = h.getEquipment();
            if (eq != null) eq.setItem(EquipmentSlot.BODY, look(Material.IRON_HORSE_ARMOR, EquipmentSlot.BODY));
            h.getInventory().setSaddle(look(Material.SADDLE, EquipmentSlot.SADDLE));
        });
        horse.addPassenger(rider);
    }

    /** Objeto de equipo con la capa infernal:dark_rider (caballo esqueleto negro o silla negra). */
    private ItemStack look(Material material, EquipmentSlot slot) {
        ItemStack item = new ItemStack(material);
        if (usePack) {
            item.setData(DataComponentTypes.EQUIPPABLE, Equippable.equippable(slot)
                    .assetId(Key.key(InfernalItems.PACK_NAMESPACE, "dark_rider")).build());
        }
        return item;
    }

    /** ¿Hay suelo y 'height' bloques libres encima? */
    private static boolean hasRoom(Location loc, int height) {
        Block feet = loc.getBlock();
        if (feet.getRelative(0, -1, 0).isPassable()) return false;
        for (int dy = 0; dy < height; dy++) {
            if (!feet.getRelative(0, dy, 0).isPassable()) return false;
        }
        return true;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onAddToWorld(EntityAddToWorldEvent event) {
        if (isRider(event.getEntity())) riders.put(event.getEntity().getUniqueId(), (LivingEntity) event.getEntity());
    }

    // ------------------------------------------------------------------ muerte y botín

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(EntityDeathEvent event) {
        LivingEntity dead = event.getEntity();
        if (isHorse(dead)) {
            // Sin silla ni "armadura" del caballo oscuro.
            event.getDrops().removeIf(i -> i != null && (i.getType() == Material.SADDLE || i.getType() == Material.IRON_HORSE_ARMOR));
            return;
        }
        if (!isRider(dead)) return;
        riders.remove(dead.getUniqueId());
        lonelySince.remove(dead.getUniqueId());
        if (dead.getVehicle() instanceof ZombieHorse horse && isHorse(horse)) vanish(horse);

        event.getDrops().removeIf(i -> i != null && i.getType() == Material.WITHER_SKELETON_SKULL);
        event.setDroppedExp(xp);
        if (dead.getKiller() == null) return; // como los cráneos vanilla: solo si lo mata un jugador
        int amount = skullsMin + ThreadLocalRandom.current().nextInt(skullsMax - skullsMin + 1);
        if (amount > 0) event.getDrops().add(new ItemStack(Material.WITHER_SKELETON_SKULL, amount));
    }

    /** El caballo se desvanece en almas (sin botín). */
    private static void vanish(ZombieHorse horse) {
        Location at = horse.getLocation().add(0, 1, 0);
        horse.getWorld().spawnParticle(Particle.SOUL, at, 20, 0.5, 0.6, 0.5, 0.02);
        horse.getWorld().spawnParticle(Particle.LARGE_SMOKE, at, 10, 0.5, 0.6, 0.5, 0.01);
        horse.eject();
        horse.remove();
    }

    // ------------------------------------------------------------------ embestida

    /** Cada tick: empieza, mueve o termina las embestidas de los jinetes montados. */
    private void chargeTick() {
        if (!chargeEnabled || riders.isEmpty()) return;
        for (LivingEntity entity : riders.values()) {
            if (!(entity instanceof Mob rider) || !rider.isValid() || rider.isDead()) continue;
            Charge c = charges.computeIfAbsent(rider.getUniqueId(), k -> new Charge());
            Entity vehicle = rider.getVehicle();
            if (!(vehicle instanceof ZombieHorse horse) || !isHorse(horse)) {
                c.ticksLeft = 0; // a pie no embiste
                continue;
            }
            if (c.ticksLeft > 0) {
                continueCharge(rider, horse, c);
                continue;
            }
            if (tick < c.cooldownUntil || tick % 5 != 0) continue;
            LivingEntity target = rider.getTarget();
            if (target == null || !target.isValid() || target.isDead() || target.getWorld() != rider.getWorld()) continue;
            if (target instanceof Player p && (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR)) continue;
            double dist = horizontalDistance(horse.getLocation(), target.getLocation());
            if (dist < chargeMinDistance || dist > chargeMaxDistance || !rider.hasLineOfSight(target)) continue;
            startCharge(horse, target, c);
        }
    }

    private void startCharge(ZombieHorse horse, LivingEntity target, Charge c) {
        c.target = target;
        c.direction = flatDirection(horse.getLocation(), target.getLocation());
        c.ticksLeft = 50;
        c.elapsed = 0;
        Location at = horse.getLocation();
        horse.getWorld().playSound(at, Sound.ENTITY_HORSE_ANGRY, 1.2f, 0.6f);
        horse.getWorld().playSound(at, Sound.ENTITY_WITHER_SKELETON_AMBIENT, 1.2f, 0.7f);
    }

    private void continueCharge(Mob rider, ZombieHorse horse, Charge c) {
        LivingEntity target = c.target;
        c.ticksLeft--;
        c.elapsed++;
        if (target == null || !target.isValid() || target.isDead() || target.getWorld() != horse.getWorld()) {
            endCharge(c, chargeCooldown / 2);
            return;
        }
        Location hl = horse.getLocation();
        Location tl = target.getLocation();
        // Corrige poco a poco hacia el objetivo (no gira en seco, como una embestida de verdad).
        Vector wanted = flatDirection(hl, tl);
        c.direction = c.direction.multiply(0.8).add(wanted.multiply(0.2)).normalize();
        Vector vel = horse.getVelocity();
        horse.setVelocity(new Vector(c.direction.getX() * chargeSpeed, vel.getY(), c.direction.getZ() * chargeSpeed));
        if (c.elapsed % 2 == 0) {
            horse.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, hl.clone().add(0, 0.6, 0), 3, 0.3, 0.2, 0.3, 0.01);
        }

        // ¿Lo alcanza? (distancia de la lanza desde el caballo)
        if (horizontalDistance(hl, tl) <= 2.6 && Math.abs(tl.getY() - hl.getY()) <= 3.0) {
            double speed = Math.sqrt(vel.getX() * vel.getX() + vel.getZ() * vel.getZ());
            double factor = Math.max(0.5, Math.min(1.0, speed / chargeSpeed));
            if (chargeDamage > 0) target.damage(chargeDamage * factor, rider);
            if (target.isInsideVehicle()) target.leaveVehicle(); // la embestida desmonta, como la vanilla
            target.setVelocity(c.direction.clone().multiply(1.6 * factor).setY(0.45));
            if (chargeWitherSeconds > 0) {
                target.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, chargeWitherSeconds * 20, 0));
            }
            target.getWorld().playSound(tl, Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.2f, 0.7f);
            target.getWorld().spawnParticle(Particle.SOUL, tl.clone().add(0, 1, 0), 12, 0.4, 0.5, 0.4, 0.02);
            endCharge(c, chargeCooldown);
            return;
        }
        // Se acabó el tiempo, se ha chocado con algo o se ha pasado del objetivo.
        double flatSpeed = Math.sqrt(vel.getX() * vel.getX() + vel.getZ() * vel.getZ());
        boolean stuck = c.elapsed > 6 && flatSpeed < chargeSpeed * 0.25;
        boolean passed = c.elapsed > 6 && wanted.dot(c.direction) < -0.2;
        if (c.ticksLeft <= 0 || stuck || passed) endCharge(c, chargeCooldown);
    }

    private void endCharge(Charge c, int cooldown) {
        c.ticksLeft = 0;
        c.target = null;
        c.cooldownUntil = tick + cooldown;
    }

    private static Vector flatDirection(Location from, Location to) {
        Vector v = new Vector(to.getX() - from.getX(), 0, to.getZ() - from.getZ());
        if (v.lengthSquared() < 1.0E-6) return new Vector(1, 0, 0);
        return v.normalize();
    }

    private static double horizontalDistance(Location a, Location b) {
        double dx = a.getX() - b.getX();
        double dz = a.getZ() - b.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    // ------------------------------------------------------------------ cada tick: embestidas; cada segundo: despawn

    private void tick() {
        tick++;
        chargeTick();
        if (tick % 20 != 0) return;
        charges.keySet().removeIf(id -> !riders.containsKey(id));
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, LivingEntity>> it = riders.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, LivingEntity> entry = it.next();
            LivingEntity rider = entry.getValue();
            if (!rider.isValid() || rider.isDead()) {
                // Descargado con su chunk o muerto (se vuelve a registrar al cargar).
                it.remove();
                lonelySince.remove(entry.getKey());
                continue;
            }
            if (playerNear(rider)) {
                lonelySince.remove(entry.getKey());
                continue;
            }
            long since = lonelySince.computeIfAbsent(entry.getKey(), k -> now);
            if (now - since >= despawnSeconds * 1000L) {
                Entity vehicle = rider.getVehicle();
                if (vehicle != null && isHorse(vehicle)) vehicle.remove();
                rider.remove();
                it.remove();
                lonelySince.remove(entry.getKey());
            }
        }
        // Caballos oscuros que se han quedado sin jinete (jinete quitado por otra cosa): se desvanecen.
        for (World world : plugin.getServer().getWorlds()) {
            for (ZombieHorse horse : world.getEntitiesByClass(ZombieHorse.class)) {
                if (isHorse(horse) && horse.getPassengers().isEmpty()) vanish(horse);
            }
        }
    }

    private boolean playerNear(LivingEntity rider) {
        double max = (double) despawnDistance * despawnDistance;
        Location loc = rider.getLocation();
        for (Player p : rider.getWorld().getPlayers()) {
            if (p.getLocation().distanceSquared(loc) <= max) return true;
        }
        return false;
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }
}
