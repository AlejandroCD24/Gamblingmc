package dev.infernal.armor;

import dev.infernal.armor.InfernalItems.Kind;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * La Plantilla Infernal solo sale en los cofres de los bastiones (no se craftea): como la plantilla de mejora de netherite
 * vanilla, siempre en el cofre del tesoro (bastion-loot.treasure-chance) y a veces en los demás cofres del bastión
 * (bastion-loot.other-chance). Vale también para los bastiones ya generados cuyos cofres no se han abierto.
 */
public final class BastionLootListener implements Listener {

    private final InfernalItems items;
    private final double treasureChance;
    private final double otherChance;

    public BastionLootListener(JavaPlugin plugin, InfernalItems items) {
        this.items = items;
        FileConfiguration cfg = plugin.getConfig();
        this.treasureChance = clamp01(cfg.getDouble("bastion-loot.treasure-chance", 1.0));
        this.otherChance = clamp01(cfg.getDouble("bastion-loot.other-chance", 0.10));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onLoot(LootGenerateEvent event) {
        String table = event.getLootTable().getKey().getKey(); // p. ej. "chests/bastion_treasure"
        double chance;
        if (table.equals("chests/bastion_treasure")) {
            chance = treasureChance;
        } else if (table.equals("chests/bastion_other") || table.equals("chests/bastion_bridge")
                || table.equals("chests/bastion_hoglin_stable")) {
            chance = otherChance;
        } else {
            return;
        }
        if (chance <= 0 || ThreadLocalRandom.current().nextDouble() >= chance) return;
        List<ItemStack> loot = new ArrayList<>(event.getLoot());
        loot.add(items.create(Kind.TEMPLATE));
        event.setLoot(loot);
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }
}
