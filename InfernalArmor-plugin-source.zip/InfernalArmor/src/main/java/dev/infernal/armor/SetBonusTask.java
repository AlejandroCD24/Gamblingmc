package dev.infernal.armor;

import dev.infernal.armor.InfernalItems.ArmorSet;
import dev.infernal.armor.InfernalItems.SetBonus;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Efectos del set completo (la infernal no da efectos: su bono es -15% de daño de fuego y lava): Resistencia (celestial: nivel de resistance-level; Vacío y Fin:
 * nivel II) y Regeneración II (solo Vacío y Fin). Se refrescan cada segundo y se retiran al quitarse una pieza o cambiar de set.
 */
public final class SetBonusTask extends BukkitRunnable {

    /** Duración con la que se aplican los efectos (ticks). */
    private static final int DURATION = 200;
    /** Se vuelven a aplicar cuando quedan menos de estos ticks. Así la Regeneración conserva su ritmo normal (1 vida cada 25 ticks en el nivel II). */
    private static final int REFRESH_BELOW = 100;

    private final InfernalItems items;
    /** Bono que aplicó este task a cada jugador (para retirarlo al perder el set sin tocar efectos de pociones o balizas). */
    private final Map<UUID, SetBonus> applied = new HashMap<>();

    public SetBonusTask(InfernalItems items) {
        this.items = items;
    }

    @Override
    public void run() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID id = player.getUniqueId();
            ArmorSet set = items.fullSet(player);
            SetBonus bonus = set == null ? null : items.setBonus(set);

            SetBonus previous = applied.get(id);
            if (previous != null && !previous.equals(bonus)) {
                if (previous.resistance() >= 0) remove(player, PotionEffectType.RESISTANCE, previous.resistance());
                if (previous.regeneration() >= 0) remove(player, PotionEffectType.REGENERATION, previous.regeneration());
                if (previous.fireResistance()) remove(player, PotionEffectType.FIRE_RESISTANCE, 0);
                applied.remove(id);
            }

            if (bonus != null) {
                applied.put(id, bonus);
                if (bonus.resistance() >= 0) refresh(player, PotionEffectType.RESISTANCE, bonus.resistance());
                if (bonus.regeneration() >= 0) refresh(player, PotionEffectType.REGENERATION, bonus.regeneration());
                if (bonus.fireResistance()) refresh(player, PotionEffectType.FIRE_RESISTANCE, 0);
            }
        }
        applied.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);
    }

    /** Aplica el efecto sin pisar uno mejor (poción, baliza...) ni acortar uno más largo del mismo nivel. */
    private static void refresh(Player player, PotionEffectType type, int amplifier) {
        PotionEffect current = player.getPotionEffect(type);
        boolean needsRefresh = current == null
                || current.getAmplifier() < amplifier
                || (current.getAmplifier() == amplifier && current.getDuration() < REFRESH_BELOW);
        if (needsRefresh) {
            player.addPotionEffect(new PotionEffect(type, DURATION, amplifier, false, false, true));
        }
    }

    /** Retira el efecto solo si es el que puso el set (mismo nivel y no más largo que lo que se aplica). */
    private static void remove(Player player, PotionEffectType type, int amplifier) {
        PotionEffect current = player.getPotionEffect(type);
        if (current != null && current.getAmplifier() == amplifier && current.getDuration() <= DURATION) {
            player.removePotionEffect(type);
        }
    }
}
