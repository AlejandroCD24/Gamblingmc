package dev.infernal.armor;

import dev.infernal.armor.InfernalItems.Kind;
import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.datacomponent.item.ItemLore;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Keyed;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Lidded;
import org.bukkit.block.ShulkerBox;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Caja de Shulker Reforzada: una caja de shulker portátil con el DOBLE de espacio (54 ranuras en vez de 27).
 *
 *  - Como objeto: click derecho con ella en el AIRE abre su inventario. El contenido se guarda dentro del propio objeto (PDC),
 *    así que viaja con ella: cofres, otro jugador, muerte...
 *  - Como bloque: se coloca y se rompe como una caja de shulker normal (del color que tenga). El bloque es una caja de shulker
 *    de verdad (con su tapa que se abre y se cierra) pero su contenido (54 ranuras) se guarda en los datos del bloque (PDC),
 *    y al romperlo suelta la caja reforzada con todo dentro. Click derecho en el bloque abre el inventario, que comparten
 *    todos los jugadores que la tengan abierta. Tolvas y dispensadores no pueden meter ni sacar objetos, los pistones no la
 *    mueven (los vanilla la destruirían) y las explosiones la sueltan con su contenido.
 *  - Mientras está abierta no se puede mover ni tirar ninguna caja reforzada, y no se pueden meter cajas de shulker
 *    dentro (igual que en vanilla), para evitar duplicados y recursión.
 *  - Una caja VACÍA queda idéntica a una recién hecha (sin datos guardados), así que se puede usar en las recetas
 *    de las plantillas del Vacío y del Fin; una con objetos no coincide con la receta y no se puede gastar por error.
 *  - Al craftearla con una caja de shulker normal que tenga objetos, estos pasan a la nueva caja reforzada.
 *  - Se tiñe como una caja de shulker normal: caja reforzada + un tinte en la cuadrícula de crafteo (con contenido y nombre
 *    incluidos). Los colores son solo estéticos: todas son la misma caja y valen en las recetas de las plantillas.
 */
public final class ReinforcedShulkerListener implements Listener {

    /** Ranuras de la caja reforzada (el doble de una caja de shulker normal: 27 x 2). */
    public static final int SIZE = 54;

    private static final TextColor TITLE_COLOR = TextColor.color(0xC44DFF);
    /** Cuántos objetos se enseñan en la descripción de la caja (igual que el tooltip de la caja de shulker vanilla). */
    private static final int PREVIEW = 5;

    private final InfernalItems items;
    /** Identificador único de la caja (se genera al abrirla por primera vez con objetos). */
    private final NamespacedKey idKey;
    /** Contenido serializado de la caja. */
    private final NamespacedKey contentsKey;
    /** Receta de crafteo de la caja (para pasar el contenido de la caja de shulker normal). */
    private final NamespacedKey recipeKey;
    /** Marca en los datos del bloque: esta caja de shulker colocada es una caja reforzada. */
    private final NamespacedKey placedKey;
    /** Cajas colocadas que están abiertas ahora mismo (un inventario compartido por posición). */
    private final Map<Pos, Inventory> openBlocks = new HashMap<>();

    public ReinforcedShulkerListener(JavaPlugin plugin, InfernalItems items) {
        this.items = items;
        this.idKey = new NamespacedKey(plugin, "box_id");
        this.contentsKey = new NamespacedKey(plugin, "box_contents");
        this.recipeKey = new NamespacedKey(plugin, "reinforced_shulker_box");
        this.placedKey = new NamespacedKey(plugin, "placed_box");
    }

    /** Holder propio: sirve para reconocer el inventario de la caja y saber qué caja es. */
    private static final class BoxHolder implements InventoryHolder {
        /** Identificador de la caja que lleva el jugador (null si es una caja colocada como bloque). */
        private final String boxId;
        /** Posición de la caja colocada como bloque (null si es una caja que lleva el jugador). */
        private final Pos pos;
        private Inventory inventory;

        private BoxHolder(String boxId, Pos pos) {
            this.boxId = boxId;
            this.pos = pos;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    /** Posición de un bloque (para reconocer una caja colocada aunque el chunk se descargue). */
    private record Pos(UUID world, int x, int y, int z) {
        static Pos of(Block block) {
            return new Pos(block.getWorld().getUID(), block.getX(), block.getY(), block.getZ());
        }

        Block block() {
            World w = Bukkit.getWorld(world);
            return w == null ? null : w.getBlockAt(x, y, z);
        }

        Location center() {
            World w = Bukkit.getWorld(world);
            return w == null ? null : new Location(w, x + 0.5, y + 0.5, z + 0.5);
        }
    }

    // ------------------------------------------------------------------------------ abrir

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        // Solo en el aire: sobre un bloque, la caja se coloca como una caja de shulker normal (o se usa el bloque).
        if (event.getAction() != Action.RIGHT_CLICK_AIR) return;
        if (!isBox(event.getItem())) return;
        EquipmentSlot hand = event.getHand();
        if (hand == null) return;

        event.setCancelled(true);
        open(event.getPlayer(), hand);
    }

    private void open(Player player, EquipmentSlot hand) {
        if (isBoxInventory(player.getOpenInventory().getTopInventory())) return; // ya hay una abierta

        PlayerInventory inv = player.getInventory();
        ItemStack stack = inv.getItem(hand);
        if (!isBox(stack)) return;

        String id = stack.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
        byte[] data = stack.getItemMeta().getPersistentDataContainer().get(contentsKey, PersistentDataType.BYTE_ARRAY);
        if (id == null) id = UUID.randomUUID().toString();
        final String boxId = id;
        stack.editMeta(meta -> meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, boxId));
        inv.setItem(hand, stack);

        BoxHolder holder = new BoxHolder(boxId, null);
        Inventory box = Bukkit.createInventory(holder, SIZE, Component.text("Caja de Shulker Reforzada", TITLE_COLOR));
        holder.inventory = box;
        if (data != null) {
            ItemStack[] saved = ItemStack.deserializeItemsFromBytes(data);
            for (int i = 0; i < Math.min(saved.length, SIZE); i++) {
                ItemStack item = saved[i];
                if (item != null && !item.getType().isAir()) box.setItem(i, item);
            }
        }
        player.openInventory(box);
        player.playSound(player.getLocation(), Sound.BLOCK_SHULKER_BOX_OPEN, 1.0f, 1.0f);
    }

    // ------------------------------------------------------------------------------ guardar

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder(false) instanceof BoxHolder holder)) return;
        if (!(event.getPlayer() instanceof Player player)) return;
        if (holder.pos != null) {
            closePlaced(holder);
            return;
        }
        save(player, holder);
        player.playSound(player.getLocation(), Sound.BLOCK_SHULKER_BOX_CLOSE, 1.0f, 1.0f);
    }

    /** Guarda el contenido en la caja del jugador que tiene ese identificador (o lo suelta si ya no la tiene). */
    private void save(Player player, BoxHolder holder) {
        ItemStack[] contents = holder.getInventory().getContents();
        boolean empty = true;
        for (ItemStack item : contents) {
            if (item != null && !item.getType().isAir()) {
                empty = false;
                break;
            }
        }

        PlayerInventory inv = player.getInventory();
        ItemStack[] all = inv.getContents();
        for (int slot = 0; slot < all.length; slot++) {
            ItemStack stack = all[slot];
            if (!isBox(stack)) continue;
            String id = stack.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
            if (!holder.boxId.equals(id)) continue;

            if (empty) {
                // Vuelve a quedar idéntica a una caja nueva (sirve en las recetas y apila igual que las demás).
                stack.editMeta(meta -> {
                    meta.getPersistentDataContainer().remove(idKey);
                    meta.getPersistentDataContainer().remove(contentsKey);
                });
            } else {
                byte[] bytes = serialize(contents);
                stack.editMeta(meta -> meta.getPersistentDataContainer().set(contentsKey, PersistentDataType.BYTE_ARRAY, bytes));
            }
            applyPreview(stack, contents); // vacía = descripción original (idéntica a una caja nueva)
            inv.setItem(slot, stack);
            return;
        }

        // La caja ya no está en el inventario (muerte, etc.): para no perder nada, el contenido se suelta.
        for (ItemStack item : contents) {
            if (item != null && !item.getType().isAir()) {
                player.getWorld().dropItemNaturally(player.getLocation(), item);
            }
        }
    }

    /** Cierra las cajas abiertas (guardando su contenido). Se llama al apagar el plugin. */
    public void closeAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (isBoxInventory(player.getOpenInventory().getTopInventory())) player.closeInventory();
        }
    }

    private static byte[] serialize(ItemStack[] contents) {
        ItemStack[] out = new ItemStack[contents.length];
        for (int i = 0; i < contents.length; i++) {
            out[i] = contents[i] == null ? new ItemStack(Material.AIR) : contents[i];
        }
        return ItemStack.serializeItemsAsBytes(out);
    }

    // ------------------------------------------------------------------------------ protecciones

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!isBoxInventory(top)) return;

        // Mientras hay una caja del inventario abierta, ninguna caja reforzada se mueve (ni la que se está usando).
        boolean carried = isItemBoxInventory(top);
        if (carried && (isBox(event.getCurrentItem()) || isBox(event.getCursor()))) {
            event.setCancelled(true);
            return;
        }
        ClickType click = event.getClick();
        ItemStack hotbar = click == ClickType.NUMBER_KEY
                ? event.getWhoClicked().getInventory().getItem(event.getHotbarButton()) : null;
        ItemStack offhand = click == ClickType.SWAP_OFFHAND
                ? event.getWhoClicked().getInventory().getItemInOffHand() : null;
        if (carried && (isBox(hotbar) || isBox(offhand))) {
            event.setCancelled(true);
            return;
        }

        // No se pueden meter cajas de shulker dentro de la caja (igual que en vanilla).
        ItemStack entering = null;
        if (click.isShiftClick()) {
            if (event.getClickedInventory() != top) entering = event.getCurrentItem();
        } else if (event.getClickedInventory() == top) {
            if (click == ClickType.NUMBER_KEY) entering = hotbar;
            else if (click == ClickType.SWAP_OFFHAND) entering = offhand;
            else entering = event.getCursor();
        }
        if (isShulkerBox(entering)) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!isBoxInventory(top) || !isShulkerBox(event.getOldCursor())) return;
        for (int slot : event.getRawSlots()) {
            if (slot < top.getSize()) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        if (isItemBoxInventory(event.getPlayer().getOpenInventory().getTopInventory())
                && isBox(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (isItemBoxInventory(player.getOpenInventory().getTopInventory())
                && (isBox(event.getMainHandItem()) || isBox(event.getOffHandItem()))) {
            event.setCancelled(true);
        }
    }

    /** Un dispensador colocaría la caja como una caja de shulker normal sin guardar el contenido: no se permite. */
    @EventHandler(ignoreCancelled = true)
    public void onDispense(BlockDispenseEvent event) {
        if (isBox(event.getItem())) event.setCancelled(true);
    }

    // ------------------------------------------------------------------------------ crafteo

    /** Al hacer la caja reforzada con una caja de shulker normal con objetos, el contenido pasa a la nueva caja. */
    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        Recipe recipe = event.getRecipe();
        if (!(recipe instanceof Keyed keyed) || !keyed.getKey().equals(recipeKey)) return;

        ItemStack[] matrix = event.getInventory().getMatrix();
        if (matrix.length < 9) return;
        ItemStack center = matrix[4];
        if (center == null || center.getType() != Material.SHULKER_BOX) return;
        if (!(center.getItemMeta() instanceof BlockStateMeta meta) || !(meta.getBlockState() instanceof ShulkerBox shulker)) return;

        ItemStack[] old = shulker.getInventory().getContents();
        boolean any = false;
        for (ItemStack item : old) {
            if (item != null && !item.getType().isAir()) {
                any = true;
                break;
            }
        }
        if (!any) return;

        ItemStack result = event.getInventory().getResult();
        if (result == null || !isBox(result)) return;
        byte[] bytes = serialize(old);
        String id = UUID.randomUUID().toString();
        result.editMeta(m -> {
            m.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, id);
            m.getPersistentDataContainer().set(contentsKey, PersistentDataType.BYTE_ARRAY, bytes);
        });
        applyPreview(result, old);
        event.getInventory().setResult(result);
    }

    /**
     * Teñir la caja reforzada: caja reforzada + un tinte (sin nada más) en la cuadrícula, igual que una caja de shulker normal.
     * Cambia solo el material (color): contenido, nombre y demás datos se conservan. ProtectionListener bloquea las recetas
     * vanilla con ingredientes infernales, así que el resultado se calcula aquí (prioridad alta para ir después).
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onPrepareDye(PrepareItemCraftEvent event) {
        ItemStack box = null;
        Material target = null;
        int count = 0;
        for (ItemStack stack : event.getInventory().getMatrix()) {
            if (stack == null || stack.getType().isAir()) continue;
            count++;
            if (isBox(stack)) {
                if (box != null) return;
                box = stack;
            } else {
                Material color = boxOfDye(stack.getType());
                if (color == null || target != null) return;
                target = color;
            }
        }
        if (count != 2 || box == null || target == null) return;
        if (box.getType() == target) return; // ya tiene ese color (igual que en vanilla)

        ItemStack result = box.clone();
        result.setAmount(1);
        result.setType(target);
        if (!isBox(result)) return; // por seguridad: si el cambio de material perdiera los datos, no se da nada
        event.getInventory().setResult(result);
    }

    /** Caja de shulker del color de un tinte (null si el objeto no es un tinte). */
    private static Material boxOfDye(Material dye) {
        String name = dye.name();
        if (!name.endsWith("_DYE")) return null;
        return Material.getMaterial(name.substring(0, name.length() - "_DYE".length()) + "_SHULKER_BOX");
    }

    // ------------------------------------------------------------------------------ caja colocada como bloque

    /** Al colocarla, el bloque (una caja de shulker normal) se marca como caja reforzada y recibe el contenido de la caja. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        ItemStack inHand = event.getItemInHand();
        if (!isBox(inHand)) return;
        if (!(event.getBlockPlaced().getState() instanceof ShulkerBox shulker)) return;

        PersistentDataContainer pdc = shulker.getPersistentDataContainer();
        pdc.set(placedKey, PersistentDataType.BYTE, (byte) 1);
        byte[] data = inHand.getItemMeta().getPersistentDataContainer().get(contentsKey, PersistentDataType.BYTE_ARRAY);
        if (data != null) pdc.set(contentsKey, PersistentDataType.BYTE_ARRAY, data);
        shulker.update();
    }

    /** Click derecho en una caja reforzada colocada: abre el inventario de 54 ranuras (y la tapa) en vez del de la caja normal. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onOpenPlaced(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null || !isPlaced(block)) return;

        Player player = event.getPlayer();
        // Igual que en vanilla: agachado y con algo en la mano se usa el objeto (p. ej. para colocar bloques), no la caja.
        if (player.isSneaking() && (!player.getInventory().getItemInMainHand().getType().isAir()
                || !player.getInventory().getItemInOffHand().getType().isAir())) {
            return;
        }

        event.setCancelled(true); // no se abre la caja de shulker normal (vacía), ni con la mano principal ni con la secundaria
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (isBoxInventory(player.getOpenInventory().getTopInventory())) return;
        if (!canOpenLid(block)) return; // algo tapa la caja (igual que en vanilla)
        if (!(block.getState(false) instanceof ShulkerBox shulker)) return;

        Pos pos = Pos.of(block);
        Inventory box = openBlocks.get(pos);
        if (box == null) {
            BoxHolder holder = new BoxHolder(null, pos);
            Component name = shulker.customName();
            box = Bukkit.createInventory(holder, SIZE,
                    name != null ? name : Component.text("Caja de Shulker Reforzada", TITLE_COLOR));
            holder.inventory = box;
            byte[] data = shulker.getPersistentDataContainer().get(contentsKey, PersistentDataType.BYTE_ARRAY);
            if (data != null) {
                ItemStack[] saved = ItemStack.deserializeItemsFromBytes(data);
                for (int i = 0; i < Math.min(saved.length, SIZE); i++) {
                    ItemStack item = saved[i];
                    if (item != null && !item.getType().isAir()) box.setItem(i, item);
                }
            }
            openBlocks.put(pos, box);
            setLid(block, true);
        }
        player.openInventory(box);
    }

    /** Cierra la caja colocada: guarda el contenido en el bloque y cierra la tapa cuando ya no queda nadie mirándola. */
    private void closePlaced(BoxHolder holder) {
        Inventory inventory = holder.getInventory();
        boolean last = inventory.getViewers().size() <= 1; // el que cierra aún cuenta
        Block block = holder.pos.block();
        if (block != null && isPlaced(block)) {
            saveToBlock(block, inventory.getContents());
            if (last) setLid(block, false);
        } else if (last) {
            // La caja ya no está (se rompió mientras estaba abierta): para no perder nada, el contenido se suelta.
            Location where = holder.pos.center();
            if (where != null) {
                for (ItemStack item : inventory.getContents()) {
                    if (item != null && !item.getType().isAir()) where.getWorld().dropItemNaturally(where, item);
                }
            }
        }
        if (last) openBlocks.remove(holder.pos);
    }

    private void saveToBlock(Block block, ItemStack[] contents) {
        if (!(block.getState() instanceof ShulkerBox shulker)) return;
        PersistentDataContainer pdc = shulker.getPersistentDataContainer();
        if (isEmpty(contents)) {
            pdc.remove(contentsKey);
        } else {
            pdc.set(contentsKey, PersistentDataType.BYTE_ARRAY, serialize(contents));
        }
        shulker.update();
    }

    /** Igual que en vanilla, la caja no se abre si hay un bloque sólido justo delante de su tapa. */
    private static boolean canOpenLid(Block block) {
        if (!(block.getBlockData() instanceof Directional directional)) return true;
        return block.getRelative(directional.getFacing()).isPassable();
    }

    /** Abre o cierra la tapa (animación y sonido de la caja de shulker). */
    private static void setLid(Block block, boolean open) {
        if (!(block.getState(false) instanceof Lidded lidded)) return;
        if (open) lidded.open();
        else lidded.close();
    }

    /** Cierra la caja a todos los que la tienen abierta (así el contenido queda guardado en el bloque antes de romperlo). */
    private void closeViewers(Block block) {
        Inventory open = openBlocks.get(Pos.of(block));
        if (open == null) return;
        for (HumanEntity viewer : new ArrayList<>(open.getViewers())) viewer.closeInventory();
    }

    /** La caja reforzada (con su contenido y su nombre) que corresponde a una caja colocada. */
    private ItemStack itemFrom(ShulkerBox shulker) {
        PersistentDataContainer pdc = shulker.getPersistentDataContainer();
        if (!pdc.has(placedKey, PersistentDataType.BYTE)) return null;
        ItemStack item = items.reinforcedShulker(shulker.getType());
        byte[] data = pdc.get(contentsKey, PersistentDataType.BYTE_ARRAY);
        if (data != null) {
            item.editMeta(meta -> meta.getPersistentDataContainer().set(contentsKey, PersistentDataType.BYTE_ARRAY, data));
            applyPreview(item, ItemStack.deserializeItemsFromBytes(data));
        }
        Component name = shulker.customName();
        if (name != null) item.setData(DataComponentTypes.CUSTOM_NAME, name);
        return item;
    }

    private static void drop(Block block, ItemStack item) {
        block.getWorld().dropItemNaturally(block.getLocation().add(0.5, 0.5, 0.5), item);
    }

    /** Al romperla se suelta la caja reforzada con todo lo que tenga dentro (en vez de una caja de shulker normal vacía). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (!isPlaced(block)) return;
        closeViewers(block);
        if (!(block.getState(false) instanceof ShulkerBox shulker)) return;
        ItemStack item = itemFrom(shulker);
        if (item == null) return;

        boolean dropsEnabled = event.isDropItems();
        event.setDropItems(false); // si no, vanilla soltaría una caja de shulker normal vacía
        if (!dropsEnabled) return;
        // Igual que en vanilla: en creativo solo se suelta si tiene objetos dentro.
        boolean hasContents = item.getItemMeta().getPersistentDataContainer().has(contentsKey, PersistentDataType.BYTE_ARRAY);
        if (event.getPlayer().getGameMode() == GameMode.CREATIVE && !hasContents) return;
        drop(block, item);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        dropFromExplosion(event.blockList());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        dropFromExplosion(event.blockList());
    }

    /** Las cajas reforzadas que revienta una explosión se sueltan con su contenido (para no perder nada). */
    private void dropFromExplosion(List<Block> blocks) {
        for (Iterator<Block> it = blocks.iterator(); it.hasNext(); ) {
            Block block = it.next();
            if (!isPlaced(block)) continue;
            closeViewers(block);
            if (!(block.getState(false) instanceof ShulkerBox shulker)) continue;
            ItemStack item = itemFrom(shulker);
            if (item == null) continue;
            it.remove(); // vanilla soltaría una caja normal vacía
            block.setType(Material.AIR);
            drop(block, item);
        }
    }

    /** Los pistones vanilla destruyen las cajas de shulker: con esta se perdería el contenido, así que no la mueven. */
    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent event) {
        if (anyPlaced(event.getBlocks())) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent event) {
        if (anyPlaced(event.getBlocks())) event.setCancelled(true);
    }

    /** Endermen, wither, etc. romperían la caja soltando una caja normal vacía: no pueden. */
    @EventHandler(ignoreCancelled = true)
    public void onEntityChangeBlock(EntityChangeBlockEvent event) {
        if (isPlaced(event.getBlock())) event.setCancelled(true);
    }

    /** Tolvas, dispensadores y cuentagotas meterían objetos en el inventario real (vacío) de la caja, donde nadie los vería. */
    @EventHandler(ignoreCancelled = true)
    public void onMoveItem(InventoryMoveItemEvent event) {
        if (isPlacedInventory(event.getDestination()) || isPlacedInventory(event.getSource())) {
            event.setCancelled(true);
        }
    }

    private boolean isPlacedInventory(Inventory inventory) {
        return inventory.getType() == InventoryType.SHULKER_BOX
                && inventory.getHolder(false) instanceof ShulkerBox shulker && isPlacedBox(shulker);
    }

    private boolean anyPlaced(List<Block> blocks) {
        for (Block block : blocks) {
            if (isPlaced(block)) return true;
        }
        return false;
    }

    /** ¿Este bloque es una caja reforzada colocada? */
    private boolean isPlaced(Block block) {
        return isShulkerMaterial(block.getType())
                && block.getState(false) instanceof ShulkerBox shulker && isPlacedBox(shulker);
    }

    private boolean isPlacedBox(ShulkerBox shulker) {
        return shulker.getPersistentDataContainer().has(placedKey, PersistentDataType.BYTE);
    }

    // ------------------------------------------------------------------------------ helpers

    private boolean isBox(ItemStack item) {
        return items.kindOf(item) == Kind.REINFORCED_SHULKER;
    }

    /** Inventario de cualquier caja reforzada abierta (la que lleva el jugador o una colocada). */
    private static boolean isBoxInventory(Inventory inventory) {
        return inventory != null && inventory.getHolder(false) instanceof BoxHolder;
    }

    /** Inventario de una caja reforzada que lleva el jugador (no una colocada como bloque). */
    private static boolean isItemBoxInventory(Inventory inventory) {
        return inventory != null && inventory.getHolder(false) instanceof BoxHolder holder && holder.pos == null;
    }

    /**
     * Pone en la descripción de la caja los primeros {@value #PREVIEW} objetos que tiene dentro (y "y N más..." si hay más),
     * como el tooltip de la caja de shulker vanilla. Es solo texto: el contenido real se guarda aparte y esto no lo toca.
     * Con la caja vacía la descripción queda exactamente como la de una caja nueva (necesario para las recetas).
     */
    private void applyPreview(ItemStack box, ItemStack[] contents) {
        ItemLore base = items.reinforcedShulker(box.getType()).getData(DataComponentTypes.LORE);
        ItemLore.Builder lore = ItemLore.lore();
        if (base != null) lore.addLines(base.lines());

        int shown = 0;
        int total = 0;
        for (ItemStack item : contents) {
            if (item == null || item.getType().isAir()) continue;
            total++;
            if (shown < PREVIEW) {
                shown++;
                lore.addLine(previewLine(item));
            }
        }
        if (total > shown) {
            lore.addLine(Component.text("y " + (total - shown) + " más...", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, true));
        }
        box.setData(DataComponentTypes.LORE, lore.build());
    }

    /** "Nombre x3": el nombre se traduce al idioma de cada jugador. */
    private static Component previewLine(ItemStack item) {
        Component name = item.getData(DataComponentTypes.CUSTOM_NAME);
        if (name == null) name = item.getData(DataComponentTypes.ITEM_NAME);
        if (name == null) name = Component.translatable(item.getType().translationKey());
        return Component.text()
                .color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)
                .append(name)
                .append(Component.text(" x" + item.getAmount()))
                .build();
    }

    private static boolean isEmpty(ItemStack[] contents) {
        for (ItemStack item : contents) {
            if (item != null && !item.getType().isAir()) return false;
        }
        return true;
    }

    private static boolean isShulkerMaterial(Material material) {
        return material.name().endsWith("SHULKER_BOX");
    }

    /** Cualquier caja de shulker (normal, teñida o reforzada). */
    private static boolean isShulkerBox(ItemStack item) {
        return item != null && item.getType().name().endsWith("SHULKER_BOX");
    }
}
