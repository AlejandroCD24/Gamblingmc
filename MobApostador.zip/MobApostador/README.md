# MobApostador 🎰

Plugin para servidores **Spigot / Paper** (Minecraft 1.21 y 26.x) que agrega un **mob apostador**: el jugador le da clic derecho, paga la apuesta, gira una ruleta y gana un ítem aleatorio de las categorías del creativo **Herramientas y utilidades, Combate, Comida y bebida e Ingredientes**.

- 6 rarezas con su propia probabilidad: **Común 49.98% · Poco común 28% · Raro 14% · Épico 6.5% · Legendario 1.5% · Mítico 0.02%**
- 377 premios, cada uno con su **peso** dentro de su rareza (probabilidad individual)
- Los ítems comunes salen en **más cantidad** (p. ej. palos 8-32, flechas 8-32, pan 2-8); los raros, épicos y legendarios casi siempre salen de 1 en 1
- Ruleta animada en un cofre que se va frenando, con sonidos; el marco toma el color de la rareza ganada
- Raro y superior: título en pantalla. Épico, Legendario y Mítico: anuncio a todo el servidor. Legendario y Mítico: fuegos artificiales (sin daño)
- **Mítico** es una rareza solo para los **élitros**: 0.02% (1 de cada 5,000 giros), el premio más difícil de todos
- El nombre del ítem aparece **en el idioma del jugador** (si su Minecraft está en español, lo ve en español)
- **Apuestas x1, x5 y x10**: al darle clic al mob se abre un menú para elegir; x5 y x10 usan una ruleta especial donde cada premio se revela uno por uno
- **Legendario garantizado cada 667 giros**: cada jugador tiene su contador (se guarda aunque se desconecte o se reinicie el servidor)
- Costo configurable: ítems (5 esmeraldas por apuesta), dinero con Vault, o gratis; descuento opcional para x5/x10
- Todo se edita en `config.yml` y `premios.yml` sin tocar código

La tabla completa de probabilidades está en [PROBABILIDADES.md](PROBABILIDADES.md).

---

## 1. Compilar el .jar

No pude compilarlo en mi entorno porque no tenía acceso a internet para descargar la API de Spigot, así que tienes que compilarlo tú. Hay dos formas:

### Opción A: con GitHub, sin instalar nada (sirve hasta desde el celular)
1. Crea un repositorio en GitHub y sube **todo** el contenido de esta carpeta (incluida la carpeta `.github`).
2. Ve a la pestaña **Actions**. La compilación empieza sola con cada subida.
   - Para elegir otra versión de Minecraft: **Actions → Compilar plugin → Run workflow** y escribe la versión (ver tabla abajo).
3. Cuando termine (✔ verde), entra a la ejecución y descarga el artefacto **MobApostador** (es un .zip que contiene el .jar).

### Opción B: en tu computadora
Necesitas **JDK 25** (para Minecraft 26.x) o **JDK 21** (para 1.21.x) y **Maven**.
```bash
mvn package
# o para otra versión:
mvn package -Dspigot.version=1.21.11-R0.1-SNAPSHOT
```
El plugin queda en `target/MobApostador-1.0.0.jar`.

| Tu servidor | `spigot.version` | JDK para compilar |
|---|---|---|
| 26.3 | `26.3-R0.1-SNAPSHOT` (por defecto) | 25 |
| 26.1 / 26.2 | `26.1-R0.1-SNAPSHOT` / `26.2-R0.1-SNAPSHOT` | 25 |
| 1.21.x | `1.21.11-R0.1-SNAPSHOT` (o la tuya) | 21 |

Compila con la versión de tu servidor para evitar sorpresas.

## 2. Instalar
1. Copia el `.jar` en la carpeta `plugins/` del servidor y reinícialo.
2. Se crean `plugins/MobApostador/config.yml` y `premios.yml`.
3. (Opcional) Si quieres cobrar con dinero, instala **Vault** + un plugin de economía (EssentialsX, CMI…) y pon `tipo-costo: DINERO`.

## 3. Uso
1. Como OP, mira el bloque donde lo quieres y escribe **`/apostador crear`**.
2. Los jugadores le dan **clic derecho** al mob → eligen **x1, x5 o x10** en el menú → pagan → gira la ruleta → reciben los premios.
3. Si le pegan, les dice cuánto cuesta. No se puede matar, no se mueve, no comercia, no se quema y no desaparece.

### Comandos
| Comando | Qué hace | Permiso |
|---|---|---|
| `/apostador crear` | Aparece el mob donde estás mirando | `apostador.admin` |
| `/apostador eliminar` | Quita el apostador más cercano (6 bloques) | `apostador.admin` |
| `/apostador eliminar todos` | Quita todos los apostadores cargados | `apostador.admin` |
| `/apostador probabilidades [rareza] [página]` | Muestra los porcentajes reales | todos |
| `/apostador garantia` | Muestra cuántos giros te faltan para el Legendario garantizado | todos |
| `/apostador garantia <jugador> [giros]` | Ver o ajustar el contador de otro jugador (útil para probar) | `apostador.admin` |
| `/apostador simular [n]` | Hace n tiradas de prueba y compara con lo esperado | `apostador.admin` |
| `/apostador recargar` | Relee `config.yml` y `premios.yml` | `apostador.admin` |
| `/apostar` | Abre el menú de apuestas sin ir al mob (se puede desactivar) | `apostador.apostar` |
| `/apostar 5` · `/apostar 10` | Apuesta x5 o x10 directo, sin menú | `apostador.apostar` |

Alias: `/casino`.

### Permisos
| Permiso | Por defecto | Para qué |
|---|---|---|
| `apostador.usar` | todos | Apostar con clic derecho al mob |
| `apostador.apostar` | todos | Usar `/apostar` |
| `apostador.admin` | OP | Crear, eliminar, simular, recargar |
| `apostador.gratis` | nadie | Apostar sin pagar (útil para probar) |

---

## 4. Cómo funcionan las probabilidades

Cada apuesta es **una tirada en dos pasos**:

1. Se elige la **rareza** según su `probabilidad`.
2. Dentro de esa rareza se elige el **premio** según su `peso`.

```
Probabilidad de un premio = probabilidad de su rareza × peso del premio ÷ suma de pesos de la rareza
```

Ejemplos con la configuración incluida:

| Premio | Rareza | Cantidad | Probabilidad |
|---|---|---|---|
| Pan | Común | 2-8 | 1.11% |
| Palos | Común | 8-32 | 1.11% |
| Diamantes | Raro | 1-3 | 0.51% |
| Manzana dorada encantada | Legendario | 1-2 | 0.29% |
| **Élitros** | **Mítico** | 1 | **0.02% (1 de cada 5,000)**: el premio más raro |

| Rareza | Prob. | Premios | Herramientas | Combate | Comida y bebida | Ingredientes |
|---|---:|---:|---:|---:|---:|---:|
| Común | 49.98% | 90 | 10.06% | 7.19% | 15.70% | 17.03% |
| Poco común | 28% | 105 | 9.62% | 7.04% | 5.61% | 5.73% |
| Raro | 14% | 131 | 4.16% | 3.08% | 1.85% | 4.90% |
| Épico | 6.5% | 42 | 1.66% | 1.91% | 1.03% | 1.91% |
| Legendario | 1.5% | 8 | 0.11% | 0.29% | 0.29% | 0.80% |
| Mítico | 0.02% | 1 (élitros) | 0.02% | — | — | — |

Los grupos grandes de variantes (tintes, discos, cerámicas, plantillas de herrería, arneses) tienen peso bajo cada uno, para que el grupo completo no se coma toda la rareza.

## 5. Apuestas x5 y x10

Al darle clic al mob se abre un menú con tres botones: **x1, x5 y x10**. Cada botón muestra cuánto cuesta, cuántos premios recibes y la probabilidad de sacar al menos un Mítico (los élitros).

- **Costo:** precio de una apuesta × número de tiradas (x5 = 25 esmeraldas, x10 = 50 esmeraldas), menos el descuento si lo configuras.
- **Probabilidades:** cada tirada es independiente y usa exactamente las mismas probabilidades que una x1. Lo que cambia es la probabilidad de sacar *al menos uno*:

| Al menos un… | x1 | x5 | x10 |
|---|---:|---:|---:|
| Mítico (élitros) | 0.02% | 0.10% | 0.20% |
| Legendario | 1.50% | 7.28% | 14.03% |
| Épico o mejor | 8.02% | 34.16% | 56.66% |
| Raro o mejor | 22.02% | 71.17% | 91.69% |

- **Ruleta x5/x10:** cada premio tiene su casilla girando; se van deteniendo una por una (más agudo el sonido cuanto más raro el premio) y debajo aparece el color de su rareza. Al final el marco toma el color de la mejor rareza obtenida.
- **Mensaje:** el chat muestra la lista de todos los premios; el título y el sonido son los de la mejor rareza; cada Épico, Legendario o Mítico se anuncia al servidor.

En `config.yml`:
```yaml
apuesta:
  multiples: [1, 5, 10]   # opciones del menú (de 1 a 10). Con solo [1] no aparece menú
  descuentos:
    5: 0                  # % de descuento para x5
    10: 10                # ejemplo: x10 cuesta 45 esmeraldas en vez de 50
```

## 6. Legendario garantizado cada 667 giros

Cada jugador tiene un **contador de giros**. Cada tirada suma 1 (una apuesta x5 suma 5 y una x10 suma 10). Al llegar al giro **667**, ese giro da un premio **Legendario** seguro (elegido con los mismos pesos de los legendarios) y el contador vuelve a 0.

- El contador se guarda en los datos del jugador: no se pierde al desconectarse ni al reiniciar el servidor.
- Si una apuesta x10 cruza el 667, solo la tirada que cae justo en el 667 es la garantizada. Ejemplo: con 660 giros, en una x10 la **7.ª** tirada es el Legendario.
- **Dónde se ve:** en el menú hay una estrella con una barra de progreso, y las apuestas que alcanzan el garantizado dicen «¡Incluye tu Legendario garantizado!». Además, después de cada apuesta el chat dice cuántos giros faltan, y `/apostador garantia` lo muestra cuando quieras.
- **Al llegar:** el premio sale marcado con «★ GARANTIZADO» en la ruleta, hay un mensaje especial y se anuncia a todo el servidor.

| | Sin garantía | Con garantía |
|---|---:|---:|
| Legendario por giro | 1.50% | 1.65% |
| Legendarios esperados en 667 giros | 10.0 | 11.0 |

En `config.yml`:
```yaml
garantizado:
  activado: true
  cada-giros: 667
  rareza: legendario
  reiniciar-con-suerte: false   # true = el contador vuelve a 0 cada vez que sacas un Legendario por suerte
  mostrar-progreso: true
```
Los **élitros no entran en la garantía**: son Míticos, así que solo salen por suerte (0.02%) y siguen siendo el premio más raro.

Con `reiniciar-con-suerte: true` funciona como el *pity* de los juegos gacha. Pero como el Legendario sale en promedio cada 67 giros, llegar a 667 sin ninguno casi nunca pasa (≈ 0.004%), así que en la práctica la garantía casi nunca se activaría. Por eso viene en `false`: cada 667 giros sale un Legendario extra, pase lo que pase.

Para probarlo rápido: `/apostador garantia TuNombre 665` y luego haz dos giros.

## 7. Personalizar `premios.yml`

Cada premio es una línea:
```yaml
premios:
  comun:
    - {material: BREAD, cantidad: "2-8", peso: 10, categoria: comida}
  raro:
    - {material: POTION, cantidad: 1, peso: 3, categoria: comida, pocion: "strength"}
    - {material: ENCHANTED_BOOK, cantidad: 1, peso: 8, categoria: ingredientes, encantamientos: "aleatorio"}
  legendario:
    - {material: NETHERITE_SWORD, cantidad: 1, peso: 3, categoria: combate, encantamientos: {sharpness: 5, mending: 1}, nombre: "&6&lEspada del Apostador"}
```

| Campo | Significado |
|---|---|
| `material` | Nombre del ítem como en `/give`, en mayúsculas |
| `cantidad` | Fija (`1`) o rango (`"4-16"`). Se limita solo al máximo del stack (las herramientas siempre dan 1) |
| `peso` | Qué tan seguido sale dentro de su rareza. Por defecto 10 |
| `categoria` | `herramientas`, `combate`, `comida` o `ingredientes` |
| `pocion` | Para `POTION`, `SPLASH_POTION`, `LINGERING_POTION`, `TIPPED_ARROW`: `healing`, `strong_strength`, `long_swiftness`… |
| `encantamientos` | `{sharpness: 5, unbreaking: 3}` o `aleatorio` (libro con un encantamiento al azar, sin maldiciones) |
| `nombre` | Nombre personalizado con colores `&` |

- Para cambiar qué tan seguido sale cada rareza, edita `probabilidad` en `rarezas:` (no tienen que sumar 100; se reparten en proporción).
- Para quitar una categoría completa, bórrala de `categorias-activas` en `config.yml`.
- Si un ítem no existe en tu versión de Minecraft, se omite solo y la consola lo avisa al arrancar.
- Después de editar: `/apostador recargar`, y revisa con `/apostador probabilidades` y `/apostador simular 100000`.

## 8. `config.yml` (lo principal)

```yaml
mob:
  tipo: wandering_trader        # villager, witch, piglin, allay, fox…
  nombre: "&6&l✦ El Apostador ✦"
apuesta:
  tipo-costo: ITEM              # ITEM, DINERO (Vault) o GRATIS
  item: EMERALD
  cantidad: 5
  dinero: 250.0
  cooldown-segundos: 3
  comando-apostar: true
  multiples: [1, 5, 10]
  descuentos: {5: 0, 10: 0}
animacion:
  activada: true                # false = premio instantáneo, sin ruleta
  pasos: 45                     # ~5 segundos de giro
```
Todos los mensajes están en español en `mensajes:` y se pueden cambiar.

## 9. Seguridad
- El premio se decide **antes** de girar; la animación solo lo muestra.
- Si el jugador cierra el cofre, se desconecta o el servidor se apaga a mitad del giro, **recibe todos sus premios igual** (también en x5/x10).
- Los ítems de la ruleta y del menú no se pueden sacar (clics y arrastres bloqueados, y al recargar el plugin se cierran todos los cofres).
- Un doble clic en el menú no cobra dos veces.
- El contador de la garantía se actualiza al momento de pagar, así que cerrar la ruleta o desconectarse no hace perder ni repetir el garantizado.
- Si el inventario está lleno, el premio cae al suelo a sus pies.
- El mob tiene la etiqueta `mob_apostador`, por si quieres usarla en comandos: `/tp @e[tag=mob_apostador,limit=1] ~ ~ ~`.
