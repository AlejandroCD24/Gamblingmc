# MobApostador 🎰

Plugin para servidores **Spigot / Paper** (Minecraft 1.21 y 26.x) que agrega un **mob apostador**: el jugador le da clic derecho, paga la apuesta, gira una ruleta y gana un ítem aleatorio de las categorías del creativo **Herramientas y utilidades, Combate, Comida y bebida e Ingredientes**.

- 7 rarezas con su propia probabilidad: **Común 51.39% · Poco común 28% · Raro 14% · Épico 6.5% · Legendario 0.1% · Mítico 0.01% · Imposible 0.0001%**
- 389 premios, cada uno con su **peso** dentro de su rareza (probabilidad individual)
- Los ítems comunes salen en **más cantidad** (p. ej. palos 8-32, flechas 8-32, pan 2-8); los raros, épicos y legendarios casi siempre salen de 1 en 1
- Ruleta animada en un cofre que se va frenando, con sonidos; el marco toma el color de la rareza ganada
- Raro y superior: título en pantalla. **Legendario, Mítico e Imposible: anuncio que ven TODOS los jugadores** (cada rareza con su propio mensaje y sonido) y fuegos artificiales (sin daño)
- **Épico**: todo lo de diamante (herramientas, armadura, espada, lanza, diamantes…), tótem y libros encantados
- **Legendario**: todo lo de netherite (herramientas, armadura, espada, lanza, chatarra, lingote…), maza, tridente, plantilla Silence, estrella del Nether y los ítems del Apostador
- **Mítico**: élitros (1 de cada 120,000) y armaduras de diamante o netherite con **2 protecciones al máximo** + Irrompibilidad III + Reparación
- **Imposible**: la **God Armor** (las 4 protecciones IV y todo al máximo). Cada pieza sale 1 de cada 4,000,000 de giros
- El nombre del ítem aparece **en el idioma del jugador** (si su Minecraft está en español, lo ve en español)
- **Apuestas x1, x5, x10 y x100**: al darle clic al Apostador se abre un menú para elegir; x100 se puede pagar con bloques de esmeralda (5 esmeraldas por giro)
- **Elegir premios**: cada jugador marca qué premios quiere y el resto se descarta (si no marca nada, recibe todo)
- **Legendario garantizado cada 667 giros y Mítico garantizado cada 66,667**: cada jugador tiene sus contadores (se guardan aunque se desconecte o se reinicie el servidor)
- Costo configurable: ítems (5 esmeraldas por apuesta), dinero con Vault, o gratis; descuento opcional para x5/x10
- Todo se edita en `config.yml` y `premios.yml` sin tocar código

La tabla completa de probabilidades está en [PROBABILIDADES.md](PROBABILIDADES.md).

---

## 1. Compilar el .jar

No pude compilarlo en mi entorno porque no tenía acceso a internet para descargar la API de Spigot, así que tienes que compilarlo tú. Hay dos formas:

### Opción A: con GitHub, sin instalar nada (sirve desde el celular)
1. Crea un repositorio en GitHub.
2. Crea el archivo `.github/workflows/build.yml` (**Add file → Create new file**, escribe esa ruta como nombre) y pega el contenido del `build.yml` de este proyecto.
3. Sube el proyecto de una de estas dos formas:
   - **Desde el celular:** sube solo el archivo **MobApostador.zip** tal cual (**Add file → Upload files**). El workflow lo descomprime solo. Deja un único .zip en el repositorio.
   - **Desde una computadora:** también puedes subir todo el contenido de la carpeta descomprimida, respetando las carpetas.
4. Ve a la pestaña **Actions**. La compilación empieza sola con cada subida.
   - Para elegir otra versión de Minecraft: **Actions → Compilar plugin → Run workflow** y escribe la versión (ver tabla abajo).
5. Cuando termine (✔ verde), entra a la ejecución y descarga el artefacto **MobApostador** (es un .zip que contiene el .jar).

### Opción B: en tu computadora
Necesitas **JDK 25** (para Minecraft 26.x) o **JDK 21** (para 1.21.x) y **Maven**.
```bash
mvn package
# o para otra versión:
mvn package -Dspigot.version=1.21.11-R0.1-SNAPSHOT
```
El plugin queda en `target/MobApostador-1.0.0.jar`.

| Tu servidor | `spigot.version` | JDK para compilar |
|---|---|---|
| 26.3 | `26.3-R0.1-SNAPSHOT` (por defecto) | 25 |
| 26.1 / 26.2 | `26.1-R0.1-SNAPSHOT` / `26.2-R0.1-SNAPSHOT` | 25 |
| 1.21.x | `1.21.11-R0.1-SNAPSHOT` (o la tuya) | 21 |

Compila con la versión de tu servidor para evitar sorpresas.

## 2. Instalar
1. Copia el `.jar` en la carpeta `plugins/` del servidor y reinícialo.
2. Se crean `plugins/MobApostador/config.yml` y `premios.yml`.
3. (Opcional) Si quieres cobrar con dinero, instala **Vault** + un plugin de economía (EssentialsX, CMI…) y pon `tipo-costo: DINERO`.

## 3. Uso
1. Como OP, mira el bloque donde lo quieres y escribe **`/apostador crear`**.
2. Los jugadores le dan **clic derecho** al mob → (opcional) marcan en «Elegir premios» lo que quieren → eligen **x1, x5, x10 o x100** → pagan → gira la ruleta → reciben los premios.
3. Pegarle (clic izquierdo, o tocarlo en celular/Bedrock) también abre el menú; se puede desactivar con `mob.abrir-con-golpe: false`. No se puede matar, no se mueve, no comercia, no se quema y no desaparece.
4. **Solo se puede apostar interactuando con el Apostador**: no hay comando para apostar.
5. Encima del mob flota un **holograma** con su nombre y «Clic para apostar». Solo se ve de cerca (10 bloques por defecto, `mob.distancia-nombre`) y no se ve a través de paredes. Al quitar el mob con `/apostador eliminar` (o un admin con `/kill`) se borra también su holograma.

### Comandos
| Comando | Qué hace | Permiso |
|---|---|---|
| `/apostador crear` | Aparece el mob donde estás mirando | `apostador.admin` |
| `/apostador eliminar` | Quita el apostador más cercano (6 bloques) | `apostador.admin` |
| `/apostador eliminar todos` | Quita todos los apostadores cargados | `apostador.admin` |
| `/apostador probabilidades [rareza] [página]` | Muestra los porcentajes reales | todos |
| `/apostador garantia` | Muestra cuántos giros te faltan para el Legendario y el Mítico garantizados | todos |
| `/apostador garantia <jugador> [giros] [legendario\|mitico]` | Ver o ajustar un contador de otro jugador (útil para probar) | `apostador.admin` |
| `/apostador simular [n]` | Hace n tiradas de prueba y compara con lo esperado | `apostador.admin` |
| `/apostador recargar` | Relee `config.yml` y `premios.yml` | `apostador.admin` |

Alias: `/casino`.

### Permisos
| Permiso | Por defecto | Para qué |
|---|---|---|
| `apostador.usar` | todos | Apostar con clic derecho al mob |
| `apostador.admin` | OP | Crear, eliminar, simular, recargar |
| `apostador.gratis` | nadie | Apostar sin pagar (útil para probar) |

---

## 4. Cómo funcionan las probabilidades

Cada apuesta es **una tirada en dos pasos**:

1. Se elige la **rareza** según su `probabilidad`.
2. Dentro de esa rareza se elige el **premio** según su `peso`.

```
Probabilidad de un premio = probabilidad de su rareza × peso del premio ÷ suma de pesos de la rareza
```

Ejemplos con la configuración incluida:

| Premio | Rareza | Cantidad | Probabilidad |
|---|---|---|---|
| Pan | Común | 2-8 | 1.14% |
| Palos | Común | 8-32 | 1.14% |
| Diamantes | Épico | 1-3 | 0.39% (1 de cada 254) |
| Manzana dorada encantada | Legendario | 1-2 | 0.0074% (1 de cada 13,500) |
| Pico de netherite | Legendario | 1 | 0.0056% (1 de cada 18,000) |
| Pieza mítica de diamante | Mítico | 1 | 0.00125% (1 de cada 80,000) |
| Pieza mítica de netherite | Mítico | 1 | 0.00104% (1 de cada 96,000) |
| Élitros | Mítico | 1 | 0.00083% (1 de cada 120,000) |
| **Una pieza de God Armor** | **Imposible** | 1 | **0.000025% (1 de cada 4,000,000)** |

| Rareza | Prob. | Premios | Herramientas | Combate | Comida y bebida | Ingredientes |
|---|---:|---:|---:|---:|---:|---:|
| Común | 51.39% | 90 | 10.35% | 7.39% | 16.14% | 17.51% |
| Poco común | 28% | 105 | 9.62% | 7.04% | 5.61% | 5.73% |
| Raro | 14% | 118 | 3.73% | 2.04% | 2.44% | 5.79% |
| Épico | 6.5% | 40 | 1.67% | 1.92% | 1.03% | 1.87% |
| Legendario | 0.1% | 23 | 0.02% | 0.04% | 0.00741% | 0.03% |
| Mítico | 0.01% | 9 | 0.0008% | 0.009% | — | — |
| Imposible | 0.0001% | 4 | — | 0.0001% | — | — |

Los grupos grandes de variantes (tintes, discos, cerámicas, plantillas de herrería, arneses) tienen peso bajo cada uno, para que el grupo completo no se coma toda la rareza.

## 5. Apuestas x5, x10 y x100

Al darle clic al mob se abre un menú con los botones **x1, x5, x10 y x100**. Cada botón muestra cuánto cuesta, cuántos premios recibes y la probabilidad de sacar al menos un premio Imposible.

- **Costo:** siempre **5 esmeraldas por giro**: x5 = 25, x10 = 50, x100 = 500 (menos el descuento si lo configuras).
- **Bloques de esmeralda:** también se puede pagar con bloques (cada uno vale 9 esmeraldas), así no tienes que cargar 500 esmeraldas sueltas. Si hace falta, el plugin rompe un bloque y te devuelve el cambio. Ejemplo: x100 con 60 bloques → se cobran 55 bloques + 1 bloque roto y te regresa 4 esmeraldas.
- **Probabilidades:** cada tirada es independiente y usa exactamente las mismas probabilidades que una x1. Lo que cambia es la probabilidad de sacar *al menos uno*:

| Al menos un… | x1 | x5 | x10 | x100 |
|---|---:|---:|---:|---:|
| Imposible (God Armor) | 0.0001% | 0.0005% | 0.001% | 0.01% |
| Mítico | 0.01% | 0.05% | 0.10% | 1.00% |
| Legendario | 0.10% | 0.50% | 1.00% | 9.52% |
| Épico o mejor | 6.61% | 28.96% | 49.53% | 99.89% |
| Raro o mejor | 20.61% | 68.46% | 90.05% | 100% |

- **Ruleta x5/x10:** cada premio tiene su casilla girando; se van deteniendo una por una (más agudo el sonido cuanto más raro el premio) y debajo aparece el color de su rareza.
- **Ruleta x100:** un cofre grande donde los premios se destapan rápido (unos 3 segundos). Se ven los 45 mejores y abajo el resumen de cuántos salieron de cada rareza.
- **Mensaje:** en x5/x10 el chat lista todos los premios; en x100 muestra un resumen por rareza y solo el detalle de los Épicos o mejores (`apuesta.detalle-desde`). Cada Legendario, Mítico o Imposible se anuncia a todo el servidor.

En `config.yml`:
```yaml
apuesta:
  multiples: [1, 5, 10, 100]   # opciones del menú (de 1 a 100). Con solo [1] no aparece menú
  equivalentes:
    EMERALD_BLOCK: 9           # qué más sirve para pagar y cuánto vale
  descuentos:
    5: 0                       # % de descuento para x5
    10: 0
```

## 5b. Elegir premios (descartar el resto)

En el menú del Apostador está el botón **«Elegir premios»** (embudo). Ahí cada jugador marca los premios que **sí** quiere recibir:

- Se abre un cofre con pestañas por rareza; tocas un premio para marcarlo (brilla y dice «✔ SELECCIONADO»). Hay botones para marcar/quitar todos los de una rareza y para borrar toda la selección.
- Al apostar, los premios que salgan y **no** estén marcados **se descartan** (no se reciben). En la ruleta aparecen con «✖ se descarta» y en el chat como «(descartado)».
- **Si no marcas ninguno, recibes todo** (es lo normal).
- **Legendario, Mítico e Imposible siempre se reciben**, aunque no estén marcados (`filtro.proteger-rarezas`).
- Las probabilidades y el precio no cambian: solo decides qué te quedas. Ideal para x100 y no llenar el inventario de cosas que no quieres.
- La selección se guarda en los datos de cada jugador.

## 6. Premios garantizados: Legendario cada 667 giros y Mítico cada 66,667

Cada jugador tiene **dos contadores de giros**, uno por garantía. Cada tirada suma 1 a los dos (una apuesta x5 suma 5 y una x10 suma 10).

- Al llegar al giro **667** del contador Legendario, ese giro da un **Legendario** seguro y ese contador vuelve a 0.
- Al llegar al giro **66,667** del contador Mítico, ese giro da un **Mítico** seguro (élitros o una armadura mítica, con sus mismos pesos) y ese contador vuelve a 0.
- Si los dos tocan en el **mismo giro**, sale el Mítico y el Legendario sale en el giro siguiente: no se pierde ninguno.
- Los contadores se guardan en los datos del jugador: no se pierden al desconectarse ni al reiniciar el servidor.
- Si una apuesta x10 cruza el número, solo la tirada que cae justo ahí es la garantizada. Ejemplo: con 660 giros, en una x10 la **7.ª** tirada es el Legendario.
- **Dónde se ve:** en el menú la estrella «★ Premios garantizados» muestra una barra de progreso por cada garantía, y las apuestas que alcanzan alguna dicen «¡Incluye tu … garantizado!». Después de cada apuesta el chat muestra, por ejemplo, `Garantizado: Legendario en 544 giros | Mítico en 66,123 giros`, y `/apostador garantia` lo muestra cuando quieras.
- **Al llegar:** el premio sale marcado con «★ GARANTIZADO» en la ruleta, hay un mensaje especial y se anuncia a todo el servidor.

| Garantía | Cada | Por giro sin garantía | Con garantía | Por suerte en ese tramo (promedio) |
|---|---:|---:|---:|---:|
| Legendario | 667 giros | 0.100% | 0.250% | 0.7 |
| Mítico | 66,667 giros | 0.0100% | 0.0115% | 6.7 |

Los premios **Imposibles (God Armor) no entran en ninguna garantía**: solo salen por suerte.

En `config.yml` (puedes agregar más garantías con el mismo formato):
```yaml
garantizado:
  activado: true
  mostrar-progreso: true
  garantias:
    legendario:
      rareza: legendario
      cada-giros: 667
      reiniciar-con-suerte: false
    mitico:
      rareza: mitico
      cada-giros: 66667
      reiniciar-con-suerte: false
```
Si tu `config.yml` es de una versión anterior (sin `garantias:`), el plugin respeta tu Legendario y agrega solo el Mítico cada 66,667. No hace falta borrarlo.

Con `reiniciar-con-suerte: true` el contador vuelve a 0 cada vez que sacas esa rareza por suerte (como el *pity* de los juegos gacha). Viene en `false`: así el garantizado es un premio extra que llega sí o sí cada 667 giros, aunque antes hayas sacado alguno por suerte.

**Para probarlo rápido:**
- Legendario: `/apostador garantia TuNombre 665` y luego haz dos giros.
- Mítico: `/apostador garantia TuNombre 66665 mitico` y luego haz dos giros.

## 7. Anuncios, armaduras míticas y God Armor

**Anuncios:** cuando alguien saca un premio **Legendario, Mítico o Imposible**, TODOS los jugadores conectados (incluido el ganador) ven un mensaje en el chat con el nombre del ítem, y los demás escuchan un sonido:

| Rareza | Mensaje | Sonido para los demás |
|---|---|---|
| Legendario | `✦ LEGENDARIO ✦ Jugador sacó 1x …` | subir de nivel |
| Mítico | `✦✦ MÍTICO ✦✦ Jugador sacó 1x …` | rugido del dragón |
| Imposible | `☠ ¡IMPOSIBLE! ☠ Jugador sacó …` | aparición del Wither |

Cada rareza tiene su `anuncio` y `sonido-anuncio` en `premios.yml`; con `anunciar: false` se desactiva. Épico ya no se anuncia (ponle `anunciar: true` si lo quieres de vuelta).

**Armaduras míticas (8):** casco, peto, pantalones y botas de **diamante** (1 de cada 80,000 cada una) y de **netherite** (1 de cada 96,000 cada una). Cada pieza trae **Irrompibilidad III + Reparación + 2 protecciones distintas a nivel IV**, elegidas al azar entre Protección, Protección contra el fuego, Protección contra explosiones y Protección contra proyectiles (6 combinaciones posibles).

**God Armor (rareza Imposible):** 4 piezas de netherite con nombre propio. Todas traen las **4 protecciones a IV + Irrompibilidad III + Reparación**, y además:
- ☠ Casco de Dios: Respiración III y Afinidad acuática
- ☠ Peto de Dios: lo base
- ☠ Pantalones de Dios: Sigilo rápido III
- ☠ Botas de Dios: Caída de pluma IV, Agilidad acuática III y Velocidad de alma III

La rareza Imposible sale el **0.0001%** de los giros (1 de cada **1,000,000**) y **cada pieza** 1 de cada **4,000,000**. Su `probabilidad` se cambia en `premios.yml`.

## 7b. Corazón de LifeHearts (Legendario)
El **Corazón** del plugin LifeHearts (+1 corazón de vida máxima permanente) es un premio **Legendario**: peso 5 dentro de Legendario,
o sea **0.0044% por giro (1 de cada ~22,600)** y ~4.4% de los Legendarios (también puede tocar con el Legendario garantizado).
- Lo crea el propio LifeHearts con su comando (`corazones give {jugador} {cantidad}`), así que es exactamente el mismo Corazón que el crafteado.
- En la ruleta se ve con su textura (`modelo: "lifehearts:heart"`) y brillo, y el anuncio a todo el servidor sale como cualquier Legendario.
- Si LifeHearts no está instalado o activo, ese premio no se usa (`requiere: "LifeHearts"`). MobApostador carga después de LifeHearts (`softdepend`).
- Sirve para cualquier objeto de otro plugin: ver los campos `comando`, `requiere`, `modelo` y `brillo` en `premios.yml`.

## 8. Personalizar `premios.yml`

Cada premio es una línea:
```yaml
premios:
  comun:
    - {material: BREAD, cantidad: "2-8", peso: 10, categoria: comida}
  raro:
    - {material: POTION, cantidad: 1, peso: 3, categoria: comida, pocion: "strength"}
    - {material: ENCHANTED_BOOK, cantidad: 1, peso: 8, categoria: ingredientes, encantamientos: "aleatorio"}
  legendario:
    - {material: NETHERITE_SWORD, cantidad: 1, peso: 3, categoria: combate, encantamientos: {sharpness: 5, mending: 1}, nombre: "&6&lEspada del Apostador"}
```

| Campo | Significado |
|---|---|
| `material` | Nombre del ítem como en `/give`, en mayúsculas |
| `cantidad` | Fija (`1`) o rango (`"4-16"`). Se limita solo al máximo del stack (las herramientas siempre dan 1) |
| `peso` | Qué tan seguido sale dentro de su rareza. Por defecto 10 |
| `categoria` | `herramientas`, `combate`, `comida` o `ingredientes` |
| `pocion` | Para `POTION`, `SPLASH_POTION`, `LINGERING_POTION`, `TIPPED_ARROW`: `healing`, `strong_strength`, `long_swiftness`… |
| `encantamientos` | `{sharpness: 5, unbreaking: 3}` o `aleatorio` (libro con un encantamiento al azar, sin maldiciones) |
| `combinar` | Elige al azar varios encantamientos distintos de una lista, al nivel máximo. Ej.: `{de: [protection, fire_protection, blast_protection, projectile_protection], cantidad: 2}`. Permite juntar protecciones que en vanilla son incompatibles |
| `nombre` | Nombre personalizado con colores `&` |

- Para cambiar qué tan seguido sale cada rareza, edita `probabilidad` en `rarezas:` (no tienen que sumar 100; se reparten en proporción).
- Para quitar una categoría completa, bórrala de `categorias-activas` en `config.yml`.
- Si un ítem no existe en tu versión de Minecraft, se omite solo y la consola lo avisa al arrancar.
- Después de editar: `/apostador recargar`, y revisa con `/apostador probabilidades` y `/apostador simular 100000`.

## 9. `config.yml` (lo principal)

```yaml
mob:
  tipo: wandering_trader        # villager, witch, piglin, allay, fox…
  nombre: "&6&l✦ El Apostador ✦"
  texto-debajo: "&eClic para apostar"   # segunda línea del holograma ("" para quitarla)
  distancia-nombre: 10          # bloques hasta donde se ve el nombre (0 = sin nombre)
apuesta:
  tipo-costo: ITEM              # ITEM, DINERO (Vault) o GRATIS
  item: EMERALD
  cantidad: 5
  dinero: 250.0
  cooldown-segundos: 3
  multiples: [1, 5, 10, 100]
  equivalentes: {EMERALD_BLOCK: 9}
  descuentos: {5: 0, 10: 0}
animacion:
  activada: true                # false = premio instantáneo, sin ruleta
  pasos: 45                     # ~5 segundos de giro
```
Todos los mensajes están en español en `mensajes:` y se pueden cambiar.

## 10. Seguridad
- El premio se decide **antes** de girar; la animación solo lo muestra.
- Si el jugador cierra el cofre, se desconecta o el servidor se apaga a mitad del giro, **recibe todos sus premios igual** (también en x5/x10).
- Los ítems de la ruleta y del menú no se pueden sacar (clics y arrastres bloqueados, y al recargar el plugin se cierran todos los cofres).
- Un doble clic en el menú no cobra dos veces.
- El contador de la garantía se actualiza al momento de pagar, así que cerrar la ruleta o desconectarse no hace perder ni repetir el garantizado.
- Si el inventario está lleno, el premio cae al suelo a sus pies.
- El mob tiene la etiqueta `mob_apostador`, por si quieres usarla en comandos: `/tp @e[tag=mob_apostador,limit=1] ~ ~ ~`. Si lo mueves con `/tp`, usa después `/apostador recargar` para que el holograma lo siga.

## 11. Rendimiento
- Los eventos que más se repiten en un servidor (daño, interacción, clics en inventarios) descartan al instante todo lo que no es del plugin: los apostadores se buscan en una lista en memoria y los inventarios del plugin en otra, sin leer datos de las entidades ni de los cofres reales.
- La ruleta reutiliza los paneles de vidrio en vez de crear ítems nuevos en cada tick.
- Los datos de cooldown de cada jugador se borran cuando sale del servidor.
- El nombre del mob es un holograma que el cliente solo dibuja de cerca, en lugar de un nombre visible a 64 bloques.
