# Tabla de probabilidades - MobApostador

Cada apuesta hace **una tirada en dos pasos**: primero se elige la rareza y luego un premio dentro de ella según su peso.

`Probabilidad del premio = probabilidad de la rareza × peso ÷ suma de pesos de esa rareza`

Los ítems comunes dan **más cantidad** (rangos como 8-32); los raros, épicos y legendarios casi siempre dan 1.

## Resumen por rareza

| Rareza | Probabilidad | Premios | Herramientas | Combate | Comida y bebida | Ingredientes |
|---|---:|---:|---:|---:|---:|---:|
| Común | **51.39%** | 90 | 10.35% | 7.39% | 16.14% | 17.51% |
| Poco común | **28.00%** | 105 | 9.62% | 7.04% | 5.61% | 5.73% |
| Raro | **14.00%** | 118 | 3.73% | 2.04% | 2.44% | 5.79% |
| Épico | **6.50%** | 42 | 1.60% | 2.07% | 0.99% | 1.84% |
| Legendario | **0.10%** | 21 | 0.02% | 0.04% | 0.008% | 0.03% |
| Mítico | **0.01%** | 9 | 0.00083% | 0.00917% | — | — |
| Imposible | **0.0001%** | 4 | — | 0.0001% | — | — |
| **Total** | 100% | 389 | 25.32% | 18.59% | 25.20% | 30.89% |

Comprobación con 1,000,000 tiradas simuladas: Común 51.36%, Poco común 28.08%, Raro 13.96%, Épico 6.49%, Legendario 0.10%, Mítico 0.01%, Imposible 0 (demasiado raro para salir en la prueba).

## Apuestas x5 y x10

Cada tirada de una apuesta múltiple es independiente y usa exactamente las mismas probabilidades. Probabilidad de sacar **al menos un** premio de cada rareza:

| Rareza | x1 | x5 | x10 |
|---|---:|---:|---:|
| Imposible | 0.0001% | 0.0005% | 0.001% |
| Mítico | 0.01% | 0.05% | 0.10% |
| Legendario | 0.10% | 0.50% | 1.00% |
| Épico | 6.50% | 28.54% | 48.94% |
| Raro | 14.00% | 52.96% | 77.87% |
| Poco común | 28.00% | 80.65% | 96.26% |
| Común | 51.39% | 97.29% | 99.93% |
| Épico **o mejor** | 6.61% | 28.96% | 49.53% |

## Premios garantizados

Cada jugador tiene un contador por cada garantía; cada tirada suma 1 giro a todos (x5 suma 5 y x10 suma 10). Al llegar al número de giros, ese giro da un premio de esa rareza (elegido con sus mismos pesos) y el contador vuelve a 0. Si dos coinciden en el mismo giro, sale el Mítico y el Legendario sale en el giro siguiente.

| Garantía | Cada | Sin garantía | Con garantía | Por suerte en ese tramo | Extra por la garantía |
|---|---:|---:|---:|---:|---:|
| Legendario | 667 giros | 0.100% | 0.250% | 0.7 en promedio | +1 |
| Mítico | 66,667 giros | 0.010% | 0.011% | 6.7 en promedio | +1 |

> Nota: si un ítem no existe en la versión de tu servidor, se omite y los porcentajes de su rareza se reparten entre los demás. En el juego, `/apostador probabilidades` muestra siempre los valores reales.

## Común — 51.39% (90 premios)

### Herramientas y utilidades — 10.35%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| BONE_MEAL | 8-24 | 10 | 1.14% (1 de 88) |
| STONE_PICKAXE | 1 | 8 | 0.910% (1 de 110) |
| STONE_AXE | 1 | 8 | 0.910% (1 de 110) |
| STONE_SHOVEL | 1 | 8 | 0.910% (1 de 110) |
| BUCKET | 1-2 | 8 | 0.910% (1 de 110) |
| WOODEN_PICKAXE | 1 | 6 | 0.682% (1 de 147) |
| WOODEN_AXE | 1 | 6 | 0.682% (1 de 147) |
| WOODEN_SHOVEL | 1 | 6 | 0.682% (1 de 147) |
| STONE_HOE | 1 | 6 | 0.682% (1 de 147) |
| FISHING_ROD | 1 | 6 | 0.682% (1 de 147) |
| LEAD | 1-3 | 6 | 0.682% (1 de 147) |
| WOODEN_HOE | 1 | 5 | 0.568% (1 de 176) |
| MAP | 1-3 | 4 | 0.455% (1 de 220) |
| WRITABLE_BOOK | 1 | 4 | 0.455% (1 de 220) |

### Combate — 7.39%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| ARROW | 8-32 | 12 | 1.36% (1 de 73) |
| STONE_SWORD | 1 | 8 | 0.910% (1 de 110) |
| SNOWBALL | 4-16 | 8 | 0.910% (1 de 110) |
| WOODEN_SWORD | 1 | 6 | 0.682% (1 de 147) |
| EGG | 2-8 | 6 | 0.682% (1 de 147) |
| STONE_SPEAR | 1 | 5 | 0.568% (1 de 176) |
| WOODEN_SPEAR | 1 | 4 | 0.455% (1 de 220) |
| LEATHER_HELMET | 1 | 4 | 0.455% (1 de 220) |
| LEATHER_CHESTPLATE | 1 | 4 | 0.455% (1 de 220) |
| LEATHER_LEGGINGS | 1 | 4 | 0.455% (1 de 220) |
| LEATHER_BOOTS | 1 | 4 | 0.455% (1 de 220) |

### Comida y bebida — 16.14%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| APPLE | 2-8 | 10 | 1.14% (1 de 88) |
| BREAD | 2-8 | 10 | 1.14% (1 de 88) |
| MELON_SLICE | 4-16 | 8 | 0.910% (1 de 110) |
| SWEET_BERRIES | 4-16 | 8 | 0.910% (1 de 110) |
| CARROT | 4-16 | 8 | 0.910% (1 de 110) |
| POTATO | 4-16 | 8 | 0.910% (1 de 110) |
| BAKED_POTATO | 4-12 | 8 | 0.910% (1 de 110) |
| GLOW_BERRIES | 4-12 | 6 | 0.682% (1 de 147) |
| BEETROOT | 4-12 | 6 | 0.682% (1 de 147) |
| COOKIE | 4-16 | 6 | 0.682% (1 de 147) |
| DRIED_KELP | 8-24 | 6 | 0.682% (1 de 147) |
| BEEF | 2-8 | 6 | 0.682% (1 de 147) |
| PORKCHOP | 2-8 | 6 | 0.682% (1 de 147) |
| MUTTON | 2-8 | 6 | 0.682% (1 de 147) |
| CHICKEN | 2-8 | 6 | 0.682% (1 de 147) |
| ROTTEN_FLESH | 4-16 | 6 | 0.682% (1 de 147) |
| COD | 2-8 | 5 | 0.568% (1 de 176) |
| SALMON | 2-8 | 5 | 0.568% (1 de 176) |
| RABBIT | 1-4 | 4 | 0.455% (1 de 220) |
| CHORUS_FRUIT | 2-8 | 4 | 0.455% (1 de 220) |
| TROPICAL_FISH | 1-4 | 3 | 0.341% (1 de 293) |
| SPIDER_EYE | 1-4 | 3 | 0.341% (1 de 293) |
| PUFFERFISH | 1-3 | 2 | 0.227% (1 de 440) |
| POISONOUS_POTATO | 1-4 | 2 | 0.227% (1 de 440) |

### Ingredientes — 17.51%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| STICK | 8-32 | 10 | 1.14% (1 de 88) |
| COAL | 4-16 | 10 | 1.14% (1 de 88) |
| WHEAT | 4-16 | 8 | 0.910% (1 de 110) |
| CHARCOAL | 4-16 | 6 | 0.682% (1 de 147) |
| FLINT | 2-8 | 6 | 0.682% (1 de 147) |
| BONE | 2-8 | 6 | 0.682% (1 de 147) |
| STRING | 2-8 | 6 | 0.682% (1 de 147) |
| FEATHER | 2-8 | 6 | 0.682% (1 de 147) |
| LEATHER | 2-6 | 6 | 0.682% (1 de 147) |
| PAPER | 4-12 | 6 | 0.682% (1 de 147) |
| IRON_NUGGET | 4-16 | 6 | 0.682% (1 de 147) |
| RAW_COPPER | 2-8 | 6 | 0.682% (1 de 147) |
| COPPER_INGOT | 2-8 | 6 | 0.682% (1 de 147) |
| GUNPOWDER | 2-6 | 6 | 0.682% (1 de 147) |
| CLAY_BALL | 4-16 | 5 | 0.568% (1 de 176) |
| GOLD_NUGGET | 4-16 | 5 | 0.568% (1 de 176) |
| SUGAR | 2-8 | 5 | 0.568% (1 de 176) |
| BRICK | 4-16 | 4 | 0.455% (1 de 220) |
| COPPER_NUGGET | 4-16 | 4 | 0.455% (1 de 220) |
| GLASS_BOTTLE | 2-6 | 4 | 0.455% (1 de 220) |
| INK_SAC | 2-6 | 4 | 0.455% (1 de 220) |
| SLIME_BALL | 1-4 | 4 | 0.455% (1 de 220) |
| BOWL | 2-8 | 3 | 0.341% (1 de 293) |
| NETHER_BRICK | 4-16 | 3 | 0.341% (1 de 293) |
| RABBIT_HIDE | 1-4 | 3 | 0.341% (1 de 293) |
| WHITE_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| ORANGE_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| MAGENTA_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| LIGHT_BLUE_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| YELLOW_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| LIME_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| PINK_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| GRAY_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| LIGHT_GRAY_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| CYAN_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| PURPLE_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| BLUE_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| BROWN_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| GREEN_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| RED_DYE | 2-8 | 1 | 0.114% (1 de 880) |
| BLACK_DYE | 2-8 | 1 | 0.114% (1 de 880) |

## Poco común — 28.00% (105 premios)

### Herramientas y utilidades — 9.62%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| IRON_PICKAXE | 1 | 8 | 0.458% (1 de 218) |
| IRON_AXE | 1 | 8 | 0.458% (1 de 218) |
| IRON_SHOVEL | 1 | 8 | 0.458% (1 de 218) |
| SHEARS | 1 | 8 | 0.458% (1 de 218) |
| FLINT_AND_STEEL | 1 | 8 | 0.458% (1 de 218) |
| ENDER_PEARL | 2-4 | 8 | 0.458% (1 de 218) |
| FIREWORK_ROCKET | 8-24 | 8 | 0.458% (1 de 218) |
| IRON_HOE | 1 | 6 | 0.344% (1 de 291) |
| COPPER_PICKAXE | 1 | 6 | 0.344% (1 de 291) |
| COPPER_AXE | 1 | 6 | 0.344% (1 de 291) |
| COPPER_SHOVEL | 1 | 6 | 0.344% (1 de 291) |
| WATER_BUCKET | 1 | 6 | 0.344% (1 de 291) |
| COMPASS | 1 | 6 | 0.344% (1 de 291) |
| CLOCK | 1 | 6 | 0.344% (1 de 291) |
| BRUSH | 1 | 6 | 0.344% (1 de 291) |
| FIRE_CHARGE | 2-6 | 6 | 0.344% (1 de 291) |
| COPPER_HOE | 1 | 5 | 0.286% (1 de 349) |
| GOLDEN_PICKAXE | 1 | 5 | 0.286% (1 de 349) |
| GOLDEN_AXE | 1 | 5 | 0.286% (1 de 349) |
| GOLDEN_SHOVEL | 1 | 5 | 0.286% (1 de 349) |
| LAVA_BUCKET | 1 | 5 | 0.286% (1 de 349) |
| SPYGLASS | 1 | 5 | 0.286% (1 de 349) |
| GOLDEN_HOE | 1 | 4 | 0.229% (1 de 437) |
| BUNDLE | 1 | 4 | 0.229% (1 de 437) |
| CARROT_ON_A_STICK | 1 | 4 | 0.229% (1 de 437) |
| POWDER_SNOW_BUCKET | 1 | 3 | 0.172% (1 de 582) |
| WARPED_FUNGUS_ON_A_STICK | 1 | 3 | 0.172% (1 de 582) |
| COD_BUCKET | 1 | 2 | 0.115% (1 de 873) |
| SALMON_BUCKET | 1 | 2 | 0.115% (1 de 873) |
| TROPICAL_FISH_BUCKET | 1 | 2 | 0.115% (1 de 873) |
| PUFFERFISH_BUCKET | 1 | 2 | 0.115% (1 de 873) |
| TADPOLE_BUCKET | 1 | 2 | 0.115% (1 de 873) |

### Combate — 7.04%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| IRON_SWORD | 1 | 8 | 0.458% (1 de 218) |
| BOW | 1 | 8 | 0.458% (1 de 218) |
| SHIELD | 1 | 8 | 0.458% (1 de 218) |
| CROSSBOW | 1 | 6 | 0.344% (1 de 291) |
| COPPER_SWORD | 1 | 5 | 0.286% (1 de 349) |
| IRON_SPEAR | 1 | 5 | 0.286% (1 de 349) |
| SPECTRAL_ARROW | 4-16 | 5 | 0.286% (1 de 349) |
| WIND_CHARGE | 2-8 | 5 | 0.286% (1 de 349) |
| TNT | 1-4 | 5 | 0.286% (1 de 349) |
| GOLDEN_SWORD | 1 | 4 | 0.229% (1 de 437) |
| COPPER_SPEAR | 1 | 4 | 0.229% (1 de 437) |
| IRON_HELMET | 1 | 4 | 0.229% (1 de 437) |
| IRON_CHESTPLATE | 1 | 4 | 0.229% (1 de 437) |
| IRON_LEGGINGS | 1 | 4 | 0.229% (1 de 437) |
| IRON_BOOTS | 1 | 4 | 0.229% (1 de 437) |
| GOLDEN_SPEAR | 1 | 3 | 0.172% (1 de 582) |
| CHAINMAIL_HELMET | 1 | 3 | 0.172% (1 de 582) |
| CHAINMAIL_CHESTPLATE | 1 | 3 | 0.172% (1 de 582) |
| CHAINMAIL_LEGGINGS | 1 | 3 | 0.172% (1 de 582) |
| CHAINMAIL_BOOTS | 1 | 3 | 0.172% (1 de 582) |
| COPPER_HELMET | 1 | 3 | 0.172% (1 de 582) |
| COPPER_CHESTPLATE | 1 | 3 | 0.172% (1 de 582) |
| COPPER_LEGGINGS | 1 | 3 | 0.172% (1 de 582) |
| COPPER_BOOTS | 1 | 3 | 0.172% (1 de 582) |
| LEATHER_HORSE_ARMOR | 1 | 3 | 0.172% (1 de 582) |
| BLUE_EGG | 2-8 | 2 | 0.115% (1 de 873) |
| BROWN_EGG | 2-8 | 2 | 0.115% (1 de 873) |
| GOLDEN_HELMET | 1 | 2 | 0.115% (1 de 873) |
| GOLDEN_CHESTPLATE | 1 | 2 | 0.115% (1 de 873) |
| GOLDEN_LEGGINGS | 1 | 2 | 0.115% (1 de 873) |
| GOLDEN_BOOTS | 1 | 2 | 0.115% (1 de 873) |
| COPPER_NAUTILUS_ARMOR | 1 | 2 | 0.115% (1 de 873) |

### Comida y bebida — 5.61%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| COOKED_BEEF | 2-8 | 10 | 0.573% (1 de 175) |
| COOKED_PORKCHOP | 2-8 | 10 | 0.573% (1 de 175) |
| COOKED_CHICKEN | 2-8 | 8 | 0.458% (1 de 218) |
| COOKED_MUTTON | 2-8 | 7 | 0.401% (1 de 249) |
| COOKED_COD | 2-8 | 6 | 0.344% (1 de 291) |
| COOKED_SALMON | 2-8 | 6 | 0.344% (1 de 291) |
| PUMPKIN_PIE | 1-4 | 6 | 0.344% (1 de 291) |
| COOKED_RABBIT | 2-6 | 5 | 0.286% (1 de 349) |
| HONEY_BOTTLE | 1-4 | 5 | 0.286% (1 de 349) |
| CAKE | 1 | 4 | 0.229% (1 de 437) |
| MILK_BUCKET | 1 | 4 | 0.229% (1 de 437) |
| MUSHROOM_STEW | 1 | 4 | 0.229% (1 de 437) |
| BEETROOT_SOUP | 1 | 3 | 0.172% (1 de 582) |
| RABBIT_STEW | 1 | 3 | 0.172% (1 de 582) |
| POTION (swiftness) | 1 | 3 | 0.172% (1 de 582) |
| POTION (leaping) | 1 | 3 | 0.172% (1 de 582) |
| POTION (fire_resistance) | 1 | 3 | 0.172% (1 de 582) |
| POTION (night_vision) | 1 | 3 | 0.172% (1 de 582) |
| POTION (water_breathing) | 1 | 3 | 0.172% (1 de 582) |
| SUSPICIOUS_STEW | 1 | 2 | 0.115% (1 de 873) |

### Ingredientes — 5.73%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| IRON_INGOT | 2-6 | 10 | 0.573% (1 de 175) |
| RAW_IRON | 2-6 | 8 | 0.458% (1 de 218) |
| LAPIS_LAZULI | 3-9 | 8 | 0.458% (1 de 218) |
| GOLD_INGOT | 1-4 | 7 | 0.401% (1 de 249) |
| RAW_GOLD | 1-4 | 6 | 0.344% (1 de 291) |
| QUARTZ | 2-8 | 6 | 0.344% (1 de 291) |
| BOOK | 1-3 | 6 | 0.344% (1 de 291) |
| AMETHYST_SHARD | 2-6 | 5 | 0.286% (1 de 349) |
| GLOWSTONE_DUST | 2-8 | 5 | 0.286% (1 de 349) |
| BLAZE_POWDER | 1-4 | 5 | 0.286% (1 de 349) |
| HONEYCOMB | 1-4 | 4 | 0.229% (1 de 437) |
| GLOW_INK_SAC | 1-4 | 4 | 0.229% (1 de 437) |
| MAGMA_CREAM | 1-3 | 4 | 0.229% (1 de 437) |
| PRISMARINE_SHARD | 2-6 | 3 | 0.172% (1 de 582) |
| PRISMARINE_CRYSTALS | 2-6 | 3 | 0.172% (1 de 582) |
| FERMENTED_SPIDER_EYE | 1-3 | 3 | 0.172% (1 de 582) |
| GLISTERING_MELON_SLICE | 1-2 | 3 | 0.172% (1 de 582) |
| PHANTOM_MEMBRANE | 1-2 | 3 | 0.172% (1 de 582) |
| ARMADILLO_SCUTE | 1-2 | 3 | 0.172% (1 de 582) |
| POPPED_CHORUS_FRUIT | 2-6 | 2 | 0.115% (1 de 873) |
| RESIN_BRICK | 2-6 | 2 | 0.115% (1 de 873) |

## Raro — 14.00% (118 premios)

### Herramientas y utilidades — 3.73%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| NAME_TAG | 1-2 | 8 | 0.543% (1 de 184) |
| SADDLE | 1 | 7 | 0.475% (1 de 211) |
| ENDER_EYE | 1-3 | 7 | 0.475% (1 de 211) |
| AXOLOTL_BUCKET | 1 | 3 | 0.204% (1 de 491) |
| RECOVERY_COMPASS | 1 | 3 | 0.204% (1 de 491) |
| GOAT_HORN | 1 | 3 | 0.204% (1 de 491) |
| MUSIC_DISC_13 | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_CAT | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_BLOCKS | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_CHIRP | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_FAR | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_MALL | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_MELLOHI | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_STAL | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_STRAD | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_WARD | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_11 | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_WAIT | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_CREATOR_MUSIC_BOX | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_PRECIPICE | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_TEARS | 1 | 1 | 0.068% (1 de 1,474) |
| MUSIC_DISC_LAVA_CHICKEN | 1 | 1 | 0.068% (1 de 1,474) |
| WHITE_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| ORANGE_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| MAGENTA_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| LIGHT_BLUE_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| YELLOW_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| LIME_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| PINK_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| GRAY_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| LIGHT_GRAY_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| CYAN_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| PURPLE_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| BLUE_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| BROWN_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| GREEN_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| RED_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |
| BLACK_HARNESS | 1 | 0.5 | 0.034% (1 de 2,947) |

### Combate — 2.04%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| TURTLE_HELMET | 1 | 4 | 0.271% (1 de 368) |
| WOLF_ARMOR | 1 | 4 | 0.271% (1 de 368) |
| END_CRYSTAL | 1-2 | 4 | 0.271% (1 de 368) |
| IRON_HORSE_ARMOR | 1 | 3 | 0.204% (1 de 491) |
| GOLDEN_HORSE_ARMOR | 1 | 3 | 0.204% (1 de 491) |
| IRON_NAUTILUS_ARMOR | 1 | 2 | 0.136% (1 de 737) |
| GOLDEN_NAUTILUS_ARMOR | 1 | 2 | 0.136% (1 de 737) |
| TIPPED_ARROW (poison) | 4-12 | 2 | 0.136% (1 de 737) |
| TIPPED_ARROW (slowness) | 4-12 | 2 | 0.136% (1 de 737) |
| TIPPED_ARROW (weakness) | 4-12 | 2 | 0.136% (1 de 737) |
| TIPPED_ARROW (harming) | 4-12 | 2 | 0.136% (1 de 737) |

### Comida y bebida — 2.44%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| GOLDEN_CARROT | 2-6 | 10 | 0.679% (1 de 147) |
| GOLDEN_APPLE | 1-2 | 8 | 0.543% (1 de 184) |
| POTION (strength) | 1 | 3 | 0.204% (1 de 491) |
| POTION (regeneration) | 1 | 3 | 0.204% (1 de 491) |
| POTION (healing) | 1 | 3 | 0.204% (1 de 491) |
| POTION (invisibility) | 1 | 2 | 0.136% (1 de 737) |
| POTION (slow_falling) | 1 | 2 | 0.136% (1 de 737) |
| POTION (long_fire_resistance) | 1 | 2 | 0.136% (1 de 737) |
| SPLASH_POTION (healing) | 1 | 2 | 0.136% (1 de 737) |
| POTION (turtle_master) | 1 | 1 | 0.068% (1 de 1,474) |

### Ingredientes — 5.79%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| EMERALD | 3-8 | 10 | 0.679% (1 de 147) |
| EXPERIENCE_BOTTLE | 4-12 | 8 | 0.543% (1 de 184) |
| ENCHANTED_BOOK [encantamiento al azar] | 1 | 8 | 0.543% (1 de 184) |
| BLAZE_ROD | 1-3 | 6 | 0.407% (1 de 246) |
| BREEZE_ROD | 1-3 | 4 | 0.271% (1 de 368) |
| GHAST_TEAR | 1-2 | 4 | 0.271% (1 de 368) |
| TRIAL_KEY | 1-2 | 4 | 0.271% (1 de 368) |
| RABBIT_FOOT | 1 | 3 | 0.204% (1 de 491) |
| TURTLE_SCUTE | 1-2 | 3 | 0.204% (1 de 491) |
| NAUTILUS_SHELL | 1-2 | 3 | 0.204% (1 de 491) |
| SHULKER_SHELL | 1-2 | 3 | 0.204% (1 de 491) |
| ECHO_SHARD | 1-2 | 3 | 0.204% (1 de 491) |
| DISC_FRAGMENT_5 | 1-3 | 2 | 0.136% (1 de 737) |
| COAST_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| DUNE_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| WILD_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| SENTRY_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| TIDE_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| SNOUT_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| RIB_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| WAYFINDER_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| SHAPER_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| RAISER_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| HOST_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| BOLT_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| FLOW_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.041% (1 de 2,456) |
| ANGLER_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| ARCHER_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| ARMS_UP_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| BLADE_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| BREWER_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| BURN_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| DANGER_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| EXPLORER_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| FLOW_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| FRIEND_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| GUSTER_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| HEART_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| HEARTBREAK_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| HOWL_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| MINER_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| MOURNER_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| PLENTY_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| PRIZE_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| SCRAPE_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| SHEAF_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| SHELTER_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| SKULL_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| SNORT_POTTERY_SHERD | 1 | 0.5 | 0.034% (1 de 2,947) |
| FLOWER_BANNER_PATTERN | 1 | 0.5 | 0.034% (1 de 2,947) |
| CREEPER_BANNER_PATTERN | 1 | 0.5 | 0.034% (1 de 2,947) |
| SKULL_BANNER_PATTERN | 1 | 0.5 | 0.034% (1 de 2,947) |
| MOJANG_BANNER_PATTERN | 1 | 0.5 | 0.034% (1 de 2,947) |
| GLOBE_BANNER_PATTERN | 1 | 0.5 | 0.034% (1 de 2,947) |
| PIGLIN_BANNER_PATTERN | 1 | 0.5 | 0.034% (1 de 2,947) |
| FLOW_BANNER_PATTERN | 1 | 0.5 | 0.034% (1 de 2,947) |
| GUSTER_BANNER_PATTERN | 1 | 0.5 | 0.034% (1 de 2,947) |
| FIELD_MASONED_BANNER_PATTERN | 1 | 0.5 | 0.034% (1 de 2,947) |
| BORDURE_INDENTED_BANNER_PATTERN | 1 | 0.5 | 0.034% (1 de 2,947) |

## Épico — 6.50% (42 premios)

### Herramientas y utilidades — 1.60%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| DIAMOND_PICKAXE | 1 | 6 | 0.283% (1 de 354) |
| DIAMOND_AXE | 1 | 5 | 0.236% (1 de 425) |
| DIAMOND_SHOVEL | 1 | 5 | 0.236% (1 de 425) |
| DIAMOND_PICKAXE [efficiency 5, unbreaking 3, fortune 3] "Pico de la Suerte" | 1 | 5 | 0.236% (1 de 425) |
| DIAMOND_HOE | 1 | 3 | 0.141% (1 de 708) |
| MUSIC_DISC_PIGSTEP | 1 | 2 | 0.094% (1 de 1,062) |
| MUSIC_DISC_OTHERSIDE | 1 | 2 | 0.094% (1 de 1,062) |
| MUSIC_DISC_RELIC | 1 | 2 | 0.094% (1 de 1,062) |
| MUSIC_DISC_CREATOR | 1 | 2 | 0.094% (1 de 1,062) |
| MUSIC_DISC_5 | 1 | 2 | 0.094% (1 de 1,062) |

### Combate — 2.07%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| DIAMOND_SWORD | 1 | 6 | 0.283% (1 de 354) |
| TOTEM_OF_UNDYING | 1 | 6 | 0.283% (1 de 354) |
| TRIDENT | 1 | 5 | 0.236% (1 de 425) |
| DIAMOND_SPEAR | 1 | 4 | 0.188% (1 de 531) |
| DIAMOND_HELMET | 1 | 4 | 0.188% (1 de 531) |
| DIAMOND_BOOTS | 1 | 4 | 0.188% (1 de 531) |
| DIAMOND_SWORD [sharpness 5, unbreaking 3, looting 3] "Filo de la Fortuna" | 1 | 4 | 0.188% (1 de 531) |
| DIAMOND_CHESTPLATE | 1 | 3 | 0.141% (1 de 708) |
| DIAMOND_LEGGINGS | 1 | 3 | 0.141% (1 de 708) |
| DIAMOND_HORSE_ARMOR | 1 | 3 | 0.141% (1 de 708) |
| DIAMOND_NAUTILUS_ARMOR | 1 | 2 | 0.094% (1 de 1,062) |

### Comida y bebida — 0.99%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| GOLDEN_APPLE | 3-5 | 6 | 0.283% (1 de 354) |
| POTION (strong_strength) | 1 | 3 | 0.141% (1 de 708) |
| POTION (strong_regeneration) | 1 | 3 | 0.141% (1 de 708) |
| SPLASH_POTION (strong_healing) | 1 | 3 | 0.141% (1 de 708) |
| POTION (strong_swiftness) | 1 | 2 | 0.094% (1 de 1,062) |
| LINGERING_POTION (regeneration) | 1 | 2 | 0.094% (1 de 1,062) |
| OMINOUS_BOTTLE | 1 | 2 | 0.094% (1 de 1,062) |

### Ingredientes — 1.84%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| DIAMOND | 1-3 | 8 | 0.377% (1 de 265) |
| HEART_OF_THE_SEA | 1 | 5 | 0.236% (1 de 425) |
| DIAMOND | 4-8 | 5 | 0.236% (1 de 425) |
| OMINOUS_TRIAL_KEY | 1 | 4 | 0.188% (1 de 531) |
| ENCHANTED_BOOK [mending 1] | 1 | 4 | 0.188% (1 de 531) |
| ENCHANTED_BOOK [sharpness 5] | 1 | 2 | 0.094% (1 de 1,062) |
| ENCHANTED_BOOK [efficiency 5] | 1 | 2 | 0.094% (1 de 1,062) |
| ENCHANTED_BOOK [protection 4] | 1 | 2 | 0.094% (1 de 1,062) |
| ENCHANTED_BOOK [fortune 3] | 1 | 2 | 0.094% (1 de 1,062) |
| WARD_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 1 | 0.047% (1 de 2,123) |
| EYE_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 1 | 0.047% (1 de 2,123) |
| VEX_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 1 | 0.047% (1 de 2,123) |
| SPIRE_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 1 | 0.047% (1 de 2,123) |
| SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 1 | 0.047% (1 de 2,123) |

## Legendario — 0.10% (21 premios)

### Herramientas y utilidades — 0.02%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| NETHERITE_PICKAXE | 1 | 6 | 0.006% (1 de 16,667) |
| NETHERITE_AXE | 1 | 5 | 0.005% (1 de 20,000) |
| NETHERITE_SHOVEL | 1 | 5 | 0.005% (1 de 20,000) |
| NETHERITE_HOE | 1 | 3 | 0.003% (1 de 33,333) |
| NETHERITE_PICKAXE [efficiency 5, unbreaking 3, fortune 3, mending 1] "Pico del Apostador" | 1 | 3 | 0.003% (1 de 33,333) |

### Combate — 0.04%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| NETHERITE_SWORD | 1 | 6 | 0.006% (1 de 16,667) |
| MACE | 1 | 5 | 0.005% (1 de 20,000) |
| NETHERITE_SPEAR | 1 | 4 | 0.004% (1 de 25,000) |
| NETHERITE_HELMET | 1 | 4 | 0.004% (1 de 25,000) |
| NETHERITE_BOOTS | 1 | 4 | 0.004% (1 de 25,000) |
| NETHERITE_CHESTPLATE | 1 | 3 | 0.003% (1 de 33,333) |
| NETHERITE_LEGGINGS | 1 | 3 | 0.003% (1 de 33,333) |
| NETHERITE_HORSE_ARMOR | 1 | 3 | 0.003% (1 de 33,333) |
| NETHERITE_NAUTILUS_ARMOR | 1 | 3 | 0.003% (1 de 33,333) |
| NETHERITE_SWORD [sharpness 5, unbreaking 3, looting 3, fire_aspect 2, mending 1] "Espada del Apostador" | 1 | 3 | 0.003% (1 de 33,333) |

### Comida y bebida — 0.008%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| ENCHANTED_GOLDEN_APPLE | 1-2 | 8 | 0.008% (1 de 12,500) |

### Ingredientes — 0.03%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| NETHERITE_SCRAP | 1-2 | 10 | 0.010% (1 de 10,000) |
| NETHERITE_INGOT | 1 | 8 | 0.008% (1 de 12,500) |
| NETHER_STAR | 1 | 5 | 0.005% (1 de 20,000) |
| NETHERITE_UPGRADE_SMITHING_TEMPLATE | 1 | 5 | 0.005% (1 de 20,000) |
| HEAVY_CORE | 1 | 4 | 0.004% (1 de 25,000) |

## Mítico — 0.01% (9 premios)

### Herramientas y utilidades — 0.00083%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| ELYTRA | 1 | 2 | 0.00083% (1 de 120,000) |

### Combate — 0.00917%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| DIAMOND_HELMET [unbreaking 3, mending 1] [+2 al azar de: protection, fire_protection, blast_protection, projectile_protection] | 1 | 3 | 0.00125% (1 de 80,000) |
| DIAMOND_CHESTPLATE [unbreaking 3, mending 1] [+2 al azar de: protection, fire_protection, blast_protection, projectile_protection] | 1 | 3 | 0.00125% (1 de 80,000) |
| DIAMOND_LEGGINGS [unbreaking 3, mending 1] [+2 al azar de: protection, fire_protection, blast_protection, projectile_protection] | 1 | 3 | 0.00125% (1 de 80,000) |
| DIAMOND_BOOTS [unbreaking 3, mending 1] [+2 al azar de: protection, fire_protection, blast_protection, projectile_protection] | 1 | 3 | 0.00125% (1 de 80,000) |
| NETHERITE_HELMET [unbreaking 3, mending 1] [+2 al azar de: protection, fire_protection, blast_protection, projectile_protection] | 1 | 2.5 | 0.00104% (1 de 96,000) |
| NETHERITE_CHESTPLATE [unbreaking 3, mending 1] [+2 al azar de: protection, fire_protection, blast_protection, projectile_protection] | 1 | 2.5 | 0.00104% (1 de 96,000) |
| NETHERITE_LEGGINGS [unbreaking 3, mending 1] [+2 al azar de: protection, fire_protection, blast_protection, projectile_protection] | 1 | 2.5 | 0.00104% (1 de 96,000) |
| NETHERITE_BOOTS [unbreaking 3, mending 1] [+2 al azar de: protection, fire_protection, blast_protection, projectile_protection] | 1 | 2.5 | 0.00104% (1 de 96,000) |

## Imposible — 0.0001% (4 premios)

### Combate — 0.0001%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| NETHERITE_HELMET [protection 4, fire_protection 4, blast_protection 4, projectile_protection 4, unbreaking 3, mending 1, respiration 3, aqua_affinity 1] "☠ Casco de Dios ☠" | 1 | 1 | 0.00002% (1 de 4,000,000) |
| NETHERITE_CHESTPLATE [protection 4, fire_protection 4, blast_protection 4, projectile_protection 4, unbreaking 3, mending 1] "☠ Peto de Dios ☠" | 1 | 1 | 0.00002% (1 de 4,000,000) |
| NETHERITE_LEGGINGS [protection 4, fire_protection 4, blast_protection 4, projectile_protection 4, unbreaking 3, mending 1, swift_sneak 3] "☠ Pantalones de Dios ☠" | 1 | 1 | 0.00002% (1 de 4,000,000) |
| NETHERITE_BOOTS [protection 4, fire_protection 4, blast_protection 4, projectile_protection 4, unbreaking 3, mending 1, feather_falling 4, depth_strider 3, soul_speed 3] "☠ Botas de Dios ☠" | 1 | 1 | 0.00002% (1 de 4,000,000) |
