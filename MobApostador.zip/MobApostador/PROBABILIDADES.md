# Tabla de probabilidades - MobApostador

Cada apuesta hace **una tirada en dos pasos**: primero se elige la rareza y luego un premio dentro de ella según su peso.

`Probabilidad del premio = probabilidad de la rareza × peso ÷ suma de pesos de esa rareza`

Los ítems comunes dan **más cantidad** (rangos como 8-32); los raros, épicos y legendarios casi siempre dan 1.

## Resumen por rareza

| Rareza | Probabilidad | Premios | Herramientas | Combate | Comida y bebida | Ingredientes |
|---|---:|---:|---:|---:|---:|---:|
| Común | **49.98%** | 90 | 10.06% | 7.19% | 15.70% | 17.03% |
| Poco común | **28.00%** | 105 | 9.62% | 7.04% | 5.61% | 5.73% |
| Raro | **14.00%** | 131 | 4.16% | 3.08% | 1.85% | 4.90% |
| Épico | **6.50%** | 42 | 1.66% | 1.91% | 1.03% | 1.91% |
| Legendario | **1.50%** | 8 | 0.11% | 0.29% | 0.29% | 0.80% |
| Mítico | **0.02%** | 1 | 0.02% | 0.00% | 0.00% | 0.00% |
| **Total** | 100% | 377 | 25.64% | 19.51% | 24.48% | 30.37% |

Comprobación con 1,000,000 tiradas simuladas: Común 49.96%, Poco común 28.06%, Raro 13.97%, Épico 6.50%, Legendario 1.48%, Mítico 0.02%.

## Apuestas x5 y x10

Cada tirada de una apuesta múltiple es independiente y usa exactamente las mismas probabilidades. Probabilidad de sacar **al menos un** premio de cada rareza:

| Rareza | x1 | x5 | x10 |
|---|---:|---:|---:|
| Mítico | 0.02% | 0.10% | 0.20% |
| Legendario | 1.50% | 7.28% | 14.03% |
| Épico | 6.50% | 28.54% | 48.94% |
| Raro | 14.00% | 52.96% | 77.87% |
| Poco común | 28.00% | 80.65% | 96.26% |
| Común | 49.98% | 96.87% | 99.90% |
| Épico **o mejor** | 8.02% | 34.16% | 56.66% |

## Legendario garantizado cada 667 giros

Cada jugador tiene un contador de giros (cada tirada suma 1; x5 suma 5 y x10 suma 10). Los giros número 667, 1334, 2001… dan siempre un premio **Legendario** elegido con los mismos pesos de esa rareza.

| | Sin garantía | Con garantía cada 667 |
|---|---:|---:|
| Legendario por giro | 1.50% | 1.65% |
| Legendarios esperados en 667 giros | 10.01 | 10.99 |

Con `reiniciar-con-suerte: true` (estilo *pity*), el contador vuelve a 0 con cada Legendario por suerte; como el 1.5% sale en promedio cada 67 giros, llegar a 667 sin ninguno pasa solo el 0.0043% de las veces.

> Nota: si un ítem no existe en la versión de tu servidor, se omite y los porcentajes de su rareza se reparten entre los demás. En el juego, `/apostador probabilidades` muestra siempre los valores reales.

## Común — 49.98% (90 premios)

### Herramientas y utilidades — 10.06%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| BONE_MEAL | 8-24 | 10 | 1.11% |
| STONE_PICKAXE | 1 | 8 | 0.885% |
| STONE_AXE | 1 | 8 | 0.885% |
| STONE_SHOVEL | 1 | 8 | 0.885% |
| BUCKET | 1-2 | 8 | 0.885% |
| WOODEN_PICKAXE | 1 | 6 | 0.663% |
| WOODEN_AXE | 1 | 6 | 0.663% |
| WOODEN_SHOVEL | 1 | 6 | 0.663% |
| STONE_HOE | 1 | 6 | 0.663% |
| FISHING_ROD | 1 | 6 | 0.663% |
| LEAD | 1-3 | 6 | 0.663% |
| WOODEN_HOE | 1 | 5 | 0.553% |
| MAP | 1-3 | 4 | 0.442% |
| WRITABLE_BOOK | 1 | 4 | 0.442% |

### Combate — 7.19%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| ARROW | 8-32 | 12 | 1.33% |
| STONE_SWORD | 1 | 8 | 0.885% |
| SNOWBALL | 4-16 | 8 | 0.885% |
| WOODEN_SWORD | 1 | 6 | 0.663% |
| EGG | 2-8 | 6 | 0.663% |
| STONE_SPEAR | 1 | 5 | 0.553% |
| WOODEN_SPEAR | 1 | 4 | 0.442% |
| LEATHER_HELMET | 1 | 4 | 0.442% |
| LEATHER_CHESTPLATE | 1 | 4 | 0.442% |
| LEATHER_LEGGINGS | 1 | 4 | 0.442% |
| LEATHER_BOOTS | 1 | 4 | 0.442% |

### Comida y bebida — 15.70%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| APPLE | 2-8 | 10 | 1.11% |
| BREAD | 2-8 | 10 | 1.11% |
| MELON_SLICE | 4-16 | 8 | 0.885% |
| SWEET_BERRIES | 4-16 | 8 | 0.885% |
| CARROT | 4-16 | 8 | 0.885% |
| POTATO | 4-16 | 8 | 0.885% |
| BAKED_POTATO | 4-12 | 8 | 0.885% |
| GLOW_BERRIES | 4-12 | 6 | 0.663% |
| BEETROOT | 4-12 | 6 | 0.663% |
| COOKIE | 4-16 | 6 | 0.663% |
| DRIED_KELP | 8-24 | 6 | 0.663% |
| BEEF | 2-8 | 6 | 0.663% |
| PORKCHOP | 2-8 | 6 | 0.663% |
| MUTTON | 2-8 | 6 | 0.663% |
| CHICKEN | 2-8 | 6 | 0.663% |
| ROTTEN_FLESH | 4-16 | 6 | 0.663% |
| COD | 2-8 | 5 | 0.553% |
| SALMON | 2-8 | 5 | 0.553% |
| RABBIT | 1-4 | 4 | 0.442% |
| CHORUS_FRUIT | 2-8 | 4 | 0.442% |
| TROPICAL_FISH | 1-4 | 3 | 0.332% |
| SPIDER_EYE | 1-4 | 3 | 0.332% |
| PUFFERFISH | 1-3 | 2 | 0.221% |
| POISONOUS_POTATO | 1-4 | 2 | 0.221% |

### Ingredientes — 17.03%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| STICK | 8-32 | 10 | 1.11% |
| COAL | 4-16 | 10 | 1.11% |
| WHEAT | 4-16 | 8 | 0.885% |
| CHARCOAL | 4-16 | 6 | 0.663% |
| FLINT | 2-8 | 6 | 0.663% |
| BONE | 2-8 | 6 | 0.663% |
| STRING | 2-8 | 6 | 0.663% |
| FEATHER | 2-8 | 6 | 0.663% |
| LEATHER | 2-6 | 6 | 0.663% |
| PAPER | 4-12 | 6 | 0.663% |
| IRON_NUGGET | 4-16 | 6 | 0.663% |
| RAW_COPPER | 2-8 | 6 | 0.663% |
| COPPER_INGOT | 2-8 | 6 | 0.663% |
| GUNPOWDER | 2-6 | 6 | 0.663% |
| CLAY_BALL | 4-16 | 5 | 0.553% |
| GOLD_NUGGET | 4-16 | 5 | 0.553% |
| SUGAR | 2-8 | 5 | 0.553% |
| BRICK | 4-16 | 4 | 0.442% |
| COPPER_NUGGET | 4-16 | 4 | 0.442% |
| GLASS_BOTTLE | 2-6 | 4 | 0.442% |
| INK_SAC | 2-6 | 4 | 0.442% |
| SLIME_BALL | 1-4 | 4 | 0.442% |
| BOWL | 2-8 | 3 | 0.332% |
| NETHER_BRICK | 4-16 | 3 | 0.332% |
| RABBIT_HIDE | 1-4 | 3 | 0.332% |
| WHITE_DYE | 2-8 | 1 | 0.111% |
| ORANGE_DYE | 2-8 | 1 | 0.111% |
| MAGENTA_DYE | 2-8 | 1 | 0.111% |
| LIGHT_BLUE_DYE | 2-8 | 1 | 0.111% |
| YELLOW_DYE | 2-8 | 1 | 0.111% |
| LIME_DYE | 2-8 | 1 | 0.111% |
| PINK_DYE | 2-8 | 1 | 0.111% |
| GRAY_DYE | 2-8 | 1 | 0.111% |
| LIGHT_GRAY_DYE | 2-8 | 1 | 0.111% |
| CYAN_DYE | 2-8 | 1 | 0.111% |
| PURPLE_DYE | 2-8 | 1 | 0.111% |
| BLUE_DYE | 2-8 | 1 | 0.111% |
| BROWN_DYE | 2-8 | 1 | 0.111% |
| GREEN_DYE | 2-8 | 1 | 0.111% |
| RED_DYE | 2-8 | 1 | 0.111% |
| BLACK_DYE | 2-8 | 1 | 0.111% |

## Poco común — 28.00% (105 premios)

### Herramientas y utilidades — 9.62%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| IRON_PICKAXE | 1 | 8 | 0.458% |
| IRON_AXE | 1 | 8 | 0.458% |
| IRON_SHOVEL | 1 | 8 | 0.458% |
| SHEARS | 1 | 8 | 0.458% |
| FLINT_AND_STEEL | 1 | 8 | 0.458% |
| ENDER_PEARL | 2-4 | 8 | 0.458% |
| FIREWORK_ROCKET | 8-24 | 8 | 0.458% |
| IRON_HOE | 1 | 6 | 0.344% |
| COPPER_PICKAXE | 1 | 6 | 0.344% |
| COPPER_AXE | 1 | 6 | 0.344% |
| COPPER_SHOVEL | 1 | 6 | 0.344% |
| WATER_BUCKET | 1 | 6 | 0.344% |
| COMPASS | 1 | 6 | 0.344% |
| CLOCK | 1 | 6 | 0.344% |
| BRUSH | 1 | 6 | 0.344% |
| FIRE_CHARGE | 2-6 | 6 | 0.344% |
| COPPER_HOE | 1 | 5 | 0.286% |
| GOLDEN_PICKAXE | 1 | 5 | 0.286% |
| GOLDEN_AXE | 1 | 5 | 0.286% |
| GOLDEN_SHOVEL | 1 | 5 | 0.286% |
| LAVA_BUCKET | 1 | 5 | 0.286% |
| SPYGLASS | 1 | 5 | 0.286% |
| GOLDEN_HOE | 1 | 4 | 0.229% |
| BUNDLE | 1 | 4 | 0.229% |
| CARROT_ON_A_STICK | 1 | 4 | 0.229% |
| POWDER_SNOW_BUCKET | 1 | 3 | 0.172% |
| WARPED_FUNGUS_ON_A_STICK | 1 | 3 | 0.172% |
| COD_BUCKET | 1 | 2 | 0.115% |
| SALMON_BUCKET | 1 | 2 | 0.115% |
| TROPICAL_FISH_BUCKET | 1 | 2 | 0.115% |
| PUFFERFISH_BUCKET | 1 | 2 | 0.115% |
| TADPOLE_BUCKET | 1 | 2 | 0.115% |

### Combate — 7.04%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| IRON_SWORD | 1 | 8 | 0.458% |
| BOW | 1 | 8 | 0.458% |
| SHIELD | 1 | 8 | 0.458% |
| CROSSBOW | 1 | 6 | 0.344% |
| COPPER_SWORD | 1 | 5 | 0.286% |
| IRON_SPEAR | 1 | 5 | 0.286% |
| SPECTRAL_ARROW | 4-16 | 5 | 0.286% |
| WIND_CHARGE | 2-8 | 5 | 0.286% |
| TNT | 1-4 | 5 | 0.286% |
| GOLDEN_SWORD | 1 | 4 | 0.229% |
| COPPER_SPEAR | 1 | 4 | 0.229% |
| IRON_HELMET | 1 | 4 | 0.229% |
| IRON_CHESTPLATE | 1 | 4 | 0.229% |
| IRON_LEGGINGS | 1 | 4 | 0.229% |
| IRON_BOOTS | 1 | 4 | 0.229% |
| GOLDEN_SPEAR | 1 | 3 | 0.172% |
| CHAINMAIL_HELMET | 1 | 3 | 0.172% |
| CHAINMAIL_CHESTPLATE | 1 | 3 | 0.172% |
| CHAINMAIL_LEGGINGS | 1 | 3 | 0.172% |
| CHAINMAIL_BOOTS | 1 | 3 | 0.172% |
| COPPER_HELMET | 1 | 3 | 0.172% |
| COPPER_CHESTPLATE | 1 | 3 | 0.172% |
| COPPER_LEGGINGS | 1 | 3 | 0.172% |
| COPPER_BOOTS | 1 | 3 | 0.172% |
| LEATHER_HORSE_ARMOR | 1 | 3 | 0.172% |
| BLUE_EGG | 2-8 | 2 | 0.115% |
| BROWN_EGG | 2-8 | 2 | 0.115% |
| GOLDEN_HELMET | 1 | 2 | 0.115% |
| GOLDEN_CHESTPLATE | 1 | 2 | 0.115% |
| GOLDEN_LEGGINGS | 1 | 2 | 0.115% |
| GOLDEN_BOOTS | 1 | 2 | 0.115% |
| COPPER_NAUTILUS_ARMOR | 1 | 2 | 0.115% |

### Comida y bebida — 5.61%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| COOKED_BEEF | 2-8 | 10 | 0.573% |
| COOKED_PORKCHOP | 2-8 | 10 | 0.573% |
| COOKED_CHICKEN | 2-8 | 8 | 0.458% |
| COOKED_MUTTON | 2-8 | 7 | 0.401% |
| COOKED_COD | 2-8 | 6 | 0.344% |
| COOKED_SALMON | 2-8 | 6 | 0.344% |
| PUMPKIN_PIE | 1-4 | 6 | 0.344% |
| COOKED_RABBIT | 2-6 | 5 | 0.286% |
| HONEY_BOTTLE | 1-4 | 5 | 0.286% |
| CAKE | 1 | 4 | 0.229% |
| MILK_BUCKET | 1 | 4 | 0.229% |
| MUSHROOM_STEW | 1 | 4 | 0.229% |
| BEETROOT_SOUP | 1 | 3 | 0.172% |
| RABBIT_STEW | 1 | 3 | 0.172% |
| POTION (swiftness) | 1 | 3 | 0.172% |
| POTION (leaping) | 1 | 3 | 0.172% |
| POTION (fire_resistance) | 1 | 3 | 0.172% |
| POTION (night_vision) | 1 | 3 | 0.172% |
| POTION (water_breathing) | 1 | 3 | 0.172% |
| SUSPICIOUS_STEW | 1 | 2 | 0.115% |

### Ingredientes — 5.73%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| IRON_INGOT | 2-6 | 10 | 0.573% |
| RAW_IRON | 2-6 | 8 | 0.458% |
| LAPIS_LAZULI | 3-9 | 8 | 0.458% |
| GOLD_INGOT | 1-4 | 7 | 0.401% |
| RAW_GOLD | 1-4 | 6 | 0.344% |
| QUARTZ | 2-8 | 6 | 0.344% |
| BOOK | 1-3 | 6 | 0.344% |
| AMETHYST_SHARD | 2-6 | 5 | 0.286% |
| GLOWSTONE_DUST | 2-8 | 5 | 0.286% |
| BLAZE_POWDER | 1-4 | 5 | 0.286% |
| HONEYCOMB | 1-4 | 4 | 0.229% |
| GLOW_INK_SAC | 1-4 | 4 | 0.229% |
| MAGMA_CREAM | 1-3 | 4 | 0.229% |
| PRISMARINE_SHARD | 2-6 | 3 | 0.172% |
| PRISMARINE_CRYSTALS | 2-6 | 3 | 0.172% |
| FERMENTED_SPIDER_EYE | 1-3 | 3 | 0.172% |
| GLISTERING_MELON_SLICE | 1-2 | 3 | 0.172% |
| PHANTOM_MEMBRANE | 1-2 | 3 | 0.172% |
| ARMADILLO_SCUTE | 1-2 | 3 | 0.172% |
| POPPED_CHORUS_FRUIT | 2-6 | 2 | 0.115% |
| RESIN_BRICK | 2-6 | 2 | 0.115% |

## Raro — 14.00% (131 premios)

### Herramientas y utilidades — 4.16%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| DIAMOND_PICKAXE | 1 | 8 | 0.411% |
| NAME_TAG | 1-2 | 8 | 0.411% |
| DIAMOND_AXE | 1 | 7 | 0.360% |
| DIAMOND_SHOVEL | 1 | 7 | 0.360% |
| SADDLE | 1 | 7 | 0.360% |
| ENDER_EYE | 1-3 | 7 | 0.360% |
| DIAMOND_HOE | 1 | 4 | 0.206% |
| AXOLOTL_BUCKET | 1 | 3 | 0.154% |
| RECOVERY_COMPASS | 1 | 3 | 0.154% |
| GOAT_HORN | 1 | 3 | 0.154% |
| MUSIC_DISC_13 | 1 | 1 | 0.051% |
| MUSIC_DISC_CAT | 1 | 1 | 0.051% |
| MUSIC_DISC_BLOCKS | 1 | 1 | 0.051% |
| MUSIC_DISC_CHIRP | 1 | 1 | 0.051% |
| MUSIC_DISC_FAR | 1 | 1 | 0.051% |
| MUSIC_DISC_MALL | 1 | 1 | 0.051% |
| MUSIC_DISC_MELLOHI | 1 | 1 | 0.051% |
| MUSIC_DISC_STAL | 1 | 1 | 0.051% |
| MUSIC_DISC_STRAD | 1 | 1 | 0.051% |
| MUSIC_DISC_WARD | 1 | 1 | 0.051% |
| MUSIC_DISC_11 | 1 | 1 | 0.051% |
| MUSIC_DISC_WAIT | 1 | 1 | 0.051% |
| MUSIC_DISC_CREATOR_MUSIC_BOX | 1 | 1 | 0.051% |
| MUSIC_DISC_PRECIPICE | 1 | 1 | 0.051% |
| MUSIC_DISC_TEARS | 1 | 1 | 0.051% |
| MUSIC_DISC_LAVA_CHICKEN | 1 | 1 | 0.051% |
| WHITE_HARNESS | 1 | 0.5 | 0.026% |
| ORANGE_HARNESS | 1 | 0.5 | 0.026% |
| MAGENTA_HARNESS | 1 | 0.5 | 0.026% |
| LIGHT_BLUE_HARNESS | 1 | 0.5 | 0.026% |
| YELLOW_HARNESS | 1 | 0.5 | 0.026% |
| LIME_HARNESS | 1 | 0.5 | 0.026% |
| PINK_HARNESS | 1 | 0.5 | 0.026% |
| GRAY_HARNESS | 1 | 0.5 | 0.026% |
| LIGHT_GRAY_HARNESS | 1 | 0.5 | 0.026% |
| CYAN_HARNESS | 1 | 0.5 | 0.026% |
| PURPLE_HARNESS | 1 | 0.5 | 0.026% |
| BLUE_HARNESS | 1 | 0.5 | 0.026% |
| BROWN_HARNESS | 1 | 0.5 | 0.026% |
| GREEN_HARNESS | 1 | 0.5 | 0.026% |
| RED_HARNESS | 1 | 0.5 | 0.026% |
| BLACK_HARNESS | 1 | 0.5 | 0.026% |

### Combate — 3.08%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| DIAMOND_SWORD | 1 | 8 | 0.411% |
| DIAMOND_SPEAR | 1 | 5 | 0.257% |
| DIAMOND_HELMET | 1 | 4 | 0.206% |
| DIAMOND_BOOTS | 1 | 4 | 0.206% |
| TURTLE_HELMET | 1 | 4 | 0.206% |
| WOLF_ARMOR | 1 | 4 | 0.206% |
| END_CRYSTAL | 1-2 | 4 | 0.206% |
| DIAMOND_CHESTPLATE | 1 | 3 | 0.154% |
| DIAMOND_LEGGINGS | 1 | 3 | 0.154% |
| IRON_HORSE_ARMOR | 1 | 3 | 0.154% |
| GOLDEN_HORSE_ARMOR | 1 | 3 | 0.154% |
| DIAMOND_HORSE_ARMOR | 1 | 2 | 0.103% |
| IRON_NAUTILUS_ARMOR | 1 | 2 | 0.103% |
| GOLDEN_NAUTILUS_ARMOR | 1 | 2 | 0.103% |
| TIPPED_ARROW (poison) | 4-12 | 2 | 0.103% |
| TIPPED_ARROW (slowness) | 4-12 | 2 | 0.103% |
| TIPPED_ARROW (weakness) | 4-12 | 2 | 0.103% |
| TIPPED_ARROW (harming) | 4-12 | 2 | 0.103% |
| DIAMOND_NAUTILUS_ARMOR | 1 | 1 | 0.051% |

### Comida y bebida — 1.85%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| GOLDEN_CARROT | 2-6 | 10 | 0.514% |
| GOLDEN_APPLE | 1-2 | 8 | 0.411% |
| POTION (strength) | 1 | 3 | 0.154% |
| POTION (regeneration) | 1 | 3 | 0.154% |
| POTION (healing) | 1 | 3 | 0.154% |
| POTION (invisibility) | 1 | 2 | 0.103% |
| POTION (slow_falling) | 1 | 2 | 0.103% |
| POTION (long_fire_resistance) | 1 | 2 | 0.103% |
| SPLASH_POTION (healing) | 1 | 2 | 0.103% |
| POTION (turtle_master) | 1 | 1 | 0.051% |

### Ingredientes — 4.90%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| DIAMOND | 1-3 | 10 | 0.514% |
| EMERALD | 3-8 | 10 | 0.514% |
| EXPERIENCE_BOTTLE | 4-12 | 8 | 0.411% |
| ENCHANTED_BOOK [encantamiento al azar] | 1 | 8 | 0.411% |
| BLAZE_ROD | 1-3 | 6 | 0.308% |
| BREEZE_ROD | 1-3 | 4 | 0.206% |
| GHAST_TEAR | 1-2 | 4 | 0.206% |
| TRIAL_KEY | 1-2 | 4 | 0.206% |
| RABBIT_FOOT | 1 | 3 | 0.154% |
| TURTLE_SCUTE | 1-2 | 3 | 0.154% |
| NAUTILUS_SHELL | 1-2 | 3 | 0.154% |
| SHULKER_SHELL | 1-2 | 3 | 0.154% |
| ECHO_SHARD | 1-2 | 3 | 0.154% |
| DISC_FRAGMENT_5 | 1-3 | 2 | 0.103% |
| COAST_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| DUNE_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| WILD_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| SENTRY_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| TIDE_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| SNOUT_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| RIB_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| WAYFINDER_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| SHAPER_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| RAISER_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| HOST_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| BOLT_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| FLOW_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 0.6 | 0.031% |
| ANGLER_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| ARCHER_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| ARMS_UP_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| BLADE_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| BREWER_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| BURN_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| DANGER_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| EXPLORER_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| FLOW_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| FRIEND_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| GUSTER_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| HEART_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| HEARTBREAK_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| HOWL_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| MINER_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| MOURNER_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| PLENTY_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| PRIZE_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| SCRAPE_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| SHEAF_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| SHELTER_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| SKULL_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| SNORT_POTTERY_SHERD | 1 | 0.5 | 0.026% |
| FLOWER_BANNER_PATTERN | 1 | 0.5 | 0.026% |
| CREEPER_BANNER_PATTERN | 1 | 0.5 | 0.026% |
| SKULL_BANNER_PATTERN | 1 | 0.5 | 0.026% |
| MOJANG_BANNER_PATTERN | 1 | 0.5 | 0.026% |
| GLOBE_BANNER_PATTERN | 1 | 0.5 | 0.026% |
| PIGLIN_BANNER_PATTERN | 1 | 0.5 | 0.026% |
| FLOW_BANNER_PATTERN | 1 | 0.5 | 0.026% |
| GUSTER_BANNER_PATTERN | 1 | 0.5 | 0.026% |
| FIELD_MASONED_BANNER_PATTERN | 1 | 0.5 | 0.026% |
| BORDURE_INDENTED_BANNER_PATTERN | 1 | 0.5 | 0.026% |

## Épico — 6.50% (42 premios)

### Herramientas y utilidades — 1.66%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| NETHERITE_PICKAXE | 1 | 6 | 0.293% |
| NETHERITE_AXE | 1 | 5 | 0.244% |
| NETHERITE_SHOVEL | 1 | 5 | 0.244% |
| DIAMOND_PICKAXE [efficiency 5, unbreaking 3, fortune 3] "Pico de la Suerte" | 1 | 5 | 0.244% |
| NETHERITE_HOE | 1 | 3 | 0.147% |
| MUSIC_DISC_PIGSTEP | 1 | 2 | 0.098% |
| MUSIC_DISC_OTHERSIDE | 1 | 2 | 0.098% |
| MUSIC_DISC_RELIC | 1 | 2 | 0.098% |
| MUSIC_DISC_CREATOR | 1 | 2 | 0.098% |
| MUSIC_DISC_5 | 1 | 2 | 0.098% |

### Combate — 1.91%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| NETHERITE_SWORD | 1 | 6 | 0.293% |
| TOTEM_OF_UNDYING | 1 | 6 | 0.293% |
| TRIDENT | 1 | 5 | 0.244% |
| NETHERITE_SPEAR | 1 | 4 | 0.195% |
| DIAMOND_SWORD [sharpness 5, unbreaking 3, looting 3] "Filo de la Fortuna" | 1 | 4 | 0.195% |
| NETHERITE_HELMET | 1 | 3 | 0.147% |
| NETHERITE_BOOTS | 1 | 3 | 0.147% |
| NETHERITE_CHESTPLATE | 1 | 2 | 0.098% |
| NETHERITE_LEGGINGS | 1 | 2 | 0.098% |
| NETHERITE_HORSE_ARMOR | 1 | 2 | 0.098% |
| NETHERITE_NAUTILUS_ARMOR | 1 | 2 | 0.098% |

### Comida y bebida — 1.03%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| GOLDEN_APPLE | 3-5 | 6 | 0.293% |
| POTION (strong_strength) | 1 | 3 | 0.147% |
| POTION (strong_regeneration) | 1 | 3 | 0.147% |
| SPLASH_POTION (strong_healing) | 1 | 3 | 0.147% |
| POTION (strong_swiftness) | 1 | 2 | 0.098% |
| LINGERING_POTION (regeneration) | 1 | 2 | 0.098% |
| OMINOUS_BOTTLE | 1 | 2 | 0.098% |

### Ingredientes — 1.91%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| NETHERITE_SCRAP | 1-2 | 8 | 0.391% |
| HEART_OF_THE_SEA | 1 | 5 | 0.244% |
| DIAMOND | 4-8 | 5 | 0.244% |
| OMINOUS_TRIAL_KEY | 1 | 4 | 0.195% |
| ENCHANTED_BOOK [mending 1] | 1 | 4 | 0.195% |
| ENCHANTED_BOOK [sharpness 5] | 1 | 2 | 0.098% |
| ENCHANTED_BOOK [efficiency 5] | 1 | 2 | 0.098% |
| ENCHANTED_BOOK [protection 4] | 1 | 2 | 0.098% |
| ENCHANTED_BOOK [fortune 3] | 1 | 2 | 0.098% |
| WARD_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 1 | 0.049% |
| EYE_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 1 | 0.049% |
| VEX_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 1 | 0.049% |
| SPIRE_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 1 | 0.049% |
| SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE | 1 | 1 | 0.049% |

## Legendario — 1.50% (8 premios)

### Herramientas y utilidades — 0.11%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| NETHERITE_PICKAXE [efficiency 5, unbreaking 3, fortune 3, mending 1] "Pico del Apostador" | 1 | 3 | 0.110% |

### Combate — 0.29%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| MACE | 1 | 5 | 0.183% |
| NETHERITE_SWORD [sharpness 5, unbreaking 3, looting 3, fire_aspect 2, mending 1] "Espada del Apostador" | 1 | 3 | 0.110% |

### Comida y bebida — 0.29%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| ENCHANTED_GOLDEN_APPLE | 1-2 | 8 | 0.293% |

### Ingredientes — 0.80%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| NETHERITE_INGOT | 1 | 8 | 0.293% |
| NETHER_STAR | 1 | 5 | 0.183% |
| NETHERITE_UPGRADE_SMITHING_TEMPLATE | 1 | 5 | 0.183% |
| HEAVY_CORE | 1 | 4 | 0.146% |

## Mítico — 0.02% (1 premios)

### Herramientas y utilidades — 0.02%

| Ítem | Cantidad | Peso | Probabilidad |
|---|---:|---:|---:|
| ELYTRA | 1 | 10 | 0.020% |
