package com.mobapostador.premios;

import com.mobapostador.util.Texto;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.logging.Logger;

/** Un nivel de rareza (común, raro, legendario...) con su probabilidad y efectos. */
public final class Rareza {

    private final String id;
    private final String nombre;
    private final String color;
    private final double probabilidad;
    private final Material panel;
    private final String sonido;
    private final boolean anunciar;
    private final boolean titulo;
    private final boolean fuegosArtificiales;
    private final String anuncio;
    private final String sonidoAnuncio;

    private Rareza(String id, String nombre, String color, double probabilidad, Material panel,
                   String sonido, boolean anunciar, boolean titulo, boolean fuegosArtificiales,
                   String anuncio, String sonidoAnuncio) {
        this.id = id;
        this.nombre = nombre;
        this.color = color;
        this.probabilidad = probabilidad;
        this.panel = panel;
        this.sonido = sonido;
        this.anunciar = anunciar;
        this.titulo = titulo;
        this.fuegosArtificiales = fuegosArtificiales;
        this.anuncio = anuncio;
        this.sonidoAnuncio = sonidoAnuncio;
    }

    static Rareza desde(String id, ConfigurationSection s, Logger log) {
        String nombre = s.getString("nombre", id);
        String color = s.getString("color", "&f");
        double probabilidad = Math.max(0.0, leerNumero(s.get("probabilidad"), id, log));

        String nombrePanel = s.getString("panel", "GRAY_STAINED_GLASS_PANE");
        Material panel = Material.matchMaterial(nombrePanel);
        if (panel == null || !panel.isItem() || panel.isAir()) {
            log.warning("Rareza '" + id + "': panel '" + nombrePanel + "' no existe, se usará GRAY_STAINED_GLASS_PANE.");
            panel = Material.GRAY_STAINED_GLASS_PANE;
        }

        return new Rareza(
                id,
                nombre,
                color,
                probabilidad,
                panel,
                s.getString("sonido", "minecraft:entity.item.pickup"),
                s.getBoolean("anunciar", false),
                s.getBoolean("titulo", false),
                s.getBoolean("fuegos-artificiales", false),
                s.getString("anuncio", null),
                s.getString("sonido-anuncio", null));
    }

    /** Acepta 0.1 y también 0,1 (decimal con coma), que YAML lee como texto. */
    private static double leerNumero(Object valor, String id, Logger log) {
        if (valor instanceof Number n) {
            return n.doubleValue();
        }
        if (valor != null) {
            String texto = String.valueOf(valor).trim().replace(" ", "").replace(',', '.').replace("%", "");
            try {
                return Double.parseDouble(texto);
            } catch (NumberFormatException e) {
                log.warning("Rareza '" + id + "': la probabilidad '" + valor + "' no es un número. Se tomará como 0.");
            }
        }
        return 0.0;
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    /** Código de color tal cual está en la config, p. ej. "&6". */
    public String getColor() {
        return color;
    }

    /** Color + nombre, sin traducir los '&' (útil para meterlo dentro de otros mensajes). */
    public String getNombreConCodigos() {
        return color + nombre;
    }

    /** Color + nombre ya traducido a colores de Minecraft. */
    public String getNombreColoreado() {
        return Texto.color(color + nombre);
    }

    /** Último carácter de color (0-9, a-f) para colorear componentes de chat. */
    public char getCodigoColor() {
        char resultado = 'f';
        for (int i = 0; i < color.length() - 1; i++) {
            char c = color.charAt(i);
            if (c == '&' || c == '§') {
                char siguiente = Character.toLowerCase(color.charAt(i + 1));
                if ((siguiente >= '0' && siguiente <= '9') || (siguiente >= 'a' && siguiente <= 'f')) {
                    resultado = siguiente;
                }
            }
        }
        return resultado;
    }

    /** Probabilidad configurada (peso relativo frente a las demás rarezas). */
    public double getProbabilidad() {
        return probabilidad;
    }

    public Material getPanel() {
        return panel;
    }

    public String getSonido() {
        return sonido;
    }

    public boolean isAnunciar() {
        return anunciar;
    }

    public boolean isTitulo() {
        return titulo;
    }

    public boolean isFuegosArtificiales() {
        return fuegosArtificiales;
    }

    /** Mensaje propio para anunciar esta rareza a todo el servidor, o null para usar mensajes.anuncio. */
    public String getAnuncio() {
        return anuncio;
    }

    /** Sonido que escuchan los demás jugadores cuando alguien saca esta rareza, o null. */
    public String getSonidoAnuncio() {
        return sonidoAnuncio;
    }
}
