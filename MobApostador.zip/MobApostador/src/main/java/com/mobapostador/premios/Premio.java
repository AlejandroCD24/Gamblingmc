package com.mobapostador.premios;

import com.mobapostador.util.Texto;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/** Un premio posible: material, cantidad, peso dentro de su rareza y extras opcionales. */
public final class Premio {

    private final Rareza rareza;
    private final String categoria;
    private final Material material;
    private final int minimo;
    private final int maximo;
    private final double peso;
    private final PotionType pocion;
    private final String clavePocion;
    private final Map<Enchantment, Integer> encantamientos;
    private final boolean encantamientoAleatorio;
    private final List<Enchantment> poolAleatorio;
    private final String nombre;

    private Premio(Rareza rareza, String categoria, Material material, int minimo, int maximo, double peso,
                   PotionType pocion, String clavePocion, Map<Enchantment, Integer> encantamientos,
                   boolean encantamientoAleatorio, List<Enchantment> poolAleatorio, String nombre) {
        this.rareza = rareza;
        this.categoria = categoria;
        this.material = material;
        this.minimo = minimo;
        this.maximo = maximo;
        this.peso = peso;
        this.pocion = pocion;
        this.clavePocion = clavePocion;
        this.encantamientos = encantamientos;
        this.encantamientoAleatorio = encantamientoAleatorio;
        this.poolAleatorio = poolAleatorio;
        this.nombre = nombre;
    }

    /**
     * Lee un premio de premios.yml.
     *
     * @return el premio, o {@code null} si el material no existe en esta versión del servidor.
     * @throws IllegalArgumentException si la entrada está mal escrita.
     */
    static Premio desde(Map<?, ?> m, Rareza rareza, List<Enchantment> poolAleatorio) {
        Object objMaterial = m.get("material");
        if (objMaterial == null) {
            throw new IllegalArgumentException("falta el campo 'material'");
        }
        Material material = Material.matchMaterial(String.valueOf(objMaterial));
        if (material == null || material.isAir() || !material.isItem()) {
            return null;
        }

        String categoria = texto(m.get("categoria"), "otros").toLowerCase(Locale.ROOT);
        double peso = numero(m.get("peso"), 10.0);

        int[] cantidad = rango(m.get("cantidad"));
        int maxStack = Math.max(1, material.getMaxStackSize());
        int minimo = limitar(cantidad[0], 1, maxStack);
        int maximo = limitar(cantidad[1], minimo, maxStack);

        String nombre = m.get("nombre") == null ? null : String.valueOf(m.get("nombre"));

        // Pociones / flechas con efecto
        PotionType pocion = null;
        String clavePocion = null;
        if (m.get("pocion") != null) {
            if (!esDePocion(material)) {
                throw new IllegalArgumentException("'pocion' solo sirve con POTION, SPLASH_POTION, LINGERING_POTION o TIPPED_ARROW");
            }
            clavePocion = String.valueOf(m.get("pocion")).toLowerCase(Locale.ROOT);
            pocion = Registry.POTION.get(NamespacedKey.minecraft(clavePocion));
            if (pocion == null) {
                throw new IllegalArgumentException("poción desconocida: " + clavePocion);
            }
        }

        // Encantamientos: mapa {clave: nivel} o la palabra "aleatorio"
        Map<Enchantment, Integer> encantamientos = new LinkedHashMap<>();
        boolean aleatorio = false;
        Object objEnc = m.get("encantamientos");
        if (objEnc instanceof Map<?, ?> mapa) {
            for (Map.Entry<?, ?> e : mapa.entrySet()) {
                String clave = String.valueOf(e.getKey()).toLowerCase(Locale.ROOT);
                NamespacedKey key = clave.contains(":") ? NamespacedKey.fromString(clave) : NamespacedKey.minecraft(clave);
                Enchantment ench = key == null ? null : Registry.ENCHANTMENT.get(key);
                if (ench == null) {
                    throw new IllegalArgumentException("encantamiento desconocido: " + clave);
                }
                encantamientos.put(ench, Math.max(1, (int) numero(e.getValue(), 1)));
            }
        } else if (objEnc != null && "aleatorio".equalsIgnoreCase(String.valueOf(objEnc).trim())) {
            if (poolAleatorio.isEmpty()) {
                throw new IllegalArgumentException("no hay encantamientos disponibles para 'aleatorio'");
            }
            aleatorio = true;
        } else if (objEnc != null) {
            throw new IllegalArgumentException("'encantamientos' debe ser {clave: nivel} o la palabra aleatorio");
        }

        return new Premio(rareza, categoria, material, minimo, maximo, peso, pocion, clavePocion,
                Collections.unmodifiableMap(encantamientos), aleatorio, poolAleatorio, nombre);
    }

    /** Crea el ItemStack que se entrega, con cantidad aleatoria dentro del rango. */
    public ItemStack crear(Random random) {
        int cantidad = minimo >= maximo ? minimo : minimo + random.nextInt(maximo - minimo + 1);
        Map<Enchantment, Integer> aplicar = encantamientos;
        if (encantamientoAleatorio) {
            Enchantment ench = poolAleatorio.get(random.nextInt(poolAleatorio.size()));
            int nivel = 1 + random.nextInt(Math.max(1, ench.getMaxLevel()));
            aplicar = Collections.singletonMap(ench, nivel);
        }
        return construir(cantidad, aplicar);
    }

    /** Ítem de ejemplo (cantidad mínima, sin encantamiento aleatorio) para mostrar en listas. */
    public ItemStack muestra() {
        return construir(minimo, encantamientos);
    }

    private ItemStack construir(int cantidad, Map<Enchantment, Integer> aplicar) {
        ItemStack item = new ItemStack(material, cantidad);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        if (pocion != null && meta instanceof PotionMeta potionMeta) {
            potionMeta.setBasePotionType(pocion);
        }
        for (Map.Entry<Enchantment, Integer> e : aplicar.entrySet()) {
            if (meta instanceof EnchantmentStorageMeta libro) {
                libro.addStoredEnchant(e.getKey(), e.getValue(), true);
            } else {
                meta.addEnchant(e.getKey(), e.getValue(), true);
            }
        }
        if (nombre != null) {
            meta.setDisplayName(Texto.color(nombre));
        }
        item.setItemMeta(meta);
        return item;
    }

    // ---------------------------------------------------------------- utilidades de lectura

    private static boolean esDePocion(Material m) {
        return m == Material.POTION || m == Material.SPLASH_POTION
                || m == Material.LINGERING_POTION || m == Material.TIPPED_ARROW;
    }

    private static String texto(Object o, String porDefecto) {
        return o == null ? porDefecto : String.valueOf(o);
    }

    private static double numero(Object o, double porDefecto) {
        if (o instanceof Number n) {
            return n.doubleValue();
        }
        if (o != null) {
            try {
                return Double.parseDouble(String.valueOf(o).trim());
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("número inválido: " + o);
            }
        }
        return porDefecto;
    }

    /** Acepta 5, "5" o "2-8". */
    private static int[] rango(Object o) {
        if (o == null) {
            return new int[]{1, 1};
        }
        if (o instanceof Number n) {
            return new int[]{n.intValue(), n.intValue()};
        }
        String s = String.valueOf(o).replace(" ", "");
        try {
            int guion = s.indexOf('-', 1);
            if (guion > 0) {
                int a = Integer.parseInt(s.substring(0, guion));
                int b = Integer.parseInt(s.substring(guion + 1));
                return new int[]{Math.min(a, b), Math.max(a, b)};
            }
            int v = Integer.parseInt(s);
            return new int[]{v, v};
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("cantidad inválida: " + o + " (usa 5 o 2-8)");
        }
    }

    private static int limitar(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    // ---------------------------------------------------------------- getters

    public Rareza getRareza() {
        return rareza;
    }

    public String getCategoria() {
        return categoria;
    }

    public Material getMaterial() {
        return material;
    }

    public int getMinimo() {
        return minimo;
    }

    public int getMaximo() {
        return maximo;
    }

    public double getPeso() {
        return peso;
    }

    /** Clave de la poción tal como se escribió (p. ej. "strong_healing"), o null. */
    public String getClavePocion() {
        return clavePocion;
    }

    public boolean isEncantamientoAleatorio() {
        return encantamientoAleatorio;
    }

    /** Nombre personalizado (con códigos '&'), o null. */
    public String getNombre() {
        return nombre;
    }
}
