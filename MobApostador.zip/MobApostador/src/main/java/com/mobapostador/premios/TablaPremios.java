package com.mobapostador.premios;

import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Logger;

/**
 * Tabla de premios con tirada en dos pasos:
 * 1) se elige la rareza según su probabilidad;
 * 2) dentro de esa rareza se elige el premio según su peso.
 *
 * Probabilidad de un premio = P(rareza) x peso / suma de pesos de esa rareza.
 */
public final class TablaPremios {

    private static final Set<String> CURSES = Set.of("binding_curse", "vanishing_curse");

    private final List<Rareza> rarezasActivas;                 // solo las que tienen premios
    private final Map<String, Rareza> rarezasPorId;            // todas, por id en minúsculas
    private final Map<Rareza, List<Premio>> premios;
    private final Map<Rareza, Double> pesoTotal;
    private final double probabilidadTotal;
    private final Map<String, String> nombresCategorias;

    private TablaPremios(List<Rareza> rarezasActivas, Map<String, Rareza> rarezasPorId,
                         Map<Rareza, List<Premio>> premios, Map<String, String> nombresCategorias) {
        this.rarezasActivas = rarezasActivas;
        this.rarezasPorId = rarezasPorId;
        this.premios = premios;
        this.nombresCategorias = nombresCategorias;
        this.pesoTotal = new HashMap<>();
        double total = 0;
        for (Rareza r : rarezasActivas) {
            double suma = 0;
            for (Premio p : premios.get(r)) {
                suma += p.getPeso();
            }
            pesoTotal.put(r, suma);
            total += r.getProbabilidad();
        }
        this.probabilidadTotal = total;
    }

    /**
     * Carga la tabla desde premios.yml.
     *
     * @param categoriasActivas categorías permitidas (vacío = todas)
     */
    public static TablaPremios cargar(ConfigurationSection cfg, Set<String> categoriasActivas, Logger log) {
        // Nombres bonitos de las categorías
        Map<String, String> nombresCategorias = new HashMap<>();
        ConfigurationSection cats = cfg.getConfigurationSection("categorias");
        if (cats != null) {
            for (String k : cats.getKeys(false)) {
                nombresCategorias.put(k.toLowerCase(Locale.ROOT), cats.getString(k, k));
            }
        }

        // Rarezas (en el orden del archivo)
        Map<String, Rareza> rarezas = new LinkedHashMap<>();
        ConfigurationSection secRarezas = cfg.getConfigurationSection("rarezas");
        if (secRarezas == null) {
            log.severe("premios.yml no tiene la sección 'rarezas'.");
        } else {
            for (String id : secRarezas.getKeys(false)) {
                ConfigurationSection s = secRarezas.getConfigurationSection(id);
                if (s != null) {
                    rarezas.put(id.toLowerCase(Locale.ROOT), Rareza.desde(id.toLowerCase(Locale.ROOT), s, log));
                }
            }
        }

        // Encantamientos posibles para libros "aleatorio" (sin maldiciones)
        List<Enchantment> pool = new ArrayList<>();
        for (Enchantment e : Registry.ENCHANTMENT) {
            if (!CURSES.contains(e.getKey().getKey())) {
                pool.add(e);
            }
        }
        List<Enchantment> poolFinal = Collections.unmodifiableList(pool);

        // Premios
        Map<Rareza, List<Premio>> premios = new LinkedHashMap<>();
        Set<String> omitidos = new TreeSet<>();
        ConfigurationSection secPremios = cfg.getConfigurationSection("premios");
        if (secPremios == null) {
            log.severe("premios.yml no tiene la sección 'premios'.");
        } else {
            for (String id : secPremios.getKeys(false)) {
                Rareza rareza = rarezas.get(id.toLowerCase(Locale.ROOT));
                if (rareza == null) {
                    log.warning("premios." + id + ": no existe una rareza con ese nombre en 'rarezas'.");
                    continue;
                }
                int n = 0;
                for (Map<?, ?> entrada : secPremios.getMapList(id)) {
                    n++;
                    try {
                        Premio p = Premio.desde(entrada, rareza, poolFinal);
                        if (p == null) {
                            omitidos.add(String.valueOf(entrada.get("material")).toUpperCase(Locale.ROOT));
                            continue;
                        }
                        if (!categoriasActivas.isEmpty() && !categoriasActivas.contains(p.getCategoria())) {
                            continue;
                        }
                        if (p.getPeso() <= 0) {
                            continue;
                        }
                        premios.computeIfAbsent(rareza, k -> new ArrayList<>()).add(p);
                    } catch (IllegalArgumentException ex) {
                        log.warning("premios." + id + " (entrada #" + n + "): " + ex.getMessage() + " -> se omite.");
                    }
                }
            }
        }

        if (!omitidos.isEmpty()) {
            log.info(omitidos.size() + " ítems no existen en esta versión del servidor y se omitieron: "
                    + String.join(", ", omitidos));
        }

        for (Rareza r : rarezas.values()) {
            if (r.getProbabilidad() <= 0 && premios.containsKey(r)) {
                log.warning("La rareza '" + r.getId() + "' tiene probabilidad 0 y no saldrá nunca. Revisa su 'probabilidad' en premios.yml.");
            }
        }

        // Solo rarezas con probabilidad > 0 y al menos un premio, en el orden del archivo
        List<Rareza> activas = new ArrayList<>();
        Map<Rareza, List<Premio>> premiosFinal = new LinkedHashMap<>();
        for (Rareza r : rarezas.values()) {
            List<Premio> lista = premios.get(r);
            if (r.getProbabilidad() > 0 && lista != null && !lista.isEmpty()) {
                activas.add(r);
                premiosFinal.put(r, Collections.unmodifiableList(lista));
            }
        }
        return new TablaPremios(Collections.unmodifiableList(activas), rarezas, premiosFinal, nombresCategorias);
    }

    // ---------------------------------------------------------------- tiradas

    public boolean estaVacia() {
        return rarezasActivas.isEmpty();
    }

    /** Elige solo la rareza (barato; se usa para simular miles de tiradas). */
    public Rareza tirarRareza(Random random) {
        double x = random.nextDouble() * probabilidadTotal;
        for (Rareza r : rarezasActivas) {
            x -= r.getProbabilidad();
            if (x < 0) {
                return r;
            }
        }
        return rarezasActivas.get(rarezasActivas.size() - 1);
    }

    /** Tirada completa: rareza -> premio -> ítem con cantidad aleatoria. */
    public Resultado tirar(Random random) {
        if (estaVacia()) {
            throw new IllegalStateException("La tabla de premios está vacía");
        }
        Premio elegido = elegirPremio(tirarRareza(random), random);
        return new Resultado(elegido, elegido.crear(random), false);
    }

    /** Tirada forzada a una rareza (premio garantizado): solo se elige el premio dentro de ella. */
    public Resultado tirarGarantizado(Rareza rareza, Random random) {
        if (!premios.containsKey(rareza)) {
            throw new IllegalArgumentException("La rareza " + rareza.getId() + " no tiene premios");
        }
        Premio elegido = elegirPremio(rareza, random);
        return new Resultado(elegido, elegido.crear(random), true);
    }

    private Premio elegirPremio(Rareza rareza, Random random) {
        List<Premio> lista = premios.get(rareza);
        double y = random.nextDouble() * pesoTotal.get(rareza);
        for (Premio p : lista) {
            y -= p.getPeso();
            if (y < 0) {
                return p;
            }
        }
        return lista.get(lista.size() - 1);
    }

    /** La rareza activa con menor probabilidad (la más difícil), o null si la tabla está vacía. */
    public Rareza rarezaMasRara() {
        Rareza rara = null;
        for (Rareza r : rarezasActivas) {
            if (rara == null || r.getProbabilidad() < rara.getProbabilidad()) {
                rara = r;
            }
        }
        return rara;
    }

    /** true si la rareza tiene premios y puede salir. */
    public boolean estaActiva(Rareza r) {
        return r != null && premios.containsKey(r);
    }

    // ---------------------------------------------------------------- probabilidades

    /** Probabilidad real (0-1) de que salga esta rareza. */
    public double probabilidadDe(Rareza r) {
        if (!premios.containsKey(r) || probabilidadTotal <= 0) {
            return 0;
        }
        return r.getProbabilidad() / probabilidadTotal;
    }

    /** Probabilidad real (0-1) de que salga este premio exacto. */
    public double probabilidadDe(Premio p) {
        Double suma = pesoTotal.get(p.getRareza());
        if (suma == null || suma <= 0) {
            return 0;
        }
        return probabilidadDe(p.getRareza()) * p.getPeso() / suma;
    }

    // ---------------------------------------------------------------- consultas

    public List<Rareza> getRarezasActivas() {
        return rarezasActivas;
    }

    public Rareza buscarRareza(String id) {
        return id == null ? null : rarezasPorId.get(id.toLowerCase(Locale.ROOT));
    }

    public List<Premio> getPremios(Rareza r) {
        List<Premio> lista = premios.get(r);
        return lista == null ? Collections.emptyList() : lista;
    }

    public int getTotalPremios() {
        int n = 0;
        for (List<Premio> l : premios.values()) {
            n += l.size();
        }
        return n;
    }

    public String getNombreCategoria(String id) {
        String n = nombresCategorias.get(id);
        if (n != null) {
            return n;
        }
        return id.isEmpty() ? id : Character.toUpperCase(id.charAt(0)) + id.substring(1);
    }
}
