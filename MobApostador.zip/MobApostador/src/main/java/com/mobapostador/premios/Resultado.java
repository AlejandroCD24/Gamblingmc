package com.mobapostador.premios;

import org.bukkit.inventory.ItemStack;

/**
 * Lo que salió en una tirada: el premio y el ítem ya creado (con su cantidad).
 *
 * @param garantizado true si salió por el contador de giros (premio garantizado) y no por suerte
 */
public record Resultado(Premio premio, ItemStack item, boolean garantizado) {
}
