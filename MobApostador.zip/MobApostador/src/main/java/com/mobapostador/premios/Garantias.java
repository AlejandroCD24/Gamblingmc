package com.mobapostador.premios;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * Todas las garantías juntas (por defecto: Legendario cada 667 giros y Mítico cada 66,667).
 *
 * Cada tirada suma 1 giro a TODOS los contadores del jugador (x5 = 5, x10 = 10).
 * Si en un mismo giro se cumplen dos garantías, gana la de la rareza más difícil y la otra
 * queda pendiente para el giro siguiente (no se pierde).
 */
public final class Garantias {

    private final boolean activado;
    private final boolean mostrarProgreso;
    private final List<Garantia> lista = new ArrayList<>();

    public Garantias(JavaPlugin plugin, ConfigurationSection sec) {
        this.activado = sec == null || sec.getBoolean("activado", true);
        this.mostrarProgreso = sec == null || sec.getBoolean("mostrar-progreso", true);

        ConfigurationSection secLista = sec == null ? null : sec.getConfigurationSection("garantias");
        if (secLista != null) {
            for (String id : secLista.getKeys(false)) {
                ConfigurationSection g = secLista.getConfigurationSection(id);
                if (g == null) {
                    continue;
                }
                int cada = g.getInt("cada-giros", 0);
                if (cada < 1) {
                    plugin.getLogger().warning("garantizado.garantias." + id + ".cada-giros debe ser 1 o más; se ignora.");
                    continue;
                }
                lista.add(new Garantia(plugin, id, g.getString("rareza", id), cada,
                        g.getBoolean("reiniciar-con-suerte", false)));
            }
        } else {
            // config.yml de una versión anterior (una sola garantía): se respeta y se agrega el Mítico
            int cada = sec == null ? 667 : Math.max(1, sec.getInt("cada-giros", 667));
            String rareza = sec == null ? "legendario" : sec.getString("rareza", "legendario");
            boolean reiniciar = sec != null && sec.getBoolean("reiniciar-con-suerte", false);
            lista.add(new Garantia(plugin, "legendario", rareza, cada, reiniciar));
            lista.add(new Garantia(plugin, "mitico", "mitico", 66667, false));
        }
    }

    /** Garantías cuya rareza existe, ordenadas de la más difícil a la más fácil. */
    public List<Garantia> activas(TablaPremios tabla) {
        if (!activado) {
            return Collections.emptyList();
        }
        List<Garantia> r = new ArrayList<>();
        for (Garantia g : lista) {
            if (g.objetivo(tabla) != null) {
                r.add(g);
            }
        }
        r.sort(Comparator.comparingDouble(g -> g.objetivo(tabla).getProbabilidad()));
        return r;
    }

    /** Hace UNA tirada para el jugador aplicando todos los contadores, y los guarda. */
    public Resultado tirar(Player p, TablaPremios tabla, Random random) {
        List<Garantia> gs = activas(tabla);
        if (gs.isEmpty()) {
            return tabla.tirar(random);
        }
        Garantia forzada = null;
        Map<Garantia, Integer> nuevos = new HashMap<>();
        for (Garantia g : gs) { // de la más rara a la más común
            int c = g.getContador(p) + 1;
            if (c >= g.getCadaGiros() && forzada == null) {
                forzada = g;
                c = 0;
            }
            nuevos.put(g, c); // si también se cumplió pero no le tocó, queda pendiente (se guarda como cada-1)
        }
        Resultado resultado = forzada != null
                ? tabla.tirarGarantizado(forzada.objetivo(tabla), random)
                : tabla.tirar(random);
        for (Garantia g : gs) {
            int c = nuevos.get(g);
            if (g != forzada && g.isReiniciarConSuerte() && resultado.premio().getRareza() == g.objetivo(tabla)) {
                c = 0;
            }
            g.setContador(p, c);
        }
        return resultado;
    }

    /** La garantía de esa rareza, o null. */
    public Garantia deRareza(Rareza rareza, TablaPremios tabla) {
        for (Garantia g : activas(tabla)) {
            if (g.objetivo(tabla) == rareza) {
                return g;
            }
        }
        return null;
    }

    /** Busca por id ("legendario", "mitico") o por id de rareza. */
    public Garantia buscar(String texto, TablaPremios tabla) {
        String t = texto.toLowerCase(Locale.ROOT);
        for (Garantia g : activas(tabla)) {
            if (g.getId().equals(t) || g.objetivo(tabla).getId().equals(t)) {
                return g;
            }
        }
        return null;
    }

    public boolean isActivado() {
        return activado;
    }

    public boolean isMostrarProgreso() {
        return mostrarProgreso;
    }
}
