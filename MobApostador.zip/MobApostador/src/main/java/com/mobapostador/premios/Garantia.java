package com.mobapostador.premios;

import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;
import java.util.Random;

/**
 * Premio garantizado por contador de giros (por defecto: un Legendario cada 667 giros).
 *
 * Cada tirada suma 1 giro al contador del jugador (x5 = 5 giros, x10 = 10 giros).
 * Al llegar al giro número N, ese giro da un premio de la rareza garantizada y el contador vuelve a 0.
 * El contador se guarda en los datos del jugador, así que sobrevive a desconexiones y reinicios.
 */
public final class Garantia {

    private final boolean activado;
    private final int cadaGiros;
    private final String idRareza;
    private final boolean reiniciarConSuerte;
    private final boolean mostrarProgreso;
    private final NamespacedKey clave;

    public Garantia(JavaPlugin plugin, ConfigurationSection sec) {
        this.clave = new NamespacedKey(plugin, "giros_garantia");
        this.activado = sec != null && sec.getBoolean("activado", true);
        int cada = sec == null ? 667 : sec.getInt("cada-giros", 667);
        if (cada < 1) {
            plugin.getLogger().warning("garantizado.cada-giros debe ser 1 o más. Se usará 667.");
            cada = 667;
        }
        this.cadaGiros = cada;
        this.idRareza = sec == null ? "legendario" : sec.getString("rareza", "legendario").toLowerCase(Locale.ROOT);
        this.reiniciarConSuerte = sec != null && sec.getBoolean("reiniciar-con-suerte", false);
        this.mostrarProgreso = sec == null || sec.getBoolean("mostrar-progreso", true);
    }

    /** La rareza que se garantiza; si la configurada no existe, la más rara que haya. */
    public Rareza objetivo(TablaPremios tabla) {
        Rareza r = tabla.buscarRareza(idRareza);
        return tabla.estaActiva(r) ? r : tabla.rarezaMasRara();
    }

    /** Hace UNA tirada para el jugador aplicando el contador. Guarda el contador nuevo. */
    public Resultado tirar(Player p, TablaPremios tabla, Random random) {
        if (!activado) {
            return tabla.tirar(random);
        }
        Rareza objetivo = objetivo(tabla);
        int contador = getContador(p) + 1;
        Resultado resultado;
        if (contador >= cadaGiros) {
            resultado = tabla.tirarGarantizado(objetivo, random);
            contador = 0;
        } else {
            resultado = tabla.tirar(random);
            if (reiniciarConSuerte && resultado.premio().getRareza() == objetivo) {
                contador = 0;
            }
        }
        setContador(p, contador);
        return resultado;
    }

    /** Giros acumulados desde el último premio garantizado (0 .. cada-giros - 1). */
    public int getContador(Player p) {
        Integer v = p.getPersistentDataContainer().get(clave, PersistentDataType.INTEGER);
        return v == null ? 0 : Math.max(0, Math.min(cadaGiros - 1, v));
    }

    public void setContador(Player p, int contador) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        pdc.set(clave, PersistentDataType.INTEGER, Math.max(0, Math.min(cadaGiros - 1, contador)));
    }

    /** Cuántos giros faltan: 1 = el próximo giro es el garantizado. */
    public int faltan(Player p) {
        return cadaGiros - getContador(p);
    }

    /**
     * Probabilidad real por giro de la rareza garantizada, contando la garantía.
     * Sin reinicio: ((N-1)·p + 1) / N. Con reinicio ("pity"): p / (1 - (1-p)^N).
     */
    public double tasaEfectiva(TablaPremios tabla) {
        Rareza obj = objetivo(tabla);
        double p = obj == null ? 0 : tabla.probabilidadDe(obj);
        if (!activado || obj == null) {
            return p;
        }
        if (reiniciarConSuerte) {
            double sinSalir = Math.pow(1 - p, cadaGiros);
            return sinSalir >= 1 ? 1.0 / cadaGiros : p / (1 - sinSalir);
        }
        return ((cadaGiros - 1) * p + 1) / cadaGiros;
    }

    /** Barra de progreso de 20 cuadritos con colores '&'. */
    public String barra(Player p) {
        int llenos = (int) Math.round(20.0 * getContador(p) / cadaGiros);
        return "&6" + "■".repeat(llenos) + "&8" + "■".repeat(20 - llenos);
    }

    public boolean isActivado() {
        return activado;
    }

    public int getCadaGiros() {
        return cadaGiros;
    }

    public boolean isReiniciarConSuerte() {
        return reiniciarConSuerte;
    }

    public boolean isMostrarProgreso() {
        return mostrarProgreso;
    }
}
