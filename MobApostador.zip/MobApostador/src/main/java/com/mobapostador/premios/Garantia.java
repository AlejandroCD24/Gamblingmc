package com.mobapostador.premios;

import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;

/**
 * UNA garantía: "un premio de la rareza X cada N giros".
 * Cada jugador tiene su propio contador, guardado en sus datos (sobrevive a desconexiones y reinicios).
 * Las garantías se manejan juntas en {@link Garantias}.
 */
public final class Garantia {

    private final String id;
    private final String idRareza;
    private final int cadaGiros;
    private final boolean reiniciarConSuerte;
    private final NamespacedKey clave;

    Garantia(JavaPlugin plugin, String id, String idRareza, int cadaGiros, boolean reiniciarConSuerte) {
        this.id = id.toLowerCase(Locale.ROOT);
        this.idRareza = idRareza.toLowerCase(Locale.ROOT);
        this.cadaGiros = Math.max(1, cadaGiros);
        this.reiniciarConSuerte = reiniciarConSuerte;
        // "legendario" conserva la clave de la versión anterior para no perder el progreso de nadie
        String nombreClave = this.id.equals("legendario")
                ? "giros_garantia"
                : "giros_garantia_" + this.id.replaceAll("[^a-z0-9._-]", "_");
        this.clave = new NamespacedKey(plugin, nombreClave);
    }

    /** La rareza que garantiza, o null si no existe o no tiene premios. */
    public Rareza objetivo(TablaPremios tabla) {
        Rareza r = tabla.buscarRareza(idRareza);
        return tabla.estaActiva(r) ? r : null;
    }

    /** Giros acumulados desde el último premio garantizado (0 .. cada-giros - 1). */
    public int getContador(Player p) {
        Integer v = p.getPersistentDataContainer().get(clave, PersistentDataType.INTEGER);
        return v == null ? 0 : Math.max(0, Math.min(cadaGiros - 1, v));
    }

    /** Se limita a cada-giros - 1: si queda "pendiente", el siguiente giro la activa. */
    public void setContador(Player p, int contador) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        pdc.set(clave, PersistentDataType.INTEGER, Math.max(0, Math.min(cadaGiros - 1, contador)));
    }

    /** Cuántos giros faltan: 1 = el próximo giro es el garantizado. */
    public int faltan(Player p) {
        return cadaGiros - getContador(p);
    }

    /**
     * Probabilidad real por giro de la rareza, contando la garantía.
     * Sin reinicio: ((N-1)·p + 1) / N. Con reinicio ("pity"): p / (1 - (1-p)^N).
     */
    public double tasaEfectiva(TablaPremios tabla) {
        Rareza obj = objetivo(tabla);
        if (obj == null) {
            return 0;
        }
        double p = tabla.probabilidadDe(obj);
        if (reiniciarConSuerte) {
            double sinSalir = Math.pow(1 - p, cadaGiros);
            return sinSalir >= 1 ? 1.0 / cadaGiros : p / (1 - sinSalir);
        }
        return ((cadaGiros - 1) * p + 1) / cadaGiros;
    }

    /** Barra de progreso de 20 cuadritos con colores '&'. */
    public String barra(Player p) {
        int llenos = (int) Math.floor(20.0 * getContador(p) / cadaGiros);
        return "&6" + "■".repeat(llenos) + "&8" + "■".repeat(20 - llenos);
    }

    public String getId() {
        return id;
    }

    public int getCadaGiros() {
        return cadaGiros;
    }

    public boolean isReiniciarConSuerte() {
        return reiniciarConSuerte;
    }
}
