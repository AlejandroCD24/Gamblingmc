package com.mobapostador.premios;

import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Selección de premios de cada jugador ("solo quiero estos").
 *
 * - Si el jugador NO seleccionó nada, recibe todos los premios.
 * - Si seleccionó algunos, los premios que salgan y no estén seleccionados se descartan.
 * - Las rarezas protegidas (por defecto Legendario, Mítico e Imposible) nunca se descartan.
 *
 * La selección se guarda en los datos del jugador.
 */
public final class Filtro {

    private final boolean activado;
    private final Set<String> protegidas = new HashSet<>();
    private final NamespacedKey clave;

    public Filtro(JavaPlugin plugin, ConfigurationSection sec) {
        this.clave = new NamespacedKey(plugin, "seleccion_premios");
        this.activado = sec == null || sec.getBoolean("activado", true);
        List<String> lista = sec == null ? null : sec.getStringList("proteger-rarezas");
        if (lista == null || lista.isEmpty()) {
            lista = List.of("legendario", "mitico", "imposible");
        }
        for (String id : lista) {
            protegidas.add(id.trim().toLowerCase(Locale.ROOT));
        }
    }

    public boolean isActivado() {
        return activado;
    }

    public boolean esProtegida(Rareza r) {
        return protegidas.contains(r.getId());
    }

    /** Claves seleccionadas guardadas (puede incluir premios que ya no existen). */
    public Set<String> leer(Player p) {
        String guardado = p.getPersistentDataContainer().get(clave, PersistentDataType.STRING);
        Set<String> r = new HashSet<>();
        if (guardado != null && !guardado.isEmpty()) {
            Collections.addAll(r, guardado.split("\n"));
        }
        return r;
    }

    public void guardar(Player p, Set<String> seleccion) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        if (seleccion.isEmpty()) {
            pdc.remove(clave);
        } else {
            pdc.set(clave, PersistentDataType.STRING, String.join("\n", seleccion));
        }
    }

    /** Selección lista para usar en una apuesta (solo con premios que existen en la tabla actual). */
    public Seleccion de(Player p, TablaPremios tabla) {
        if (!activado) {
            return new Seleccion(Collections.emptySet());
        }
        Set<String> s = leer(p);
        s.retainAll(tabla.getClaves());
        return new Seleccion(s);
    }

    public final class Seleccion {
        private final Set<String> claves;

        private Seleccion(Set<String> claves) {
            this.claves = claves;
        }

        /** true si este premio se va a descartar para este jugador. */
        public boolean descarta(Premio premio) {
            return !claves.isEmpty() && !esProtegida(premio.getRareza()) && !claves.contains(premio.getClave());
        }

        public boolean activa() {
            return !claves.isEmpty();
        }

        public int tamanio() {
            return claves.size();
        }
    }
}
