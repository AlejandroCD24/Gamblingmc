package com.mobapostador.comandos;

import com.mobapostador.MobApostador;
import com.mobapostador.premios.Garantia;
import com.mobapostador.premios.Premio;
import com.mobapostador.premios.Rareza;
import com.mobapostador.premios.TablaPremios;
import com.mobapostador.util.Mensajeria;
import com.mobapostador.util.Texto;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * /apostador crear | eliminar [todos] | probabilidades [rareza] [página] | simular [n] | recargar
 * /apostar
 */
public final class ComandoApostador implements TabExecutor {

    private static final int POR_PAGINA = 10;
    private static final String ADMIN = "apostador.admin";

    private final MobApostador plugin;

    public ComandoApostador(MobApostador plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("apostar")) {
            apostar(sender, args);
            return true;
        }
        if (args.length == 0) {
            ayuda(sender, label);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "crear" -> crear(sender);
            case "eliminar", "borrar" -> eliminar(sender, args);
            case "probabilidades", "prob", "premios" -> probabilidades(sender, label, args);
            case "simular" -> simular(sender, args);
            case "garantia", "garantizado", "progreso" -> garantia(sender, args);
            case "recargar", "reload" -> recargar(sender);
            default -> ayuda(sender, label);
        }
        return true;
    }

    // ---------------------------------------------------------------- subcomandos

    /** /apostar -> menú x1/x5/x10 · /apostar 5 o /apostar x10 -> apuesta directa. */
    private void apostar(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.enviar(sender, "solo-jugadores");
            return;
        }
        if (!plugin.getConfig().getBoolean("apuesta.comando-apostar", true)) {
            plugin.enviar(p, "comando-desactivado");
            return;
        }
        if (!p.hasPermission("apostador.apostar")) {
            plugin.enviar(p, "sin-permiso");
            return;
        }
        if (args.length == 0) {
            plugin.abrirMenuOApostar(p);
            return;
        }
        try {
            int veces = Integer.parseInt(args[0].toLowerCase(Locale.ROOT).replace("x", "").trim());
            plugin.intentarApuesta(p, veces);
        } catch (NumberFormatException e) {
            plugin.enviar(p, "multiple-invalido", "{opciones}", plugin.textoMultiples());
        }
    }

    private void crear(CommandSender sender) {
        if (!esAdmin(sender)) {
            return;
        }
        if (!(sender instanceof Player p)) {
            plugin.enviar(sender, "solo-jugadores");
            return;
        }
        plugin.getGestorMob().crear(p);
        plugin.enviar(p, "mob-creado");
    }

    private void eliminar(CommandSender sender, String[] args) {
        if (!esAdmin(sender)) {
            return;
        }
        if (args.length >= 2 && args[1].equalsIgnoreCase("todos")) {
            int n = plugin.getGestorMob().eliminarTodos();
            plugin.enviar(sender, "mobs-eliminados", "{cantidad}", String.valueOf(n));
            return;
        }
        if (!(sender instanceof Player p)) {
            plugin.enviar(sender, "solo-jugadores");
            return;
        }
        Entity mob = plugin.getGestorMob().masCercano(p, 6);
        if (mob == null) {
            plugin.enviar(p, "ningun-mob-cerca");
            return;
        }
        mob.remove();
        plugin.enviar(p, "mob-eliminado");
    }

    private void recargar(CommandSender sender) {
        if (!esAdmin(sender)) {
            return;
        }
        plugin.recargar();
        plugin.enviar(sender, "recargado", "{premios}", String.valueOf(plugin.getTabla().getTotalPremios()));
    }

    private void probabilidades(CommandSender sender, String label, String[] args) {
        TablaPremios tabla = plugin.getTabla();
        String pre = plugin.getPrefijo();

        if (args.length < 2) {
            sender.sendMessage(Texto.color(pre + "&6&lProbabilidades por rareza"));
            StringBuilder costos = new StringBuilder(" &7Costo: ");
            for (int i = 0; i < plugin.getMultiples().size(); i++) {
                int v = plugin.getMultiples().get(i);
                if (i > 0) {
                    costos.append(" &8· ");
                }
                costos.append("&ex").append(v).append(" &7").append(plugin.getCobro().descripcion(v));
            }
            sender.sendMessage(Texto.color(costos.toString()));
            for (Rareza r : tabla.getRarezasActivas()) {
                List<Premio> lista = tabla.getPremios(r);
                int min = Integer.MAX_VALUE;
                int max = 0;
                for (Premio p : lista) {
                    min = Math.min(min, p.getMinimo());
                    max = Math.max(max, p.getMaximo());
                }
                sender.sendMessage(Texto.color(" &8• " + r.getNombreConCodigos() + " &f"
                        + Texto.porcentaje(tabla.probabilidadDe(r)) + " &8| &7" + lista.size()
                        + " premios &8| &7cantidad x" + Texto.rango(min, max)));
            }
            Garantia garantia = plugin.getGarantia();
            Rareza objetivo = garantia.objetivo(tabla);
            if (garantia.isActivado() && objetivo != null) {
                sender.sendMessage(Texto.color(" &6★ " + objetivo.getNombreConCodigos() + " &6garantizado cada &f"
                        + garantia.getCadaGiros() + " &6giros &7(probabilidad real por giro: &f"
                        + Texto.porcentaje(garantia.tasaEfectiva(tabla)) + "&7)"));
            }
            sender.sendMessage(Texto.color(" &7Detalle: &e/" + label + " probabilidades <rareza> [página]"));
            return;
        }

        Rareza rareza = tabla.buscarRareza(args[1]);
        if (rareza == null || tabla.getPremios(rareza).isEmpty()) {
            plugin.enviar(sender, "rareza-desconocida", "{rareza}", args[1]);
            return;
        }
        List<Premio> lista = new ArrayList<>(tabla.getPremios(rareza));
        lista.sort(Comparator.comparingDouble(Premio::getPeso).reversed());

        int paginas = Math.max(1, (lista.size() + POR_PAGINA - 1) / POR_PAGINA);
        int pagina = 1;
        if (args.length >= 3) {
            try {
                pagina = Integer.parseInt(args[2]);
            } catch (NumberFormatException ignored) {
                // se queda en la página 1
            }
        }
        pagina = Math.max(1, Math.min(paginas, pagina));

        sender.sendMessage(Texto.color(pre + rareza.getNombreConCodigos() + " &f"
                + Texto.porcentaje(tabla.probabilidadDe(rareza)) + " &7- página " + pagina + "/" + paginas));
        int desde = (pagina - 1) * POR_PAGINA;
        int hasta = Math.min(lista.size(), desde + POR_PAGINA);
        for (int i = desde; i < hasta; i++) {
            Premio p = lista.get(i);
            String extra = p.isEncantamientoAleatorio() ? " &8(encantamiento al azar)" : "";
            String linea = Texto.color(" &8• ") + "{item}" + Texto.color(extra + " &f"
                    + Texto.porcentaje(tabla.probabilidadDe(p)) + " &8| &7x" + Texto.rango(p.getMinimo(), p.getMaximo())
                    + " &8| &7" + tabla.getNombreCategoria(p.getCategoria()));
            Mensajeria.enviarConItem(sender, linea, p, p.muestra());
        }
        if (pagina < paginas) {
            sender.sendMessage(Texto.color(" &7Siguiente: &e/" + label + " probabilidades "
                    + rareza.getId() + " " + (pagina + 1)));
        }
    }

    /**
     * /apostador garantia                      -> tu progreso
     * /apostador garantia <jugador>            -> progreso de otro (admin)
     * /apostador garantia <jugador> <giros>    -> ajusta el contador (admin, útil para probar)
     */
    private void garantia(CommandSender sender, String[] args) {
        Garantia garantia = plugin.getGarantia();
        Rareza objetivo = garantia.objetivo(plugin.getTabla());
        if (!garantia.isActivado() || objetivo == null) {
            plugin.enviar(sender, "garantia-desactivada");
            return;
        }
        Player objetivoJugador;
        if (args.length < 2) {
            if (!(sender instanceof Player p)) {
                plugin.enviar(sender, "solo-jugadores");
                return;
            }
            objetivoJugador = p;
        } else {
            if (!esAdmin(sender)) {
                return;
            }
            objetivoJugador = Bukkit.getPlayerExact(args[1]);
            if (objetivoJugador == null) {
                plugin.enviar(sender, "jugador-no-encontrado", "{jugador}", args[1]);
                return;
            }
            if (args.length >= 3) {
                int giros;
                try {
                    giros = Integer.parseInt(args[2]);
                } catch (NumberFormatException e) {
                    plugin.enviar(sender, "numero-invalido", "{valor}", args[2]);
                    return;
                }
                garantia.setContador(objetivoJugador, giros);
                plugin.enviar(sender, "garantia-establecida",
                        "{jugador}", objetivoJugador.getName(),
                        "{contador}", String.valueOf(garantia.getContador(objetivoJugador)),
                        "{cada}", String.valueOf(garantia.getCadaGiros()));
            }
        }
        plugin.enviar(sender, "garantia-info",
                "{jugador}", objetivoJugador.getName(),
                "{contador}", String.valueOf(garantia.getContador(objetivoJugador)),
                "{cada}", String.valueOf(garantia.getCadaGiros()),
                "{faltan}", String.valueOf(garantia.faltan(objetivoJugador)),
                "{rareza}", objetivo.getNombreConCodigos());
        sender.sendMessage(Texto.color(" " + garantia.barra(objetivoJugador)));
    }

    /** Hace miles de tiradas para comprobar que los porcentajes reales coinciden con los configurados. */
    private void simular(CommandSender sender, String[] args) {
        if (!esAdmin(sender)) {
            return;
        }
        TablaPremios tabla = plugin.getTabla();
        if (tabla.estaVacia()) {
            plugin.enviar(sender, "tabla-vacia");
            return;
        }
        int n = 100_000;
        if (args.length >= 2) {
            try {
                n = Integer.parseInt(args[1]);
            } catch (NumberFormatException ignored) {
                // usa el valor por defecto
            }
        }
        n = Math.max(1, Math.min(2_000_000, n));

        Map<Rareza, Integer> conteo = new LinkedHashMap<>();
        for (Rareza r : tabla.getRarezasActivas()) {
            conteo.put(r, 0);
        }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int i = 0; i < n; i++) {
            conteo.merge(tabla.tirarRareza(rnd), 1, Integer::sum);
        }

        sender.sendMessage(Texto.color(plugin.getPrefijo() + "&6Simulación de &f" + n + " &6tiradas:"));
        for (Map.Entry<Rareza, Integer> e : conteo.entrySet()) {
            double real = (double) e.getValue() / n;
            sender.sendMessage(Texto.color(" &8• " + e.getKey().getNombreConCodigos() + " &f" + e.getValue()
                    + " &7(" + Texto.porcentaje(real) + " &8vs esperado &7"
                    + Texto.porcentaje(tabla.probabilidadDe(e.getKey())) + ")"));
        }
        Garantia garantia = plugin.getGarantia();
        Rareza objetivo = garantia.objetivo(tabla);
        if (garantia.isActivado() && objetivo != null) {
            sender.sendMessage(Texto.color(" &6★ &7Sumando el garantizado cada &f" + garantia.getCadaGiros()
                    + " &7giros, " + objetivo.getNombreConCodigos() + " &7sale en el &f"
                    + Texto.porcentaje(garantia.tasaEfectiva(tabla)) + " &7de los giros."));
        }
    }

    private void ayuda(CommandSender sender, String label) {
        sender.sendMessage(Texto.color(plugin.getPrefijo() + "&6&lComandos"));
        if (sender.hasPermission(ADMIN)) {
            sender.sendMessage(Texto.color(" &e/" + label + " crear &7- aparece el mob apostador donde miras"));
            sender.sendMessage(Texto.color(" &e/" + label + " eliminar [todos] &7- quita el mob más cercano (o todos)"));
            sender.sendMessage(Texto.color(" &e/" + label + " simular [n] &7- prueba n tiradas y compara porcentajes"));
            sender.sendMessage(Texto.color(" &e/" + label + " recargar &7- relee config.yml y premios.yml"));
        }
        sender.sendMessage(Texto.color(" &e/" + label + " probabilidades [rareza] &7- tabla de premios"));
        if (plugin.getGarantia().isActivado()) {
            sender.sendMessage(Texto.color(" &e/" + label + " garantia &7- cuántos giros te faltan para el premio garantizado"));
            if (sender.hasPermission(ADMIN)) {
                sender.sendMessage(Texto.color(" &e/" + label + " garantia <jugador> [giros] &7- ver o ajustar el contador de alguien"));
            }
        }
        if (plugin.getConfig().getBoolean("apuesta.comando-apostar", true)) {
            sender.sendMessage(Texto.color(" &e/apostar &7- abre el menú de apuestas sin ir al mob"));
            sender.sendMessage(Texto.color(" &e/apostar <" + String.join("|", plugin.textoMultiples().replace("x", "").split(", "))
                    + "> &7- apuesta directa (" + plugin.textoMultiples() + ")"));
        }
    }

    private boolean esAdmin(CommandSender sender) {
        if (sender.hasPermission(ADMIN)) {
            return true;
        }
        plugin.enviar(sender, "sin-permiso");
        return false;
    }

    // ---------------------------------------------------------------- autocompletado

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> opciones = new ArrayList<>();
        if (command.getName().equalsIgnoreCase("apostar")) {
            if (args.length != 1) {
                return Collections.emptyList();
            }
            for (int v : plugin.getMultiples()) {
                opciones.add(String.valueOf(v));
            }
            opciones.removeIf(o -> !o.startsWith(args[0].toLowerCase(Locale.ROOT).replace("x", "")));
            return opciones;
        }
        if (args.length == 1) {
            opciones.add("probabilidades");
            opciones.add("garantia");
            if (sender.hasPermission(ADMIN)) {
                opciones.add("crear");
                opciones.add("eliminar");
                opciones.add("simular");
                opciones.add("recargar");
            }
        } else if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (sub.equals("probabilidades") || sub.equals("prob") || sub.equals("premios")) {
                for (Rareza r : plugin.getTabla().getRarezasActivas()) {
                    opciones.add(r.getId());
                }
            } else if (sub.equals("garantia") && sender.hasPermission(ADMIN)) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    opciones.add(p.getName());
                }
            } else if (sub.equals("eliminar") && sender.hasPermission(ADMIN)) {
                opciones.add("todos");
            } else if (sub.equals("simular") && sender.hasPermission(ADMIN)) {
                opciones.add("100000");
            }
        }
        String ultimo = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        opciones.removeIf(o -> !o.toLowerCase(Locale.ROOT).startsWith(ultimo));
        return opciones;
    }
}
