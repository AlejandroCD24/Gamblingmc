package com.mobapostador.util;

import com.mobapostador.premios.Premio;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * Envía mensajes que contienen el marcador {item}.
 * Si se puede, el nombre del ítem se manda como texto traducible (cada jugador lo ve en su idioma);
 * si no, se usa un nombre en texto plano.
 */
public final class Mensajeria {

    private static boolean componentesDisponibles = true;

    private Mensajeria() {
    }

    /** @param plantilla texto YA coloreado que contiene {item} */
    public static void enviarConItem(CommandSender destino, String plantilla, Premio premio, ItemStack item) {
        if (destino instanceof Player jugador && componentesDisponibles) {
            try {
                ComponentesBungee.enviar(jugador, plantilla, premio, item, false);
                return;
            } catch (LinkageError e) {
                componentesDisponibles = false;
            }
        }
        destino.sendMessage(plantilla.replace("{item}", nombrePlano(premio, item)));
    }

    /** Igual que {@link #enviarConItem} pero en la barra de acción (encima de la hotbar). */
    public static void actionBarConItem(Player jugador, String plantilla, Premio premio, ItemStack item) {
        if (!componentesDisponibles) {
            return;
        }
        try {
            ComponentesBungee.enviar(jugador, plantilla, premio, item, true);
        } catch (LinkageError e) {
            componentesDisponibles = false;
        }
    }

    /** Nombre de respaldo en texto plano. */
    public static String nombrePlano(Premio premio, ItemStack item) {
        if (premio.getNombre() != null) {
            return Texto.color(premio.getNombre());
        }
        String color = Texto.color(premio.getRareza().getColor());
        String nombre = Texto.bonito(item.getType().name());
        if (premio.getClavePocion() != null) {
            nombre += " (" + Texto.bonito(premio.getClavePocion()) + ")";
        }
        return color + nombre;
    }
}
