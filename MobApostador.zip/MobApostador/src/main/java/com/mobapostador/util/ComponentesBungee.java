package com.mobapostador.util;

import com.mobapostador.premios.Premio;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.TranslatableComponent;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Todo lo que usa la API de chat de BungeeCord está aquí aislado.
 * Así, si algún servidor no la trae, {@link Mensajeria} usa texto plano y el plugin sigue funcionando.
 */
final class ComponentesBungee {

    private static final Pattern MARCADOR_ITEM = Pattern.compile(Pattern.quote("{item}"));

    private ComponentesBungee() {
    }

    static void enviar(Player destino, String plantilla, Premio premio, ItemStack item, boolean actionBar) {
        BaseComponent nombre = nombre(premio, item);
        String[] partes = MARCADOR_ITEM.split(plantilla, -1);
        List<BaseComponent> salida = new ArrayList<>();
        String colorArrastrado = "";
        for (int i = 0; i < partes.length; i++) {
            String parte = colorArrastrado + partes[i];
            if (!parte.isEmpty()) {
                salida.addAll(Arrays.asList(TextComponent.fromLegacyText(parte)));
            }
            if (i < partes.length - 1) {
                salida.add(nombre.duplicate());
            }
            // Mantiene el color que venía antes de {item} para el texto que sigue
            colorArrastrado = ChatColor.getLastColors(parte);
        }
        BaseComponent[] arreglo = salida.toArray(new BaseComponent[0]);
        if (actionBar) {
            destino.spigot().sendMessage(ChatMessageType.ACTION_BAR, arreglo);
        } else {
            destino.spigot().sendMessage(arreglo);
        }
    }

    /** Nombre del ítem que el cliente traduce a su propio idioma (español si su Minecraft está en español). */
    private static BaseComponent nombre(Premio premio, ItemStack item) {
        if (premio.getNombre() != null) {
            return new TextComponent(TextComponent.fromLegacyText(Texto.color(premio.getNombre())));
        }

        BaseComponent base;
        Material tipo = item.getType();
        String clavePocion = premio.getClavePocion();
        if (clavePocion != null) {
            String efecto = clavePocion.replaceFirst("^(long_|strong_)", "");
            base = new TranslatableComponent(prefijoPocion(tipo) + efecto);
            if (clavePocion.startsWith("strong_")) {
                base.addExtra(" II");
            }
        } else {
            base = new TranslatableComponent(tipo.getTranslationKey());
            if (premio.getNivel() > 0) {
                base.addExtra(" ");
                base.addExtra(new TranslatableComponent("enchantment.level." + premio.getNivel()));
            }
            ItemMeta meta = item.getItemMeta();
            if (meta instanceof EnchantmentStorageMeta libro && libro.hasStoredEnchants()) {
                Map.Entry<Enchantment, Integer> primero = libro.getStoredEnchants().entrySet().iterator().next();
                NamespacedKey k = primero.getKey().getKey();
                base.addExtra(" (");
                base.addExtra(new TranslatableComponent("enchantment." + k.getNamespace() + "." + k.getKey()));
                base.addExtra(" ");
                base.addExtra(new TranslatableComponent("enchantment.level." + primero.getValue()));
                base.addExtra(")");
            }
        }

        net.md_5.bungee.api.ChatColor color = net.md_5.bungee.api.ChatColor.getByChar(premio.getRareza().getCodigoColor());
        if (color != null) {
            base.setColor(color);
        }
        return base;
    }

    private static String prefijoPocion(Material tipo) {
        if (tipo == Material.SPLASH_POTION) {
            return "item.minecraft.splash_potion.effect.";
        }
        if (tipo == Material.LINGERING_POTION) {
            return "item.minecraft.lingering_potion.effect.";
        }
        if (tipo == Material.TIPPED_ARROW) {
            return "item.minecraft.tipped_arrow.effect.";
        }
        return "item.minecraft.potion.effect.";
    }
}
