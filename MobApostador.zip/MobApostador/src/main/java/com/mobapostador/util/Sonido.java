package com.mobapostador.util;

import org.bukkit.entity.Player;

/** Reproduce sonidos por su id ("minecraft:entity.player.levelup") sin romper nada si el id está mal escrito. */
public final class Sonido {

    private Sonido() {
    }

    public static void reproducir(Player p, String sonido, float volumen, float tono) {
        if (sonido == null || sonido.isBlank() || sonido.equalsIgnoreCase("ninguno")) {
            return;
        }
        try {
            p.playSound(p.getLocation(), sonido.trim().toLowerCase(java.util.Locale.ROOT), volumen, tono);
        } catch (RuntimeException ignored) {
            // id de sonido inválido: se ignora
        }
    }
}
