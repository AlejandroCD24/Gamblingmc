package com.mobapostador.util;

import org.bukkit.ChatColor;

import java.util.Locale;

/** Utilidades de texto: colores con '&', nombres legibles y porcentajes. */
public final class Texto {

    private Texto() {
    }

    /** Convierte los códigos '&' en colores de Minecraft. */
    public static String color(String s) {
        return s == null ? "" : ChatColor.translateAlternateColorCodes('&', s);
    }

    /** Quita todos los colores de un texto. */
    public static String sinColor(String s) {
        return s == null ? "" : ChatColor.stripColor(color(s));
    }

    /** COOKED_BEEF -> "Cooked Beef". Se usa solo como respaldo cuando no hay traducción del cliente. */
    public static String bonito(String constante) {
        if (constante == null) {
            return "";
        }
        String[] partes = constante.toLowerCase(Locale.ROOT).split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : partes) {
            if (p.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        }
        return sb.toString();
    }

    /** Recibe una probabilidad entre 0 y 1 y devuelve "12.50%", "0.125%", etc. */
    public static String porcentaje(double probabilidad) {
        double v = probabilidad * 100.0;
        if (v >= 1.0) {
            return String.format(Locale.ROOT, "%.2f%%", v);
        }
        if (v >= 0.01) {
            return String.format(Locale.ROOT, "%.3f%%", v);
        }
        return String.format(Locale.ROOT, "%.4f%%", v);
    }

    /** 66667 -> "66,667" */
    public static String miles(long n) {
        return String.format(Locale.US, "%,d", n);
    }

    /** "5" si min == max, si no "2-8". */
    public static String rango(int min, int max) {
        return min == max ? String.valueOf(min) : min + "-" + max;
    }
}
