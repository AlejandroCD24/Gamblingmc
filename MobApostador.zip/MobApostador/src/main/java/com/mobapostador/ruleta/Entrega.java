package com.mobapostador.ruleta;

import com.mobapostador.MobApostador;
import com.mobapostador.premios.Garantia;
import com.mobapostador.premios.Premio;
import com.mobapostador.premios.Rareza;
import com.mobapostador.premios.Resultado;
import com.mobapostador.util.Mensajeria;
import com.mobapostador.util.Sonido;
import com.mobapostador.util.Texto;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Da los premios al jugador con mensajes, sonido, título, anuncio y fuegos artificiales. */
public final class Entrega {

    private Entrega() {
    }

    public static void entregar(MobApostador plugin, Player jugador, List<Resultado> resultados) {
        if (resultados.isEmpty()) {
            return;
        }

        // 1) Dar todos los ítems (lo que no quepa se tira al suelo)
        boolean alSuelo = false;
        for (Resultado r : resultados) {
            Map<Integer, ItemStack> sobrantes = jugador.getInventory().addItem(r.item().clone());
            for (ItemStack s : sobrantes.values()) {
                jugador.getWorld().dropItemNaturally(jugador.getLocation(), s);
                alSuelo = true;
            }
        }
        if (alSuelo) {
            plugin.enviar(jugador, "inventario-lleno");
        }

        // 2) Mensajes al ganador (el nombre del ítem sale en el idioma de su Minecraft)
        Garantia garantia = plugin.getGarantia();
        Rareza objetivo = garantia.objetivo(plugin.getTabla());
        for (Resultado r : resultados) {
            if (r.garantizado()) {
                plugin.enviar(jugador, "garantia-activada",
                        "{cada}", String.valueOf(garantia.getCadaGiros()),
                        "{rareza}", r.premio().getRareza().getNombreConCodigos());
                Sonido.reproducir(jugador, "minecraft:entity.player.levelup", 1.0f, 0.6f);
            }
        }
        if (resultados.size() == 1) {
            Resultado r = resultados.get(0);
            Mensajeria.enviarConItem(jugador, linea(plugin, "ganaste", jugador, r, true), r.premio(), r.item());
            Mensajeria.actionBarConItem(jugador, Texto.color("&f" + r.item().getAmount() + "x {item}"), r.premio(), r.item());
        } else {
            jugador.sendMessage(Texto.color(plugin.getPrefijo() + plugin.getTexto("ganaste-varios")
                    .replace("{total}", String.valueOf(resultados.size()))));
            for (Resultado r : resultados) {
                Mensajeria.enviarConItem(jugador, linea(plugin, "premio-linea", jugador, r, false), r.premio(), r.item());
            }
        }

        // 3) Sonido y título de la MEJOR rareza obtenida
        Rareza mejor = mejorRareza(resultados);
        Sonido.reproducir(jugador, mejor.getSonido(), 1.0f, 1.0f);
        if (mejor.isTitulo()) {
            jugador.sendTitle(
                    Texto.color(mejor.getColor() + "&l¡" + mejor.getNombre().toUpperCase(Locale.ROOT) + "!"),
                    Texto.color(plugin.getTexto("subtitulo")),
                    10, 50, 15);
        }

        // 4) Anuncio a todo el servidor por cada premio de rareza anunciable
        boolean fuegos = false;
        for (Resultado r : resultados) {
            Rareza rareza = r.premio().getRareza();
            fuegos |= rareza.isFuegosArtificiales();
            if (!rareza.isAnunciar()) {
                continue;
            }
            String anuncio = linea(plugin, r.garantizado() ? "anuncio-garantizado" : "anuncio", jugador, r, true)
                    .replace("{cada}", String.valueOf(garantia.getCadaGiros()));
            for (Player otro : Bukkit.getOnlinePlayers()) {
                if (!otro.equals(jugador)) {
                    Mensajeria.enviarConItem(otro, anuncio, r.premio(), r.item());
                }
            }
            plugin.getLogger().info(jugador.getName() + " ganó " + r.item().getAmount() + "x "
                    + r.item().getType().name() + " (" + rareza.getNombre() + ")");
        }

        // 5) Fuegos artificiales (no hacen daño: se cancelan en MobListener)
        if (fuegos && plugin.isEnabled()) {
            fuegos(plugin, jugador.getLocation());
        }

        // 6) Cuántos giros faltan para el próximo premio garantizado
        if (garantia.isActivado() && garantia.isMostrarProgreso() && objetivo != null) {
            plugin.enviar(jugador, "progreso-garantia",
                    "{faltan}", String.valueOf(garantia.faltan(jugador)),
                    "{contador}", String.valueOf(garantia.getContador(jugador)),
                    "{cada}", String.valueOf(garantia.getCadaGiros()),
                    "{rareza}", objetivo.getNombreConCodigos());
        }
    }

    /** Arma un mensaje de la config con {cantidad}, {rareza} y {jugador}; deja {item} para Mensajeria. */
    private static String linea(MobApostador plugin, String clave, Player jugador, Resultado r, boolean conPrefijo) {
        Premio premio = r.premio();
        String texto = plugin.getTexto(clave)
                .replace("{cantidad}", String.valueOf(r.item().getAmount()))
                .replace("{rareza}", premio.getRareza().getNombreConCodigos())
                .replace("{jugador}", jugador.getName());
        return Texto.color((conPrefijo ? plugin.getPrefijo() : "") + texto);
    }

    /** La rareza más difícil (menor probabilidad) entre los resultados. */
    static Rareza mejorRareza(List<Resultado> resultados) {
        Rareza mejor = resultados.get(0).premio().getRareza();
        for (Resultado r : resultados) {
            if (r.premio().getRareza().getProbabilidad() < mejor.getProbabilidad()) {
                mejor = r.premio().getRareza();
            }
        }
        return mejor;
    }

    private static void fuegos(MobApostador plugin, Location centro) {
        if (centro.getWorld() == null) {
            return;
        }
        double[][] desplazamientos = {{0, 2.5, 0}, {1.5, 2.0, 1.5}, {-1.5, 2.0, -1.5}};
        for (double[] d : desplazamientos) {
            Location loc = centro.clone().add(d[0], d[1], d[2]);
            Firework fw = centro.getWorld().spawn(loc, Firework.class);
            fw.getPersistentDataContainer().set(plugin.getClaveFuego(), PersistentDataType.BYTE, (byte) 1);
            FireworkMeta meta = fw.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder()
                    .with(FireworkEffect.Type.BALL_LARGE)
                    .withColor(Color.ORANGE, Color.YELLOW)
                    .withFade(Color.WHITE)
                    .flicker(true)
                    .trail(true)
                    .build());
            meta.setPower(0);
            fw.setFireworkMeta(meta);
            fw.detonate();
        }
    }
}
