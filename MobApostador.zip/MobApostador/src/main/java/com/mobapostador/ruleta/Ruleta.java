package com.mobapostador.ruleta;

import com.mobapostador.MobApostador;
import com.mobapostador.premios.Resultado;
import com.mobapostador.premios.TablaPremios;
import com.mobapostador.util.Sonido;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Apuesta x1: tragamonedas en un cofre de 3 filas.
 * La fila del medio gira y se va frenando; el ítem que queda en el centro (bajo las flechas) es el premio.
 */
final class Ruleta extends Animacion {

    private static final int TAMANIO = 27;
    private static final int PRIMER_SLOT_RODILLO = 9;   // fila del medio: 9..17
    private static final int ANCHO_RODILLO = 9;
    private static final int CENTRO = 4;                // posición del centro dentro del rodillo (slot 13)
    private static final int PUNTERO_ARRIBA = 4;
    private static final int PUNTERO_ABAJO = 22;

    private final Resultado resultado;
    private final int totalFrames;
    private final String sonidoGiro;
    private final List<ItemStack> secuencia = new ArrayList<>();
    private int frame = 0;
    private int espera = 0;

    Ruleta(MobApostador plugin, GestorRuletas gestor, Player jugador, Resultado resultado) {
        super(plugin, gestor, jugador, List.of(resultado));
        this.resultado = resultado;
        FileConfiguration cfg = plugin.getConfig();
        this.totalFrames = Math.max(15, Math.min(150, cfg.getInt("animacion.pasos", 45)));
        this.sonidoGiro = cfg.getString("animacion.sonido-giro", "minecraft:block.note_block.hat");
    }

    @Override
    protected Inventory crearInventario() {
        Inventory inv = Bukkit.createInventory(this, TAMANIO, titulo());
        inventario = inv;

        // Rodillo: ítems al azar (con las mismas probabilidades reales) y el premio en la posición final
        TablaPremios tabla = plugin.getTabla();
        Random rnd = ThreadLocalRandom.current();
        int largo = totalFrames + ANCHO_RODILLO - 1;
        int indicePremio = (totalFrames - 1) + CENTRO;
        for (int i = 0; i < largo; i++) {
            Resultado r = (i == indicePremio) ? resultado : tabla.tirar(rnd);
            secuencia.add(decorar(r));
        }
        pintarMarco(null);
        mostrarFrame();
        return inv;
    }

    @Override
    protected void paso() {
        if (++espera < retraso(frame)) {
            return;
        }
        espera = 0;
        frame++;
        mostrarFrame();
        pintarMarco(null);
        float tono = 0.8f + 1.0f * frame / totalFrames;
        Sonido.reproducir(jugador, sonidoGiro, 0.6f, tono);

        if (frame >= totalFrames - 1) {
            pintarMarco(resultado.premio().getRareza().getPanel());
            terminar();
        }
    }

    /** Se frena poco a poco: rápido al inicio, lento al final. */
    private int retraso(int f) {
        double p = (double) f / totalFrames;
        if (p < 0.45) return 1;
        if (p < 0.65) return 2;
        if (p < 0.80) return 3;
        if (p < 0.90) return 4;
        if (p < 0.96) return 6;
        return 9;
    }

    private void mostrarFrame() {
        for (int i = 0; i < ANCHO_RODILLO; i++) {
            inventario.setItem(PRIMER_SLOT_RODILLO + i, secuencia.get(frame + i));
        }
    }

    /** @param fijo null = colores aleatorios (girando); si no, todo el marco de ese color (resultado). */
    private void pintarMarco(Material fijo) {
        Random rnd = ThreadLocalRandom.current();
        for (int slot = 0; slot < TAMANIO; slot++) {
            if (slot >= PRIMER_SLOT_RODILLO && slot < PRIMER_SLOT_RODILLO + ANCHO_RODILLO) {
                continue;
            }
            if (slot == PUNTERO_ARRIBA) {
                inventario.setItem(slot, panel(Material.LIME_STAINED_GLASS_PANE, "&a&l▼ PREMIO ▼"));
            } else if (slot == PUNTERO_ABAJO) {
                inventario.setItem(slot, panel(Material.LIME_STAINED_GLASS_PANE, "&a&l▲ PREMIO ▲"));
            } else {
                Material m = fijo != null ? fijo : COLORES[rnd.nextInt(COLORES.length)];
                inventario.setItem(slot, panel(m, " "));
            }
        }
    }
}
