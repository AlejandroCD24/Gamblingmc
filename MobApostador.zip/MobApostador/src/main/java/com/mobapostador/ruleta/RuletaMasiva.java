package com.mobapostador.ruleta;

import com.mobapostador.MobApostador;
import com.mobapostador.premios.Rareza;
import com.mobapostador.premios.Resultado;
import com.mobapostador.premios.TablaPremios;
import com.mobapostador.util.Sonido;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Apuesta grande (x100): un cofre de 6 filas donde los premios se van destapando rápido, en desorden.
 * Se muestran los 45 mejores (los más raros primero); abajo queda el resumen por rareza.
 * Dura unos 3 segundos.
 */
final class RuletaMasiva extends Animacion {

    private static final int TAMANIO = 54;
    private static final int CUADRICULA = 45;
    private static final int PAUSA_INICIAL = 10;

    private final List<Resultado> ordenados;
    private final int mostrados;
    private final List<Integer> orden = new ArrayList<>();
    private final int porTick;
    private int tick = 0;
    private int destapados = 0;

    RuletaMasiva(MobApostador plugin, GestorRuletas gestor, Player jugador, List<Resultado> resultados) {
        super(plugin, gestor, jugador, resultados);
        // Los más raros primero, para que se vean aunque haya más premios que casillas
        ordenados = new ArrayList<>(resultados);
        ordenados.sort(Comparator.comparingDouble((Resultado r) -> r.premio().getRareza().getProbabilidad())
                .thenComparing(r -> r.premio().getClave()));
        mostrados = Math.min(CUADRICULA, ordenados.size());
        for (int i = 0; i < mostrados; i++) {
            orden.add(i);
        }
        Collections.shuffle(orden, ThreadLocalRandom.current());
        porTick = Math.max(1, (int) Math.ceil(mostrados / 45.0));
    }

    @Override
    protected Inventory crearInventario() {
        Inventory inv = Bukkit.createInventory(this, TAMANIO, titulo());
        inventario = inv;
        for (int i = 0; i < CUADRICULA; i++) {
            inv.setItem(i, i < mostrados
                    ? panel(Material.GRAY_STAINED_GLASS_PANE, "&7&l?")
                    : panel(Material.BLACK_STAINED_GLASS_PANE, " "));
        }
        for (int i = CUADRICULA; i < TAMANIO; i++) {
            inv.setItem(i, panel(Material.BLACK_STAINED_GLASS_PANE, " "));
        }
        return inv;
    }

    @Override
    protected void paso() {
        tick++;
        if (tick < PAUSA_INICIAL) {
            return;
        }
        TablaPremios tabla = plugin.getTabla();
        for (int k = 0; k < porTick && destapados < mostrados; k++) {
            int slot = orden.get(destapados++);
            Resultado r = ordenados.get(slot);
            inventario.setItem(slot, decorar(r));
            Rareza rareza = r.premio().getRareza();
            if (rareza.isTitulo()) {
                float tono = Math.min(2.0f, 0.7f + 0.3f * tabla.rango(rareza));
                Sonido.reproducir(jugador, "minecraft:block.note_block.bell", 0.8f, tono);
            } else if (destapados % 2 == 0) {
                Sonido.reproducir(jugador, "minecraft:block.note_block.hat", 0.4f, 1.5f);
            }
        }
        if (destapados >= mostrados) {
            dibujarResumen();
            terminar();
        }
    }

    /** Fila de abajo: cuántos premios salieron de cada rareza. */
    private void dibujarResumen() {
        Map<Rareza, int[]> conteo = new LinkedHashMap<>(); // [total, descartados]
        for (Rareza r : plugin.getTabla().getRarezasActivas()) {
            conteo.put(r, new int[2]);
        }
        for (Resultado r : resultados) {
            int[] c = conteo.computeIfAbsent(r.premio().getRareza(), k -> new int[2]);
            c[0]++;
            if (seleccion.descarta(r.premio())) {
                c[1]++;
            }
        }
        int slot = CUADRICULA + 1;
        for (Map.Entry<Rareza, int[]> e : conteo.entrySet()) {
            if (slot >= TAMANIO - 1) {
                break;
            }
            int[] c = e.getValue();
            String texto = e.getKey().getNombreConCodigos() + "&7: &f" + c[0]
                    + (c[1] > 0 ? " &8(" + c[1] + " descartados)" : "");
            inventario.setItem(slot++, panelNuevo(c[0] > 0 ? e.getKey().getPanel() : Material.GRAY_STAINED_GLASS_PANE, texto));
        }
        if (resultados.size() > mostrados) {
            inventario.setItem(CUADRICULA, panelNuevo(Material.PAPER,
                    "&e+" + (resultados.size() - mostrados) + " premios más &7(míralos en el chat)"));
        }
    }
}
