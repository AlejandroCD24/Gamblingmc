package com.mobapostador.ruleta;

import com.mobapostador.MobApostador;
import com.mobapostador.premios.Rareza;
import com.mobapostador.premios.Resultado;
import com.mobapostador.premios.TablaPremios;
import com.mobapostador.util.Sonido;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Apuesta x5 / x10: cada premio tiene su propia casilla que gira y se detiene una por una, de izquierda a derecha.
 * Debajo de cada casilla aparece el color de la rareza que salió.
 *
 * x5  -> cofre de 3 filas (1 fila de premios)
 * x10 -> cofre de 6 filas (2 filas de 5 premios)
 */
final class RuletaMultiple extends Animacion {

    private static final int POR_FILA = 5;
    private static final int TAMANIO_POOL = 40;

    private final int[] slotsPremio;
    private final int[] slotsIndicador;
    private final Set<Integer> slotsReservados = new HashSet<>();
    private final int tamanio;
    private final int inicio;
    private final int intervalo;
    private final String sonidoGiro;
    private final List<ItemStack> pool = new ArrayList<>();
    private int tick = 0;
    private int detenidos = 0;

    RuletaMultiple(MobApostador plugin, GestorRuletas gestor, Player jugador, List<Resultado> resultados) {
        super(plugin, gestor, jugador, resultados);
        int n = resultados.size();
        int filasPremios = (n + POR_FILA - 1) / POR_FILA;
        // borde superior + (premios + indicadores) por fila + borde inferior si hay más de una fila
        int filas = Math.min(6, 1 + 2 * filasPremios + (filasPremios > 1 ? 1 : 0));
        this.tamanio = filas * 9;

        this.slotsPremio = new int[n];
        this.slotsIndicador = new int[n];
        for (int i = 0; i < n; i++) {
            int fila = i / POR_FILA;
            int enEstaFila = Math.min(POR_FILA, n - fila * POR_FILA);
            int columna = (9 - enEstaFila) / 2 + (i % POR_FILA);
            int slot = (1 + 2 * fila) * 9 + columna;
            slotsPremio[i] = slot;
            slotsIndicador[i] = slot + 9;
            slotsReservados.add(slot);
            slotsReservados.add(slot + 9);
        }

        FileConfiguration cfg = plugin.getConfig();
        this.inicio = Math.max(5, cfg.getInt("animacion.multiple-inicio-ticks", 20));
        this.intervalo = Math.max(1, cfg.getInt("animacion.multiple-intervalo-ticks", n > POR_FILA ? 6 : 8));
        this.sonidoGiro = cfg.getString("animacion.sonido-giro", "minecraft:block.note_block.hat");
    }

    @Override
    protected Inventory crearInventario() {
        Inventory inv = Bukkit.createInventory(this, tamanio, titulo());
        inventario = inv;

        // Ítems de relleno que pasan mientras gira (mismas probabilidades reales)
        TablaPremios tabla = plugin.getTabla();
        Random rnd = ThreadLocalRandom.current();
        for (int i = 0; i < TAMANIO_POOL; i++) {
            pool.add(decorar(tabla.tirar(rnd)));
        }
        for (int i = 0; i < slotsPremio.length; i++) {
            inv.setItem(slotsPremio[i], pool.get(rnd.nextInt(pool.size())));
            inv.setItem(slotsIndicador[i], panel(Material.GRAY_STAINED_GLASS_PANE, "&7&l?"));
        }
        pintarMarco(null);
        return inv;
    }

    @Override
    protected void paso() {
        tick++;
        Random rnd = ThreadLocalRandom.current();

        // ¿Toca detener la siguiente casilla?
        while (detenidos < slotsPremio.length && tick >= inicio + detenidos * intervalo) {
            revelar(detenidos);
            detenidos++;
        }
        if (detenidos >= slotsPremio.length) {
            pintarMarco(Entrega.mejorRareza(resultados).getPanel());
            terminar();
            return;
        }

        // Las casillas que siguen girando cambian de ítem cada 2 ticks
        if (tick % 2 == 0) {
            for (int i = detenidos; i < slotsPremio.length; i++) {
                inventario.setItem(slotsPremio[i], pool.get(rnd.nextInt(pool.size())));
            }
            Sonido.reproducir(jugador, sonidoGiro, 0.4f, 1.4f);
        }
        if (tick % 4 == 0) {
            pintarMarco(null);
        }
    }

    private void revelar(int i) {
        Resultado r = resultados.get(i);
        Rareza rareza = r.premio().getRareza();
        inventario.setItem(slotsPremio[i], decorar(r));
        String etiqueta = rareza.getNombreConCodigos() + (r.garantizado() ? " &6&l★ GARANTIZADO" : "");
        inventario.setItem(slotsIndicador[i], panel(rareza.getPanel(), etiqueta));
        // Más agudo cuanto más rara la rareza
        float tono = Math.min(2.0f, 0.7f + 0.3f * rango(rareza));
        Sonido.reproducir(jugador, "minecraft:block.note_block.bell", 0.9f, tono);
    }

    /** 0 = la rareza más común; sube con cada rareza más difícil. */
    private int rango(Rareza rareza) {
        int r = 0;
        for (Rareza otra : plugin.getTabla().getRarezasActivas()) {
            if (otra.getProbabilidad() > rareza.getProbabilidad()) {
                r++;
            }
        }
        return r;
    }

    /** @param fijo null = colores aleatorios (girando); si no, todo el marco de ese color. */
    private void pintarMarco(Material fijo) {
        Random rnd = ThreadLocalRandom.current();
        for (int slot = 0; slot < tamanio; slot++) {
            if (slotsReservados.contains(slot)) {
                continue;
            }
            Material m = fijo != null ? fijo : COLORES[rnd.nextInt(COLORES.length)];
            inventario.setItem(slot, panel(m, " "));
        }
    }
}
