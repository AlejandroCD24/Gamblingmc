package com.mobapostador.ruleta;

import com.mobapostador.MobApostador;
import com.mobapostador.premios.Filtro;
import com.mobapostador.premios.Premio;
import com.mobapostador.premios.Rareza;
import com.mobapostador.premios.TablaPremios;
import com.mobapostador.util.Sonido;
import com.mobapostador.util.Texto;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Menú "Elegir premios": el jugador marca los premios que quiere recibir.
 * Los que no marque se descartan al apostar. Si no marca ninguno, recibe todos.
 *
 * Filas 1-4: premios de la rareza elegida (36 por página)
 * Fila 5:    ◀ página | pestañas de rareza | página ▶
 * Fila 6:    volver | marcar todos | info | quitar todos | borrar toda la selección
 */
public final class MenuFiltro implements InventoryHolder {

    private static final int TAMANIO = 54;
    private static final int POR_PAGINA = 36;
    private static final int SLOT_ANTERIOR = 36;
    private static final int SLOT_SIGUIENTE = 44;
    private static final int PRIMERA_PESTANIA = 37; // 37..43 (hasta 7 rarezas)
    private static final int SLOT_VOLVER = 45;
    private static final int SLOT_MARCAR_TODOS = 47;
    private static final int SLOT_INFO = 49;
    private static final int SLOT_QUITAR_TODOS = 51;
    private static final int SLOT_BORRAR = 53;

    private final MobApostador plugin;
    private final Player jugador;
    private final Inventory inventario;
    private final Set<String> seleccion;
    private final List<Rareza> rarezas;
    private final Map<Integer, String> claveEnSlot = new HashMap<>();
    private Rareza actual;
    private int pagina = 0;

    private MenuFiltro(MobApostador plugin, Player jugador) {
        this.plugin = plugin;
        this.jugador = jugador;
        TablaPremios tabla = plugin.getTabla();
        this.seleccion = plugin.getFiltro().leer(jugador);
        this.seleccion.retainAll(tabla.getClaves());
        this.rarezas = new ArrayList<>(tabla.getRarezasActivas());
        if (rarezas.size() > 7) {
            rarezas.subList(7, rarezas.size()).clear();
        }
        this.actual = rarezas.isEmpty() ? null : rarezas.get(0);
        this.inventario = Bukkit.createInventory(this, TAMANIO,
                Texto.color(plugin.getConfig().getString("filtro.titulo", "&8» &b&lElige tus premios")));
        dibujar();
    }

    static MenuFiltro abrir(MobApostador plugin, Player p) {
        MenuFiltro menu = new MenuFiltro(plugin, p);
        p.openInventory(menu.inventario);
        return menu;
    }

    @Override
    public Inventory getInventory() {
        return inventario;
    }

    // ---------------------------------------------------------------- dibujo

    /** Premios de la rareza actual agrupados por clave (ej. "Diamantes 1-3" y "4-8" son una sola entrada). */
    private Map<String, List<Premio>> entradas() {
        Map<String, List<Premio>> r = new LinkedHashMap<>();
        if (actual != null) {
            for (Premio p : plugin.getTabla().getPremios(actual)) {
                r.computeIfAbsent(p.getClave(), k -> new ArrayList<>()).add(p);
            }
        }
        return r;
    }

    private void dibujar() {
        inventario.clear();
        claveEnSlot.clear();
        ItemStack relleno = Animacion.panel(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = POR_PAGINA; i < TAMANIO; i++) {
            inventario.setItem(i, relleno);
        }
        if (actual == null) {
            return;
        }
        Filtro filtro = plugin.getFiltro();
        boolean protegida = filtro.esProtegida(actual);
        TablaPremios tabla = plugin.getTabla();

        // Premios de la página
        List<Map.Entry<String, List<Premio>>> lista = new ArrayList<>(entradas().entrySet());
        int paginas = Math.max(1, (lista.size() + POR_PAGINA - 1) / POR_PAGINA);
        pagina = Math.max(0, Math.min(paginas - 1, pagina));
        int desde = pagina * POR_PAGINA;
        for (int i = 0; i < POR_PAGINA && desde + i < lista.size(); i++) {
            Map.Entry<String, List<Premio>> e = lista.get(desde + i);
            double prob = 0;
            for (Premio p : e.getValue()) {
                prob += tabla.probabilidadDe(p);
            }
            boolean marcado = seleccion.contains(e.getKey());
            ItemStack icono = e.getValue().get(0).muestra();
            ItemMeta meta = icono.getItemMeta();
            if (meta != null) {
                List<String> lore = new ArrayList<>();
                lore.add(Texto.color("&7Sale 1 de cada &f" + Texto.miles(Math.round(1 / Math.max(prob, 1e-12))) + " &7giros"));
                lore.add("");
                if (protegida) {
                    lore.add(Texto.color("&aEsta rareza siempre se recibe."));
                } else if (marcado) {
                    lore.add(Texto.color("&a&l✔ SELECCIONADO"));
                    lore.add(Texto.color("&7Clic para quitarlo"));
                } else {
                    lore.add(Texto.color("&7Clic para seleccionarlo"));
                }
                meta.setLore(lore);
                if (marcado) {
                    meta.setEnchantmentGlintOverride(true);
                }
                icono.setItemMeta(meta);
            }
            inventario.setItem(i, icono);
            claveEnSlot.put(i, e.getKey());
        }

        // Páginas
        if (pagina > 0) {
            inventario.setItem(SLOT_ANTERIOR, boton(Material.ARROW, "&e◀ Página anterior", List.of()));
        }
        if (pagina < paginas - 1) {
            inventario.setItem(SLOT_SIGUIENTE, boton(Material.ARROW, "&ePágina siguiente ▶", List.of()));
        }

        // Pestañas de rareza
        for (int i = 0; i < rarezas.size(); i++) {
            Rareza r = rarezas.get(i);
            int marcados = 0;
            for (Premio p : tabla.getPremios(r)) {
                if (seleccion.contains(p.getClave())) {
                    marcados++;
                }
            }
            List<String> lore = new ArrayList<>();
            lore.add(filtro.esProtegida(r) ? "&aSiempre se recibe" : "&7Seleccionados: &f" + marcados);
            lore.add(r == actual ? "&e» Viendo ahora" : "&7Clic para ver");
            ItemStack pestania = boton(r.getPanel(), r.getNombreConCodigos(), lore);
            if (r == actual) {
                ItemMeta m = pestania.getItemMeta();
                if (m != null) {
                    m.setEnchantmentGlintOverride(true);
                    pestania.setItemMeta(m);
                }
            }
            inventario.setItem(PRIMERA_PESTANIA + i, pestania);
        }

        // Controles
        inventario.setItem(SLOT_VOLVER, boton(Material.OAK_DOOR, "&e« Volver a apostar", List.of()));
        if (!protegida) {
            inventario.setItem(SLOT_MARCAR_TODOS, boton(Material.LIME_DYE, "&aSeleccionar todos de " + actual.getNombreConCodigos(), List.of()));
            inventario.setItem(SLOT_QUITAR_TODOS, boton(Material.GRAY_DYE, "&7Quitar todos de " + actual.getNombreConCodigos(), List.of()));
        }
        inventario.setItem(SLOT_BORRAR, boton(Material.BARRIER, "&cBorrar toda la selección",
                List.of("&7Vuelves a recibir todos los premios.")));
        inventario.setItem(SLOT_INFO, boton(Material.BOOK, "&b&lCómo funciona", List.of(
                seleccion.isEmpty()
                        ? "&aNo tienes nada seleccionado: recibes TODOS los premios."
                        : "&7Tienes &f" + seleccion.size() + " &7premios seleccionados.",
                "",
                "&7Marca los premios que quieres recibir.",
                "&7Los que salgan y &cno &7estén marcados se &cdescartan&7.",
                "&7Si no marcas ninguno, recibes todo.",
                "&aLas rarezas protegidas siempre se reciben.",
                "&7Las probabilidades no cambian.")));
    }

    private static ItemStack boton(Material material, String nombre, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Texto.color(nombre));
            List<String> l = new ArrayList<>();
            for (String s : lore) {
                l.add(Texto.color(s));
            }
            meta.setLore(l);
            item.setItemMeta(meta);
        }
        return item;
    }

    // ---------------------------------------------------------------- clics

    void clic(Player p, int slot) {
        if (actual == null) {
            return;
        }
        boolean protegida = plugin.getFiltro().esProtegida(actual);
        boolean cambio = false;

        if (slot < POR_PAGINA) {
            String clave = claveEnSlot.get(slot);
            if (clave == null || protegida) {
                return;
            }
            if (!seleccion.remove(clave)) {
                seleccion.add(clave);
            }
            cambio = true;
        } else if (slot == SLOT_ANTERIOR) {
            pagina--;
        } else if (slot == SLOT_SIGUIENTE) {
            pagina++;
        } else if (slot >= PRIMERA_PESTANIA && slot < PRIMERA_PESTANIA + rarezas.size()) {
            actual = rarezas.get(slot - PRIMERA_PESTANIA);
            pagina = 0;
        } else if (slot == SLOT_MARCAR_TODOS && !protegida) {
            seleccion.addAll(entradas().keySet());
            cambio = true;
        } else if (slot == SLOT_QUITAR_TODOS && !protegida) {
            seleccion.removeAll(entradas().keySet());
            cambio = true;
        } else if (slot == SLOT_BORRAR) {
            seleccion.clear();
            cambio = true;
        } else if (slot == SLOT_VOLVER) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (p.isOnline()) {
                    plugin.getRuletas().abrirMenu(p);
                }
            });
            return;
        } else {
            return;
        }

        if (cambio) {
            plugin.getFiltro().guardar(jugador, seleccion);
        }
        Sonido.reproducir(p, "minecraft:ui.button.click", 0.5f, 1.2f);
        dibujar();
    }
}
