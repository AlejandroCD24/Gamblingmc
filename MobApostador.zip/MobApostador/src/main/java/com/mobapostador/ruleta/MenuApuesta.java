package com.mobapostador.ruleta;

import com.mobapostador.MobApostador;
import com.mobapostador.economia.Cobro;
import com.mobapostador.premios.Garantia;
import com.mobapostador.premios.Rareza;
import com.mobapostador.premios.TablaPremios;
import com.mobapostador.util.Texto;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Menú que aparece al darle clic al mob: elegir apostar x1, x5 o x10. */
public final class MenuApuesta implements InventoryHolder {

    private static final int TAMANIO = 27;
    private static final int SLOT_PROBABILIDADES = 22;
    private static final int SLOT_GARANTIA = 4;

    private final MobApostador plugin;
    private final Player jugador;
    private final Inventory inventario;
    private final Map<Integer, Integer> opciones = new HashMap<>(); // slot -> número de tiradas
    private long ultimoClic = 0;

    private MenuApuesta(MobApostador plugin, Player jugador) {
        this.plugin = plugin;
        this.jugador = jugador;
        this.inventario = Bukkit.createInventory(this, TAMANIO,
                Texto.color(plugin.getConfig().getString("menu.titulo", "&8» &6&lElige tu apuesta")));

        ItemStack relleno = Animacion.panel(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < TAMANIO; i++) {
            inventario.setItem(i, relleno);
        }

        // Opciones centradas en la fila del medio
        List<Integer> multiples = plugin.getMultiples();
        int n = Math.min(9, multiples.size());
        int separacion = n <= 4 ? 2 : 1;
        int inicio = 13 - (n - 1) * separacion / 2;
        for (int i = 0; i < n; i++) {
            int slot = inicio + i * separacion;
            int veces = multiples.get(i);
            opciones.put(slot, veces);
            inventario.setItem(slot, opcion(veces));
        }

        inventario.setItem(SLOT_PROBABILIDADES, boton(Material.BOOK, "&6&lVer probabilidades",
                List.of("&7Muestra en el chat la tabla", "&7de rarezas y premios.")));

        // Progreso hacia el premio garantizado
        Garantia garantia = plugin.getGarantia();
        Rareza objetivo = garantia.objetivo(plugin.getTabla());
        if (garantia.isActivado() && objetivo != null) {
            int cada = garantia.getCadaGiros();
            inventario.setItem(SLOT_GARANTIA, boton(Material.NETHER_STAR,
                    "&6&l★ " + objetivo.getNombre() + " garantizado",
                    List.of("&7Cada &f" + cada + " &7giros recibes un premio " + objetivo.getNombreConCodigos() + "&7.",
                            "&7Cada tirada cuenta como 1 giro.",
                            "",
                            garantia.barra(jugador),
                            "&7Llevas &f" + garantia.getContador(jugador) + "&7/&f" + cada + " &7giros",
                            "&7Te faltan &e" + garantia.faltan(jugador) + " &7giros")));
        }
    }

    static MenuApuesta abrir(MobApostador plugin, Player p) {
        MenuApuesta menu = new MenuApuesta(plugin, p);
        p.openInventory(menu.inventario);
        return menu;
    }

    @Override
    public Inventory getInventory() {
        return inventario;
    }

    private ItemStack opcion(int veces) {
        Cobro cobro = plugin.getCobro();
        TablaPremios tabla = plugin.getTabla();
        List<String> lore = new ArrayList<>();
        lore.add("&7Recibes &f" + veces + (veces == 1 ? " &7premio" : " &7premios"));
        lore.add("&7Costo: " + cobro.descripcion(veces));
        double descuento = cobro.descuento(veces);
        if (descuento > 0) {
            lore.add("&a&l¡" + Texto.porcentaje(descuento / 100.0).replace(".00%", "%") + " de descuento!");
        }
        Rareza rara = tabla.rarezaMasRara();
        if (rara != null) {
            double p = 1 - Math.pow(1 - tabla.probabilidadDe(rara), veces);
            lore.add("&7Prob. de 1+ " + rara.getNombreConCodigos() + "&7: &f" + Texto.porcentaje(p));
        }
        Garantia garantia = plugin.getGarantia();
        Rareza objetivo = garantia.objetivo(tabla);
        if (garantia.isActivado() && objetivo != null && veces >= garantia.faltan(jugador)) {
            lore.add("&6&l★ ¡Incluye tu " + objetivo.getNombre() + " garantizado!");
        }
        lore.add("");
        lore.add("&e» Clic para apostar");

        ItemStack item = boton(cobro.icono(), "&a&lApostar x" + veces, lore);
        item.setAmount(Math.max(1, Math.min(64, veces)));
        return item;
    }

    private static ItemStack boton(Material material, String nombre, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Texto.color(nombre));
            List<String> coloreado = new ArrayList<>();
            for (String l : lore) {
                coloreado.add(Texto.color(l));
            }
            meta.setLore(coloreado);
            item.setItemMeta(meta);
        }
        return item;
    }

    /** Clic en una casilla del menú (ya cancelado por GestorRuletas). */
    void clic(Player p, int slot) {
        long ahora = System.currentTimeMillis();
        if (ahora - ultimoClic < 400) {
            return; // evita apostar dos veces con un doble clic
        }
        Integer veces = opciones.get(slot);
        if (veces != null) {
            ultimoClic = ahora;
            // Se hace en el siguiente tick: abrir otro inventario dentro del evento de clic da problemas
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (p.isOnline()) {
                    plugin.intentarApuesta(p, veces);
                }
            });
        } else if (slot == SLOT_PROBABILIDADES) {
            ultimoClic = ahora;
            Bukkit.getScheduler().runTask(plugin, () -> {
                p.closeInventory();
                p.performCommand("apostador probabilidades");
            });
        }
    }
}
