package com.mobapostador.ruleta;

import com.mobapostador.MobApostador;
import com.mobapostador.premios.Resultado;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Lleva el control de las ruletas y menús abiertos y protege sus inventarios. */
public final class GestorRuletas implements Listener {

    private final MobApostador plugin;
    /** Animaciones que todavía no entregan sus premios (una por jugador). */
    private final Map<UUID, Animacion> activas = new HashMap<>();
    /** Todas las animaciones con el cofre abierto, incluidas las que ya terminaron y muestran los premios. */
    private final Set<Animacion> abiertas = new HashSet<>();
    /** Menús de selección x1/x5/x10 abiertos. */
    private final Set<MenuApuesta> menus = new HashSet<>();
    /**
     * Inventarios del plugin abiertos ahora mismo. Los eventos de inventario se disparan con CUALQUIER
     * cofre del servidor; con este set se descartan al instante los que no son nuestros, sin llamar
     * a getHolder() (que en cofres reales es costoso).
     */
    private final Set<Inventory> inventarios = new HashSet<>();

    public GestorRuletas(MobApostador plugin) {
        this.plugin = plugin;
    }

    public boolean estaGirando(Player p) {
        return activas.containsKey(p.getUniqueId());
    }

    /** 1 resultado = ruleta clásica; varios = ruleta múltiple. */
    public void iniciar(Player p, List<Resultado> resultados) {
        Animacion animacion = resultados.size() == 1
                ? new Ruleta(plugin, this, p, resultados.get(0))
                : new RuletaMultiple(plugin, this, p, resultados);
        activas.put(p.getUniqueId(), animacion);
        abiertas.add(animacion);
        animacion.iniciar();
    }

    public void abrirMenu(Player p) {
        MenuApuesta menu = MenuApuesta.abrir(plugin, p);
        if (menu.getInventory().getViewers().contains(p)) {
            menus.add(menu);
            inventarios.add(menu.getInventory());
        }
    }

    void registrar(Inventory inventario) {
        inventarios.add(inventario);
    }

    /** Ya entregó los premios: el jugador puede volver a apostar. */
    void quitar(Animacion animacion) {
        activas.remove(animacion.getJugador().getUniqueId(), animacion);
    }

    /** La animación terminó por completo (tarea cancelada). */
    void cerrada(Animacion animacion) {
        quitar(animacion);
        abiertas.remove(animacion);
        if (animacion.getInventory() != null) {
            inventarios.remove(animacion.getInventory());
        }
    }

    /**
     * Al apagar o recargar: entrega los premios pendientes y cierra TODOS los cofres del plugin,
     * para que nadie pueda sacar los ítems de muestra cuando el plugin deja de proteger el inventario.
     */
    public void finalizarTodas() {
        for (Animacion a : new ArrayList<>(abiertas)) {
            a.forzarEntrega(true);
        }
        for (MenuApuesta m : new ArrayList<>(menus)) {
            for (HumanEntity h : new ArrayList<>(m.getInventory().getViewers())) {
                h.closeInventory();
            }
        }
        activas.clear();
        abiertas.clear();
        menus.clear();
        inventarios.clear();
    }

    // ---------------------------------------------------------------- eventos

    @EventHandler(priority = EventPriority.LOWEST)
    public void alClic(InventoryClickEvent e) {
        if (!inventarios.contains(e.getInventory())) {
            return; // no es nuestro: salida inmediata
        }
        InventoryHolder holder = e.getInventory().getHolder();
        if (holder instanceof Animacion) {
            e.setCancelled(true);
        } else if (holder instanceof MenuApuesta menu) {
            e.setCancelled(true);
            int slot = e.getRawSlot();
            if (slot >= 0 && slot < e.getInventory().getSize() && e.getWhoClicked() instanceof Player p) {
                menu.clic(p, slot);
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void alArrastrar(InventoryDragEvent e) {
        if (!inventarios.contains(e.getInventory())) {
            return;
        }
        InventoryHolder holder = e.getInventory().getHolder();
        if (holder instanceof Animacion || holder instanceof MenuApuesta) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void alCerrar(InventoryCloseEvent e) {
        if (!inventarios.contains(e.getInventory())) {
            return;
        }
        InventoryHolder holder = e.getInventory().getHolder();
        if (holder instanceof Animacion animacion) {
            animacion.alCerrar();
        } else if (holder instanceof MenuApuesta menu) {
            menus.remove(menu);
            inventarios.remove(menu.getInventory());
        }
    }

    @EventHandler
    public void alSalir(PlayerQuitEvent e) {
        Animacion animacion = activas.get(e.getPlayer().getUniqueId());
        if (animacion != null) {
            animacion.forzarEntrega(false);
        }
        plugin.olvidarJugador(e.getPlayer().getUniqueId()); // libera su cooldown de la memoria
    }
}
