package com.mobapostador.ruleta;

import com.mobapostador.MobApostador;
import com.mobapostador.premios.Resultado;
import com.mobapostador.util.Texto;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Base de las animaciones de apuesta (simple y múltiple).
 * Se encarga de la tarea por tick, de entregar los premios UNA sola vez y del cierre del cofre.
 * Los resultados se deciden ANTES de animar; la animación solo los muestra.
 */
public abstract class Animacion implements InventoryHolder {

    protected static final Material[] COLORES = {
            Material.RED_STAINED_GLASS_PANE, Material.ORANGE_STAINED_GLASS_PANE,
            Material.YELLOW_STAINED_GLASS_PANE, Material.LIME_STAINED_GLASS_PANE,
            Material.LIGHT_BLUE_STAINED_GLASS_PANE, Material.BLUE_STAINED_GLASS_PANE,
            Material.PURPLE_STAINED_GLASS_PANE, Material.MAGENTA_STAINED_GLASS_PANE,
            Material.PINK_STAINED_GLASS_PANE, Material.CYAN_STAINED_GLASS_PANE
    };

    protected final MobApostador plugin;
    protected final Player jugador;
    protected final List<Resultado> resultados;
    protected Inventory inventario;

    private final GestorRuletas gestor;
    private final int ticksCierre;
    private BukkitTask tarea;
    private int ticksTrasTerminar = 0;
    private boolean terminada = false;
    private boolean entregado = false;
    private boolean detenida = false;

    protected Animacion(MobApostador plugin, GestorRuletas gestor, Player jugador, List<Resultado> resultados) {
        this.plugin = plugin;
        this.gestor = gestor;
        this.jugador = jugador;
        this.resultados = List.copyOf(resultados);
        this.ticksCierre = Math.max(0, plugin.getConfig().getInt("animacion.cerrar-tras-ticks", 60));
    }

    /** Crea y llena el inventario inicial. */
    protected abstract Inventory crearInventario();

    /** Se llama cada tick mientras gira. Debe llamar a {@link #terminar()} cuando acabe. */
    protected abstract void paso();

    @Override
    public Inventory getInventory() {
        return inventario;
    }

    public Player getJugador() {
        return jugador;
    }

    final void iniciar() {
        inventario = crearInventario();
        gestor.registrar(inventario);
        jugador.openInventory(inventario);
        tarea = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    private void tick() {
        if (!jugador.isOnline()) {
            forzarEntrega(false);
            return;
        }
        if (terminada) {
            // Ya terminó: deja ver los premios un momento y cierra
            if (!estaViendo()) {
                detener();
                return;
            }
            if (ticksCierre > 0 && ++ticksTrasTerminar >= ticksCierre) {
                detener();
                jugador.closeInventory();
            }
            return;
        }
        paso();
    }

    /** La animación llegó al final: entrega los premios. */
    protected final void terminar() {
        terminada = true;
        entregar();
    }

    // ---------------------------------------------------------------- utilidades para las subclases

    /** Paneles ya creados: la animación los reutiliza en vez de crear ítems nuevos en cada tick. */
    private static final Map<String, ItemStack> PANELES = new HashMap<>();

    /** Devuelve un panel compartido: NO se debe modificar (setItem del inventario hace su propia copia). */
    protected static ItemStack panel(Material material, String nombre) {
        return PANELES.computeIfAbsent(material.name() + '|' + nombre, k -> {
            ItemStack item = new ItemStack(material);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(Texto.color(nombre));
                item.setItemMeta(meta);
            }
            return item;
        });
    }

    /** Copia del ítem con la rareza y categoría en la descripción (solo para mostrar). */
    protected ItemStack decorar(Resultado r) {
        ItemStack copia = r.item().clone();
        ItemMeta meta = copia.getItemMeta();
        if (meta == null) {
            return copia;
        }
        List<String> lore = new ArrayList<>();
        if (meta.hasLore() && meta.getLore() != null) {
            lore.addAll(meta.getLore());
        }
        lore.add("");
        lore.add(Texto.color("&7Rareza: ") + r.premio().getRareza().getNombreColoreado());
        lore.add(Texto.color("&7Categoría: &f" + plugin.getTabla().getNombreCategoria(r.premio().getCategoria())));
        if (r.garantizado()) {
            lore.add(Texto.color("&6&l★ GARANTIZADO ★"));
        }
        meta.setLore(lore);
        copia.setItemMeta(meta);
        return copia;
    }

    protected String titulo() {
        return Texto.color(plugin.getConfig().getString("animacion.titulo", "&6&lRuleta del Apostador"));
    }

    // ---------------------------------------------------------------- cierre / entrega

    private boolean estaViendo() {
        return inventario != null && inventario.getViewers().contains(jugador);
    }

    /** Entrega una sola vez, pase lo que pase. */
    private void entregar() {
        if (entregado) {
            return;
        }
        entregado = true;
        gestor.quitar(this);
        Entrega.entregar(plugin, jugador, resultados);
    }

    /** El jugador cerró el cofre: si aún giraba, se le dan los premios al instante. */
    void alCerrar() {
        entregar();
        detener();
    }

    /** Termina ya (desconexión, apagado del servidor...). */
    void forzarEntrega(boolean cerrarInventario) {
        boolean viendo = estaViendo();
        entregar();
        detener();
        if (cerrarInventario && viendo) {
            jugador.closeInventory();
        }
    }

    private void detener() {
        if (detenida) {
            return;
        }
        detenida = true;
        if (tarea != null) {
            tarea.cancel();
        }
        gestor.cerrada(this);
    }
}
