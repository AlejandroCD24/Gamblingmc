package com.mobapostador.economia;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Conexión con Vault. Esta clase solo se carga si el plugin Vault está instalado,
 * por eso el resto del plugin funciona aunque Vault no exista.
 */
final class VaultHook {

    private final Economy economia;

    private VaultHook(Economy economia) {
        this.economia = economia;
    }

    static VaultHook intentar(JavaPlugin plugin) {
        RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null || rsp.getProvider() == null) {
            return null;
        }
        return new VaultHook(rsp.getProvider());
    }

    boolean tiene(Player p, double cantidad) {
        return economia.has(p, cantidad);
    }

    boolean cobrar(Player p, double cantidad) {
        return economia.withdrawPlayer(p, cantidad).transactionSuccess();
    }

    String formatear(double cantidad) {
        return economia.format(cantidad);
    }
}
