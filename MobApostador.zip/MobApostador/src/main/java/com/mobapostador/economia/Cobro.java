package com.mobapostador.economia;

import com.mobapostador.util.Texto;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Cobra la apuesta: con ítems del inventario, con dinero (Vault) o gratis.
 * Las apuestas múltiples (x5, x10...) cuestan el precio de una apuesta por el número de tiradas,
 * menos el descuento configurado.
 */
public final class Cobro {

    public enum Tipo { ITEM, DINERO, GRATIS }

    public enum Estado { OK, SIN_FONDOS, VAULT_NO_DISPONIBLE }

    private final JavaPlugin plugin;
    private final Tipo tipo;
    private final Material material;
    private final int cantidad;
    private final double dinero;
    private final String textoItem;
    private final String textoDinero;
    private final Map<Integer, Double> descuentos = new HashMap<>();
    private VaultHook vault;

    public Cobro(JavaPlugin plugin, ConfigurationSection sec) {
        this.plugin = plugin;

        Tipo t;
        String nombreTipo = sec == null ? "ITEM" : sec.getString("tipo-costo", "ITEM");
        try {
            t = Tipo.valueOf(nombreTipo.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("apuesta.tipo-costo '" + nombreTipo + "' no es válido (ITEM, DINERO o GRATIS). Se usará ITEM.");
            t = Tipo.ITEM;
        }
        this.tipo = t;

        String nombreMat = sec == null ? "EMERALD" : sec.getString("item", "EMERALD");
        Material m = Material.matchMaterial(nombreMat);
        if (m == null || m.isAir() || !m.isItem()) {
            plugin.getLogger().warning("apuesta.item '" + nombreMat + "' no existe. Se usará EMERALD.");
            m = Material.EMERALD;
        }
        this.material = m;
        this.cantidad = sec == null ? 5 : sec.getInt("cantidad", 5);
        this.dinero = sec == null ? 100.0 : sec.getDouble("dinero", 100.0);
        this.textoItem = sec == null ? "&a{cantidad} esmeraldas" : sec.getString("texto-costo-item", "&a{cantidad} esmeraldas");
        this.textoDinero = sec == null ? "&a{dinero}" : sec.getString("texto-costo-dinero", "&a{dinero}");

        ConfigurationSection secDesc = sec == null ? null : sec.getConfigurationSection("descuentos");
        if (secDesc != null) {
            for (String k : secDesc.getKeys(false)) {
                try {
                    int veces = Integer.parseInt(k.trim().toLowerCase(Locale.ROOT).replace("x", ""));
                    double pct = Math.max(0.0, Math.min(100.0, secDesc.getDouble(k, 0.0)));
                    descuentos.put(veces, pct);
                } catch (NumberFormatException e) {
                    plugin.getLogger().warning("apuesta.descuentos: '" + k + "' no es un número de tiradas.");
                }
            }
        }
    }

    public boolean esGratis() {
        return tipo == Tipo.GRATIS
                || (tipo == Tipo.ITEM && cantidad <= 0)
                || (tipo == Tipo.DINERO && dinero <= 0);
    }

    /** Descuento en % para ese número de tiradas (0 si no hay). */
    public double descuento(int veces) {
        return descuentos.getOrDefault(veces, 0.0);
    }

    private int costoItems(int veces) {
        return (int) Math.ceil(cantidad * veces * (1.0 - descuento(veces) / 100.0) - 1e-9);
    }

    private double costoDinero(int veces) {
        return dinero * veces * (1.0 - descuento(veces) / 100.0);
    }

    /** Revisa y cobra en un solo paso. Si devuelve OK, ya se cobró. */
    public Estado cobrar(Player p, int veces) {
        if (esGratis()) {
            return Estado.OK;
        }
        if (tipo == Tipo.ITEM) {
            int total = costoItems(veces);
            if (total <= 0) {
                return Estado.OK;
            }
            if (!p.getInventory().containsAtLeast(new ItemStack(material), total)) {
                return Estado.SIN_FONDOS;
            }
            int restante = total;
            int porStack = Math.max(1, material.getMaxStackSize());
            while (restante > 0) {
                int n = Math.min(restante, porStack);
                p.getInventory().removeItem(new ItemStack(material, n));
                restante -= n;
            }
            return Estado.OK;
        }
        // DINERO
        double total = costoDinero(veces);
        if (total <= 0) {
            return Estado.OK;
        }
        VaultHook v = vault();
        if (v == null) {
            return Estado.VAULT_NO_DISPONIBLE;
        }
        if (!v.tiene(p, total) || !v.cobrar(p, total)) {
            return Estado.SIN_FONDOS;
        }
        return Estado.OK;
    }

    /** Texto del costo de una apuesta x1 (con códigos '&'). */
    public String descripcion() {
        return descripcion(1);
    }

    /** Texto del costo para ese número de tiradas (con códigos '&'). */
    public String descripcion(int veces) {
        if (esGratis()) {
            return "&agratis";
        }
        if (tipo == Tipo.ITEM) {
            return textoItem
                    .replace("{cantidad}", String.valueOf(costoItems(veces)))
                    .replace("{item}", Texto.bonito(material.name()));
        }
        double total = costoDinero(veces);
        VaultHook v = vault();
        String monto = v != null ? v.formatear(total) : String.format(Locale.ROOT, "%.2f", total);
        return textoDinero.replace("{dinero}", monto);
    }

    /** Ícono para el menú: el ítem con que se paga, o un lingote de oro si es dinero. */
    public Material icono() {
        return tipo == Tipo.DINERO ? Material.GOLD_INGOT : material;
    }

    public Tipo getTipo() {
        return tipo;
    }

    /** Busca la economía la primera vez que se necesita (los plugins de economía a veces cargan después). */
    private VaultHook vault() {
        if (vault == null && plugin.getServer().getPluginManager().getPlugin("Vault") != null) {
            vault = VaultHook.intentar(plugin);
        }
        return vault;
    }
}
