package com.mobapostador.economia;

import com.mobapostador.util.Texto;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Cobra la apuesta: con ítems del inventario, con dinero (Vault) o gratis.
 * Las apuestas múltiples (x5, x10...) cuestan el precio de una apuesta por el número de tiradas,
 * menos el descuento configurado.
 */
public final class Cobro {

    public enum Tipo { ITEM, DINERO, GRATIS }

    public enum Estado { OK, SIN_FONDOS, VAULT_NO_DISPONIBLE }

    private final JavaPlugin plugin;
    private final Tipo tipo;
    private final Material material;
    private final int cantidad;
    private final double dinero;
    private final String textoItem;
    private final String textoDinero;
    private final Map<Integer, Double> descuentos = new HashMap<>();
    /** Otros ítems que sirven para pagar y cuánto vale cada uno (ej. bloque de esmeralda = 9). De mayor a menor valor. */
    private final LinkedHashMap<Material, Integer> equivalentes = new LinkedHashMap<>();
    private final String textoEquivalentes;
    private VaultHook vault;

    public Cobro(JavaPlugin plugin, ConfigurationSection sec) {
        this.plugin = plugin;

        Tipo t;
        String nombreTipo = sec == null ? "ITEM" : sec.getString("tipo-costo", "ITEM");
        try {
            t = Tipo.valueOf(nombreTipo.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("apuesta.tipo-costo '" + nombreTipo + "' no es válido (ITEM, DINERO o GRATIS). Se usará ITEM.");
            t = Tipo.ITEM;
        }
        this.tipo = t;

        String nombreMat = sec == null ? "EMERALD" : sec.getString("item", "EMERALD");
        Material m = Material.matchMaterial(nombreMat);
        if (m == null || m.isAir() || !m.isItem()) {
            plugin.getLogger().warning("apuesta.item '" + nombreMat + "' no existe. Se usará EMERALD.");
            m = Material.EMERALD;
        }
        this.material = m;
        this.cantidad = sec == null ? 5 : sec.getInt("cantidad", 5);
        this.dinero = sec == null ? 100.0 : sec.getDouble("dinero", 100.0);
        this.textoItem = sec == null ? "&a{cantidad} esmeraldas" : sec.getString("texto-costo-item", "&a{cantidad} esmeraldas");
        this.textoDinero = sec == null ? "&a{dinero}" : sec.getString("texto-costo-dinero", "&a{dinero}");

        // Equivalentes (por defecto, si se paga con esmeraldas, también valen los bloques de esmeralda)
        Map<Material, Integer> leidos = new HashMap<>();
        ConfigurationSection secEq = sec == null ? null : sec.getConfigurationSection("equivalentes");
        if (secEq != null) {
            for (String k : secEq.getKeys(false)) {
                Material eq = Material.matchMaterial(k);
                int valor = secEq.getInt(k, 0);
                if (eq == null || eq.isAir() || !eq.isItem() || eq == m || valor < 2) {
                    plugin.getLogger().warning("apuesta.equivalentes." + k + " no es válido (ítem existente y valor 2 o más).");
                    continue;
                }
                leidos.put(eq, valor);
            }
        } else if (m == Material.EMERALD) {
            leidos.put(Material.EMERALD_BLOCK, 9);
        }
        leidos.entrySet().stream()
                .sorted(Map.Entry.<Material, Integer>comparingByValue().reversed())
                .forEach(e -> equivalentes.put(e.getKey(), e.getValue()));
        this.textoEquivalentes = equivalentes.isEmpty() ? ""
                : (sec == null ? "&7(también se paga con bloques de esmeralda)"
                : sec.getString("texto-equivalentes", "&7(también se paga con bloques de esmeralda)"));

        ConfigurationSection secDesc = sec == null ? null : sec.getConfigurationSection("descuentos");
        if (secDesc != null) {
            for (String k : secDesc.getKeys(false)) {
                try {
                    int veces = Integer.parseInt(k.trim().toLowerCase(Locale.ROOT).replace("x", ""));
                    double pct = Math.max(0.0, Math.min(100.0, secDesc.getDouble(k, 0.0)));
                    descuentos.put(veces, pct);
                } catch (NumberFormatException e) {
                    plugin.getLogger().warning("apuesta.descuentos: '" + k + "' no es un número de tiradas.");
                }
            }
        }
    }

    public boolean esGratis() {
        return tipo == Tipo.GRATIS
                || (tipo == Tipo.ITEM && cantidad <= 0)
                || (tipo == Tipo.DINERO && dinero <= 0);
    }

    /** Descuento en % para ese número de tiradas (0 si no hay). */
    public double descuento(int veces) {
        return descuentos.getOrDefault(veces, 0.0);
    }

    private int costoItems(int veces) {
        return (int) Math.ceil(cantidad * veces * (1.0 - descuento(veces) / 100.0) - 1e-9);
    }

    private double costoDinero(int veces) {
        return dinero * veces * (1.0 - descuento(veces) / 100.0);
    }

    /** Revisa y cobra en un solo paso. Si devuelve OK, ya se cobró. */
    public Estado cobrar(Player p, int veces) {
        if (esGratis()) {
            return Estado.OK;
        }
        if (tipo == Tipo.ITEM) {
            int total = costoItems(veces);
            if (total <= 0) {
                return Estado.OK;
            }
            return cobrarItems(p, total) ? Estado.OK : Estado.SIN_FONDOS;
        }
        // DINERO
        double total = costoDinero(veces);
        if (total <= 0) {
            return Estado.OK;
        }
        VaultHook v = vault();
        if (v == null) {
            return Estado.VAULT_NO_DISPONIBLE;
        }
        if (!v.tiene(p, total) || !v.cobrar(p, total)) {
            return Estado.SIN_FONDOS;
        }
        return Estado.OK;
    }

    /**
     * Cobra 'total' unidades del ítem base usando también los equivalentes (bloques).
     * Primero usa los bloques que caben exactos, luego ítems sueltos y, si falta, rompe un bloque
     * y devuelve el cambio. Ej.: x100 = 500 esmeraldas = 55 bloques + 5 esmeraldas.
     */
    private boolean cobrarItems(Player p, int total) {
        int disponible = contar(p, material);
        for (Map.Entry<Material, Integer> e : equivalentes.entrySet()) {
            disponible += contar(p, e.getKey()) * e.getValue();
        }
        if (disponible < total) {
            return false;
        }
        int restante = total;
        for (Map.Entry<Material, Integer> e : equivalentes.entrySet()) { // de mayor a menor valor
            int usar = Math.min(contar(p, e.getKey()), restante / e.getValue());
            quitar(p, e.getKey(), usar);
            restante -= usar * e.getValue();
        }
        int sueltos = Math.min(contar(p, material), restante);
        quitar(p, material, sueltos);
        restante -= sueltos;
        if (restante > 0) {
            // No alcanzan los sueltos: se rompe la unidad más chica que tenga y se devuelve el cambio
            List<Map.Entry<Material, Integer>> deMenorAMayor = new ArrayList<>(equivalentes.entrySet());
            Collections.reverse(deMenorAMayor);
            for (Map.Entry<Material, Integer> e : deMenorAMayor) {
                if (contar(p, e.getKey()) > 0 && e.getValue() >= restante) {
                    quitar(p, e.getKey(), 1);
                    dar(p, material, e.getValue() - restante);
                    restante = 0;
                    break;
                }
            }
        }
        return restante <= 0;
    }

    /** Cuenta solo ítems normales (sin nombre ni encantamientos) del inventario principal. */
    private static int contar(Player p, Material m) {
        ItemStack referencia = new ItemStack(m);
        int n = 0;
        for (ItemStack it : p.getInventory().getStorageContents()) {
            if (it != null && it.isSimilar(referencia)) {
                n += it.getAmount();
            }
        }
        return n;
    }

    private static void quitar(Player p, Material m, int cantidad) {
        int porStack = Math.max(1, m.getMaxStackSize());
        while (cantidad > 0) {
            int n = Math.min(cantidad, porStack);
            p.getInventory().removeItem(new ItemStack(m, n));
            cantidad -= n;
        }
    }

    private static void dar(Player p, Material m, int cantidad) {
        int porStack = Math.max(1, m.getMaxStackSize());
        while (cantidad > 0) {
            int n = Math.min(cantidad, porStack);
            for (ItemStack sobra : p.getInventory().addItem(new ItemStack(m, n)).values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), sobra);
            }
            cantidad -= n;
        }
    }

    /** "(también se paga con bloques de esmeralda)" o vacío si no hay equivalentes. */
    public String textoEquivalentes() {
        return textoEquivalentes;
    }

    /** Texto del costo de una apuesta x1 (con códigos '&'). */
    public String descripcion() {
        return descripcion(1);
    }

    /** Texto del costo para ese número de tiradas (con códigos '&'). */
    public String descripcion(int veces) {
        if (esGratis()) {
            return "&agratis";
        }
        if (tipo == Tipo.ITEM) {
            return textoItem
                    .replace("{cantidad}", String.valueOf(costoItems(veces)))
                    .replace("{item}", Texto.bonito(material.name()));
        }
        double total = costoDinero(veces);
        VaultHook v = vault();
        String monto = v != null ? v.formatear(total) : String.format(Locale.ROOT, "%.2f", total);
        return textoDinero.replace("{dinero}", monto);
    }

    /** Ícono para el menú: el ítem con que se paga, o un lingote de oro si es dinero. */
    public Material icono() {
        return tipo == Tipo.DINERO ? Material.GOLD_INGOT : material;
    }

    public Tipo getTipo() {
        return tipo;
    }

    /** Busca la economía la primera vez que se necesita (los plugins de economía a veces cargan después). */
    private VaultHook vault() {
        if (vault == null && plugin.getServer().getPluginManager().getPlugin("Vault") != null) {
            vault = VaultHook.intentar(plugin);
        }
        return vault;
    }
}
