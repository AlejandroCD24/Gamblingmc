package com.mobapostador;

import com.mobapostador.comandos.ComandoApostador;
import com.mobapostador.economia.Cobro;
import com.mobapostador.mob.GestorMob;
import com.mobapostador.mob.MobListener;
import com.mobapostador.premios.Garantias;
import com.mobapostador.premios.Resultado;
import com.mobapostador.premios.TablaPremios;
import com.mobapostador.ruleta.Entrega;
import com.mobapostador.ruleta.GestorRuletas;
import com.mobapostador.util.Sonido;
import com.mobapostador.util.Texto;
import org.bukkit.NamespacedKey;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class MobApostador extends JavaPlugin {

    /** Máximo de tiradas en una sola apuesta (lo que cabe en la ruleta múltiple). */
    public static final int MAX_TIRADAS = 10;

    private final Map<UUID, Long> ultimaApuesta = new HashMap<>();
    private List<Integer> multiples = List.of(1, 5, 10);
    private TablaPremios tabla;
    private Cobro cobro;
    private Garantias garantias;
    private GestorMob gestorMob;
    private GestorRuletas ruletas;
    private NamespacedKey claveFuego;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "premios.yml").exists()) {
            saveResource("premios.yml", false);
        }
        claveFuego = new NamespacedKey(this, "fuego_apostador");
        gestorMob = new GestorMob(this);
        ruletas = new GestorRuletas(this);

        recargar();

        getServer().getPluginManager().registerEvents(new MobListener(this, gestorMob), this);
        getServer().getPluginManager().registerEvents(ruletas, this);

        ComandoApostador comando = new ComandoApostador(this);
        registrarComando("apostador", comando);
        registrarComando("apostar", comando);

        getLogger().info("MobApostador listo: " + tabla.getTotalPremios() + " premios en "
                + tabla.getRarezasActivas().size() + " rarezas.");
    }

    @Override
    public void onDisable() {
        if (ruletas != null) {
            ruletas.finalizarTodas(); // nadie pierde su premio si el servidor se apaga a media ruleta
        }
    }

    private void registrarComando(String nombre, ComandoApostador ejecutor) {
        PluginCommand cmd = getCommand(nombre);
        if (cmd != null) {
            cmd.setExecutor(ejecutor);
            cmd.setTabCompleter(ejecutor);
        }
    }

    /** Relee config.yml y premios.yml. */
    public void recargar() {
        reloadConfig();
        YamlConfiguration premiosCfg = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "premios.yml"));
        Set<String> categorias = new HashSet<>();
        for (String c : getConfig().getStringList("categorias-activas")) {
            categorias.add(c.trim().toLowerCase(Locale.ROOT));
        }
        tabla = TablaPremios.cargar(premiosCfg, categorias, getLogger());
        cobro = new Cobro(this, getConfig().getConfigurationSection("apuesta"));
        garantias = new Garantias(this, getConfig().getConfigurationSection("garantizado"));

        // Apuestas permitidas: x1, x5, x10... (de 1 a 10 tiradas)
        TreeSet<Integer> lista = new TreeSet<>();
        for (Integer v : getConfig().getIntegerList("apuesta.multiples")) {
            if (v != null && v >= 1 && v <= MAX_TIRADAS) {
                lista.add(v);
            } else {
                getLogger().warning("apuesta.multiples: " + v + " no es válido (debe ser de 1 a " + MAX_TIRADAS + ").");
            }
        }
        if (lista.isEmpty()) {
            lista.addAll(List.of(1, 5, 10));
        }
        multiples = List.copyOf(lista);
        if (tabla.estaVacia()) {
            getLogger().severe("¡No hay ningún premio válido! Revisa premios.yml y categorias-activas en config.yml.");
        }
        gestorMob.refrescarTodos();
    }

    /** Clic al mob o /apostar sin número: abre el menú x1/x5/x10 (o apuesta directo si solo hay una opción). */
    public void abrirMenuOApostar(Player p) {
        if (!p.hasPermission("apostador.usar")) {
            enviar(p, "sin-permiso");
            return;
        }
        if (ruletas.estaGirando(p)) {
            enviar(p, "ya-girando");
            return;
        }
        if (multiples.size() == 1) {
            intentarApuesta(p, multiples.get(0));
        } else {
            ruletas.abrirMenu(p);
        }
    }

    /** Todo el flujo de una apuesta de {@code veces} tiradas: validar, cobrar, tirar y mostrar la ruleta. */
    public void intentarApuesta(Player p, int veces) {
        if (!p.hasPermission("apostador.usar")) {
            enviar(p, "sin-permiso");
            return;
        }
        if (!multiples.contains(veces)) {
            enviar(p, "multiple-invalido", "{opciones}", textoMultiples());
            return;
        }
        if (ruletas.estaGirando(p)) {
            enviar(p, "ya-girando");
            return;
        }
        long ahora = System.currentTimeMillis();
        long espera = (long) (getConfig().getDouble("apuesta.cooldown-segundos", 3.0) * 1000L);
        Long ultima = ultimaApuesta.get(p.getUniqueId());
        if (ultima != null && ahora - ultima < espera) {
            double faltan = (espera - (ahora - ultima)) / 1000.0;
            enviar(p, "cooldown", "{segundos}", String.format(Locale.ROOT, "%.1f", faltan));
            return;
        }
        if (tabla.estaVacia()) {
            enviar(p, "tabla-vacia");
            return;
        }

        if (!p.hasPermission("apostador.gratis")) {
            switch (cobro.cobrar(p, veces)) {
                case SIN_FONDOS -> {
                    enviar(p, "sin-fondos", "{costo}", cobro.descripcion(veces), "{veces}", String.valueOf(veces));
                    Sonido.reproducir(p, "minecraft:entity.villager.no", 1.0f, 1.0f);
                    return;
                }
                case VAULT_NO_DISPONIBLE -> {
                    enviar(p, "vault-no-disponible");
                    return;
                }
                default -> {
                    if (!cobro.esGratis()) {
                        enviar(p, "cobrado", "{costo}", cobro.descripcion(veces), "{veces}", String.valueOf(veces));
                    }
                }
            }
        }

        ultimaApuesta.put(p.getUniqueId(), ahora);
        // Cada tirada pasa por los contadores de giros (Legendario y Mítico garantizados)
        List<Resultado> resultados = new ArrayList<>(veces);
        for (int i = 0; i < veces; i++) {
            resultados.add(garantias.tirar(p, tabla, ThreadLocalRandom.current()));
        }
        if (getConfig().getBoolean("animacion.activada", true)) {
            ruletas.iniciar(p, resultados);
        } else {
            Entrega.entregar(this, p, resultados);
        }
    }

    /** "x1, x5, x10" */
    public String textoMultiples() {
        StringBuilder sb = new StringBuilder();
        for (int v : multiples) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append('x').append(v);
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------- mensajes

    public String getPrefijo() {
        return getConfig().getString("prefijo", "");
    }

    /** Texto crudo de mensajes.&lt;clave&gt; (con códigos '&'). */
    public String getTexto(String clave) {
        return getConfig().getString("mensajes." + clave, "");
    }

    /** Envía mensajes.&lt;clave&gt; con prefijo y reemplazos en pares: "{a}", "valor", "{b}", "valor"... */
    public void enviar(CommandSender destino, String clave, String... reemplazos) {
        String texto = getTexto(clave);
        if (texto == null || texto.isEmpty()) {
            return;
        }
        for (int i = 0; i + 1 < reemplazos.length; i += 2) {
            texto = texto.replace(reemplazos[i], reemplazos[i + 1]);
        }
        destino.sendMessage(Texto.color(getPrefijo() + texto));
    }

    // ---------------------------------------------------------------- getters

    public TablaPremios getTabla() {
        return tabla;
    }

    public Cobro getCobro() {
        return cobro;
    }

    public Garantias getGarantias() {
        return garantias;
    }

    public GestorMob getGestorMob() {
        return gestorMob;
    }

    public GestorRuletas getRuletas() {
        return ruletas;
    }

    public NamespacedKey getClaveFuego() {
        return claveFuego;
    }

    /** Números de tiradas permitidos, ordenados (p. ej. [1, 5, 10]). */
    public List<Integer> getMultiples() {
        return multiples;
    }
}
