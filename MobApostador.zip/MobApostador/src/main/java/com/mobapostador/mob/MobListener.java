package com.mobapostador.mob;

import com.mobapostador.MobApostador;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityTransformEvent;
import org.bukkit.event.entity.PlayerLeashEntityEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.event.world.EntitiesUnloadEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/** Clic derecho al mob = apostar. Además lo protege de daño, fuego, transformaciones y correas. */
public final class MobListener implements Listener {

    private final MobApostador plugin;
    private final GestorMob gestor;

    public MobListener(MobApostador plugin, GestorMob gestor) {
        this.plugin = plugin;
        this.gestor = gestor;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void alInteractuar(PlayerInteractEntityEvent e) {
        if (!gestor.esApostador(e.getRightClicked())) {
            return;
        }
        e.setCancelled(true); // sin tradeos, sin name tags, sin nada más
        if (e instanceof PlayerInteractAtEntityEvent || e.getHand() != EquipmentSlot.HAND) {
            return; // evita apostar dos veces con un solo clic
        }
        plugin.abrirMenuOApostar(e.getPlayer());
    }

    /** HIGHEST: se ejecuta al final, así ningún otro plugin le quita la protección al mob. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void alRecibirDanio(EntityDamageEvent e) {
        if (gestor.esApostador(e.getEntity())) {
            if (e.getCause().name().equals("KILL")) {
                return; // deja que un admin lo quite con /kill
            }
            e.setCancelled(true);
            if (e instanceof EntityDamageByEntityEvent porEntidad && porEntidad.getDamager() instanceof Player p) {
                // Pegarle también abre el menú: útil en celular/Bedrock, donde tocar al mob cuenta como golpe
                if (plugin.getConfig().getBoolean("mob.abrir-con-golpe", true)) {
                    plugin.abrirMenuOApostar(p);
                } else {
                    plugin.enviar(p, "info-mob", "{costo}", plugin.getCobro().descripcion());
                }
            }
            return;
        }
        // Los fuegos artificiales de los premios no lastiman a nadie
        if (e instanceof EntityDamageByEntityEvent porEntidad
                && porEntidad.getDamager() instanceof Firework fw
                && fw.getPersistentDataContainer().has(plugin.getClaveFuego(), PersistentDataType.BYTE)) {
            e.setCancelled(true);
        }
    }

    /**
     * Al cargar chunks: registra los apostadores en la caché, les pone/actualiza el holograma
     * (y corrige los de versiones anteriores) y borra hologramas sin dueño.
     * Se hace un tick después para no modificar el mundo mientras el chunk se está cargando.
     */
    @EventHandler
    public void alCargarEntidades(EntitiesLoadEvent e) {
        List<Entity> mobs = new ArrayList<>();
        List<Entity> hologramas = new ArrayList<>();
        for (Entity entidad : e.getEntities()) {
            if (gestor.tieneMarca(entidad)) {
                mobs.add(entidad);
            } else if (gestor.esHolograma(entidad)) {
                hologramas.add(entidad);
            }
        }
        if (mobs.isEmpty() && hologramas.isEmpty()) {
            return;
        }
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (Entity mob : mobs) {
                if (mob.isValid()) {
                    gestor.configurar(mob);
                }
            }
            for (Entity h : hologramas) {
                if (h.isValid() && gestor.esHuerfano(h)) {
                    h.remove();
                }
            }
        });
    }

    /** Al descargar chunks: los saca de la caché (se vuelven a meter cuando el chunk carga otra vez). */
    @EventHandler
    public void alDescargarEntidades(EntitiesUnloadEvent e) {
        for (Entity entidad : e.getEntities()) {
            gestor.olvidar(entidad);
        }
    }

    /** Si un admin lo mata con /kill, se borra también su holograma. */
    @EventHandler
    public void alMorir(EntityDeathEvent e) {
        if (gestor.esApostador(e.getEntity())) {
            e.getDrops().clear();
            gestor.eliminar(e.getEntity());
        }
    }

    @EventHandler
    public void alQuemarse(EntityCombustEvent e) {
        if (gestor.esApostador(e.getEntity())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void alTransformarse(EntityTransformEvent e) {
        if (gestor.esApostador(e.getEntity())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void alAtar(PlayerLeashEntityEvent e) {
        if (gestor.esApostador(e.getEntity())) {
            e.setCancelled(true);
        }
    }
}
