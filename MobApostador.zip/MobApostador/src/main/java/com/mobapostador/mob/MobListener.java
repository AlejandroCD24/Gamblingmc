package com.mobapostador.mob;

import com.mobapostador.MobApostador;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityTransformEvent;
import org.bukkit.event.entity.PlayerLeashEntityEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;

/** Clic derecho al mob = apostar. Además lo protege de daño, fuego, transformaciones y correas. */
public final class MobListener implements Listener {

    private final MobApostador plugin;
    private final GestorMob gestor;

    public MobListener(MobApostador plugin, GestorMob gestor) {
        this.plugin = plugin;
        this.gestor = gestor;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void alInteractuar(PlayerInteractEntityEvent e) {
        if (!gestor.esApostador(e.getRightClicked())) {
            return;
        }
        e.setCancelled(true); // sin tradeos, sin name tags, sin nada más
        if (e instanceof PlayerInteractAtEntityEvent || e.getHand() != EquipmentSlot.HAND) {
            return; // evita apostar dos veces con un solo clic
        }
        plugin.abrirMenuOApostar(e.getPlayer());
    }

    /** HIGHEST: se ejecuta al final, así ningún otro plugin le quita la protección al mob. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void alRecibirDanio(EntityDamageEvent e) {
        if (gestor.esApostador(e.getEntity())) {
            e.setCancelled(true);
            if (e instanceof EntityDamageByEntityEvent porEntidad && porEntidad.getDamager() instanceof Player p) {
                // Pegarle también abre el menú: útil en celular/Bedrock, donde tocar al mob cuenta como golpe
                if (plugin.getConfig().getBoolean("mob.abrir-con-golpe", true)) {
                    plugin.abrirMenuOApostar(p);
                } else {
                    plugin.enviar(p, "info-mob", "{costo}", plugin.getCobro().descripcion());
                }
            }
            return;
        }
        // Los fuegos artificiales de los premios no lastiman a nadie
        if (e instanceof EntityDamageByEntityEvent porEntidad
                && porEntidad.getDamager() instanceof Firework fw
                && fw.getPersistentDataContainer().has(plugin.getClaveFuego(), PersistentDataType.BYTE)) {
            e.setCancelled(true);
        }
    }

    /** Cuando se cargan chunks: corrige apostadores creados con versiones anteriores (invulnerables). */
    @EventHandler
    public void alCargarEntidades(EntitiesLoadEvent e) {
        for (Entity entidad : e.getEntities()) {
            if (gestor.esApostador(entidad) && entidad.isInvulnerable()) {
                gestor.configurar(entidad);
            }
        }
    }

    @EventHandler
    public void alQuemarse(EntityCombustEvent e) {
        if (gestor.esApostador(e.getEntity())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void alTransformarse(EntityTransformEvent e) {
        if (gestor.esApostador(e.getEntity())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void alAtar(PlayerLeashEntityEvent e) {
        if (gestor.esApostador(e.getEntity())) {
            e.setCancelled(true);
        }
    }
}
