package com.mobapostador.mob;

import com.mobapostador.MobApostador;
import com.mobapostador.util.Texto;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.WanderingTrader;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Locale;

/** Crea, reconoce y elimina el mob apostador. */
public final class GestorMob {

    /** Etiqueta de scoreboard: sirve para /kill @e[tag=mob_apostador] o /tp. */
    public static final String TAG = "mob_apostador";

    private final MobApostador plugin;
    private final NamespacedKey clave;

    public GestorMob(MobApostador plugin) {
        this.plugin = plugin;
        this.clave = new NamespacedKey(plugin, "mob_apostador");
    }

    public boolean esApostador(Entity e) {
        return e != null && e.getPersistentDataContainer().has(clave, PersistentDataType.BYTE);
    }

    /** Aparece el mob en el bloque que mira el jugador (o donde está parado), mirando hacia él. */
    public Entity crear(Player p) {
        Location loc = ubicacion(p);
        Entity e = p.getWorld().spawnEntity(loc, tipoConfigurado());
        configurar(e);
        return e;
    }

    private EntityType tipoConfigurado() {
        String nombre = plugin.getConfig().getString("mob.tipo", "WANDERING_TRADER").trim().toLowerCase(Locale.ROOT);
        try {
            EntityType tipo = Registry.ENTITY_TYPE.get(NamespacedKey.minecraft(nombre));
            if (tipo != null && tipo.isAlive() && tipo.isSpawnable()) {
                return tipo;
            }
        } catch (IllegalArgumentException ignored) {
            // nombre con caracteres inválidos
        }
        plugin.getLogger().warning("mob.tipo '" + nombre + "' no es un mob válido. Se usará WANDERING_TRADER.");
        return EntityType.WANDERING_TRADER;
    }

    private Location ubicacion(Player p) {
        Block objetivo = p.getTargetBlockExact(6);
        Location loc = objetivo != null
                ? objetivo.getLocation().add(0.5, 1.0, 0.5)
                : p.getLocation().clone();
        Vector haciaJugador = p.getLocation().toVector().subtract(loc.toVector());
        if (haciaJugador.lengthSquared() > 0.0001) {
            loc.setDirection(haciaJugador);
        }
        loc.setPitch(0f);
        return loc;
    }

    /** Lo deja quieto, inmortal, persistente y con nombre. */
    public void configurar(Entity e) {
        e.getPersistentDataContainer().set(clave, PersistentDataType.BYTE, (byte) 1);
        e.addScoreboardTag(TAG);
        aplicarNombre(e);
        // NO se usa setInvulnerable(true): con eso, los golpes de jugadores en supervivencia ni siquiera
        // generan evento y no se podría abrir el menú pegándole (solo funcionaría en creativo).
        // La protección real está en MobListener, que cancela TODO el daño que reciba.
        e.setInvulnerable(false);
        e.setSilent(plugin.getConfig().getBoolean("mob.silencioso", true));
        e.setPersistent(true);
        if (e instanceof LivingEntity vivo) {
            vivo.setAI(false);
            vivo.setRemoveWhenFarAway(false);
            vivo.setCollidable(false);
            vivo.setCanPickupItems(false);
        }
        if (e instanceof Ageable ageable) {
            ageable.setAdult();
        }
        if (e instanceof WanderingTrader comerciante) {
            comerciante.setDespawnDelay(0); // 0 = nunca se va
        }
    }

    private void aplicarNombre(Entity e) {
        e.setCustomName(Texto.color(plugin.getConfig().getString("mob.nombre", "&6&l✦ El Apostador ✦")));
        e.setCustomNameVisible(true);
    }

    /**
     * Al arrancar o con /apostador recargar: vuelve a aplicar nombre y ajustes a los mobs cargados.
     * También corrige los creados con versiones anteriores del plugin (que eran invulnerables).
     */
    public void refrescarTodos() {
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (esApostador(e)) {
                    configurar(e);
                }
            }
        }
    }

    public Entity masCercano(Player p, double radio) {
        Entity mejor = null;
        double mejorDist = Double.MAX_VALUE;
        for (Entity e : p.getNearbyEntities(radio, radio, radio)) {
            if (!esApostador(e)) {
                continue;
            }
            double d = e.getLocation().distanceSquared(p.getLocation());
            if (d < mejorDist) {
                mejorDist = d;
                mejor = e;
            }
        }
        return mejor;
    }

    /** Elimina todos los mobs apostadores de los chunks cargados. */
    public int eliminarTodos() {
        int n = 0;
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : new ArrayList<>(w.getEntities())) {
                if (esApostador(e)) {
                    e.remove();
                    n++;
                }
            }
        }
        return n;
    }
}
