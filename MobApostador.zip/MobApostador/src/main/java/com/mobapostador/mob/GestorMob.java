package com.mobapostador.mob;

import com.mobapostador.MobApostador;
import com.mobapostador.util.Texto;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.entity.WanderingTrader;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Crea, reconoce y elimina el mob apostador y su holograma con el nombre.
 *
 * Optimización: los UUID de los apostadores cargados se guardan en memoria, así los eventos que se
 * disparan muchísimo (daño, interacción, fuego...) solo hacen una búsqueda en un HashSet.
 */
public final class GestorMob {

    /** Etiqueta de scoreboard: sirve para /kill @e[tag=mob_apostador] o /tp. */
    public static final String TAG = "mob_apostador";
    /** Rango por defecto del motor de Minecraft para entidades "display" (view_range 1.0 = 64 bloques). */
    private static final double BLOQUES_POR_VIEW_RANGE = 64.0;

    private final MobApostador plugin;
    private final NamespacedKey clave;            // marca del mob apostador
    private final NamespacedKey claveHolograma;   // en el mob: UUID de su holograma
    private final NamespacedKey claveDuenio;      // en el holograma: UUID de su mob
    private final Set<UUID> cargados = new HashSet<>();

    public GestorMob(MobApostador plugin) {
        this.plugin = plugin;
        this.clave = new NamespacedKey(plugin, "mob_apostador");
        this.claveHolograma = new NamespacedKey(plugin, "holograma");
        this.claveDuenio = new NamespacedKey(plugin, "holograma_de");
    }

    // ---------------------------------------------------------------- reconocer

    /** Rápido: solo mira la caché en memoria. */
    public boolean esApostador(Entity e) {
        return e != null && cargados.contains(e.getUniqueId());
    }

    /** Lento (lee los datos de la entidad): se usa solo al cargar chunks o al arrancar. */
    boolean tieneMarca(Entity e) {
        return e.getPersistentDataContainer().has(clave, PersistentDataType.BYTE);
    }

    boolean esHolograma(Entity e) {
        return e instanceof TextDisplay && e.getPersistentDataContainer().has(claveDuenio, PersistentDataType.STRING);
    }

    void olvidar(Entity e) {
        cargados.remove(e.getUniqueId());
    }

    // ---------------------------------------------------------------- crear

    /** Aparece el mob en el bloque que mira el jugador (o donde está parado), mirando hacia él. */
    public Entity crear(Player p) {
        Location loc = ubicacion(p);
        Entity e = p.getWorld().spawnEntity(loc, tipoConfigurado());
        configurar(e);
        return e;
    }

    private EntityType tipoConfigurado() {
        String nombre = plugin.getConfig().getString("mob.tipo", "WANDERING_TRADER").trim().toLowerCase(Locale.ROOT);
        try {
            EntityType tipo = Registry.ENTITY_TYPE.get(NamespacedKey.minecraft(nombre));
            if (tipo != null && tipo.isAlive() && tipo.isSpawnable()) {
                return tipo;
            }
        } catch (IllegalArgumentException ignored) {
            // nombre con caracteres inválidos
        }
        plugin.getLogger().warning("mob.tipo '" + nombre + "' no es un mob válido. Se usará WANDERING_TRADER.");
        return EntityType.WANDERING_TRADER;
    }

    private Location ubicacion(Player p) {
        Block objetivo = p.getTargetBlockExact(6);
        Location loc = objetivo != null
                ? objetivo.getLocation().add(0.5, 1.0, 0.5)
                : p.getLocation().clone();
        Vector haciaJugador = p.getLocation().toVector().subtract(loc.toVector());
        if (haciaJugador.lengthSquared() > 0.0001) {
            loc.setDirection(haciaJugador);
        }
        loc.setPitch(0f);
        return loc;
    }

    /** Lo deja quieto, protegido y persistente, y le pone (o actualiza) su holograma. */
    public void configurar(Entity e) {
        e.getPersistentDataContainer().set(clave, PersistentDataType.BYTE, (byte) 1);
        e.addScoreboardTag(TAG);
        // NO se usa setInvulnerable(true): con eso, los golpes de jugadores en supervivencia ni siquiera
        // generan evento y no se podría abrir el menú pegándole (solo funcionaría en creativo).
        // La protección real está en MobListener, que cancela TODO el daño que reciba.
        e.setInvulnerable(false);
        e.setSilent(plugin.getConfig().getBoolean("mob.silencioso", true));
        e.setPersistent(true);
        if (e instanceof LivingEntity vivo) {
            vivo.setAI(false);
            vivo.setRemoveWhenFarAway(false);
            vivo.setCollidable(false);
            vivo.setCanPickupItems(false);
        }
        if (e instanceof Ageable ageable) {
            ageable.setAdult();
        }
        if (e instanceof WanderingTrader comerciante) {
            comerciante.setDespawnDelay(0); // 0 = nunca se va
        }
        // El nombre ya no va en el mob (se veía desde 64 bloques y a través de paredes): va en un holograma
        e.setCustomName(null);
        e.setCustomNameVisible(false);
        cargados.add(e.getUniqueId());
        actualizarHolograma(e);
    }

    // ---------------------------------------------------------------- holograma del nombre

    /**
     * Holograma (TextDisplay) encima del mob. A diferencia del nombre normal de un mob, se puede limitar
     * hasta cuántos bloques se ve (mob.distancia-nombre) y no se ve a través de las paredes.
     */
    private void actualizarHolograma(Entity mob) {
        FileConfiguration cfg = plugin.getConfig();
        double distancia = cfg.getDouble("mob.distancia-nombre", 10.0);
        TextDisplay holograma = buscarHolograma(mob);
        if (distancia <= 0) {
            if (holograma != null) {
                holograma.remove();
            }
            mob.getPersistentDataContainer().remove(claveHolograma);
            return;
        }

        Location loc = mob.getLocation().add(0, mob.getHeight() + 0.25, 0);
        loc.setYaw(0f);
        loc.setPitch(0f);
        if (holograma == null) {
            holograma = mob.getWorld().spawn(loc, TextDisplay.class);
            holograma.getPersistentDataContainer().set(claveDuenio, PersistentDataType.STRING, mob.getUniqueId().toString());
            mob.getPersistentDataContainer().set(claveHolograma, PersistentDataType.STRING, holograma.getUniqueId().toString());
        } else if (holograma.getLocation().distanceSquared(loc) > 0.01) {
            holograma.teleport(loc);
        }

        String texto = Texto.color(cfg.getString("mob.nombre", "&6&l✦ El Apostador ✦"));
        String debajo = cfg.getString("mob.texto-debajo", "&eClic para apostar");
        if (debajo != null && !debajo.isBlank()) {
            texto += "\n" + Texto.color(debajo);
        }
        holograma.setText(texto);
        holograma.setBillboard(Display.Billboard.CENTER);       // siempre mira al jugador
        holograma.setViewRange((float) (distancia / BLOQUES_POR_VIEW_RANGE));
        holograma.setSeeThrough(false);                          // no se ve a través de bloques
        holograma.setShadowed(true);
        holograma.setPersistent(true);
    }

    private TextDisplay buscarHolograma(Entity mob) {
        String id = mob.getPersistentDataContainer().get(claveHolograma, PersistentDataType.STRING);
        if (id == null) {
            return null;
        }
        try {
            Entity e = Bukkit.getEntity(UUID.fromString(id));
            return e instanceof TextDisplay td ? td : null;
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    /** true si el holograma ya no tiene dueño (su mob no existe o tiene otro holograma). */
    boolean esHuerfano(Entity holograma) {
        PersistentDataContainer pdc = holograma.getPersistentDataContainer();
        String duenio = pdc.get(claveDuenio, PersistentDataType.STRING);
        if (duenio == null) {
            return false;
        }
        try {
            Entity mob = Bukkit.getEntity(UUID.fromString(duenio));
            if (mob == null || !tieneMarca(mob)) {
                return true;
            }
            String suyo = mob.getPersistentDataContainer().get(claveHolograma, PersistentDataType.STRING);
            return !holograma.getUniqueId().toString().equals(suyo);
        } catch (IllegalArgumentException ex) {
            return true;
        }
    }

    // ---------------------------------------------------------------- mantenimiento

    /**
     * Al arrancar o con /apostador recargar: vuelve a aplicar ajustes y holograma a los mobs cargados,
     * y borra hologramas que se quedaron sin mob.
     */
    public void refrescarTodos() {
        cargados.clear();
        List<Entity> hologramas = new ArrayList<>();
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (tieneMarca(e)) {
                    configurar(e);
                } else if (esHolograma(e)) {
                    hologramas.add(e);
                }
            }
        }
        for (Entity h : hologramas) {
            if (esHuerfano(h)) {
                h.remove();
            }
        }
    }

    public Entity masCercano(Player p, double radio) {
        Entity mejor = null;
        double mejorDist = Double.MAX_VALUE;
        for (Entity e : p.getNearbyEntities(radio, radio, radio)) {
            if (!esApostador(e)) {
                continue;
            }
            double d = e.getLocation().distanceSquared(p.getLocation());
            if (d < mejorDist) {
                mejorDist = d;
                mejor = e;
            }
        }
        return mejor;
    }

    /** Quita el mob y su holograma. */
    public void eliminar(Entity mob) {
        TextDisplay holograma = buscarHolograma(mob);
        if (holograma != null) {
            holograma.remove();
        }
        cargados.remove(mob.getUniqueId());
        mob.remove();
    }

    /** Elimina todos los mobs apostadores (y sus hologramas) de los chunks cargados. */
    public int eliminarTodos() {
        int n = 0;
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : new ArrayList<>(w.getEntities())) {
                if (tieneMarca(e)) {
                    eliminar(e);
                    n++;
                } else if (esHolograma(e)) {
                    e.remove();
                }
            }
        }
        cargados.clear();
        return n;
    }
}
